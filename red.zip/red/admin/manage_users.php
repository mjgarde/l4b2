<?php
require_once '../config/config.php';
require_once '../config/db.php';
requireAdmin();

$success=$error='';

if($_SERVER['REQUEST_METHOD']==='POST'&&validateCSRF($_POST['csrf_token'])){
    $userId=intval($_POST['user_id']??0);
    try{
        if(isset($_POST['update_status'])){
            $newStatus=sanitize($_POST['status']);
            $user=$db->query("SELECT full_name FROM users WHERE user_id=$userId")->fetch();
            
            $db->prepare("UPDATE users SET status=? WHERE user_id=?")->execute([$newStatus,$userId]);
            
            // Send notification
            try{
                notifyUserStatusChange($db,$userId,$newStatus,$_SESSION['user_id']);
            }catch(Exception $e){
                // If notification fails, still continue
            }
            
            // Log audit
            logAudit($db,$_SESSION['user_id'],'User Status Changed','users',$userId,"Status changed to: $newStatus for ".$user['full_name']);
            
            $success="User status updated and notified";
        }
        elseif(isset($_POST['update_role'])){
            $newRole=sanitize($_POST['user_role']);
            $user=$db->query("SELECT full_name FROM users WHERE user_id=$userId")->fetch();
            
            $db->prepare("UPDATE users SET user_role=? WHERE user_id=?")->execute([$newRole,$userId]);
            
            // Send notification
            createNotification($db,$userId,"Role Updated","Your role is now: ".ucfirst($newRole),'info');
            
            // Log audit
            logAudit($db,$_SESSION['user_id'],'User Role Changed','users',$userId,"Role changed to: $newRole for ".$user['full_name']);
            
            $success="User role updated";
        }
        elseif(isset($_POST['delete_user'])){
            $user=$db->query("SELECT username,full_name FROM users WHERE user_id=$userId")->fetch();
            $db->prepare("DELETE FROM users WHERE user_id=?")->execute([$userId]);
            
            // Log audit
            logAudit($db,$_SESSION['user_id'],'User Deleted','users',$userId,"Deleted user: ".$user['full_name']." (@".$user['username'].")");
            
            $success="User deleted";
        }
    }catch(Exception $e){
        $error="Error: ".$e->getMessage();
    }
}

$statusFilter=$_GET['status']??'';
$roleFilter=$_GET['role']??'';
$searchQuery=$_GET['search']??'';
$where=[];$params=[];
if($statusFilter){$where[]="status=?";$params[]=$statusFilter;}
if($roleFilter){$where[]="user_role=?";$params[]=$roleFilter;}
if($searchQuery){$where[]="(full_name LIKE ? OR username LIKE ? OR email LIKE ?)";$params[]="%$searchQuery%";$params[]="%$searchQuery%";$params[]="%$searchQuery%";}
$whereSQL=$where?'WHERE '.implode(' AND ',$where):'';

$stmt=$db->prepare("SELECT u.*,bt.blood_type,
       di.donor_id,di.date_of_birth,di.gender,di.weight,di.medical_conditions,di.last_donation_date,di.eligible_to_donate,
       (SELECT COUNT(*) FROM donations d WHERE d.donor_id=di.donor_id AND d.status='completed') as donation_count
       FROM users u 
       LEFT JOIN blood_types bt ON u.blood_type_id=bt.blood_type_id 
       LEFT JOIN donors_info di ON u.user_id=di.user_id
       $whereSQL ORDER BY u.created_at DESC");
$stmt->execute($params);
$users=$stmt->fetchAll();

$stats=$db->query("SELECT COUNT(*) as total,SUM(user_role='admin') as admins,SUM(status='active') as active,SUM(DATE(created_at)=CURDATE()) as new_today FROM users")->fetch();

$pageTitle='Manage Users';
include '../includes/admin_header.php';
?>

<style>
.stats-card-3d{background:#fff;border-radius:20px;padding:25px;box-shadow:0 10px 40px rgba(0,0,0,0.1);transition:all 0.4s}
.stats-card-3d:hover{transform:translateY(-10px);box-shadow:0 20px 60px rgba(0,0,0,0.2)}
.stats-icon-3d{width:70px;height:70px;border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:2rem;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;box-shadow:0 10px 30px rgba(102,126,234,0.4);animation:float 3s ease-in-out infinite}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
.stats-number{font-size:2.5rem;font-weight:800;background:linear-gradient(135deg,#667eea,#764ba2);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.card-3d{border-radius:20px;border:none;box-shadow:0 15px 45px rgba(0,0,0,0.1);transition:all 0.4s}
.btn-3d{border-radius:12px;padding:10px 24px;font-weight:600;transition:all 0.3s;border:none;box-shadow:0 5px 15px rgba(0,0,0,0.2)}
.btn-3d:hover{transform:translateY(-3px);box-shadow:0 8px 25px rgba(0,0,0,0.3)}
.table-3d tbody tr{background:#fff;box-shadow:0 5px 15px rgba(0,0,0,0.08);transition:all 0.3s}
.table-3d tbody tr:hover{transform:scale(1.02);box-shadow:0 8px 25px rgba(0,0,0,0.15)}
.table-3d tbody td{padding:20px 15px;border:none;vertical-align:middle}
.user-avatar-3d{width:60px;height:60px;border-radius:50%;background:linear-gradient(135deg,#667eea,#764ba2);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:1.5rem;box-shadow:0 8px 20px rgba(102,126,234,0.4);transition:all 0.3s ease}
.user-avatar-3d:hover{transform:scale(1.1);box-shadow:0 12px 30px rgba(102,126,234,0.6)}
.badge-3d{padding:8px 16px;border-radius:20px;font-weight:600;font-size:0.85rem;box-shadow:0 4px 12px rgba(0,0,0,0.15)}
/* Modal fixes - NO FLICKERING */
.modal-backdrop{background-color:#000!important;opacity:0.5!important}
.modal{background:rgba(0,0,0,0.5)!important}
.modal-content{border-radius:20px;border:none;box-shadow:0 10px 40px rgba(0,0,0,0.5)!important}
.modal-dialog{margin:1.75rem auto!important;max-width:800px}
body.modal-open{overflow:hidden!important}
/* Remove all animations */
.modal,.modal-dialog,.modal-backdrop{transition:none!important;animation:none!important;transform:none!important}
</style>

<div class="container-fluid" style="background:linear-gradient(135deg,#f5f7fa,#c3cfe2);min-height:100vh;padding-bottom:50px">
<div class="row">
<?php include '../includes/admin_sidebar.php';?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

<div style="background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;padding:40px;border-radius:25px;margin-bottom:30px;box-shadow:0 15px 40px rgba(102,126,234,0.3)">
<h1 style="font-weight:800;font-size:2.5rem"><i class="bi bi-people-fill me-3"></i>User Management</h1>
<p class="mb-0 mt-2">Manage system users and permissions</p>
</div>

<?php if($success):?>
<div class="alert alert-success alert-dismissible fade show" style="border-radius:15px;border:none;box-shadow:0 5px 15px rgba(25,135,84,0.3)">
<i class="bi bi-check-circle-fill me-2"></i><?=$success?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif;if($error):?>
<div class="alert alert-danger alert-dismissible fade show" style="border-radius:15px;border:none;box-shadow:0 5px 15px rgba(220,53,69,0.3)">
<i class="bi bi-exclamation-triangle-fill me-2"></i><?=$error?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif;?>

<div class="row mb-4">
<div class="col-lg-3 col-md-6 mb-3"><div class="stats-card-3d"><div class="d-flex align-items-center">
<div class="stats-icon-3d me-3"><i class="bi bi-people-fill"></i></div>
<div><div class="stats-number"><?=number_format($stats['total'])?></div>
<small class="text-muted" style="font-weight:600">Total Users</small></div></div></div></div>

<div class="col-lg-3 col-md-6 mb-3"><div class="stats-card-3d"><div class="d-flex align-items-center">
<div class="stats-icon-3d me-3" style="background:linear-gradient(135deg,#0cebeb,#29ffc6)"><i class="bi bi-check-circle-fill"></i></div>
<div><div class="stats-number" style="background:linear-gradient(135deg,#0cebeb,#29ffc6);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><?=number_format($stats['active'])?></div>
<small class="text-muted" style="font-weight:600">Active</small></div></div></div></div>

<div class="col-lg-3 col-md-6 mb-3"><div class="stats-card-3d"><div class="d-flex align-items-center">
<div class="stats-icon-3d me-3" style="background:linear-gradient(135deg,#f093fb,#f5576c)"><i class="bi bi-shield-fill-check"></i></div>
<div><div class="stats-number" style="background:linear-gradient(135deg,#f093fb,#f5576c);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><?=number_format($stats['admins'])?></div>
<small class="text-muted" style="font-weight:600">Admins</small></div></div></div></div>

<div class="col-lg-3 col-md-6 mb-3"><div class="stats-card-3d"><div class="d-flex align-items-center">
<div class="stats-icon-3d me-3" style="background:linear-gradient(135deg,#fa709a,#fee140)"><i class="bi bi-person-plus-fill"></i></div>
<div><div class="stats-number" style="background:linear-gradient(135deg,#fa709a,#fee140);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><?=number_format($stats['new_today'])?></div>
<small class="text-muted" style="font-weight:600">New Today</small></div></div></div></div>
</div>

<div style="background:#fff;border-radius:20px;padding:25px;box-shadow:0 10px 30px rgba(0,0,0,0.1);margin-bottom:30px">
<h5 class="mb-3" style="font-weight:700"><i class="bi bi-funnel-fill me-2" style="color:#667eea"></i>Search & Filters</h5>
<form method="GET" class="row g-3">
<div class="col-md-4"><input type="text" name="search" class="form-control" placeholder="🔍 Search users..." value="<?=htmlspecialchars($searchQuery)?>" style="border-radius:12px"></div>
<div class="col-md-3">
<select name="status" class="form-select" style="border-radius:12px">
<option value="">All Status</option>
<option value="active" <?=$statusFilter=='active'?'selected':''?>>Active</option>
<option value="inactive" <?=$statusFilter=='inactive'?'selected':''?>>Inactive</option>
<option value="suspended" <?=$statusFilter=='suspended'?'selected':''?>>Suspended</option>
</select>
</div>
<div class="col-md-3">
<select name="role" class="form-select" style="border-radius:12px">
<option value="">All Roles</option>
<option value="admin" <?=$roleFilter=='admin'?'selected':''?>>Admin</option>
<option value="user" <?=$roleFilter=='user'?'selected':''?>>User</option>
</select>
</div>
<div class="col-md-2">
<button type="submit" class="btn btn-3d w-100" style="background:linear-gradient(135deg,#667eea,#764ba2);color:#fff"><i class="bi bi-search me-1"></i>Search</button>
</div>
</form>
</div>

<div class="card-3d">
<div style="background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;padding:20px;border-radius:20px 20px 0 0">
<h5 class="mb-0" style="font-weight:700"><i class="bi bi-list-ul me-2"></i>Users List (<?=count($users)?>)</h5>
</div>
<div class="card-body p-0">
<?php if(count($users)>0):?>
<div class="table-responsive">
<table class="table table-3d mb-0">
<thead><tr><th>User</th><th>Contact</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
<tbody>
<?php foreach($users as $u):?>
<tr>
<td><div class="d-flex align-items-center">
<div class="user-avatar-3d me-3"><?=strtoupper(substr($u['full_name'],0,2))?></div>
<div><strong style="font-size:1.1rem"><?=htmlspecialchars($u['full_name'])?></strong>
<?php if($u['donor_id']):?><span class="badge badge-3d bg-danger ms-2" style="font-size:0.7rem" title="Registered Donor"><i class="bi bi-heart-pulse-fill"></i> Donor</span><?php endif;?>
<br>
<small class="text-muted">@<?=htmlspecialchars($u['username'])?></small></div></div></td>
<td><small><i class="bi bi-envelope me-1"></i><?=htmlspecialchars($u['email'])?></small><br>
<small><i class="bi bi-telephone me-1"></i><?=htmlspecialchars($u['phone'])?:'N/A'?></small></td>
<td><span class="badge-3d <?=$u['user_role']=='admin'?'bg-danger':'bg-primary'?>"><?=ucfirst($u['user_role'])?></span></td>
<td><span class="badge-3d <?=['active'=>'bg-success','pending'=>'bg-warning','inactive'=>'bg-secondary','suspended'=>'bg-danger'][$u['status']] ?? 'bg-secondary'?>"><?=ucfirst($u['status'])?></span></td>
<td>
<div class="btn-group">
<a href="view_user_profile.php?id=<?=$u['user_id']?>" class="btn btn-sm btn-primary" style="border-radius:10px 0 0 10px" title="View Profile">
<i class="bi bi-eye"></i>
</a>
<a href="edit_user.php?id=<?=$u['user_id']?>" class="btn btn-sm btn-success" style="border-radius:0 10px 10px 0" title="Edit User">
<i class="bi bi-pencil"></i>
</a>
</div>

<!-- Modals removed - now using separate pages for view and edit -->

</td>
</tr>
<?php endforeach;?>
</tbody>
</table>
</div>
<?php else:?>
<div class="text-center py-5">
<i class="bi bi-people" style="font-size:5rem;color:#ddd"></i>
<h4 class="mt-3 text-muted">No Users Found</h4>
</div>
<?php endif;?>
</div>
</div>

</main>
</div>
</div>

<!-- Modals and JavaScript removed - user profile now opens in separate page (view_user_profile.php) -->

<?php include '../includes/footer.php';?>
