<?php
/**
 * User Approvals Page - Admin Only
 * Manage pending user registrations
 */

require_once '../config/config.php';
require_once '../config/db.php';
require_once 'sms_functions.php';

// Check admin authentication
requireAdmin();

$success = '';
$error = '';

// Handle approval/rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        $userId = intval($_POST['user_id']);
        $action = $_POST['action'];
        
        try {
            if ($action === 'approve') {
                // Approve user
                $sql = "UPDATE users SET status = 'active' WHERE user_id = :user_id AND status = 'pending'";
                $stmt = $db->prepare($sql);
                $result = $stmt->execute([':user_id' => $userId]);
                
                if ($result && $stmt->rowCount() > 0) {
                    // Get user details
                    $userSql = "SELECT username, full_name, email, phone FROM users WHERE user_id = :user_id";
                    $userStmt = $db->prepare($userSql);
                    $userStmt->execute([':user_id' => $userId]);
                    $user = $userStmt->fetch();
                    
                    // Notify user
                    createNotification(
                        $db,
                        $userId,
                        'Account Approved!',
                        'Congratulations! Your account has been approved by the administrator. You can now log in and access all features.',
                        'success'
                    );
                    
                    // Send SMS notification if phone number exists
                    if (!empty($user['phone'])) {
                        $smsResult = sendApprovalSMS($user['phone'], $user['full_name']);
                        if ($smsResult['success']) {
                            error_log("SMS sent successfully to {$user['phone']}: {$smsResult['message']}");
                        } else {
                            error_log("SMS failed to {$user['phone']}: {$smsResult['message']}");
                        }
                    }
                    
                    // Log audit
                    logAudit($db, $_SESSION['user_id'], 'User Approval', 'users', $userId, "Approved user: {$user['username']}");
                    
                    $success = "User {$user['full_name']} has been approved successfully!";
                } else {
                    $error = 'User not found or already processed';
                }
            } elseif ($action === 'reject') {
                // Reject user (mark as inactive or delete)
                $reason = sanitize($_POST['reason'] ?? 'No reason provided');
                
                // Get user details first
                $userSql = "SELECT username, full_name, phone FROM users WHERE user_id = :user_id";
                $userStmt = $db->prepare($userSql);
                $userStmt->execute([':user_id' => $userId]);
                $user = $userStmt->fetch();
                
                // Notify user before rejection
                createNotification(
                    $db,
                    $userId,
                    'Account Registration Rejected',
                    "We regret to inform you that your account registration has been rejected. Reason: $reason. If you believe this is an error, please contact us.",
                    'error'
                );
                
                // Send SMS notification if phone number exists
                if (!empty($user['phone'])) {
                    $smsResult = sendRejectionSMS($user['phone'], $user['full_name'], $reason);
                    if ($smsResult['success']) {
                        error_log("Rejection SMS sent successfully to {$user['phone']}: {$smsResult['message']}");
                    } else {
                        error_log("Rejection SMS failed to {$user['phone']}: {$smsResult['message']}");
                    }
                }
                
                // Mark as inactive instead of deleting
                $sql = "UPDATE users SET status = 'inactive' WHERE user_id = :user_id AND status = 'pending'";
                $stmt = $db->prepare($sql);
                $result = $stmt->execute([':user_id' => $userId]);
                
                if ($result && $stmt->rowCount() > 0) {
                    // Log audit
                    logAudit($db, $_SESSION['user_id'], 'User Rejection', 'users', $userId, "Rejected user: {$user['username']} - Reason: $reason");
                    
                    $success = "User {$user['full_name']} has been rejected.";
                } else {
                    $error = 'User not found or already processed';
                }
            }
        } catch(PDOException $e) {
            $error = 'An error occurred. Please try again.';
            error_log("User approval error: " . $e->getMessage());
        }
    }
}

// Get pending users with donor information
try {
    $sql = "SELECT u.*, bt.blood_type,
            di.donor_id, di.date_of_birth, di.gender, di.weight, di.medical_conditions, di.eligible_to_donate,
            DATE_FORMAT(u.created_at, '%M %d, %Y %h:%i %p') as registration_date
            FROM users u
            LEFT JOIN blood_types bt ON u.blood_type_id = bt.blood_type_id
            LEFT JOIN donors_info di ON u.user_id = di.user_id
            WHERE u.status = 'pending' AND u.user_role = 'user'
            ORDER BY u.created_at DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $pendingUsers = $stmt->fetchAll();
    
    // Get uploaded documents for each user
    foreach ($pendingUsers as &$user) {
        $docSql = "SELECT * FROM user_documents WHERE user_id = :user_id ORDER BY document_type";
        $docStmt = $db->prepare($docSql);
        $docStmt->execute([':user_id' => $user['user_id']]);
        $user['documents'] = $docStmt->fetchAll();
    }
} catch(PDOException $e) {
    $pendingUsers = [];
    error_log("Fetch pending users error: " . $e->getMessage());
}

// Get statistics
try {
    $statsSql = "SELECT 
                    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count,
                    COUNT(CASE WHEN status = 'active' THEN 1 END) as active_count,
                    COUNT(CASE WHEN status = 'inactive' THEN 1 END) as rejected_count
                 FROM users WHERE user_role = 'user'";
    $statsStmt = $db->prepare($statsSql);
    $statsStmt->execute();
    $stats = $statsStmt->fetch();
} catch(PDOException $e) {
    $stats = ['pending_count' => 0, 'active_count' => 0, 'rejected_count' => 0];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Approvals - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .approval-card-modern{background:#fff;border-radius:15px;padding:25px;box-shadow:0 3px 15px rgba(0,0,0,0.08);transition:all 0.3s;border:1px solid #e9ecef;margin-bottom:20px;border-left:4px solid #dc3545}
        .approval-card-modern:hover{transform:translateY(-3px);box-shadow:0 8px 25px rgba(0,0,0,0.12)}
        .stats-card-modern{background:#fff;border-radius:15px;padding:25px;box-shadow:0 3px 15px rgba(0,0,0,0.08);transition:all 0.3s;border:1px solid #e9ecef}
        .stats-card-modern:hover{transform:translateY(-5px);box-shadow:0 8px 25px rgba(0,0,0,0.12)}
        .stats-icon-modern{width:60px;height:60px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.8rem;color:#fff;margin-bottom:15px}
        .stats-number-modern{font-size:2.5rem;font-weight:700;color:#2c3e50;margin-bottom:5px}
        .stats-label{color:#6c757d;font-size:0.9rem;font-weight:500;text-transform:uppercase;letter-spacing:0.5px}
        .icon-pending{background:#ffc107}
        .icon-approved{background:#28a745}
        .icon-rejected{background:#dc3545}
        .page-header-modern{background:#fff;border-radius:20px;padding:35px 40px;margin-bottom:30px;box-shadow:0 5px 20px rgba(0,0,0,0.08);border-left:5px solid #dc3545}
        .page-header-modern h1{color:#2c3e50;font-size:2rem;margin-bottom:8px}
        .page-header-modern p{color:#6c757d;font-size:1rem;margin-bottom:0}
        .user-avatar-modern{width:70px;height:70px;border-radius:50%;background:#dc3545;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:600;font-size:1.5rem;transition:all 0.3s}
        .user-avatar-modern:hover{transform:scale(1.05)}
        .btn-modern{border-radius:8px;padding:10px 24px;font-weight:600;transition:all 0.2s;border:none}
        .btn-modern:hover{transform:translateY(-2px)}
        .btn-approve-modern{background:#28a745;color:#fff}
        .btn-approve-modern:hover{background:#218838;box-shadow:0 4px 12px rgba(40,167,69,0.3)}
        .btn-reject-modern{background:#dc3545;color:#fff}
        .btn-reject-modern:hover{background:#c82333;box-shadow:0 4px 12px rgba(220,53,69,0.3)}
        .info-box-medical{background:linear-gradient(135deg,#fff5e6,#ffe0b2);padding:20px;border-radius:15px;margin:15px 0;box-shadow:0 5px 15px rgba(255,193,7,0.2);border-left:4px solid #ff9800}
        .badge-donor{background:linear-gradient(135deg,#f093fb,#f5576c);color:#fff;padding:8px 16px;border-radius:20px;font-weight:600;box-shadow:0 4px 12px rgba(245,87,108,0.4)}
        /* Body and Layout Fixes */
        body{padding-top:60px!important}
        .navbar.sticky-top{position:fixed!important;top:0!important;left:0!important;right:0!important;z-index:1030!important}
        main.col-md-9{margin-top:0!important;padding-top:20px!important}
        /* Modal styles - NO DARK BACKDROP */
        .modal-backdrop{display:none!important}
        .modal{background-color:transparent!important;margin-top:70px!important}
        .modal-content{border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,0.5);border:2px solid #ddd}
        .modal-footer{background:white}
        .modal-footer .btn, .modal-footer button{cursor:pointer;position:relative;z-index:1}
        @keyframes modalFadeIn{from{opacity:0;transform:scale(0.9)}to{opacity:1;transform:scale(1)}}
    </style>
</head>
<body class="bg-light">
    <?php include '../includes/admin_header.php'; ?>

   
    <div class="container-fluid">
        <div class="row">
            
 <?php include '../includes/admin_sidebar.php'; ?>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <!-- Page Header -->
                <div class="page-header-modern">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h1><i class="bi bi-person-check-fill me-2"></i>User Approvals</h1>
                            <p>Review and approve/decline pending user registrations</p>
                        </div>
                    </div>
                </div>

                <!-- Alerts -->
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="bi bi-check-circle-fill me-2"></i><?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-md-4 mb-3">
                        <div class="stats-card-modern text-center">
                            <div class="stats-icon-modern icon-pending mx-auto"><i class="bi bi-clock-fill"></i></div>
                            <div class="stats-number-modern"><?php echo $stats['pending_count']; ?></div>
                            <div class="stats-label">Pending Approvals</div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="stats-card-modern text-center">
                            <div class="stats-icon-modern icon-approved mx-auto"><i class="bi bi-check-circle-fill"></i></div>
                            <div class="stats-number-modern"><?php echo $stats['active_count']; ?></div>
                            <div class="stats-label">Approved Users</div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="stats-card-modern text-center">
                            <div class="stats-icon-modern icon-rejected mx-auto"><i class="bi bi-x-circle-fill"></i></div>
                            <div class="stats-number-modern"><?php echo $stats['rejected_count']; ?></div>
                            <div class="stats-label">Rejected Users</div>
                        </div>
                    </div>
                </div>

                <!-- Pending Users List -->
                <div class="card border-0 shadow-sm" style="border-radius: 1.5rem;">
                    <div class="card-header bg-white border-0 pt-4 px-4">
                        <h5 class="fw-bold mb-0">
                            <i class="bi bi-people text-warning me-2"></i>Pending User Registrations
                        </h5>
                    </div>
                    <div class="card-body p-4">
                        <?php if (empty($pendingUsers)): ?>
                            <div class="text-center py-5">
                                <i class="bi bi-check-circle text-success" style="font-size: 4rem; opacity: 0.3;"></i>
                                <h4 class="mt-3 text-muted">No Pending Approvals</h4>
                                <p class="text-muted">All user registrations have been processed!</p>
                            </div>
                        <?php else: ?>
                            <div class="row g-4">
                                <?php foreach ($pendingUsers as $user): ?>
                                    <div class="col-md-6">
                                        <div class="approval-card-modern h-100">
                                            <div class="d-flex align-items-start mb-4">
                                                <div class="user-avatar-modern me-3"><?=strtoupper(substr($user['full_name'],0,2))?></div>
                                                <div class="flex-grow-1">
                                                    <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($user['full_name']); ?>
                                                    <?php if($user['donor_id']):?><span class="badge bg-danger ms-2"><i class="bi bi-heart-pulse-fill me-1"></i>Donor</span><?php endif;?>
                                                    </h5>
                                                    <p class="text-muted mb-0 small">@<?php echo htmlspecialchars($user['username']); ?></p>
                                                </div>
                                                <span class="badge bg-warning text-dark">
                                                    <i class="bi bi-clock me-1"></i>Pending
                                                </span>
                                            </div>

                                                <div class="mb-3">
                                                    <div class="d-flex align-items-center mb-2">
                                                        <i class="bi bi-envelope text-danger me-2"></i>
                                                        <small class="text-muted"><?php echo htmlspecialchars($user['email']); ?></small>
                                                    </div>
                                                    <?php if ($user['phone']): ?>
                                                        <div class="d-flex align-items-center mb-2">
                                                            <i class="bi bi-telephone text-danger me-2"></i>
                                                            <small class="text-muted"><?php echo htmlspecialchars($user['phone']); ?></small>
                                                        </div>
                                                    <?php endif; ?>
                                                    <?php if ($user['blood_type']): ?>
                                                        <div class="d-flex align-items-center mb-2">
                                                            <i class="bi bi-droplet text-danger me-2"></i>
                                                            <small class="text-muted">Blood Type: <strong><?php echo $user['blood_type']; ?></strong></small>
                                                        </div>
                                                    <?php endif; ?>
                                                    <?php if ($user['address']): ?>
                                                        <div class="d-flex align-items-start mb-2">
                                                            <i class="bi bi-geo-alt text-danger me-2 mt-1"></i>
                                                            <small class="text-muted"><?php echo htmlspecialchars($user['address']); ?></small>
                                                        </div>
                                                    <?php endif; ?>
                                                    <div class="d-flex align-items-center">
                                                        <i class="bi bi-calendar text-danger me-2"></i>
                                                        <small class="text-muted">Registered: <?php echo $user['registration_date']; ?></small>
                                                    </div>
                                                </div>

                                                <!-- Donor Medical Information -->
                                                <?php if($user['donor_id']):?>
                                                <div class="info-box-medical mb-3">
                                                    <h6 class="fw-bold mb-3"><i class="bi bi-heart-pulse-fill me-2"></i>Donor Medical Information</h6>
                                                    <div class="row g-2">
                                                        <div class="col-6"><small><strong><i class="bi bi-calendar3 me-1"></i>Birth:</strong> <?=$user['date_of_birth']?date('M j, Y',strtotime($user['date_of_birth'])):'N/A'?></small></div>
                                                        <div class="col-6"><small><strong><i class="bi bi-gender-ambiguous me-1"></i>Gender:</strong> <?=htmlspecialchars($user['gender'])?:'N/A'?></small></div>
                                                        <div class="col-6"><small><strong><i class="bi bi-speedometer me-1"></i>Weight:</strong> <?=$user['weight']?$user['weight'].' kg':'N/A'?></small></div>
                                                        <div class="col-6"><small><strong><i class="bi bi-droplet-fill me-1"></i>Blood:</strong> <?=$user['blood_type']?:'N/A'?></small></div>
                                                    </div>
                                                    <?php if($user['medical_conditions']):?>
                                                    <div class="mt-3" style="background:#fff;padding:10px;border-radius:8px;border-left:3px solid #dc3545">
                                                        <strong><i class="bi bi-clipboard2-pulse-fill me-1"></i>Medical Conditions:</strong>
                                                        <p class="mb-0 mt-1" style="font-size:0.9rem"><?=nl2br(htmlspecialchars($user['medical_conditions']))?></p>
                                                    </div>
                                                    <?php else:?>
                                                    <div class="mt-3" style="background:#d1f4dd;padding:10px;border-radius:8px">
                                                        <small><i class="bi bi-check-circle-fill text-success me-1"></i><strong>No medical conditions reported</strong></small>
                                                    </div>
                                                    <?php endif;?>
                                                </div>
                                                <?php endif;?>

                                                <!-- Uploaded Documents -->
                                                <?php if (!empty($user['documents'])): ?>
                                                    <div class="card mb-3" style="background: #f8f9fa; border-radius: 0.75rem; border: 2px dashed #17a2b8;">
                                                        <div class="card-body p-3">
                                                            <h6 class="fw-bold mb-3">
                                                                <i class="bi bi-file-earmark-check text-info me-2"></i>Uploaded Documents
                                                            </h6>
                                                            <div class="row g-2">
                                                                <?php foreach ($user['documents'] as $doc): ?>
                                                                    <div class="col-12">
                                                                        <div class="d-flex align-items-center justify-content-between p-2" 
                                                                             style="background: white; border-radius: 0.5rem; border: 1px solid #dee2e6;">
                                                                            <div class="d-flex align-items-center">
                                                                                <?php if ($doc['document_type'] === 'medical_certificate'): ?>
                                                                                    <i class="bi bi-file-earmark-medical text-danger me-2" style="font-size: 1.5rem;"></i>
                                                                                <?php else: ?>
                                                                                    <i class="bi bi-card-image text-primary me-2" style="font-size: 1.5rem;"></i>
                                                                                <?php endif; ?>
                                                                                <div>
                                                                                    <small class="fw-bold d-block">
                                                                                        <?php echo $doc['document_type'] === 'medical_certificate' ? 'Medical Certificate' : 'Photo ID'; ?>
                                                                                    </small>
                                                                                    <small class="text-muted"><?php echo number_format($doc['file_size'] / 1024, 2); ?> KB</small>
                                                                                </div>
                                                                            </div>
                                                                            <?php 
                                                                            $fileExt = strtolower(pathinfo($doc['file_path'], PATHINFO_EXTENSION));
                                                                            $isImage = in_array($fileExt, ['jpg', 'jpeg', 'png', 'gif', 'webp']);
                                                                            
                                                                            if ($isImage): ?>
                                                                                <button type="button" 
                                                                                        class="btn btn-sm btn-outline-info view-document-btn" 
                                                                                        style="border-radius: 50px;"
                                                                                        data-file-path="../<?php echo htmlspecialchars($doc['file_path']); ?>"
                                                                                        data-file-name="<?php echo htmlspecialchars($doc['document_type'] === 'medical_certificate' ? 'Medical Certificate' : 'Photo ID'); ?>">
                                                                                    <i class="bi bi-eye me-1"></i>View
                                                                                </button>
                                                                            <?php else: ?>
                                                                                <a href="../<?php echo htmlspecialchars($doc['file_path']); ?>" 
                                                                                   target="_blank" 
                                                                                   class="btn btn-sm btn-outline-info" 
                                                                                   style="border-radius: 50px;">
                                                                                    <i class="bi bi-eye me-1"></i>View
                                                                                </a>
                                                                            <?php endif; ?>
                                                                        
                                                                        </div>
                                                                    </div>
                                                                <?php endforeach; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="alert alert-warning mb-3" style="border-radius: 0.75rem;">
                                                        <i class="bi bi-exclamation-triangle me-2"></i>
                                                        <small>No documents uploaded</small>
                                                    </div>
                                                <?php endif; ?>

                                                <div class="d-flex gap-2 mt-4">
                                                    <form method="POST" class="flex-fill" onsubmit="return confirm('✅ Approve this user registration?');">
                                                        <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">
                                                        <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                                        <input type="hidden" name="action" value="approve">
                                                        <button type="submit" class="btn btn-modern btn-approve-modern w-100">
                                                            <i class="bi bi-check-circle-fill me-2"></i>Approve
                                                        </button>
                                                    </form>
                                                    <button type="button" class="btn btn-modern btn-reject-modern" 
                                                            data-bs-toggle="modal" data-bs-target="#rejectModal<?php echo $user['user_id']; ?>">
                                                        <i class="bi bi-x-circle-fill me-2"></i>Decline
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Reject Modal -->
                                    <div class="modal fade" id="rejectModal<?php echo $user['user_id']; ?>" tabindex="-1">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content" style="border-radius: 1.5rem;">
                                                <div class="modal-header border-0">
                                                    <h5 class="modal-title fw-bold">Reject User Registration</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <form method="POST">
                                                    <div class="modal-body">
                                                        <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">
                                                        <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                                        <input type="hidden" name="action" value="reject">
                                                        
                                                        <p class="text-muted">You are about to reject the registration of:</p>
                                                        <div class="alert alert-warning">
                                                            <strong><?php echo htmlspecialchars($user['full_name']); ?></strong><br>
                                                            <small><?php echo htmlspecialchars($user['email']); ?></small>
                                                        </div>
                                                        
                                                        <div class="mb-3">
                                                            <label for="reason<?php echo $user['user_id']; ?>" class="form-label">Reason for Rejection</label>
                                                            <textarea class="form-control" id="reason<?php echo $user['user_id']; ?>" 
                                                                      name="reason" rows="3" placeholder="Provide a reason for rejection (optional)"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer border-0">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-danger">
                                                            <i class="bi bi-x-lg me-2"></i>Confirm Rejection
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Image Preview Modal -->
    <div class="modal fade" id="imagePreviewModal" tabindex="-1" aria-labelledby="imagePreviewModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content" style="border-radius: 1.5rem; border: none; overflow: hidden;">
                <div class="modal-header" style="background: linear-gradient(135deg, #17a2b8, #138496); color: white; border: none;">
                    <h5 class="modal-title fw-bold" id="imagePreviewModalLabel">
                        <i class="bi bi-image me-2"></i>Document Preview
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center p-4" style="background: #f8f9fa;">
                    <div id="imageLoadingSpinner" class="text-center py-5">
                        <div class="spinner-border text-info" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <p class="mt-3 text-muted">Loading image...</p>
                    </div>
                    <img id="previewImage" src="" alt="Document Preview" 
                         style="max-width: 100%; height: auto; border-radius: 1rem; box-shadow: 0 10px 40px rgba(0,0,0,0.2); display: none;">
                </div>
                <div class="modal-footer border-0" style="background: #f8f9fa;">
                    <a id="downloadImageLink" href="" download class="btn btn-sm btn-info" style="border-radius: 50px;">
                        <i class="bi bi-download me-1"></i>Download
                    </a>
                    <a id="openNewTabLink" href="" target="_blank" class="btn btn-sm btn-outline-info" style="border-radius: 50px;">
                        <i class="bi bi-box-arrow-up-right me-1"></i>Open in New Tab
                    </a>
                    <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal" style="border-radius: 50px;">
                        <i class="bi bi-x-lg me-1"></i>Close
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-hide alerts after 5 seconds
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);

        // Image preview functionality
        document.addEventListener('DOMContentLoaded', function() {
            const imageModal = new bootstrap.Modal(document.getElementById('imagePreviewModal'));
            const previewImage = document.getElementById('previewImage');
            const modalTitle = document.getElementById('imagePreviewModalLabel');
            const downloadLink = document.getElementById('downloadImageLink');
            const openNewTabLink = document.getElementById('openNewTabLink');
            const loadingSpinner = document.getElementById('imageLoadingSpinner');

            // Handle view document button clicks
            document.querySelectorAll('.view-document-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const filePath = this.getAttribute('data-file-path');
                    const fileName = this.getAttribute('data-file-name');
                    
                    // Update modal title
                    modalTitle.innerHTML = '<i class="bi bi-image me-2"></i>' + fileName;
                    
                    // Show loading spinner
                    loadingSpinner.style.display = 'block';
                    previewImage.style.display = 'none';
                    
                    // Set image source
                    previewImage.src = filePath;
                    
                    // Set download and open links
                    downloadLink.href = filePath;
                    openNewTabLink.href = filePath;
                    
                    // Show modal
                    imageModal.show();
                });
            });

            // Handle image load event
            previewImage.addEventListener('load', function() {
                loadingSpinner.style.display = 'none';
                previewImage.style.display = 'block';
            });

            // Handle image error event
            previewImage.addEventListener('error', function() {
                loadingSpinner.innerHTML = '<i class="bi bi-exclamation-triangle text-warning" style="font-size: 3rem;"></i><p class="mt-3 text-muted">Failed to load image</p>';
            });

        });
    </script>
</body>
</html>
