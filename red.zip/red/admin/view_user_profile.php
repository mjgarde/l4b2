<?php
require_once '../config/config.php';
require_once '../config/db.php';

// Check if admin is logged in
requireAdmin();

// Get user_id from URL
$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($user_id == 0) {
    header('Location: manage_users.php');
    exit;
}

// Get user information with blood type and donation count
$sql = "SELECT u.*, bt.blood_type, di.donor_id, di.date_of_birth, di.gender, di.weight, 
               di.medical_conditions, di.eligible_to_donate, di.last_donation_date,
               (SELECT COUNT(*) FROM donations d WHERE d.donor_id = di.donor_id AND d.status = 'completed') as donation_count
        FROM users u
        LEFT JOIN blood_types bt ON u.blood_type_id = bt.blood_type_id
        LEFT JOIN donors_info di ON u.user_id = di.user_id
        WHERE u.user_id = :user_id";
$stmt = $db->prepare($sql);
$stmt->execute([':user_id' => $user_id]);
$user = $stmt->fetch();

if (!$user) {
    header('Location: manage_users.php');
    exit;
}

// Get user documents
$docSql = "SELECT * FROM user_documents WHERE user_id = :user_id ORDER BY document_type";
$docStmt = $db->prepare($docSql);
$docStmt->execute([':user_id' => $user_id]);
$documents = $docStmt->fetchAll();

$pageTitle = "User Profile - " . htmlspecialchars($user['full_name']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body { background: #f0f2f5; padding-top: 70px; }
        .profile-header { background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 40px; border-radius: 15px; margin-bottom: 30px; }
        .profile-avatar { width: 120px; height: 120px; border-radius: 50%; background: white; color: #667eea; display: flex; align-items: center; justify-content: center; font-size: 3rem; font-weight: bold; margin: 0 auto 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); }
        .info-card { background: white; border-radius: 15px; padding: 25px; margin-bottom: 20px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
        .info-card h5 { color: #667eea; margin-bottom: 20px; font-weight: 600; }
        .info-row { display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #f0f0f0; }
        .info-row:last-child { border-bottom: none; }
        .info-label { font-weight: 600; color: #666; }
        .info-value { color: #333; }
        .doc-card { background: #f8f9fa; border: 2px solid #e9ecef; border-radius: 12px; padding: 20px; margin-bottom: 15px; transition: all 0.3s; }
        .doc-card:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .doc-icon { font-size: 3rem; margin-bottom: 15px; }
        .btn-back { background: white; color: #667eea; border: 2px solid white; }
        .btn-back:hover { background: transparent; color: white; }
    </style>
</head>
<body>
    <?php include '../includes/admin_header.php'; ?>

    <div class="container">
        <!-- Back Button -->
        <a href="manage_users.php" class="btn btn-secondary mb-3">
            <i class="bi bi-arrow-left"></i> Back to User Management
        </a>

        <!-- Profile Header -->
        <div class="profile-header text-center">
            <div class="profile-avatar">
                <?php echo strtoupper(substr($user['full_name'], 0, 2)); ?>
            </div>
            <h2 class="mb-2"><?php echo htmlspecialchars($user['full_name']); ?></h2>
            <p class="mb-0">@<?php echo htmlspecialchars($user['username']); ?></p>
            <div class="mt-3">
                <span class="badge bg-<?php echo $user['user_role'] == 'admin' ? 'danger' : 'light'; ?> px-4 py-2">
                    <?php echo ucfirst($user['user_role']); ?>
                </span>
                <span class="badge bg-<?php echo ['active'=>'success','inactive'=>'secondary','suspended'=>'danger'][$user['status']]; ?> px-4 py-2">
                    <?php echo ucfirst($user['status']); ?>
                </span>
            </div>
        </div>

        <div class="row">
            <!-- Left Column: Basic Info -->
            <div class="col-md-6">
                <div class="info-card">
                    <h5><i class="bi bi-person-circle me-2"></i>Basic Information</h5>
                    <div class="info-row">
                        <span class="info-label">Username:</span>
                        <span class="info-value">@<?php echo htmlspecialchars($user['username']); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Email:</span>
                        <span class="info-value"><?php echo htmlspecialchars($user['email']); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Phone:</span>
                        <span class="info-value"><?php echo htmlspecialchars($user['phone']) ?: 'N/A'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Blood Type:</span>
                        <span class="info-value"><?php echo $user['blood_type'] ?: 'Not specified'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Joined:</span>
                        <span class="info-value"><?php echo date('F j, Y', strtotime($user['created_at'])); ?></span>
                    </div>
                    <?php if ($user['address']): ?>
                    <div class="info-row">
                        <span class="info-label">Address:</span>
                        <span class="info-value"><?php echo nl2br(htmlspecialchars($user['address'])); ?></span>
                    </div>
                    <?php endif; ?>
                </div>

                <?php if ($user['donor_id']): ?>
                <!-- Donor Medical Info -->
                <div class="info-card">
                    <h5><i class="bi bi-heart-pulse-fill me-2"></i>Donor Medical Information</h5>
                    <div class="info-row">
                        <span class="info-label">Date of Birth:</span>
                        <span class="info-value"><?php echo $user['date_of_birth'] ? date('F j, Y', strtotime($user['date_of_birth'])) : 'N/A'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Gender:</span>
                        <span class="info-value"><?php echo htmlspecialchars($user['gender']) ?: 'N/A'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Weight:</span>
                        <span class="info-value"><?php echo $user['weight'] ? $user['weight'] . ' kg' : 'N/A'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Total Donations:</span>
                        <span class="info-value"><span class="badge bg-danger"><?php echo $user['donation_count'] ?: 0; ?></span></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Last Donation:</span>
                        <span class="info-value"><?php echo $user['last_donation_date'] ? date('F j, Y', strtotime($user['last_donation_date'])) : 'Never'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Eligibility:</span>
                        <span class="info-value">
                            <span class="badge bg-<?php echo $user['eligible_to_donate'] == 'Yes' ? 'success' : 'danger'; ?>">
                                <?php echo $user['eligible_to_donate'] == 'Yes' ? 'Eligible' : 'Not Eligible'; ?>
                            </span>
                        </span>
                    </div>
                    <?php if ($user['medical_conditions']): ?>
                    <div class="mt-3 p-3 bg-light rounded">
                        <strong><i class="bi bi-clipboard2-pulse-fill me-2"></i>Medical Conditions:</strong>
                        <p class="mb-0 mt-2"><?php echo nl2br(htmlspecialchars($user['medical_conditions'])); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Right Column: Documents -->
            <div class="col-md-6">
                <div class="info-card">
                    <h5><i class="bi bi-file-earmark-check-fill me-2"></i>Uploaded Documents</h5>
                    
                    <?php if (empty($documents)): ?>
                        <div class="alert alert-warning">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            <strong>No documents uploaded</strong>
                        </div>
                    <?php else: ?>
                        <?php foreach ($documents as $doc): 
                            $fileExists = file_exists('../' . $doc['file_path']);
                            $docType = $doc['document_type'] === 'medical_certificate' ? 'Medical Certificate' : 'Photo ID / Valid ID';
                            $docIcon = $doc['document_type'] === 'medical_certificate' ? 'file-earmark-medical' : 'card-image';
                            $iconColor = $doc['document_type'] === 'medical_certificate' ? 'text-danger' : 'text-primary';
                        ?>
                        <div class="doc-card">
                            <div class="text-center">
                                <i class="bi bi-<?php echo $docIcon; ?> <?php echo $iconColor; ?> doc-icon"></i>
                                <h6 class="fw-bold"><?php echo $docType; ?></h6>
                                <p class="text-muted mb-3">
                                    <?php echo number_format($doc['file_size'] / 1024, 2); ?> KB<br>
                                    <small>Uploaded: <?php echo date('M j, Y', strtotime($doc['uploaded_at'])); ?></small>
                                </p>
                                
                                <?php if ($fileExists): 
                                    $fileExt = strtolower(pathinfo($doc['file_path'], PATHINFO_EXTENSION));
                                    $isImage = in_array($fileExt, ['jpg', 'jpeg', 'png', 'gif', 'webp']);
                                    
                                    if ($isImage): ?>
                                        <img src="../<?php echo htmlspecialchars($doc['file_path']); ?>" 
                                             class="img-fluid rounded mb-3" 
                                             style="max-height: 300px; object-fit: contain;">
                                    <?php endif; ?>
                                    
                                    <div class="d-grid gap-2">
                                        <a href="../<?php echo htmlspecialchars($doc['file_path']); ?>" 
                                           target="_blank" 
                                           class="btn btn-outline-primary">
                                            <i class="bi bi-eye me-1"></i> View Full Size
                                        </a>
                                        <a href="../<?php echo htmlspecialchars($doc['file_path']); ?>" 
                                           download 
                                           class="btn btn-outline-secondary">
                                            <i class="bi bi-download me-1"></i> Download
                                        </a>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-danger">
                                        <i class="bi bi-exclamation-circle me-1"></i> File not found
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <!-- Actions -->
                <div class="info-card">
                    <h5><i class="bi bi-gear-fill me-2"></i>Actions</h5>
                    <div class="d-grid gap-2">
                        <a href="edit_user.php?id=<?php echo $user_id; ?>" class="btn btn-primary">
                            <i class="bi bi-pencil me-1"></i> Edit User
                        </a>
                        <a href="manage_users.php" class="btn btn-secondary">
                            <i class="bi bi-arrow-left me-1"></i> Back to List
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
