<?php
/**
 * SMS Functions for User Approvals
 * Sends SMS notifications for approve/decline actions
 */

require_once __DIR__ . '/../sms/vendor/autoload.php';

use AndroidSmsGateway\Client;
use AndroidSmsGateway\Domain\Message;

/**
 * Send SMS notification to user
 * @param string $phoneNumber - Phone number starting with 09 (e.g., 09123456789)
 * @param string $message - SMS message content
 * @return array - ['success' => bool, 'message' => string]
 */
function sendUserSMS($phoneNumber, $message) {
    // SMS Gateway credentials
    $username = '3YQ1CD';
    $password = '0rvpkbhbgdosr6';
    
    try {
        // Validate phone number format
        // Expected format: 09XXXXXXXXX (starts with 09, total 11 digits)
        $phoneNumber = trim($phoneNumber);
        
        // Remove any spaces or dashes
        $phoneNumber = preg_replace('/[\s-]/', '', $phoneNumber);
        
        // Check if starts with 09
        if (!preg_match('/^09\d{9}$/', $phoneNumber)) {
            return [
                'success' => false,
                'message' => 'Invalid phone number format. Must start with 09 and be 11 digits long.'
            ];
        }
        
        // Convert 09XXXXXXXXX to +639XXXXXXXXX format
        $formattedNumber = '+63' . substr($phoneNumber, 1); // Remove first 0 and add +63
        
        // Validate final format
        if (!preg_match('/^\+639\d{9}$/', $formattedNumber)) {
            return [
                'success' => false,
                'message' => 'Failed to format phone number correctly.'
            ];
        }
        
        // Initialize SMS client
        $client = new Client($username, $password);
        $smsMessage = new Message($message, [$formattedNumber]);
        
        // Send message
        $messageState = $client->Send($smsMessage);
        
        // Get message state
        $state = $client->GetState($messageState->ID());
        
        return [
            'success' => true,
            'message' => 'SMS sent successfully',
            'message_id' => $messageState->ID(),
            'state' => $state->State()
        ];
        
    } catch (Exception $e) {
        error_log("SMS Error: " . $e->getMessage());
        return [
            'success' => false,
            'message' => 'Failed to send SMS: ' . $e->getMessage()
        ];
    }
}

/**
 * Send approval SMS notification
 * @param string $phoneNumber - Phone number starting with 09
 * @param string $fullName - User's full name
 * @return array
 */
function sendApprovalSMS($phoneNumber, $fullName) {
    $message = "Congratulations {$fullName}! Your account registration at Koronadal Red Cross has been APPROVED. You can now log in and access all features.";
    return sendUserSMS($phoneNumber, $message);
}

/**
 * Send rejection SMS notification
 * @param string $phoneNumber - Phone number starting with 09
 * @param string $fullName - User's full name
 * @param string $reason - Rejection reason
 * @return array
 */
function sendRejectionSMS($phoneNumber, $fullName, $reason = '') {
    $message = "Hello {$fullName}, we regret to inform you that your account registration at Koronadal Red Cross has been REJECTED.";
    
    if (!empty($reason)) {
        $message .= " Reason: {$reason}.";
    }
    
    $message .= " If you believe this is an error, please contact us.";
    
    return sendUserSMS($phoneNumber, $message);
}
