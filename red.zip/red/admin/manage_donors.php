<?php
require_once '../config/config.php';
require_once '../config/db.php';
requireAdmin();

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCSRF($_POST['csrf_token'])) {
    try {
        if (isset($_POST['send_reminders'])) {
            $count = sendDonationReminders($db, $_SESSION['user_id']);
            $success = "Sent reminders to $count eligible donors";
        }
    } catch(PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}

$eligibilityFilter = $_GET['eligibility'] ?? '';
$bloodTypeFilter = $_GET['blood_type'] ?? '';
$where = [];
$params = [];
if ($eligibilityFilter) { $where[] = "di.eligible_to_donate = ?"; $params[] = $eligibilityFilter; }
if ($bloodTypeFilter) { $where[] = "di.blood_type_id = ?"; $params[] = $bloodTypeFilter; }
$whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$stmt = $db->prepare("SELECT di.*, u.username, u.full_name, u.email, u.phone, u.status, bt.blood_type,
       (SELECT COUNT(*) FROM donations d WHERE d.donor_id = di.donor_id AND d.status = 'completed') as completed_donations,
       DATEDIFF(CURDATE(), di.last_donation_date) as days_since_donation
       FROM donors_info di
       JOIN users u ON di.user_id = u.user_id
       JOIN blood_types bt ON di.blood_type_id = bt.blood_type_id
       $whereSQL ORDER BY di.donor_id DESC");
$stmt->execute($params);
$donors = $stmt->fetchAll();

$stats = $db->query("SELECT COUNT(*) as total, SUM(eligible_to_donate='Yes') as eligible, 
       SUM(DATEDIFF(CURDATE(), last_donation_date) >= 56 AND last_donation_date IS NOT NULL) as can_donate
       FROM donors_info")->fetch();

$bloodTypes = $db->query("SELECT * FROM blood_types ORDER BY blood_type")->fetchAll();

$pageTitle = 'Manage Donors';
include '../includes/admin_header.php';
?>

<style>
.stats-card-3d{background:#fff;border-radius:20px;padding:25px;box-shadow:0 10px 40px rgba(0,0,0,0.1);transition:all 0.4s;border-top:5px solid #667eea}
.stats-card-3d:hover{transform:translateY(-10px);box-shadow:0 20px 60px rgba(0,0,0,0.2)}
.stats-icon-3d{width:70px;height:70px;border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:2rem;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff;box-shadow:0 10px 30px rgba(102,126,234,0.4);animation:float 3s ease-in-out infinite}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
.stats-number{font-size:2.5rem;font-weight:800;background:linear-gradient(135deg,#667eea,#764ba2);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.card-3d{border-radius:20px;border:none;box-shadow:0 15px 45px rgba(0,0,0,0.1);transition:all 0.4s}
.card-3d:hover{transform:translateY(-5px);box-shadow:0 20px 60px rgba(0,0,0,0.15)}
.card-header-3d{background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border:none;padding:20px;border-radius:20px 20px 0 0}
.btn-3d{border-radius:12px;padding:10px 24px;font-weight:600;transition:all 0.3s;border:none;box-shadow:0 5px 15px rgba(0,0,0,0.2)}
.btn-3d:hover{transform:translateY(-3px);box-shadow:0 8px 25px rgba(0,0,0,0.3)}
.btn-gradient-primary{background:linear-gradient(135deg,#667eea,#764ba2);color:#fff}
.table-3d tbody tr{background:#fff;box-shadow:0 5px 15px rgba(0,0,0,0.08);transition:all 0.3s;margin-bottom:10px}
.table-3d tbody tr:hover{transform:scale(1.02);box-shadow:0 8px 25px rgba(0,0,0,0.15)}
.table-3d tbody td{padding:20px 15px;border:none;vertical-align:middle}
.badge-3d{padding:8px 16px;border-radius:20px;font-weight:600;font-size:0.85rem;box-shadow:0 4px 12px rgba(0,0,0,0.15)}
.donor-avatar-3d{width:50px;height:50px;border-radius:50%;background:linear-gradient(135deg,#667eea,#764ba2);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:1.2rem;box-shadow:0 5px 15px rgba(102,126,234,0.4);transition:all 0.3s ease}
.donor-avatar-3d:hover{transform:scale(1.1);box-shadow:0 8px 20px rgba(102,126,234,0.6)}
.blood-type-badge-3d{padding:10px 20px;border-radius:15px;font-weight:700;font-size:1.1rem;background:linear-gradient(135deg,#f093fb,#f5576c);color:#fff;box-shadow:0 5px 15px rgba(245,87,108,0.4);display:inline-block}
.filter-card-3d{background:#fff;border-radius:20px;padding:25px;box-shadow:0 10px 30px rgba(0,0,0,0.1);margin-bottom:30px}
.modal{animation:none !important}
.modal-content{animation:modalFadeIn 0.3s ease-out}
@keyframes modalFadeIn{from{opacity:0;transform:scale(0.9)}to{opacity:1;transform:scale(1)}}
</style>

<div class="container-fluid" style="background:linear-gradient(135deg,#f5f7fa 0%,#c3cfe2 100%);min-height:100vh;padding-bottom:50px">
<div class="row">
<?php include '../includes/admin_sidebar.php'; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

<div style="background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;padding:30px;border-radius:20px;margin-bottom:30px;box-shadow:0 15px 40px rgba(102,126,234,0.3)">
<div class="d-flex justify-content-between align-items-center">
<div><h1 style="font-weight:800"><i class="bi bi-heart-pulse me-3"></i>Donor Management</h1>
<p class="mb-0 mt-2">Manage and track all blood donors</p></div>
<button class="btn btn-3d" style="background:#fff;color:#667eea" data-bs-toggle="modal" data-bs-target="#sendRemindersModal">
<i class="bi bi-send me-2"></i>Send Reminders</button>
</div></div>

<?php if($success): ?>
<div class="alert alert-success alert-dismissible fade show" style="border-radius:15px;border:none;box-shadow:0 5px 15px rgba(25,135,84,0.3)">
<i class="bi bi-check-circle-fill me-2"></i><?=$success?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; if($error): ?>
<div class="alert alert-danger alert-dismissible fade show" style="border-radius:15px;border:none;box-shadow:0 5px 15px rgba(220,53,69,0.3)">
<i class="bi bi-exclamation-triangle-fill me-2"></i><?=$error?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>

<div class="row mb-4">
<div class="col-md-4 mb-3"><div class="stats-card-3d"><div class="d-flex align-items-center">
<div class="stats-icon-3d me-3"><i class="bi bi-people-fill"></i></div>
<div><div class="stats-number"><?=number_format($stats['total'])?></div>
<small class="text-muted" style="font-weight:600">Total Donors</small></div></div></div></div>

<div class="col-md-4 mb-3"><div class="stats-card-3d"><div class="d-flex align-items-center">
<div class="stats-icon-3d me-3" style="background:linear-gradient(135deg,#f093fb,#f5576c)"><i class="bi bi-check-circle-fill"></i></div>
<div><div class="stats-number" style="background:linear-gradient(135deg,#f093fb,#f5576c);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><?=number_format($stats['eligible'])?></div>
<small class="text-muted" style="font-weight:600">Eligible Now</small></div></div></div></div>

<div class="col-md-4 mb-3"><div class="stats-card-3d"><div class="d-flex align-items-center">
<div class="stats-icon-3d me-3" style="background:linear-gradient(135deg,#4facfe,#00f2fe)"><i class="bi bi-clock-history"></i></div>
<div><div class="stats-number" style="background:linear-gradient(135deg,#4facfe,#00f2fe);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><?=number_format($stats['can_donate'])?></div>
<small class="text-muted" style="font-weight:600">Can Donate</small></div></div></div></div>
</div>

<div class="filter-card-3d">
<h5 class="mb-3" style="font-weight:700"><i class="bi bi-funnel me-2" style="color:#667eea"></i>Filters</h5>
<form method="GET" class="row g-3">
<div class="col-md-5"><label class="form-label" style="font-weight:600">Eligibility Status</label>
<select name="eligibility" class="form-select" style="border-radius:12px;border:2px solid #e9ecef">
<option value="">All Donors</option>
<option value="Yes" <?=$eligibilityFilter=='Yes'?'selected':''?>>Eligible</option>
<option value="No" <?=$eligibilityFilter=='No'?'selected':''?>>Not Eligible</option>
</select></div>
<div class="col-md-4"><label class="form-label" style="font-weight:600">Blood Type</label>
<select name="blood_type" class="form-select" style="border-radius:12px;border:2px solid #e9ecef">
<option value="">All Types</option>
<?php foreach($bloodTypes as $bt): ?>
<option value="<?=$bt['blood_type_id']?>" <?=$bloodTypeFilter==$bt['blood_type_id']?'selected':''?>><?=$bt['blood_type']?></option>
<?php endforeach; ?>
</select></div>
<div class="col-md-3 d-flex align-items-end">
<button type="submit" class="btn btn-3d btn-gradient-primary me-2"><i class="bi bi-search me-1"></i>Filter</button>
<a href="manage_donors.php" class="btn btn-3d" style="background:#f8f9fa;color:#495057"><i class="bi bi-x-circle me-1"></i>Clear</a>
</div>
</form>
</div>

<div class="card-3d">
<div class="card-header-3d"><h5 class="mb-0" style="font-weight:700"><i class="bi bi-list-check me-2"></i>Donors List (<?=count($donors)?>)</h5></div>
<div class="card-body p-0">
<?php if(count($donors) > 0): ?>
<div class="table-responsive">
<table class="table table-3d mb-0">
<thead><tr><th>Donor</th><th>Blood Type</th><th>Donations</th><th>Last Donation</th><th>Eligibility</th><th>Actions</th></tr></thead>
<tbody>
<?php foreach($donors as $d): 
$canDonate = $d['days_since_donation'] >= 56 || $d['days_since_donation'] === null;
?>
<tr>
<td><div class="d-flex align-items-center">
<div class="donor-avatar-3d me-3"><?=strtoupper(substr($d['full_name'],0,2))?></div>
<div><strong style="font-size:1.05rem"><?=htmlspecialchars($d['full_name'])?></strong><br>
<small class="text-muted">@<?=htmlspecialchars($d['username'])?></small></div></div></td>
<td><span class="blood-type-badge-3d"><?=htmlspecialchars($d['blood_type'])?></span></td>
<td><strong style="font-size:1.3rem;color:#667eea"><?=$d['completed_donations']?></strong> times</td>
<td><?php if($d['last_donation_date']): ?>
<strong><?=date('M j, Y',strtotime($d['last_donation_date']))?></strong><br>
<small class="<?=$canDonate?'text-success':'text-warning'?>"><i class="bi bi-clock me-1"></i><?=$d['days_since_donation']?> days ago</small>
<?php else: ?>
<span class="badge-3d bg-secondary">Never</span>
<?php endif; ?></td>
<td><?php if($d['eligible_to_donate']==='Yes'): ?>
<span class="badge-3d bg-success"><i class="bi bi-check-circle me-1"></i>Eligible</span>
<?php else: ?>
<span class="badge-3d bg-danger"><i class="bi bi-x-circle me-1"></i>Not Eligible</span>
<?php endif; ?></td>
<td>
<div class="btn-group">
<a href="update_donor_eligibility.php?id=<?=$d['donor_id']?>" class="btn btn-sm btn-primary" style="border-radius:10px" title="Update Eligibility">
<i class="bi bi-pencil"></i>
</a>
<a href="view_donor.php?id=<?=$d['donor_id']?>" class="btn btn-sm btn-info" style="border-radius:10px" title="View Details">
<i class="bi bi-eye"></i>
</a>
</div>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php else: ?>
<div class="text-center py-5">
<i class="bi bi-people" style="font-size:5rem;color:#ddd"></i>
<h4 class="mt-3 text-muted">No Donors Found</h4>
</div>
<?php endif; ?>
</div>
</div>

</main>
</div>
</div>

<div class="modal fade" id="sendRemindersModal"><div class="modal-dialog"><div class="modal-content" style="border-radius:20px">
<div class="modal-header" style="background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border-radius:20px 20px 0 0">
<h5 class="modal-title"><i class="bi bi-send me-2"></i>Send Reminders</h5>
<button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<form method="POST"><div class="modal-body">
<input type="hidden" name="csrf_token" value="<?=getCSRFToken()?>">
<div class="alert alert-info" style="border-radius:12px">
<i class="bi bi-info-circle me-2"></i>This will send donation reminders to all eligible donors who can donate now (56+ days since last donation).
</div>
</div><div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" name="send_reminders" class="btn btn-3d btn-gradient-primary">
<i class="bi bi-send me-1"></i>Send Reminders</button>
</div></form></div></div></div>

<?php include '../includes/footer.php'; ?>
