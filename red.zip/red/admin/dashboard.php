<?php
/**
 * Admin Dashboard
 * Overview and statistics for administrators
 */

require_once '../config/config.php';
require_once '../config/db.php';

requireAdmin();

// Get statistics
try {
    // Total users
    $userCountSql = "SELECT COUNT(*) as count FROM users WHERE user_role = 'user'";
    $stmt = $db->prepare($userCountSql);
    $stmt->execute();
    $totalUsers = $stmt->fetch()['count'];
    
    // Total donations
    $donationCountSql = "SELECT COUNT(*) as count FROM donations";
    $stmt = $db->prepare($donationCountSql);
    $stmt->execute();
    $totalDonations = $stmt->fetch()['count'];
    
    // Total requests
    $requestCountSql = "SELECT COUNT(*) as count FROM requests";
    $stmt = $db->prepare($requestCountSql);
    $stmt->execute();
    $totalRequests = $stmt->fetch()['count'];
    
    // Pending approvals
    $pendingDonationsSql = "SELECT COUNT(*) as count FROM donations WHERE status = 'pending'";
    $stmt = $db->prepare($pendingDonationsSql);
    $stmt->execute();
    $pendingDonations = $stmt->fetch()['count'];
    
    $pendingRequestsSql = "SELECT COUNT(*) as count FROM requests WHERE status = 'pending'";
    $stmt = $db->prepare($pendingRequestsSql);
    $stmt->execute();
    $pendingRequests = $stmt->fetch()['count'];
    
    // Total blood inventory
    $inventorySql = "SELECT SUM(quantity_ml) as total FROM inventory WHERE status = 'available'";
    $stmt = $db->prepare($inventorySql);
    $stmt->execute();
    $totalInventory = floor($stmt->fetch()['total'] / 450);
    
} catch(PDOException $e) {
    $totalUsers = $totalDonations = $totalRequests = $pendingDonations = $pendingRequests = $totalInventory = 0;
}

// Recent donations
try {
    $recentDonationsSql = "SELECT d.*, u.full_name, bt.blood_type, di.donor_id 
                           FROM donations d 
                           JOIN donors_info di ON d.donor_id = di.donor_id 
                           JOIN users u ON di.user_id = u.user_id 
                           JOIN blood_types bt ON d.blood_type_id = bt.blood_type_id 
                           ORDER BY d.created_at DESC LIMIT 5";
    $stmt = $db->prepare($recentDonationsSql);
    $stmt->execute();
    $recentDonations = $stmt->fetchAll();
} catch(PDOException $e) {
    $recentDonations = [];
}

// Recent requests
try {
    $recentRequestsSql = "SELECT r.*, u.full_name, bt.blood_type 
                          FROM requests r 
                          JOIN users u ON r.user_id = u.user_id 
                          JOIN blood_types bt ON r.blood_type_id = bt.blood_type_id 
                          ORDER BY r.created_at DESC LIMIT 5";
    $stmt = $db->prepare($recentRequestsSql);
    $stmt->execute();
    $recentRequests = $stmt->fetchAll();
} catch(PDOException $e) {
    $recentRequests = [];
}

// Blood type distribution
try {
    $bloodDistSql = "SELECT bt.blood_type, SUM(i.quantity_ml) as total_ml 
                     FROM inventory i 
                     JOIN blood_types bt ON i.blood_type_id = bt.blood_type_id 
                     WHERE i.status = 'available' 
                     GROUP BY bt.blood_type_id 
                     ORDER BY bt.blood_type";
    $stmt = $db->prepare($bloodDistSql);
    $stmt->execute();
    $bloodDistribution = $stmt->fetchAll();
} catch(PDOException $e) {
    $bloodDistribution = [];
}

$pageTitle = 'Admin Dashboard';
include '../includes/admin_header.php';
?>

<style>
.stats-card-3d{background:#fff;border-radius:20px;padding:25px;box-shadow:0 10px 40px rgba(0,0,0,0.1);transition:all 0.4s;position:relative;overflow:hidden}
.stats-card-3d:hover{transform:translateY(-10px);box-shadow:0 20px 60px rgba(0,0,0,0.2)}
.stats-card-3d::before{content:'';position:absolute;top:0;left:0;right:0;height:5px}
.stats-card-3d.blue::before{background:linear-gradient(135deg,#0d6efd,#0a58ca)}
.stats-card-3d.red::before{background:linear-gradient(135deg,#dc3545,#ff6b6b)}
.stats-card-3d.green::before{background:linear-gradient(135deg,#28a745,#20c997)}
.stats-card-3d.yellow::before{background:linear-gradient(135deg,#ffc107,#ff9800)}
.stats-icon-3d{width:70px;height:70px;border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:2rem;color:#fff;box-shadow:0 10px 30px rgba(0,0,0,0.3);animation:float 3s ease-in-out infinite}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
.stats-number{font-size:2.5rem;font-weight:800;-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.card-3d{border-radius:20px;border:none;box-shadow:0 15px 45px rgba(0,0,0,0.1);transition:all 0.4s}
.btn-action-3d{border-radius:15px;padding:15px;font-weight:600;transition:all 0.3s;border:2px solid;box-shadow:0 5px 15px rgba(0,0,0,0.1)}
.btn-action-3d:hover{transform:translateY(-5px);box-shadow:0 10px 25px rgba(0,0,0,0.2)}
.blood-bar-3d{height:25px;border-radius:15px;background:#e9ecef;overflow:hidden;box-shadow:inset 0 2px 5px rgba(0,0,0,0.1)}
.blood-fill-3d{height:100%;transition:width 0.5s ease;border-radius:15px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700}
</style>

<div class="container-fluid" style="background:linear-gradient(135deg,#f5f7fa 0%,#c3cfe2 100%);min-height:100vh;padding-bottom:50px">
<div class="row">
<?php include '../includes/admin_sidebar.php'; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

<div style="background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;padding:30px;border-radius:20px;margin-bottom:30px;box-shadow:0 15px 40px rgba(102,126,234,0.3)">
<div class="d-flex justify-content-between align-items-center">
<div><h1 style="font-weight:800"><i class="bi bi-speedometer2 me-3"></i>Admin Dashboard</h1>
<p class="mb-0 mt-2">Welcome back! Here's what's happening today</p></div>
<div class="btn-toolbar">
<button class="btn" style="background:#fff;color:#667eea;border-radius:12px;font-weight:600" data-bs-toggle="dropdown">
<i class="bi bi-calendar-week me-1"></i>This Week <i class="bi bi-chevron-down ms-1"></i>
</button>
<ul class="dropdown-menu">
<li><a class="dropdown-item" href="#">Today</a></li>
<li><a class="dropdown-item" href="#">This Week</a></li>
<li><a class="dropdown-item" href="#">This Month</a></li>
</ul>
</div>
</div></div>

<?php if($pendingDonations > 0 || $pendingRequests > 0): ?>
<div class="alert alert-warning alert-dismissible fade show" style="border-radius:15px;border:none;box-shadow:0 5px 15px rgba(255,193,7,0.3)">
<i class="bi bi-exclamation-triangle-fill me-2"></i><strong>Action Required:</strong> 
You have <?=$pendingDonations?> pending donation(s) and <?=$pendingRequests?> pending request(s) awaiting review.
<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row mb-4">
<div class="col-md-3 mb-3"><div class="stats-card-3d blue">
<div class="d-flex justify-content-between align-items-center">
<div>
<p class="text-muted mb-1" style="font-weight:600">Total Users</p>
<h3 class="stats-number mb-0" style="background:linear-gradient(135deg,#0d6efd,#0a58ca);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text"><?=$totalUsers?></h3>
</div>
<div class="stats-icon-3d" style="background:linear-gradient(135deg,#0d6efd,#0a58ca)">
<i class="bi bi-people-fill"></i>
</div>
</div>
</div></div>
<div class="col-md-3 mb-3"><div class="stats-card-3d red">
<div class="d-flex justify-content-between align-items-center">
<div>
<p class="text-muted mb-1" style="font-weight:600">Total Donations</p>
<h3 class="stats-number mb-0" style="background:linear-gradient(135deg,#dc3545,#ff6b6b);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text"><?=$totalDonations?></h3>
</div>
<div class="stats-icon-3d" style="background:linear-gradient(135deg,#dc3545,#ff6b6b)">
<i class="bi bi-droplet-fill"></i>
</div>
</div>
</div></div>
<div class="col-md-3 mb-3"><div class="stats-card-3d green">
<div class="d-flex justify-content-between align-items-center">
<div>
<p class="text-muted mb-1" style="font-weight:600">Blood Inventory</p>
<h3 class="stats-number mb-0" style="background:linear-gradient(135deg,#28a745,#20c997);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text"><?=$totalInventory?> <small style="font-size:1rem">units</small></h3>
</div>
<div class="stats-icon-3d" style="background:linear-gradient(135deg,#28a745,#20c997)">
<i class="bi bi-clipboard-data-fill"></i>
</div>
</div>
</div></div>
<div class="col-md-3 mb-3"><div class="stats-card-3d yellow">
<div class="d-flex justify-content-between align-items-center">
<div>
<p class="text-muted mb-1" style="font-weight:600">Pending Items</p>
<h3 class="stats-number mb-0" style="background:linear-gradient(135deg,#ffc107,#ff9800);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text"><?=$pendingDonations + $pendingRequests?></h3>
</div>
<div class="stats-icon-3d" style="background:linear-gradient(135deg,#ffc107,#ff9800)">
<i class="bi bi-clock-history"></i>
</div>
</div>
</div></div>
</div>

<div class="card-3d mb-4">
<div class="card-body">
<h5 style="font-weight:700;color:#667eea;margin-bottom:20px"><i class="bi bi-lightning-fill me-2"></i>Quick Actions</h5>
<div class="row g-3">
<div class="col-md-3">
<a href="manage_donations.php" class="btn btn-action-3d border-danger text-danger w-100">
<i class="bi bi-droplet me-2"></i>Manage Donations
</a>
</div>
<div class="col-md-3">
<a href="manage_requests.php" class="btn btn-action-3d border-primary text-primary w-100">
<i class="bi bi-bandaid me-2"></i>Manage Requests
</a>
</div>
<div class="col-md-3">
<a href="manage_inventory.php" class="btn btn-action-3d border-success text-success w-100">
<i class="bi bi-box-seam me-2"></i>Manage Inventory
</a>
</div>
<div class="col-md-3">
<a href="manage_users.php" class="btn btn-action-3d border-info text-info w-100">
<i class="bi bi-people me-2"></i>Manage Users
</a>
</div>
</div>
</div>
</div>

<div class="card-3d mb-4">
<div class="card-body">
<h5 style="font-weight:700;color:#dc3545;margin-bottom:20px">
<i class="bi bi-graph-up me-2"></i>Blood Inventory by Type
</h5>
<div class="row">
<?php foreach($bloodDistribution as $blood): 
$units = floor($blood['total_ml'] / 450);
$percentage = min(($units / 20) * 100, 100);
$gradientColor = $percentage > 50 ? 'linear-gradient(135deg,#28a745,#20c997)' : ($percentage > 20 ? 'linear-gradient(135deg,#ffc107,#ff9800)' : 'linear-gradient(135deg,#dc3545,#ff6b6b)');
?>
<div class="col-md-3 mb-3">
<div class="text-center">
<h4 style="font-weight:800;color:#dc3545;margin-bottom:10px"><?=$blood['blood_type']?></h4>
<div class="blood-bar-3d mb-2">
<div class="blood-fill-3d" style="width:<?=$percentage?>%;background:<?=$gradientColor?>">
<?=$units?> units
</div>
</div>
<small class="text-muted"><?=$blood['total_ml']?>ml</small>
</div>
</div>
<?php endforeach; ?>
</div>
</div>
</div>

<div class="row">
<div class="col-md-6 mb-4">
<div class="card-3d">
<div class="d-flex justify-content-between align-items-center mb-3">
<h5 class="mb-0" style="font-weight:700;color:#dc3545">
<i class="bi bi-droplet-half me-2"></i>Recent Donations
</h5>
<a href="manage_donations.php" class="btn btn-sm" style="background:linear-gradient(135deg,#dc3545,#ff6b6b);color:#fff;border-radius:10px">View All</a>
</div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Donor</th>
                                            <th>Blood Type</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (count($recentDonations) > 0): ?>
                                            <?php foreach ($recentDonations as $donation): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($donation['full_name']); ?></td>
                                                    <td><span class="badge bg-danger"><?php echo $donation['blood_type']; ?></span></td>
                                                    <td><small><?php echo formatDate($donation['donation_date']); ?></small></td>
                                                    <td>
                                                        <span class="badge bg-<?php 
                                                            echo $donation['status'] === 'completed' ? 'success' : 
                                                                 ($donation['status'] === 'pending' ? 'warning' : 
                                                                 ($donation['status'] === 'approved' ? 'info' : 'danger')); 
                                                        ?>">
                                                            <?php echo ucfirst($donation['status']); ?>
                                                        </span>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="4" class="text-center text-muted py-3">No donations yet</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

<div class="col-md-6 mb-4">
<div class="card-3d">
<div class="d-flex justify-content-between align-items-center mb-3">
<h5 class="mb-0" style="font-weight:700;color:#0d6efd">
<i class="bi bi-bandaid me-2"></i>Recent Requests
</h5>
<a href="manage_requests.php" class="btn btn-sm" style="background:linear-gradient(135deg,#0d6efd,#0a58ca);color:#fff;border-radius:10px">View All</a>
</div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Requester</th>
                                            <th>Blood Type</th>
                                            <th>Urgency</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (count($recentRequests) > 0): ?>
                                            <?php foreach ($recentRequests as $request): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($request['full_name']); ?></td>
                                                    <td><span class="badge bg-primary"><?php echo $request['blood_type']; ?></span></td>
                                                    <td>
                                                        <span class="badge bg-<?php 
                                                            echo $request['urgency'] === 'Critical' ? 'danger' : 
                                                                 ($request['urgency'] === 'High' ? 'warning' : 'secondary'); 
                                                        ?>">
                                                            <?php echo $request['urgency']; ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-<?php 
                                                            echo $request['status'] === 'fulfilled' ? 'success' : 
                                                                 ($request['status'] === 'pending' ? 'warning' : 
                                                                 ($request['status'] === 'approved' ? 'info' : 'danger')); 
                                                        ?>">
                                                            <?php echo ucfirst($request['status']); ?>
                                                        </span>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="4" class="text-center text-muted py-3">No requests yet</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
