<?php
/**
 * Manage Donations - Admin
 * CRUD operations for blood donations
 */

require_once '../config/config.php';
require_once '../config/db.php';
require_once 'sms_functions.php';

requireAdmin();

$error = '';
$success = '';

// Handle status update
if (isset($_POST['update_status'])) {
    if (!validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        $donationId = intval($_POST['donation_id']);
        $status = sanitize($_POST['status']);
        $notes = sanitize($_POST['admin_notes']);
        
        try {
            $updateSql = "UPDATE donations SET status = :status, notes = :notes, updated_at = NOW() 
                         WHERE donation_id = :donation_id";
            $stmt = $db->prepare($updateSql);
            $result = $stmt->execute([
                ':status' => $status,
                ':notes' => $notes,
                ':donation_id' => $donationId
            ]);
            
            if ($result) {
                // Get donation details with user info
                $donationSql = "SELECT d.*, u.full_name, u.phone, bt.blood_type, di.user_id 
                               FROM donations d 
                               JOIN donors_info di ON d.donor_id = di.donor_id 
                               JOIN users u ON di.user_id = u.user_id 
                               JOIN blood_types bt ON d.blood_type_id = bt.blood_type_id 
                               WHERE d.donation_id = :donation_id";
                $stmt = $db->prepare($donationSql);
                $stmt->execute([':donation_id' => $donationId]);
                $donation = $stmt->fetch();
                
                // If approved or completed, update inventory
                if ($status === 'approved' || $status === 'completed') {
                    if ($donation && $status === 'completed') {
                        // Update inventory
                        $inventorySql = "UPDATE inventory SET quantity_ml = quantity_ml + :quantity 
                                        WHERE blood_type_id = :blood_type_id AND status = 'available'";
                        $stmt = $db->prepare($inventorySql);
                        $stmt->execute([
                            ':quantity' => $donation['quantity_ml'],
                            ':blood_type_id' => $donation['blood_type_id']
                        ]);
                        
                        // Update donor's last donation date
                        $updateDonorSql = "UPDATE donors_info SET last_donation_date = :date 
                                          WHERE donor_id = :donor_id";
                        $stmt = $db->prepare($updateDonorSql);
                        $stmt->execute([
                            ':date' => $donation['donation_date'],
                            ':donor_id' => $donation['donor_id']
                        ]);
                    }
                    
                    // Send in-app notification
                    if ($donation) {
                        createNotification($db, $donation['user_id'], 'Donation ' . ucfirst($status), 
                            'Your blood donation has been ' . $status . '.', 
                            $status === 'completed' ? 'success' : 'info');
                    }
                }
                
                // Send SMS notification for all status changes
                if ($donation && !empty($donation['phone'])) {
                    $smsMessage = '';
                    
                    if ($status === 'approved') {
                        $smsMessage = "Good news {$donation['full_name']}! Your blood donation of {$donation['blood_type']} ({$donation['quantity_ml']}ml) has been APPROVED by Koronadal Red Cross. Thank you for saving lives!";
                    } elseif ($status === 'completed') {
                        $smsMessage = "Thank you {$donation['full_name']}! Your blood donation of {$donation['blood_type']} ({$donation['quantity_ml']}ml) has been COMPLETED and added to our inventory. You are a hero!";
                    } elseif ($status === 'rejected') {
                        $smsMessage = "We regret to inform you {$donation['full_name']} that your blood donation has been REJECTED.";
                        if (!empty($notes)) {
                            $smsMessage .= " Reason: {$notes}";
                        }
                    }
                    
                    if (!empty($smsMessage)) {
                        $smsResult = sendUserSMS($donation['phone'], $smsMessage);
                        if ($smsResult['success']) {
                            error_log("Donation SMS sent to {$donation['phone']}: {$smsResult['message']}");
                        } else {
                            error_log("Donation SMS failed to {$donation['phone']}: {$smsResult['message']}");
                        }
                    }
                }
                
                logAudit($db, $_SESSION['user_id'], 'Donation Status Updated', 'donations', $donationId, 
                    'Status changed to ' . $status);
                
                $success = 'Donation status updated successfully!';
            }
        } catch(PDOException $e) {
            $error = 'Error updating donation: ' . $e->getMessage();
        }
    }
}

// Handle delete
if (isset($_POST['delete_donation'])) {
    if (!validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        $donationId = intval($_POST['donation_id']);
        
        try {
            $deleteSql = "DELETE FROM donations WHERE donation_id = :donation_id";
            $stmt = $db->prepare($deleteSql);
            $result = $stmt->execute([':donation_id' => $donationId]);
            
            if ($result) {
                logAudit($db, $_SESSION['user_id'], 'Donation Deleted', 'donations', $donationId, 
                    'Donation record deleted');
                $success = 'Donation deleted successfully!';
            }
        } catch(PDOException $e) {
            $error = 'Error deleting donation: ' . $e->getMessage();
        }
    }
}

// Get all donations with filters
$filterStatus = isset($_GET['status']) ? sanitize($_GET['status']) : '';
$filterBloodType = isset($_GET['blood_type']) ? sanitize($_GET['blood_type']) : '';

try {
    $sql = "SELECT d.*, u.full_name, u.email, bt.blood_type, di.donor_id 
            FROM donations d 
            JOIN donors_info di ON d.donor_id = di.donor_id 
            JOIN users u ON di.user_id = u.user_id 
            JOIN blood_types bt ON d.blood_type_id = bt.blood_type_id 
            WHERE 1=1";
    
    if (!empty($filterStatus)) {
        $sql .= " AND d.status = :status";
    }
    if (!empty($filterBloodType)) {
        $sql .= " AND bt.blood_type = :blood_type";
    }
    
    $sql .= " ORDER BY d.created_at DESC";
    
    $stmt = $db->prepare($sql);
    
    if (!empty($filterStatus)) {
        $stmt->bindParam(':status', $filterStatus);
    }
    if (!empty($filterBloodType)) {
        $stmt->bindParam(':blood_type', $filterBloodType);
    }
    
    $stmt->execute();
    $donations = $stmt->fetchAll();
} catch(PDOException $e) {
    $donations = [];
    $error = 'Error loading donations';
}

// Get blood types for filter
try {
    $bloodTypesSql = "SELECT * FROM blood_types ORDER BY blood_type";
    $stmt = $db->prepare($bloodTypesSql);
    $stmt->execute();
    $bloodTypes = $stmt->fetchAll();
} catch(PDOException $e) {
    $bloodTypes = [];
}

// Get stats
$stats = $db->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
    SUM(CASE WHEN status = 'completed' THEN quantity_ml ELSE 0 END) as total_ml
    FROM donations")->fetch();

$pageTitle = 'Manage Donations';
include '../includes/admin_header.php';
?>

<style>
.stats-card-3d{background:#fff;border-radius:20px;padding:25px;box-shadow:0 10px 40px rgba(0,0,0,0.1);transition:all 0.4s;border-top:5px solid #dc3545}
.stats-card-3d:hover{transform:translateY(-10px);box-shadow:0 20px 60px rgba(0,0,0,0.2)}
.stats-icon-3d{width:70px;height:70px;border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:2rem;background:linear-gradient(135deg,#dc3545 0%,#ff6b6b 100%);color:#fff;box-shadow:0 10px 30px rgba(220,53,69,0.4);animation:float 3s ease-in-out infinite}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
.stats-number{font-size:2.5rem;font-weight:800;background:linear-gradient(135deg,#dc3545,#ff6b6b);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.card-3d{border-radius:20px;border:none;box-shadow:0 15px 45px rgba(0,0,0,0.1);transition:all 0.4s}
.card-3d:hover{transform:translateY(-5px);box-shadow:0 20px 60px rgba(0,0,0,0.15)}
.card-header-3d{background:linear-gradient(135deg,#dc3545,#ff6b6b);color:#fff;border:none;padding:20px;border-radius:20px 20px 0 0}
.btn-3d{border-radius:12px;padding:10px 24px;font-weight:600;transition:all 0.3s;border:none;box-shadow:0 5px 15px rgba(0,0,0,0.2)}
.btn-3d:hover{transform:translateY(-3px);box-shadow:0 8px 25px rgba(0,0,0,0.3)}
.btn-gradient-primary{background:linear-gradient(135deg,#dc3545,#ff6b6b);color:#fff}
.table-3d tbody tr{background:#fff;box-shadow:0 5px 15px rgba(0,0,0,0.08);transition:all 0.3s;margin-bottom:10px}
.table-3d tbody tr:hover{transform:scale(1.01);box-shadow:0 8px 25px rgba(0,0,0,0.15)}
.table-3d tbody td{padding:20px 15px;border:none;vertical-align:middle}
.badge-3d{padding:8px 16px;border-radius:20px;font-weight:600;font-size:0.85rem;box-shadow:0 4px 12px rgba(0,0,0,0.15)}
.donor-avatar-3d{width:50px;height:50px;border-radius:50%;background:linear-gradient(135deg,#dc3545,#ff6b6b);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:1.2rem;box-shadow:0 5px 15px rgba(220,53,69,0.4);transition:all 0.3s ease}
.donor-avatar-3d:hover{transform:scale(1.1);box-shadow:0 8px 20px rgba(220,53,69,0.6)}
.blood-type-badge-3d{padding:10px 20px;border-radius:15px;font-weight:700;font-size:1.1rem;background:linear-gradient(135deg,#dc3545,#ff6b6b);color:#fff;box-shadow:0 5px 15px rgba(220,53,69,0.4);display:inline-block}
.filter-card-3d{background:#fff;border-radius:20px;padding:25px;box-shadow:0 10px 30px rgba(0,0,0,0.1);margin-bottom:30px}
</style>

<div class="container-fluid" style="background:linear-gradient(135deg,#f5f7fa 0%,#c3cfe2 100%);min-height:100vh;padding-bottom:50px">
<div class="row">
<?php include '../includes/admin_sidebar.php'; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

<div style="background:linear-gradient(135deg,#dc3545,#ff6b6b);color:#fff;padding:30px;border-radius:20px;margin-bottom:30px;box-shadow:0 15px 40px rgba(220,53,69,0.3)">
<div class="d-flex justify-content-between align-items-center">
<div><h1 style="font-weight:800"><i class="bi bi-droplet-fill me-3"></i>Donation Management</h1>
<p class="mb-0 mt-2">Manage and track all blood donations</p></div>
</div></div>

<?php if($success): ?>
<div class="alert alert-success alert-dismissible fade show" style="border-radius:15px;border:none;box-shadow:0 5px 15px rgba(25,135,84,0.3)">
<i class="bi bi-check-circle-fill me-2"></i><?=$success?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; if($error): ?>
<div class="alert alert-danger alert-dismissible fade show" style="border-radius:15px;border:none;box-shadow:0 5px 15px rgba(220,53,69,0.3)">
<i class="bi bi-exclamation-triangle-fill me-2"></i><?=$error?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>

<div class="row mb-4">
<div class="col-md-3 mb-3"><div class="stats-card-3d"><div class="d-flex align-items-center">
<div class="stats-icon-3d me-3"><i class="bi bi-droplet-fill"></i></div>
<div><div class="stats-number"><?=number_format($stats['total'])?></div>
<small class="text-muted" style="font-weight:600">Total Donations</small></div></div></div></div>

<div class="col-md-3 mb-3"><div class="stats-card-3d"><div class="d-flex align-items-center">
<div class="stats-icon-3d me-3" style="background:linear-gradient(135deg,#ffc107,#ff9800)"><i class="bi bi-clock-history"></i></div>
<div><div class="stats-number" style="background:linear-gradient(135deg,#ffc107,#ff9800);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><?=number_format($stats['pending'])?></div>
<small class="text-muted" style="font-weight:600">Pending</small></div></div></div></div>

<div class="col-md-3 mb-3"><div class="stats-card-3d"><div class="d-flex align-items-center">
<div class="stats-icon-3d me-3" style="background:linear-gradient(135deg,#28a745,#20c997)"><i class="bi bi-check-circle-fill"></i></div>
<div><div class="stats-number" style="background:linear-gradient(135deg,#28a745,#20c997);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><?=number_format($stats['completed'])?></div>
<small class="text-muted" style="font-weight:600">Completed</small></div></div></div></div>

<div class="col-md-3 mb-3"><div class="stats-card-3d"><div class="d-flex align-items-center">
<div class="stats-icon-3d me-3" style="background:linear-gradient(135deg,#6f42c1,#d63384)"><i class="bi bi-heart-pulse-fill"></i></div>
<div><div class="stats-number" style="background:linear-gradient(135deg,#6f42c1,#d63384);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><?=number_format($stats['total_ml']/1000,1)?> L</div>
<small class="text-muted" style="font-weight:600">Total Collected</small></div></div></div></div>
</div>

<div class="filter-card-3d">
<h5 class="mb-3" style="font-weight:700"><i class="bi bi-funnel me-2" style="color:#dc3545"></i>Filters</h5>
<form method="GET" class="row g-3">
<div class="col-md-5"><label class="form-label" style="font-weight:600">Status</label>
<select name="status" class="form-select" style="border-radius:12px;border:2px solid #e9ecef">
<option value="">All Statuses</option>
<option value="pending" <?=$filterStatus==='pending'?'selected':''?>>Pending</option>
<option value="approved" <?=$filterStatus==='approved'?'selected':''?>>Approved</option>
<option value="completed" <?=$filterStatus==='completed'?'selected':''?>>Completed</option>
<option value="rejected" <?=$filterStatus==='rejected'?'selected':''?>>Rejected</option>
</select></div>
<div class="col-md-4"><label class="form-label" style="font-weight:600">Blood Type</label>
<select name="blood_type" class="form-select" style="border-radius:12px;border:2px solid #e9ecef">
<option value="">All Types</option>
<?php foreach($bloodTypes as $type): ?>
<option value="<?=$type['blood_type']?>" <?=$filterBloodType===$type['blood_type']?'selected':''?>><?=$type['blood_type']?></option>
<?php endforeach; ?>
</select></div>
<div class="col-md-3 d-flex align-items-end">
<button type="submit" class="btn btn-3d btn-gradient-primary me-2"><i class="bi bi-search me-1"></i>Filter</button>
<a href="manage_donations.php" class="btn btn-3d" style="background:#f8f9fa;color:#495057"><i class="bi bi-x-circle me-1"></i>Clear</a>
</div>
</form>
</div>

<div class="card-3d">
<div class="card-header-3d"><h5 class="mb-0" style="font-weight:700"><i class="bi bi-list-check me-2"></i>Donations List (<?=count($donations)?>)</h5></div>
<div class="card-body p-0">
<?php if(count($donations) > 0): ?>
<div class="table-responsive">
<table class="table table-3d mb-0">
<thead><tr><th>Donor</th><th>Blood Type</th><th>Quantity</th><th>Date</th><th>Location</th><th>Status</th><th>Actions</th></tr></thead>
<tbody>
<?php foreach($donations as $donation): ?>
<tr>
<td><div class="d-flex align-items-center">
<div class="donor-avatar-3d me-3"><?=strtoupper(substr($donation['full_name'],0,2))?></div>
<div><strong style="font-size:1.05rem"><?=htmlspecialchars($donation['full_name'])?></strong><br>
<small class="text-muted"><?=htmlspecialchars($donation['email'])?></small></div></div></td>
<td><span class="blood-type-badge-3d"><?=$donation['blood_type']?></span></td>
<td><strong style="font-size:1.3rem;color:#dc3545"><?=$donation['quantity_ml']?></strong> ml</td>
<td><?=date('M j, Y',strtotime($donation['donation_date']))?></td>
<td><small><?=htmlspecialchars($donation['donation_location'])?></small></td>
<td><?php 
$statusBadges = ['pending'=>'warning','approved'=>'info','completed'=>'success','rejected'=>'danger'];
$badgeColor = $statusBadges[$donation['status']] ?? 'secondary';
?>
<span class="badge-3d bg-<?=$badgeColor?>"><i class="bi bi-<?=$donation['status']==='completed'?'check-circle':($donation['status']==='pending'?'clock-history':'info-circle')?> me-1"></i><?=ucfirst($donation['status'])?></span>
</td>
<td>
<div class="btn-group">
<button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editModal<?=$donation['donation_id']?>" style="border-radius:10px"><i class="bi bi-pencil"></i></button>
<button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?=$donation['donation_id']?>" style="border-radius:10px"><i class="bi bi-trash"></i></button>
</div>
</td>
</tr>

<!-- Edit Modal -->
<div class="modal fade" id="editModal<?=$donation['donation_id']?>"><div class="modal-dialog"><div class="modal-content" style="border-radius:20px">
<div class="modal-header" style="background:linear-gradient(135deg,#dc3545,#ff6b6b);color:#fff;border-radius:20px 20px 0 0">
<h5 class="modal-title">Update Donation Status</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<form method="POST"><div class="modal-body">
<input type="hidden" name="csrf_token" value="<?=getCSRFToken()?>">
<input type="hidden" name="donation_id" value="<?=$donation['donation_id']?>">
<div class="mb-3"><label class="form-label">Status</label>
<select name="status" class="form-select" required>
<option value="pending" <?=$donation['status']==='pending'?'selected':''?>>Pending</option>
<option value="approved" <?=$donation['status']==='approved'?'selected':''?>>Approved</option>
<option value="completed" <?=$donation['status']==='completed'?'selected':''?>>Completed</option>
<option value="rejected" <?=$donation['status']==='rejected'?'selected':''?>>Rejected</option>
</select></div>
<div class="mb-3"><label class="form-label">Admin Notes</label>
<textarea name="admin_notes" class="form-control" rows="3"><?=htmlspecialchars($donation['notes'])?></textarea>
</div></div><div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" name="update_status" class="btn btn-3d btn-gradient-primary">Update</button>
</div></form></div></div></div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal<?=$donation['donation_id']?>"><div class="modal-dialog"><div class="modal-content" style="border-radius:20px">
<div class="modal-header" style="background:linear-gradient(135deg,#dc3545,#ff6b6b);color:#fff;border-radius:20px 20px 0 0">
<h5 class="modal-title">Confirm Delete</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body">Are you sure you want to delete this donation record from <strong><?=htmlspecialchars($donation['full_name'])?></strong>?</div>
<div class="modal-footer"><form method="POST">
<input type="hidden" name="csrf_token" value="<?=getCSRFToken()?>">
<input type="hidden" name="donation_id" value="<?=$donation['donation_id']?>">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" name="delete_donation" class="btn btn-danger">Delete</button>
</form></div></div></div></div>

<?php endforeach; ?>
</tbody>
</table>
</div>
<?php else: ?>
<div class="text-center py-5">
<i class="bi bi-droplet" style="font-size:5rem;color:#ddd"></i>
<h4 class="mt-3 text-muted">No Donations Found</h4>
<p class="text-muted">Try adjusting your filters</p>
</div>
<?php endif; ?>
</div>
</div>

</main>
</div>
</div>


<?php include '../includes/footer.php'; ?>
