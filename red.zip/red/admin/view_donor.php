<?php
require_once '../config/config.php';
require_once '../config/db.php';
requireAdmin();

$donor_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($donor_id == 0) {
    header('Location: manage_donors.php');
    exit;
}

// Get donor info with donation history
$stmt = $db->prepare("SELECT di.*, u.username, u.full_name, u.email, u.phone, u.address, bt.blood_type,
       (SELECT COUNT(*) FROM donations d WHERE d.donor_id = di.donor_id AND d.status = 'completed') as completed_donations,
       DATEDIFF(CURDATE(), di.last_donation_date) as days_since_donation
       FROM donors_info di
       JOIN users u ON di.user_id = u.user_id
       JOIN blood_types bt ON di.blood_type_id = bt.blood_type_id
       WHERE di.donor_id = ?");
$stmt->execute([$donor_id]);
$donor = $stmt->fetch();

if (!$donor) {
    header('Location: manage_donors.php');
    exit;
}

// Get donation history
$donationStmt = $db->prepare("SELECT d.*, bt.blood_type 
                               FROM donations d
                               LEFT JOIN blood_types bt ON d.blood_type_id = bt.blood_type_id
                               WHERE d.donor_id = ?
                               ORDER BY d.donation_date DESC
                               LIMIT 10");
$donationStmt->execute([$donor_id]);
$donations = $donationStmt->fetchAll();

$pageTitle = 'Donor Details - ' . htmlspecialchars($donor['full_name']);
include '../includes/admin_header.php';
?>

<style>
body { background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); min-height: 100vh; padding-bottom: 50px; }
.page-header-3d { background: linear-gradient(135deg, #667eea, #764ba2); color: #fff; padding: 40px; border-radius: 20px; margin-bottom: 30px; box-shadow: 0 15px 40px rgba(102,126,234,0.3); }
.card-3d { background: #fff; border-radius: 20px; padding: 30px; box-shadow: 0 15px 45px rgba(0,0,0,0.1); margin-bottom: 20px; }
.donor-avatar-3d { width: 120px; height: 120px; border-radius: 50%; background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 700; font-size: 3rem; box-shadow: 0 10px 30px rgba(102,126,234,0.4); margin: 0 auto; }
.blood-type-badge-3d { padding: 12px 30px; border-radius: 15px; font-weight: 700; font-size: 1.3rem; background: linear-gradient(135deg, #f093fb, #f5576c); color: #fff; box-shadow: 0 5px 15px rgba(245,87,108,0.4); display: inline-block; }
.info-box { background: #f8f9fa; border-radius: 15px; padding: 20px; }
.info-row { display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #dee2e6; }
.info-row:last-child { border-bottom: none; }
.stat-card { background: linear-gradient(135deg, #667eea, #764ba2); color: #fff; padding: 25px; border-radius: 15px; text-align: center; box-shadow: 0 8px 25px rgba(102,126,234,0.3); }
.stat-number { font-size: 2.5rem; font-weight: 800; }
.btn-3d { border-radius: 12px; padding: 12px 30px; font-weight: 600; transition: all 0.3s; border: none; box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
.btn-3d:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(0,0,0,0.3); }
</style>

<div class="container-fluid">
<div class="row">
<?php include '../includes/admin_sidebar.php'; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

<div class="page-header-3d">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h1 style="font-weight: 800"><i class="bi bi-person-circle me-3"></i>Donor Profile</h1>
            <p class="mb-0 mt-2">Complete donor information and donation history</p>
        </div>
        <a href="manage_donors.php" class="btn btn-3d" style="background: #fff; color: #667eea">
            <i class="bi bi-arrow-left me-2"></i>Back to List
        </a>
    </div>
</div>

<div class="row">
    <!-- Profile Card -->
    <div class="col-lg-4 mb-4">
        <div class="card-3d text-center">
            <div class="donor-avatar-3d mb-4">
                <?=strtoupper(substr($donor['full_name'], 0, 2))?>
            </div>
            <h3 style="font-weight: 700; margin-bottom: 10px"><?=htmlspecialchars($donor['full_name'])?></h3>
            <p class="text-muted mb-3">@<?=htmlspecialchars($donor['username'])?></p>
            <span class="blood-type-badge-3d mb-4 d-inline-block"><?=htmlspecialchars($donor['blood_type'])?></span>
            
            <div class="mt-4">
                <?php if($donor['eligible_to_donate'] === 'Yes'): ?>
                <span class="badge bg-success px-4 py-2" style="font-size: 1rem">
                    <i class="bi bi-check-circle me-1"></i>Eligible to Donate
                </span>
                <?php else: ?>
                <span class="badge bg-danger px-4 py-2" style="font-size: 1rem">
                    <i class="bi bi-x-circle me-1"></i>Not Eligible
                </span>
                <?php endif; ?>
            </div>
            
            <div class="d-grid gap-2 mt-4">
                <a href="update_donor_eligibility.php?id=<?=$donor_id?>" class="btn btn-3d" style="background: linear-gradient(135deg, #667eea, #764ba2); color: #fff">
                    <i class="bi bi-pencil me-2"></i>Update Eligibility
                </a>
            </div>
        </div>
    </div>

    <!-- Info Cards -->
    <div class="col-lg-8">
        <!-- Stats -->
        <div class="row mb-4">
            <div class="col-md-4 mb-3">
                <div class="stat-card">
                    <div class="stat-number"><?=$donor['completed_donations']?></div>
                    <div style="font-size: 0.9rem; opacity: 0.9">Total Donations</div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="stat-card" style="background: linear-gradient(135deg, #f093fb, #f5576c)">
                    <div class="stat-number"><?=$donor['weight']?> kg</div>
                    <div style="font-size: 0.9rem; opacity: 0.9">Weight</div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="stat-card" style="background: linear-gradient(135deg, #4facfe, #00f2fe)">
                    <div class="stat-number">
                        <?php if($donor['days_since_donation']): ?>
                            <?=$donor['days_since_donation']?>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </div>
                    <div style="font-size: 0.9rem; opacity: 0.9">Days Since Last</div>
                </div>
            </div>
        </div>

        <!-- Contact Information -->
        <div class="card-3d">
            <h5 style="font-weight: 700; color: #667eea; margin-bottom: 20px">
                <i class="bi bi-person-lines-fill me-2"></i>Contact Information
            </h5>
            <div class="info-box">
                <div class="info-row">
                    <strong><i class="bi bi-envelope me-2"></i>Email</strong>
                    <span><?=htmlspecialchars($donor['email'])?></span>
                </div>
                <div class="info-row">
                    <strong><i class="bi bi-telephone me-2"></i>Phone</strong>
                    <span><?=htmlspecialchars($donor['phone'])?></span>
                </div>
                <div class="info-row">
                    <strong><i class="bi bi-geo-alt me-2"></i>Address</strong>
                    <span><?=htmlspecialchars($donor['address']) ?: 'N/A'?></span>
                </div>
            </div>
        </div>

        <!-- Personal Information -->
        <div class="card-3d">
            <h5 style="font-weight: 700; color: #667eea; margin-bottom: 20px">
                <i class="bi bi-clipboard-data me-2"></i>Personal Information
            </h5>
            <div class="info-box">
                <div class="info-row">
                    <strong><i class="bi bi-calendar me-2"></i>Date of Birth</strong>
                    <span><?=date('F j, Y', strtotime($donor['date_of_birth']))?></span>
                </div>
                <div class="info-row">
                    <strong><i class="bi bi-gender-ambiguous me-2"></i>Gender</strong>
                    <span><?=$donor['gender']?></span>
                </div>
                <div class="info-row">
                    <strong><i class="bi bi-droplet-half me-2"></i>Blood Type</strong>
                    <span class="badge bg-danger"><?=htmlspecialchars($donor['blood_type'])?></span>
                </div>
                <div class="info-row">
                    <strong><i class="bi bi-speedometer me-2"></i>Weight</strong>
                    <span><?=$donor['weight']?> kg</span>
                </div>
                <div class="info-row">
                    <strong><i class="bi bi-calendar-check me-2"></i>Last Donation</strong>
                    <span>
                        <?php if($donor['last_donation_date']): ?>
                            <?=date('F j, Y', strtotime($donor['last_donation_date']))?>
                            <small class="text-muted">(<?=$donor['days_since_donation']?> days ago)</small>
                        <?php else: ?>
                            <span class="badge bg-secondary">Never</span>
                        <?php endif; ?>
                    </span>
                </div>
            </div>

            <?php if($donor['medical_conditions']): ?>
            <div class="mt-3 p-3" style="background: #fff3cd; border-left: 4px solid #ffc107; border-radius: 8px">
                <strong><i class="bi bi-clipboard2-pulse me-2"></i>Medical Conditions:</strong>
                <p class="mb-0 mt-2"><?=nl2br(htmlspecialchars($donor['medical_conditions']))?></p>
            </div>
            <?php endif; ?>
        </div>

        <!-- Donation History -->
        <div class="card-3d">
            <h5 style="font-weight: 700; color: #667eea; margin-bottom: 20px">
                <i class="bi bi-clock-history me-2"></i>Recent Donation History
            </h5>
            
            <?php if(count($donations) > 0): ?>
            <div class="table-responsive">
                <table class="table">
                    <thead style="background: #f8f9fa">
                        <tr>
                            <th>Date</th>
                            <th>Blood Type</th>
                            <th>Quantity</th>
                            <th>Location</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($donations as $donation): ?>
                        <tr>
                            <td><?=date('M j, Y', strtotime($donation['donation_date']))?></td>
                            <td><span class="badge bg-danger"><?=$donation['blood_type']?></span></td>
                            <td><?=$donation['quantity_ml']?> ml</td>
                            <td><?=htmlspecialchars($donation['donation_location'])?></td>
                            <td>
                                <?php 
                                $statusColors = ['pending' => 'warning', 'approved' => 'info', 'completed' => 'success', 'rejected' => 'danger'];
                                $statusColor = $statusColors[$donation['status']] ?? 'secondary';
                                ?>
                                <span class="badge bg-<?=$statusColor?>">
                                    <?=ucfirst($donation['status'])?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-4" style="background: #f8f9fa; border-radius: 10px">
                <i class="bi bi-inbox" style="font-size: 3rem; color: #ddd"></i>
                <p class="text-muted mt-2 mb-0">No donation records found</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

</main>
</div>
</div>

<?php include '../includes/footer.php'; ?>
