<?php
require_once '../config/config.php';
require_once '../config/db.php';
requireAdmin();

$donor_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$success = $error = '';

if ($donor_id == 0) {
    header('Location: manage_donors.php');
    exit;
}

// Get donor info
$stmt = $db->prepare("SELECT di.*, u.username, u.full_name, u.email, u.phone, bt.blood_type,
       (SELECT COUNT(*) FROM donations d WHERE d.donor_id = di.donor_id AND d.status = 'completed') as completed_donations
       FROM donors_info di
       JOIN users u ON di.user_id = u.user_id
       JOIN blood_types bt ON di.blood_type_id = bt.blood_type_id
       WHERE di.donor_id = ?");
$stmt->execute([$donor_id]);
$donor = $stmt->fetch();

if (!$donor) {
    header('Location: manage_donors.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCSRF($_POST['csrf_token'])) {
    try {
        $eligible = sanitize($_POST['eligible_to_donate']);
        $db->prepare("UPDATE donors_info SET eligible_to_donate = ? WHERE donor_id = ?")->execute([$eligible, $donor_id]);
        
        if ($eligible === 'Yes') {
            notifyDonationEligibility($db, $donor['user_id'], null);
        }
        
        $success = "Donor eligibility updated successfully!";
        
        // Refresh donor data
        $stmt->execute([$donor_id]);
        $donor = $stmt->fetch();
    } catch(PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}

$pageTitle = 'Update Donor Eligibility';
include '../includes/admin_header.php';
?>

<style>
body { background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); min-height: 100vh; }
.page-header-3d { background: linear-gradient(135deg, #667eea, #764ba2); color: #fff; padding: 40px; border-radius: 20px; margin-bottom: 30px; box-shadow: 0 15px 40px rgba(102,126,234,0.3); }
.card-3d { background: #fff; border-radius: 20px; padding: 30px; box-shadow: 0 15px 45px rgba(0,0,0,0.1); }
.donor-avatar-3d { width: 100px; height: 100px; border-radius: 50%; background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 700; font-size: 2.5rem; box-shadow: 0 8px 20px rgba(102,126,234,0.4); margin: 0 auto; }
.blood-type-badge-3d { padding: 10px 25px; border-radius: 15px; font-weight: 700; font-size: 1.2rem; background: linear-gradient(135deg, #f093fb, #f5576c); color: #fff; box-shadow: 0 5px 15px rgba(245,87,108,0.4); display: inline-block; }
.info-box { background: #f8f9fa; border-radius: 15px; padding: 20px; margin-bottom: 20px; }
.btn-3d { border-radius: 12px; padding: 12px 30px; font-weight: 600; transition: all 0.3s; border: none; box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
.btn-3d:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(0,0,0,0.3); }
.btn-gradient-primary { background: linear-gradient(135deg, #667eea, #764ba2); color: #fff; }
</style>

<div class="container-fluid">
<div class="row">
<?php include '../includes/admin_sidebar.php'; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

<div class="page-header-3d">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h1 style="font-weight: 800"><i class="bi bi-pencil-square me-3"></i>Update Donor Eligibility</h1>
            <p class="mb-0 mt-2">Manage donor eligibility status</p>
        </div>
        <a href="manage_donors.php" class="btn btn-3d" style="background: #fff; color: #667eea">
            <i class="bi bi-arrow-left me-2"></i>Back to List
        </a>
    </div>
</div>

<?php if($success): ?>
<div class="alert alert-success alert-dismissible fade show" style="border-radius: 15px; border: none; box-shadow: 0 5px 15px rgba(25,135,84,0.3)">
    <i class="bi bi-check-circle-fill me-2"></i><?=$success?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; if($error): ?>
<div class="alert alert-danger alert-dismissible fade show" style="border-radius: 15px; border: none; box-shadow: 0 5px 15px rgba(220,53,69,0.3)">
    <i class="bi bi-exclamation-triangle-fill me-2"></i><?=$error?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-4 mb-4">
        <div class="card-3d text-center">
            <div class="donor-avatar-3d mb-3">
                <?=strtoupper(substr($donor['full_name'], 0, 2))?>
            </div>
            <h3 style="font-weight: 700"><?=htmlspecialchars($donor['full_name'])?></h3>
            <p class="text-muted mb-3">@<?=htmlspecialchars($donor['username'])?></p>
            <span class="blood-type-badge-3d"><?=htmlspecialchars($donor['blood_type'])?></span>
        </div>
    </div>

    <div class="col-lg-8 mb-4">
        <div class="card-3d">
            <h5 style="font-weight: 700; color: #667eea; margin-bottom: 20px">
                <i class="bi bi-person-circle me-2"></i>Donor Information
            </h5>
            
            <div class="info-box">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <strong><i class="bi bi-envelope me-2"></i>Email:</strong><br>
                        <?=htmlspecialchars($donor['email'])?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <strong><i class="bi bi-telephone me-2"></i>Phone:</strong><br>
                        <?=htmlspecialchars($donor['phone'])?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <strong><i class="bi bi-calendar me-2"></i>Date of Birth:</strong><br>
                        <?=date('F j, Y', strtotime($donor['date_of_birth']))?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <strong><i class="bi bi-gender-ambiguous me-2"></i>Gender:</strong><br>
                        <?=$donor['gender']?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <strong><i class="bi bi-speedometer me-2"></i>Weight:</strong><br>
                        <?=$donor['weight']?> kg
                    </div>
                    <div class="col-md-6 mb-3">
                        <strong><i class="bi bi-droplet-fill me-2"></i>Total Donations:</strong><br>
                        <span style="font-size: 1.3rem; color: #667eea; font-weight: 700"><?=$donor['completed_donations']?></span> times
                    </div>
                    <div class="col-12">
                        <strong><i class="bi bi-calendar-check me-2"></i>Last Donation:</strong><br>
                        <?php if($donor['last_donation_date']): ?>
                            <?=date('F j, Y', strtotime($donor['last_donation_date']))?>
                            <small class="text-muted">(<?=floor((time() - strtotime($donor['last_donation_date'])) / 86400)?> days ago)</small>
                        <?php else: ?>
                            <span class="badge bg-secondary">Never donated</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if($donor['medical_conditions']): ?>
            <div class="info-box mt-3">
                <strong><i class="bi bi-clipboard2-pulse me-2"></i>Medical Conditions:</strong><br>
                <p class="mb-0 mt-2"><?=nl2br(htmlspecialchars($donor['medical_conditions']))?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="card-3d">
    <h5 style="font-weight: 700; color: #667eea; margin-bottom: 20px">
        <i class="bi bi-clipboard-check me-2"></i>Update Eligibility Status
    </h5>
    
    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?=getCSRFToken()?>">
        
        <div class="mb-4">
            <label class="form-label" style="font-weight: 600; font-size: 1.1rem">Eligibility Status</label>
            <select name="eligible_to_donate" class="form-select form-select-lg" style="border-radius: 12px; border: 2px solid #e9ecef" required>
                <option value="Yes" <?=$donor['eligible_to_donate']=='Yes'?'selected':''?>>
                    ✓ Eligible to Donate
                </option>
                <option value="No" <?=$donor['eligible_to_donate']=='No'?'selected':''?>>
                    ✗ Not Eligible to Donate
                </option>
            </select>
            <small class="text-muted">
                <i class="bi bi-info-circle me-1"></i>
                Setting to "Eligible" will send a notification to the donor
            </small>
        </div>

        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-3d btn-gradient-primary">
                <i class="bi bi-check-circle me-2"></i>Update Eligibility
            </button>
            <a href="manage_donors.php" class="btn btn-3d" style="background: #6c757d; color: #fff">
                <i class="bi bi-x-circle me-2"></i>Cancel
            </a>
        </div>
    </form>
</div>

</main>
</div>
</div>

<?php include '../includes/footer.php'; ?>
