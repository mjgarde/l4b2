<?php
require_once '../config/config.php';
require_once '../config/db.php';

// Check if admin is logged in
requireAdmin();

$error = '';
$success = '';

// Get user_id from URL
$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($user_id == 0) {
    header('Location: manage_users.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        if (isset($_POST['update_status'])) {
            $status = sanitize($_POST['status']);
            
            try {
                $sql = "UPDATE users SET status = :status WHERE user_id = :user_id";
                $stmt = $db->prepare($sql);
                $result = $stmt->execute([':status' => $status, ':user_id' => $user_id]);
                
                if ($result) {
                    logAudit($db, $_SESSION['user_id'], 'User Status Updated', 'users', $user_id, "Status updated to: $status");
                    $success = 'User status updated successfully!';
                }
            } catch(PDOException $e) {
                $error = 'Error updating status: ' . $e->getMessage();
            }
        }
        
        if (isset($_POST['update_role'])) {
            $role = sanitize($_POST['user_role']);
            
            try {
                $sql = "UPDATE users SET user_role = :role WHERE user_id = :user_id";
                $stmt = $db->prepare($sql);
                $result = $stmt->execute([':role' => $role, ':user_id' => $user_id]);
                
                if ($result) {
                    logAudit($db, $_SESSION['user_id'], 'User Role Updated', 'users', $user_id, "Role updated to: $role");
                    $success = 'User role updated successfully!';
                }
            } catch(PDOException $e) {
                $error = 'Error updating role: ' . $e->getMessage();
            }
        }
    }
}

// Get user information
$sql = "SELECT u.*, bt.blood_type 
        FROM users u
        LEFT JOIN blood_types bt ON u.blood_type_id = bt.blood_type_id
        WHERE u.user_id = :user_id";
$stmt = $db->prepare($sql);
$stmt->execute([':user_id' => $user_id]);
$user = $stmt->fetch();

if (!$user) {
    header('Location: manage_users.php');
    exit;
}

$pageTitle = "Edit User - " . htmlspecialchars($user['full_name']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body { background: #f0f2f5; padding-top: 70px; }
        .edit-header { background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 30px; border-radius: 15px; margin-bottom: 30px; }
        .user-avatar { width: 80px; height: 80px; border-radius: 50%; background: white; color: #667eea; display: flex; align-items: center; justify-content: center; font-size: 2rem; font-weight: bold; margin-right: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
        .edit-card { background: white; border-radius: 15px; padding: 30px; margin-bottom: 20px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
        .btn-back { background: white; color: #667eea; border: 2px solid white; }
        .btn-back:hover { background: transparent; color: white; }
    </style>
</head>
<body>
    <?php include '../includes/admin_header.php'; ?>

    <div class="container">
        <!-- Back Button -->
        <a href="manage_users.php" class="btn btn-secondary mb-3">
            <i class="bi bi-arrow-left"></i> Back to User Management
        </a>

        <!-- Edit Header -->
        <div class="edit-header">
            <div class="d-flex align-items-center">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($user['full_name'], 0, 2)); ?>
                </div>
                <div>
                    <h2 class="mb-1">Edit User</h2>
                    <p class="mb-0"><?php echo htmlspecialchars($user['full_name']); ?> (@<?php echo htmlspecialchars($user['username']); ?>)</p>
                </div>
            </div>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="bi bi-check-circle-fill me-2"></i><?php echo $success; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <!-- User Information -->
            <div class="col-md-4">
                <div class="edit-card">
                    <h5 class="fw-bold mb-3"><i class="bi bi-person-circle me-2"></i>User Information</h5>
                    <div class="mb-2">
                        <strong>Username:</strong><br>
                        <span class="text-muted">@<?php echo htmlspecialchars($user['username']); ?></span>
                    </div>
                    <div class="mb-2">
                        <strong>Email:</strong><br>
                        <span class="text-muted"><?php echo htmlspecialchars($user['email']); ?></span>
                    </div>
                    <div class="mb-2">
                        <strong>Phone:</strong><br>
                        <span class="text-muted"><?php echo htmlspecialchars($user['phone']) ?: 'N/A'; ?></span>
                    </div>
                    <div class="mb-2">
                        <strong>Blood Type:</strong><br>
                        <span class="text-muted"><?php echo $user['blood_type'] ?: 'Not specified'; ?></span>
                    </div>
                    <div class="mb-0">
                        <strong>Registered:</strong><br>
                        <span class="text-muted"><?php echo date('F j, Y', strtotime($user['created_at'])); ?></span>
                    </div>
                </div>

                <div class="edit-card">
                    <h5 class="fw-bold mb-3"><i class="bi bi-eye-fill me-2"></i>Quick Actions</h5>
                    <div class="d-grid gap-2">
                        <a href="view_user_profile.php?id=<?php echo $user_id; ?>" class="btn btn-outline-primary">
                            <i class="bi bi-eye me-1"></i> View Full Profile
                        </a>
                        <a href="manage_users.php" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left me-1"></i> Back to List
                        </a>
                    </div>
                </div>
            </div>

            <!-- Edit Forms -->
            <div class="col-md-8">
                <!-- Update Status -->
                <div class="edit-card">
                    <h5 class="fw-bold mb-3"><i class="bi bi-shield-check me-2"></i>Update Status</h5>
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Current Status</label>
                            <div class="mb-3">
                                <span class="badge bg-<?php echo ['active'=>'success','inactive'=>'secondary','suspended'=>'danger','pending'=>'warning'][$user['status']]; ?> fs-5">
                                    <?php echo ucfirst($user['status']); ?>
                                </span>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">New Status</label>
                            <select name="status" class="form-select form-select-lg" required>
                                <option value="active" <?php echo $user['status'] === 'active' ? 'selected' : ''; ?>>Active - User can access the system</option>
                                <option value="inactive" <?php echo $user['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive - User account is disabled</option>
                                <option value="suspended" <?php echo $user['status'] === 'suspended' ? 'selected' : ''; ?>>Suspended - User is temporarily blocked</option>
                                <option value="pending" <?php echo $user['status'] === 'pending' ? 'selected' : ''; ?>>Pending - Waiting for approval</option>
                            </select>
                        </div>

                        <button type="submit" name="update_status" class="btn btn-primary btn-lg w-100">
                            <i class="bi bi-shield-check me-2"></i>Update Status
                        </button>
                    </form>
                </div>

                <!-- Update Role -->
                <div class="edit-card">
                    <h5 class="fw-bold mb-3"><i class="bi bi-person-badge me-2"></i>Update Role</h5>
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Current Role</label>
                            <div class="mb-3">
                                <span class="badge bg-<?php echo $user['user_role'] === 'admin' ? 'danger' : 'primary'; ?> fs-5">
                                    <?php echo ucfirst($user['user_role']); ?>
                                </span>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">New Role</label>
                            <select name="user_role" class="form-select form-select-lg" required>
                                <option value="user" <?php echo $user['user_role'] === 'user' ? 'selected' : ''; ?>>User - Regular user with limited access</option>
                                <option value="admin" <?php echo $user['user_role'] === 'admin' ? 'selected' : ''; ?>>Admin - Full system access</option>
                            </select>
                            <div class="form-text text-danger">
                                <i class="bi bi-exclamation-triangle me-1"></i>
                                <strong>Warning:</strong> Changing to Admin gives full system access!
                            </div>
                        </div>

                        <button type="submit" name="update_role" class="btn btn-danger btn-lg w-100">
                            <i class="bi bi-person-badge me-2"></i>Update Role
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
