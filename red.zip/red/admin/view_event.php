<?php
require_once '../config/config.php';
require_once '../config/db.php';
requireAdmin();

$event_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($event_id == 0) {
    header('Location: manage_events.php');
    exit;
}

// Get event details
$stmt = $db->prepare("SELECT e.*, 
       (SELECT COUNT(*) FROM appointments WHERE event_id = e.event_id) as registered_count 
       FROM events e WHERE e.event_id = ?");
$stmt->execute([$event_id]);
$event = $stmt->fetch();

if (!$event) {
    header('Location: manage_events.php');
    exit;
}

// Get registered participants
$participantsStmt = $db->prepare("SELECT a.*, u.full_name, u.email, u.phone 
                                   FROM appointments a 
                                   JOIN users u ON a.user_id = u.user_id 
                                   WHERE a.event_id = ? 
                                   ORDER BY a.created_at ASC");
$participantsStmt->execute([$event_id]);
$participants = $participantsStmt->fetchAll();

$percentage = $event['max_participants'] > 0 ? round(($event['registered_count'] / $event['max_participants']) * 100) : 0;

$pageTitle = 'Event Details - ' . htmlspecialchars($event['event_name']);
include '../includes/admin_header.php';
?>

<style>
body { background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); min-height: 100vh; }
.page-header-3d { background: linear-gradient(135deg, #28a745, #20c997); color: #fff; padding: 40px; border-radius: 20px; margin-bottom: 30px; box-shadow: 0 15px 40px rgba(40,167,69,0.3); }
.card-3d { background: #fff; border-radius: 20px; padding: 30px; box-shadow: 0 15px 45px rgba(0,0,0,0.1); margin-bottom: 20px; }
.event-icon-3d { width: 100px; height: 100px; border-radius: 50%; background: linear-gradient(135deg, #28a745, #20c997); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 700; font-size: 2.5rem; box-shadow: 0 8px 20px rgba(40,167,69,0.4); margin: 0 auto; }
.badge-3d { padding: 10px 25px; border-radius: 15px; font-weight: 700; font-size: 1.2rem; box-shadow: 0 5px 15px rgba(0,0,0,0.4); display: inline-block; }
.info-box { background: #f8f9fa; border-radius: 15px; padding: 20px; margin-bottom: 20px; }
.btn-3d { border-radius: 12px; padding: 12px 30px; font-weight: 600; transition: all 0.3s; border: none; box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
.btn-3d:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(0,0,0,0.3); }
.progress-3d { height: 12px; border-radius: 10px; background: #e9ecef; overflow: hidden; }
.progress-fill-3d { background: linear-gradient(135deg, #28a745, #20c997); height: 100%; transition: width 0.5s ease; border-radius: 10px; }
.participant-avatar { width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, #28a745, #20c997); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 700; font-size: 1rem; }
</style>

<div class="container-fluid">
<div class="row">
<?php include '../includes/admin_sidebar.php'; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

<div class="page-header-3d">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h1 style="font-weight: 800"><i class="bi bi-calendar-event me-3"></i>Event Details</h1>
            <p class="mb-0 mt-2">Complete information about this event</p>
        </div>
        <a href="manage_events.php" class="btn btn-3d" style="background: #fff; color: #28a745">
            <i class="bi bi-arrow-left me-2"></i>Back to Events
        </a>
    </div>
</div>

<div class="row">
    <!-- Event Info Card -->
    <div class="col-lg-4 mb-4">
        <div class="card-3d text-center">
            <div class="event-icon-3d mb-3">
                <i class="bi bi-calendar-heart"></i>
            </div>
            <h3 style="font-weight: 700"><?=htmlspecialchars($event['event_name'])?></h3>
            <p class="text-muted mb-3"><?=date('l, F j, Y', strtotime($event['event_date']))?></p>
            <?php 
            $statusColors = ['upcoming'=>'primary','ongoing'=>'warning','completed'=>'info','cancelled'=>'danger'];
            $statusColor = $statusColors[$event['status']] ?? 'secondary';
            ?>
            <span class="badge-3d bg-<?=$statusColor?>"><?=ucfirst($event['status'])?></span>
        </div>

        <!-- Capacity Card -->
        <div class="card-3d">
            <h5 style="font-weight: 700; color: #28a745; margin-bottom: 20px">
                <i class="bi bi-people me-2"></i>Participant Capacity
            </h5>
            <div class="text-center mb-3">
                <h2 style="font-weight: 800; color: #28a745"><?=$event['registered_count']?> / <?=$event['max_participants']?></h2>
                <p class="text-muted">Registered Participants (<?=$percentage?>%)</p>
            </div>
            <div class="progress-3d">
                <div class="progress-fill-3d" style="width: <?=$percentage?>%; background: <?=$percentage>=80?'linear-gradient(135deg,#dc3545,#ff6b6b)':($percentage>=50?'linear-gradient(135deg,#ffc107,#ff9800)':'linear-gradient(135deg,#28a745,#20c997)')?>"></div>
            </div>
            <?php if($percentage >= 80): ?>
            <div class="alert alert-warning mt-3 mb-0">
                <i class="bi bi-exclamation-triangle me-2"></i>
                <strong>Almost Full!</strong> Limited slots remaining.
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Event Details -->
    <div class="col-lg-8 mb-4">
        <div class="card-3d">
            <h5 style="font-weight: 700; color: #28a745; margin-bottom: 20px">
                <i class="bi bi-info-circle me-2"></i>Event Information
            </h5>
            
            <div class="info-box">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <strong><i class="bi bi-calendar3 me-2"></i>Date:</strong><br>
                        <?=date('l, F j, Y', strtotime($event['event_date']))?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <strong><i class="bi bi-geo-alt me-2"></i>Location:</strong><br>
                        <?=htmlspecialchars($event['event_location'])?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <strong><i class="bi bi-person me-2"></i>Organizer:</strong><br>
                        <?=htmlspecialchars($event['organizer'])?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <strong><i class="bi bi-people me-2"></i>Max Participants:</strong><br>
                        <?=$event['max_participants']?> people
                    </div>
                    <div class="col-md-6 mb-3">
                        <strong><i class="bi bi-check-circle me-2"></i>Registered:</strong><br>
                        <span style="font-size: 1.3rem; color: #28a745; font-weight: 700"><?=$event['registered_count']?></span> participants
                    </div>
                    <div class="col-md-6 mb-3">
                        <strong><i class="bi bi-tag me-2"></i>Status:</strong><br>
                        <span class="badge bg-<?=$statusColor?>"><?=ucfirst($event['status'])?></span>
                    </div>
                </div>
            </div>

            <div class="info-box mt-3">
                <strong><i class="bi bi-file-text me-2"></i>Description:</strong>
                <p class="mb-0 mt-2"><?=nl2br(htmlspecialchars($event['event_description']))?></p>
            </div>

            <div class="mt-3">
                <small class="text-muted">
                    <i class="bi bi-clock me-1"></i>Created: <?=formatDateTime($event['created_at'])?>
                </small>
            </div>
        </div>

        <!-- Registered Participants -->
        <div class="card-3d">
            <h5 style="font-weight: 700; color: #28a745; margin-bottom: 20px">
                <i class="bi bi-people-fill me-2"></i>Registered Participants (<?=count($participants)?>)
            </h5>
            
            <?php if(count($participants) > 0): ?>
            <div class="table-responsive">
                <table class="table">
                    <thead style="background: #f8f9fa">
                        <tr>
                            <th>Participant</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Registered At</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($participants as $p): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="participant-avatar me-2">
                                        <?=strtoupper(substr($p['full_name'], 0, 2))?>
                                    </div>
                                    <strong><?=htmlspecialchars($p['full_name'])?></strong>
                                </div>
                            </td>
                            <td><?=htmlspecialchars($p['email'])?></td>
                            <td><?=htmlspecialchars($p['phone'])?></td>
                            <td><?=date('M j, Y', strtotime($p['created_at']))?></td>
                            <td>
                                <?php 
                                $aptStatusColors = ['scheduled'=>'warning','confirmed'=>'info','completed'=>'success','cancelled'=>'danger'];
                                $aptColor = $aptStatusColors[$p['status']] ?? 'secondary';
                                ?>
                                <span class="badge bg-<?=$aptColor?>"><?=ucfirst($p['status'])?></span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-4" style="background: #f8f9fa; border-radius: 10px">
                <i class="bi bi-person-x" style="font-size: 3rem; color: #ddd"></i>
                <p class="text-muted mt-2 mb-0">No participants registered yet</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

</main>
</div>
</div>

<?php include '../includes/footer.php'; ?>
