<?php
/**
 * Manage Blood Requests - Admin
 * CRUD operations for blood requests
 */

require_once '../config/config.php';
require_once '../config/db.php';
require_once 'sms_functions.php';

requireAdmin();

$error = '';
$success = '';

// Handle status update
if (isset($_POST['update_status'])) {
    if (!validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        $requestId = intval($_POST['request_id']);
        $status = sanitize($_POST['status']);
        $adminNotes = sanitize($_POST['admin_notes']);
        
        try {
            $updateSql = "UPDATE requests SET status = :status, updated_at = NOW() 
                         WHERE request_id = :request_id";
            $stmt = $db->prepare($updateSql);
            $result = $stmt->execute([
                ':status' => $status,
                ':request_id' => $requestId
            ]);
            
            if ($result) {
                // Get request details with user info
                $requestSql = "SELECT r.*, u.full_name, u.phone, bt.blood_type 
                              FROM requests r 
                              JOIN users u ON r.user_id = u.user_id 
                              JOIN blood_types bt ON r.blood_type_id = bt.blood_type_id 
                              WHERE r.request_id = :request_id";
                $stmt = $db->prepare($requestSql);
                $stmt->execute([':request_id' => $requestId]);
                $request = $stmt->fetch();
                
                // If fulfilled, update inventory
                if ($status === 'fulfilled' && $request) {
                    $inventorySql = "UPDATE inventory SET quantity_ml = quantity_ml - :quantity1 
                                    WHERE blood_type_id = :blood_type_id AND status = 'available' AND quantity_ml >= :quantity2
                                    LIMIT 1";
                    $stmt = $db->prepare($inventorySql);
                    $stmt->execute([
                        ':quantity1' => $request['quantity_ml'],
                        ':quantity2' => $request['quantity_ml'],
                        ':blood_type_id' => $request['blood_type_id']
                    ]);
                }
                
                // Send in-app notification
                if ($request) {
                    createNotification($db, $request['user_id'], 'Request ' . ucfirst($status), 
                        'Your blood request has been ' . $status . '. ' . $adminNotes, 
                        $status === 'fulfilled' ? 'success' : 'info');
                    
                    // Send SMS notification if phone exists
                    if (!empty($request['phone'])) {
                        $smsMessage = '';
                        
                        if ($status === 'approved') {
                            $smsMessage = "Good news {$request['full_name']}! Your blood request for {$request['blood_type']} ({$request['quantity_ml']}ml) has been APPROVED by Koronadal Red Cross. We will process your request shortly.";
                        } elseif ($status === 'fulfilled') {
                            $smsMessage = "Hello {$request['full_name']}, your blood request for {$request['blood_type']} ({$request['quantity_ml']}ml) has been FULFILLED by Koronadal Red Cross. Thank you!";
                        } elseif ($status === 'rejected') {
                            $smsMessage = "We regret to inform you {$request['full_name']} that your blood request for {$request['blood_type']} has been REJECTED.";
                            if (!empty($adminNotes)) {
                                $smsMessage .= " Reason: {$adminNotes}";
                            }
                        }
                        
                        if (!empty($smsMessage)) {
                            $smsResult = sendUserSMS($request['phone'], $smsMessage);
                            if ($smsResult['success']) {
                                error_log("Request SMS sent to {$request['phone']}: {$smsResult['message']}");
                            } else {
                                error_log("Request SMS failed to {$request['phone']}: {$smsResult['message']}");
                            }
                        }
                    }
                }
                
                logAudit($db, $_SESSION['user_id'], 'Request Status Updated', 'requests', $requestId, 
                    'Status changed to ' . $status);
                
                $success = 'Request status updated successfully!';
            }
        } catch(PDOException $e) {
            $error = 'Error updating request: ' . $e->getMessage();
        }
    }
}

// Handle delete
if (isset($_POST['delete_request'])) {
    if (!validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        $requestId = intval($_POST['request_id']);
        
        try {
            $deleteSql = "DELETE FROM requests WHERE request_id = :request_id";
            $stmt = $db->prepare($deleteSql);
            $result = $stmt->execute([':request_id' => $requestId]);
            
            if ($result) {
                logAudit($db, $_SESSION['user_id'], 'Request Deleted', 'requests', $requestId, 
                    'Request record deleted');
                $success = 'Request deleted successfully!';
            }
        } catch(PDOException $e) {
            $error = 'Error deleting request: ' . $e->getMessage();
        }
    }
}

// Get all requests with filters
$filterStatus = isset($_GET['status']) ? sanitize($_GET['status']) : '';
$filterUrgency = isset($_GET['urgency']) ? sanitize($_GET['urgency']) : '';

try {
    $sql = "SELECT r.*, u.full_name, u.email, bt.blood_type 
            FROM requests r 
            JOIN users u ON r.user_id = u.user_id 
            JOIN blood_types bt ON r.blood_type_id = bt.blood_type_id 
            WHERE 1=1";
    
    if (!empty($filterStatus)) {
        $sql .= " AND r.status = :status";
    }
    if (!empty($filterUrgency)) {
        $sql .= " AND r.urgency = :urgency";
    }
    
    $sql .= " ORDER BY 
              CASE r.urgency 
                WHEN 'Critical' THEN 1 
                WHEN 'High' THEN 2 
                WHEN 'Medium' THEN 3 
                WHEN 'Low' THEN 4 
              END, r.created_at DESC";
    
    $stmt = $db->prepare($sql);
    
    if (!empty($filterStatus)) {
        $stmt->bindParam(':status', $filterStatus);
    }
    if (!empty($filterUrgency)) {
        $stmt->bindParam(':urgency', $filterUrgency);
    }
    
    $stmt->execute();
    $requests = $stmt->fetchAll();
} catch(PDOException $e) {
    $requests = [];
    $error = 'Error loading requests';
}

// Get stats
$stats = $db->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
    SUM(CASE WHEN status = 'fulfilled' THEN 1 ELSE 0 END) as fulfilled,
    SUM(CASE WHEN urgency = 'Critical' THEN 1 ELSE 0 END) as critical
    FROM requests")->fetch();

$pageTitle = 'Manage Requests';
include '../includes/admin_header.php';
?>

<style>
.stats-card-3d{background:#fff;border-radius:20px;padding:25px;box-shadow:0 10px 40px rgba(0,0,0,0.1);transition:all 0.4s;border-top:5px solid #0d6efd}
.stats-card-3d:hover{transform:translateY(-10px);box-shadow:0 20px 60px rgba(0,0,0,0.2)}
.stats-icon-3d{width:70px;height:70px;border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:2rem;background:linear-gradient(135deg,#0d6efd 0%,#0a58ca 100%);color:#fff;box-shadow:0 10px 30px rgba(13,110,253,0.4);animation:float 3s ease-in-out infinite}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
.stats-number{font-size:2.5rem;font-weight:800;background:linear-gradient(135deg,#0d6efd,#0a58ca);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.card-3d{border-radius:20px;border:none;box-shadow:0 15px 45px rgba(0,0,0,0.1);transition:all 0.4s}
.card-3d:hover{transform:translateY(-5px);box-shadow:0 20px 60px rgba(0,0,0,0.15)}
.card-header-3d{background:linear-gradient(135deg,#0d6efd,#0a58ca);color:#fff;border:none;padding:20px;border-radius:20px 20px 0 0}
.btn-3d{border-radius:12px;padding:10px 24px;font-weight:600;transition:all 0.3s;border:none;box-shadow:0 5px 15px rgba(0,0,0,0.2)}
.btn-3d:hover{transform:translateY(-3px);box-shadow:0 8px 25px rgba(0,0,0,0.3)}
.btn-gradient-primary{background:linear-gradient(135deg,#0d6efd,#0a58ca);color:#fff}
.table-3d tbody tr{background:#fff;box-shadow:0 5px 15px rgba(0,0,0,0.08);transition:all 0.3s;margin-bottom:10px}
.table-3d tbody tr:hover{transform:scale(1.01);box-shadow:0 8px 25px rgba(0,0,0,0.15)}
.table-3d tbody td{padding:20px 15px;border:none;vertical-align:middle}
.badge-3d{padding:8px 16px;border-radius:20px;font-weight:600;font-size:0.85rem;box-shadow:0 4px 12px rgba(0,0,0,0.15)}
.user-avatar-3d{width:50px;height:50px;border-radius:50%;background:linear-gradient(135deg,#0d6efd,#0a58ca);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:1.2rem;box-shadow:0 5px 15px rgba(13,110,253,0.4);transition:all 0.3s ease}
.user-avatar-3d:hover{transform:scale(1.1);box-shadow:0 8px 20px rgba(13,110,253,0.6)}
.blood-type-badge-3d{padding:10px 20px;border-radius:15px;font-weight:700;font-size:1.1rem;background:linear-gradient(135deg,#0d6efd,#0a58ca);color:#fff;box-shadow:0 5px 15px rgba(13,110,253,0.4);display:inline-block}
.filter-card-3d{background:#fff;border-radius:20px;padding:25px;box-shadow:0 10px 30px rgba(0,0,0,0.1);margin-bottom:30px}
.urgency-critical{border-left:5px solid #dc3545 !important}
</style>

<div class="container-fluid" style="background:linear-gradient(135deg,#f5f7fa 0%,#c3cfe2 100%);min-height:100vh;padding-bottom:50px">
<div class="row">
<?php include '../includes/admin_sidebar.php'; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

<div style="background:linear-gradient(135deg,#0d6efd,#0a58ca);color:#fff;padding:30px;border-radius:20px;margin-bottom:30px;box-shadow:0 15px 40px rgba(13,110,253,0.3)">
<div class="d-flex justify-content-between align-items-center">
<div><h1 style="font-weight:800"><i class="bi bi-bandaid me-3"></i>Blood Request Management</h1>
<p class="mb-0 mt-2">Manage and process all blood requests</p></div>
</div></div>

<?php if($success): ?>
<div class="alert alert-success alert-dismissible fade show" style="border-radius:15px;border:none;box-shadow:0 5px 15px rgba(25,135,84,0.3)">
<i class="bi bi-check-circle-fill me-2"></i><?=$success?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; if($error): ?>
<div class="alert alert-danger alert-dismissible fade show" style="border-radius:15px;border:none;box-shadow:0 5px 15px rgba(220,53,69,0.3)">
<i class="bi bi-exclamation-triangle-fill me-2"></i><?=$error?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>

<div class="row mb-4">
<div class="col-md-3 mb-3"><div class="stats-card-3d"><div class="d-flex align-items-center">
<div class="stats-icon-3d me-3"><i class="bi bi-bandaid"></i></div>
<div><div class="stats-number"><?=number_format($stats['total'])?></div>
<small class="text-muted" style="font-weight:600">Total Requests</small></div></div></div></div>

<div class="col-md-3 mb-3"><div class="stats-card-3d"><div class="d-flex align-items-center">
<div class="stats-icon-3d me-3" style="background:linear-gradient(135deg,#ffc107,#ff9800)"><i class="bi bi-clock-history"></i></div>
<div><div class="stats-number" style="background:linear-gradient(135deg,#ffc107,#ff9800);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><?=number_format($stats['pending'])?></div>
<small class="text-muted" style="font-weight:600">Pending</small></div></div></div></div>

<div class="col-md-3 mb-3"><div class="stats-card-3d"><div class="d-flex align-items-center">
<div class="stats-icon-3d me-3" style="background:linear-gradient(135deg,#28a745,#20c997)"><i class="bi bi-check-circle-fill"></i></div>
<div><div class="stats-number" style="background:linear-gradient(135deg,#28a745,#20c997);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><?=number_format($stats['fulfilled'])?></div>
<small class="text-muted" style="font-weight:600">Fulfilled</small></div></div></div></div>

<div class="col-md-3 mb-3"><div class="stats-card-3d"><div class="d-flex align-items-center">
<div class="stats-icon-3d me-3" style="background:linear-gradient(135deg,#dc3545,#ff6b6b)"><i class="bi bi-exclamation-triangle-fill"></i></div>
<div><div class="stats-number" style="background:linear-gradient(135deg,#dc3545,#ff6b6b);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><?=number_format($stats['critical'])?></div>
<small class="text-muted" style="font-weight:600">Critical</small></div></div></div></div>
</div>

<div class="filter-card-3d">
<h5 class="mb-3" style="font-weight:700"><i class="bi bi-funnel me-2" style="color:#0d6efd"></i>Filters</h5>
<form method="GET" class="row g-3">
<div class="col-md-5"><label class="form-label" style="font-weight:600">Status</label>
<select name="status" class="form-select" style="border-radius:12px;border:2px solid #e9ecef">
<option value="">All Statuses</option>
<option value="pending" <?=$filterStatus==='pending'?'selected':''?>>Pending</option>
<option value="approved" <?=$filterStatus==='approved'?'selected':''?>>Approved</option>
<option value="fulfilled" <?=$filterStatus==='fulfilled'?'selected':''?>>Fulfilled</option>
<option value="rejected" <?=$filterStatus==='rejected'?'selected':''?>>Rejected</option>
</select></div>
<div class="col-md-4"><label class="form-label" style="font-weight:600">Urgency</label>
<select name="urgency" class="form-select" style="border-radius:12px;border:2px solid #e9ecef">
<option value="">All Urgencies</option>
<option value="Critical" <?=$filterUrgency==='Critical'?'selected':''?>>Critical</option>
<option value="High" <?=$filterUrgency==='High'?'selected':''?>>High</option>
<option value="Medium" <?=$filterUrgency==='Medium'?'selected':''?>>Medium</option>
<option value="Low" <?=$filterUrgency==='Low'?'selected':''?>>Low</option>
</select></div>
<div class="col-md-3 d-flex align-items-end">
<button type="submit" class="btn btn-3d btn-gradient-primary me-2"><i class="bi bi-search me-1"></i>Filter</button>
<a href="manage_requests.php" class="btn btn-3d" style="background:#f8f9fa;color:#495057"><i class="bi bi-x-circle me-1"></i>Clear</a>
</div>
</form>
</div>

<div class="card-3d">
<div class="card-header-3d"><h5 class="mb-0" style="font-weight:700"><i class="bi bi-list-check me-2"></i>Blood Requests List (<?=count($requests)?>)</h5></div>
<div class="card-body p-0">
<?php if(count($requests) > 0): ?>
<div class="table-responsive">
<table class="table table-3d mb-0">
<thead><tr><th>Requester</th><th>Patient</th><th>Blood Type</th><th>Quantity</th><th>Urgency</th><th>Required Date</th><th>Status</th><th>Actions</th></tr></thead>
<tbody>
<?php foreach($requests as $request): ?>
<tr class="<?=$request['urgency']==='Critical'?'urgency-critical':''?>">
<td><div class="d-flex align-items-center">
<div class="user-avatar-3d me-3"><?=strtoupper(substr($request['full_name'],0,2))?></div>
<div><strong style="font-size:1.05rem"><?=htmlspecialchars($request['full_name'])?></strong><br>
<small class="text-muted"><?=htmlspecialchars($request['email'])?></small></div></div></td>
<td><strong><?=htmlspecialchars($request['patient_name'])?></strong><br>
<small class="text-muted"><?=htmlspecialchars($request['hospital_name'])?></small></td>
<td><span class="blood-type-badge-3d"><?=$request['blood_type']?></span></td>
<td><strong style="font-size:1.3rem;color:#0d6efd"><?=$request['quantity_ml']?></strong> ml</td>
<td><?php 
$urgencyColors = ['Critical'=>'danger','High'=>'warning','Medium'=>'info','Low'=>'secondary'];
$urgencyColor = $urgencyColors[$request['urgency']] ?? 'secondary';
?>
<span class="badge-3d bg-<?=$urgencyColor?>"><i class="bi bi-<?=$request['urgency']==='Critical'?'exclamation-triangle-fill':'info-circle'?> me-1"></i><?=$request['urgency']?></span>
</td>
<td><strong><?=date('M j, Y',strtotime($request['required_date']))?></strong></td>
<td><?php 
$statusBadges = ['pending'=>'warning','approved'=>'info','fulfilled'=>'success','rejected'=>'danger'];
$badgeColor = $statusBadges[$request['status']] ?? 'secondary';
$statusIcons = ['pending'=>'clock-history','approved'=>'check-circle-fill','fulfilled'=>'check-circle','rejected'=>'x-circle-fill'];
$statusIcon = $statusIcons[$request['status']] ?? 'info-circle';
?>
<span class="badge-3d bg-<?=$badgeColor?>"><i class="bi bi-<?=$statusIcon?> me-1"></i><?=ucfirst($request['status'])?></span>
</td>
<td>
<div class="btn-group">
<button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editModal<?=$request['request_id']?>" style="border-radius:10px"><i class="bi bi-pencil"></i></button>
<button class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#viewModal<?=$request['request_id']?>" style="border-radius:10px"><i class="bi bi-eye"></i></button>
</div>
</td>
</tr>

<!-- Edit Modal -->
<div class="modal fade" id="editModal<?=$request['request_id']?>"><div class="modal-dialog"><div class="modal-content" style="border-radius:20px">
<div class="modal-header" style="background:linear-gradient(135deg,#0d6efd,#0a58ca);color:#fff;border-radius:20px 20px 0 0">
<h5 class="modal-title">Update Request Status</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<form method="POST"><div class="modal-body">
<input type="hidden" name="csrf_token" value="<?=getCSRFToken()?>">
<input type="hidden" name="request_id" value="<?=$request['request_id']?>">
<div class="mb-3"><label class="form-label">Status</label>
<select name="status" class="form-select" required>
<option value="pending" <?=$request['status']==='pending'?'selected':''?>>Pending - Awaiting Review</option>
<option value="approved" <?=$request['status']==='approved'?'selected':''?>>✅ Approved - Request Accepted</option>
<option value="fulfilled" <?=$request['status']==='fulfilled'?'selected':''?>>✅ Fulfilled - Blood Delivered</option>
<option value="rejected" <?=$request['status']==='rejected'?'selected':''?>>❌ Rejected - Request Denied</option>
</select></div>
<div class="mb-3"><label class="form-label">Admin Notes</label>
<textarea name="admin_notes" class="form-control" rows="3" placeholder="Add notes for the user"></textarea>
</div></div><div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" name="update_status" class="btn btn-3d btn-gradient-primary">Update</button>
</div></form></div></div></div>

<!-- View Modal -->
<div class="modal fade" id="viewModal<?=$request['request_id']?>"><div class="modal-dialog modal-lg"><div class="modal-content" style="border-radius:20px">
<div class="modal-header" style="background:linear-gradient(135deg,#0d6efd,#0a58ca);color:#fff;border-radius:20px 20px 0 0">
<h5 class="modal-title">Request Details #<?=$request['request_id']?></h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body">
<div class="row">
<div class="col-md-6 mb-3"><strong><i class="bi bi-person me-2"></i>Requester:</strong><br><?=htmlspecialchars($request['full_name'])?></div>
<div class="col-md-6 mb-3"><strong><i class="bi bi-hospital me-2"></i>Patient:</strong><br><?=htmlspecialchars($request['patient_name'])?></div>
<div class="col-md-6 mb-3"><strong><i class="bi bi-building me-2"></i>Hospital:</strong><br><?=htmlspecialchars($request['hospital_name'])?></div>
<div class="col-md-6 mb-3"><strong><i class="bi bi-droplet me-2"></i>Blood Type:</strong><br><span class="badge bg-primary"><?=$request['blood_type']?></span></div>
<div class="col-md-6 mb-3"><strong><i class="bi bi-hash me-2"></i>Quantity:</strong><br><?=$request['quantity_ml']?>ml</div>
<div class="col-md-6 mb-3"><strong><i class="bi bi-exclamation-triangle me-2"></i>Urgency:</strong><br><span class="badge bg-<?=$urgencyColor?>"><?=$request['urgency']?></span></div>
<div class="col-md-6 mb-3"><strong><i class="bi bi-calendar me-2"></i>Required Date:</strong><br><?=formatDate($request['required_date'])?></div>
<div class="col-md-6 mb-3"><strong><i class="bi bi-check-circle me-2"></i>Status:</strong><br><span class="badge bg-<?=$badgeColor?>"><?=ucfirst($request['status'])?></span></div>
<div class="col-12 mb-3"><hr><strong><i class="bi bi-chat-text me-2"></i>Reason:</strong><br><p class="mt-2"><?=nl2br(htmlspecialchars($request['reason']))?></p></div>
<div class="col-md-6"><small class="text-muted">Submitted: <?=formatDateTime($request['created_at'])?></small></div>
<div class="col-md-6"><small class="text-muted">Updated: <?=formatDateTime($request['updated_at'])?></small></div>
</div></div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
</div></div></div></div>

<?php endforeach; ?>
</tbody>
</table>
</div>
<?php else: ?>
<div class="text-center py-5">
<i class="bi bi-bandaid" style="font-size:5rem;color:#ddd"></i>
<h4 class="mt-3 text-muted">No Requests Found</h4>
<p class="text-muted">Try adjusting your filters</p>
</div>
<?php endif; ?>
</div>
</div>

</main>
</div>
</div>

<?php include '../includes/footer.php'; ?>
