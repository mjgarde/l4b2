<?php
/**
 * Admin Audit Logs
 * View and filter system audit logs
 */

require_once '../config/config.php';
require_once '../config/db.php';
require_once '../config/notification_functions.php';

requireAdmin();

$currentPage = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$recordsPerPage = 50;
$offset = ($currentPage - 1) * $recordsPerPage;

// Get filter parameters
$filters = [
    'user_id' => isset($_GET['user_id']) ? intval($_GET['user_id']) : null,
    'action' => isset($_GET['action']) ? sanitize($_GET['action']) : '',
    'table' => isset($_GET['table']) ? sanitize($_GET['table']) : '',
    'date_from' => isset($_GET['date_from']) ? sanitize($_GET['date_from']) : '',
    'date_to' => isset($_GET['date_to']) ? sanitize($_GET['date_to']) : ''
];

// Get audit logs
$auditLogs = getAuditLogs($db, $filters, $recordsPerPage, $offset);

// Get total count for pagination
try {
    $countSql = "SELECT COUNT(*) as total FROM audit_logs WHERE 1=1";
    $params = [];
    
    if (!empty($filters['user_id'])) {
        $countSql .= " AND user_id = :user_id";
        $params[':user_id'] = $filters['user_id'];
    }
    if (!empty($filters['action'])) {
        $countSql .= " AND action LIKE :action";
        $params[':action'] = '%' . $filters['action'] . '%';
    }
    if (!empty($filters['table'])) {
        $countSql .= " AND table_affected = :table";
        $params[':table'] = $filters['table'];
    }
    if (!empty($filters['date_from'])) {
        $countSql .= " AND DATE(created_at) >= :date_from";
        $params[':date_from'] = $filters['date_from'];
    }
    if (!empty($filters['date_to'])) {
        $countSql .= " AND DATE(created_at) <= :date_to";
        $params[':date_to'] = $filters['date_to'];
    }
    
    $stmt = $db->prepare($countSql);
    $stmt->execute($params);
    $totalRecords = $stmt->fetch()['total'];
    $totalPages = ceil($totalRecords / $recordsPerPage);
} catch(PDOException $e) {
    $totalRecords = 0;
    $totalPages = 1;
}

// Get all users for filter dropdown
try {
    $usersSql = "SELECT user_id, username, full_name FROM users ORDER BY username";
    $stmt = $db->prepare($usersSql);
    $stmt->execute();
    $users = $stmt->fetchAll();
} catch(PDOException $e) {
    $users = [];
}

// Get distinct tables for filter
$tables = ['users', 'donors_info', 'donations', 'requests', 'appointments', 'events', 'inventory', 'notifications'];

// Get distinct actions
try {
    $actionsSql = "SELECT DISTINCT action FROM audit_logs ORDER BY action";
    $stmt = $db->prepare($actionsSql);
    $stmt->execute();
    $actions = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch(PDOException $e) {
    $actions = [];
}

// Export to CSV
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $exportLogs = getAuditLogs($db, $filters, 10000, 0); // Get up to 10000 records
    
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="audit_logs_' . date('Y-m-d_His') . '.csv"');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Log ID', 'User', 'Action', 'Table', 'Record ID', 'Details', 'IP Address', 'Date/Time']);
    
    foreach ($exportLogs as $log) {
        fputcsv($output, [
            $log['log_id'],
            $log['username'] ?? 'System',
            $log['action'],
            $log['table_affected'] ?? 'N/A',
            $log['record_id'] ?? 'N/A',
            $log['details'] ?? '',
            $log['ip_address'],
            $log['created_at']
        ]);
    }
    
    fclose($output);
    exit;
}

$pageTitle = 'Audit Logs';
include '../includes/admin_header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include '../includes/admin_sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <i class="bi bi-shield-check text-primary me-2"></i>Audit Logs
                </h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="?export=csv<?php echo !empty($_GET) ? '&' . http_build_query(array_filter($filters)) : ''; ?>" 
                       class="btn btn-sm btn-outline-success">
                        <i class="bi bi-download me-1"></i>Export CSV
                    </a>
                </div>
            </div>

            <!-- Statistics Cards -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <i class="bi bi-journal-text text-primary" style="font-size: 2rem;"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="text-muted mb-1">Total Logs</h6>
                                    <h3 class="mb-0"><?php echo number_format($totalRecords); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php
                try {
                    $todayCountSql = "SELECT COUNT(*) as count FROM audit_logs WHERE DATE(created_at) = CURDATE()";
                    $stmt = $db->prepare($todayCountSql);
                    $stmt->execute();
                    $todayCount = $stmt->fetch()['count'];
                } catch(PDOException $e) {
                    $todayCount = 0;
                }
                ?>
                
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <i class="bi bi-calendar-day text-success" style="font-size: 2rem;"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="text-muted mb-1">Today's Actions</h6>
                                    <h3 class="mb-0"><?php echo number_format($todayCount); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php
                try {
                    $uniqueUsersSql = "SELECT COUNT(DISTINCT user_id) as count FROM audit_logs WHERE user_id IS NOT NULL";
                    $stmt = $db->prepare($uniqueUsersSql);
                    $stmt->execute();
                    $uniqueUsers = $stmt->fetch()['count'];
                } catch(PDOException $e) {
                    $uniqueUsers = 0;
                }
                ?>
                
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <i class="bi bi-people text-info" style="font-size: 2rem;"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="text-muted mb-1">Active Users</h6>
                                    <h3 class="mb-0"><?php echo number_format($uniqueUsers); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php
                try {
                    $recentActivitySql = "SELECT created_at FROM audit_logs ORDER BY created_at DESC LIMIT 1";
                    $stmt = $db->prepare($recentActivitySql);
                    $stmt->execute();
                    $lastActivity = $stmt->fetch();
                } catch(PDOException $e) {
                    $lastActivity = null;
                }
                ?>
                
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <i class="bi bi-clock-history text-warning" style="font-size: 2rem;"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="text-muted mb-1">Last Activity</h6>
                                    <p class="mb-0 small">
                                        <?php 
                                        if ($lastActivity) {
                                            echo formatDateTime($lastActivity['created_at'], 'M j, g:i A');
                                        } else {
                                            echo 'No activity';
                                        }
                                        ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filters -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">
                        <i class="bi bi-filter me-2"></i>Filters
                    </h5>
                </div>
                <div class="card-body">
                    <form method="GET" action="audit_logs.php" class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label">User</label>
                            <select name="user_id" class="form-select">
                                <option value="">All Users</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?php echo $user['user_id']; ?>" 
                                            <?php echo $filters['user_id'] == $user['user_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($user['username']); ?> 
                                        (<?php echo htmlspecialchars($user['full_name']); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-3">
                            <label class="form-label">Action</label>
                            <input type="text" name="action" class="form-control" 
                                   placeholder="Search action..." 
                                   value="<?php echo htmlspecialchars($filters['action']); ?>">
                        </div>
                        
                        <div class="col-md-2">
                            <label class="form-label">Table</label>
                            <select name="table" class="form-select">
                                <option value="">All Tables</option>
                                <?php foreach ($tables as $table): ?>
                                    <option value="<?php echo $table; ?>" 
                                            <?php echo $filters['table'] === $table ? 'selected' : ''; ?>>
                                        <?php echo ucfirst($table); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-2">
                            <label class="form-label">Date From</label>
                            <input type="date" name="date_from" class="form-control" 
                                   value="<?php echo htmlspecialchars($filters['date_from']); ?>">
                        </div>
                        
                        <div class="col-md-2">
                            <label class="form-label">Date To</label>
                            <input type="date" name="date_to" class="form-control" 
                                   value="<?php echo htmlspecialchars($filters['date_to']); ?>">
                        </div>
                        
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-search me-1"></i>Apply Filters
                            </button>
                            <a href="audit_logs.php" class="btn btn-outline-secondary">
                                <i class="bi bi-x-circle me-1"></i>Clear Filters
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Audit Logs Table -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Audit Log Entries</h5>
                </div>
                <div class="card-body p-0">
                    <?php if (count($auditLogs) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>ID</th>
                                        <th>Date/Time</th>
                                        <th>User</th>
                                        <th>Action</th>
                                        <th>Table</th>
                                        <th>Record ID</th>
                                        <th>Details</th>
                                        <th>IP Address</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($auditLogs as $log): ?>
                                        <tr>
                                            <td><?php echo $log['log_id']; ?></td>
                                            <td>
                                                <small><?php echo formatDateTime($log['created_at'], 'M j, Y g:i A'); ?></small>
                                            </td>
                                            <td>
                                                <?php if ($log['username']): ?>
                                                    <span class="badge bg-primary">
                                                        <?php echo htmlspecialchars($log['username']); ?>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">System</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php
                                                $badgeClass = 'bg-info';
                                                if (stripos($log['action'], 'delete') !== false || stripos($log['action'], 'reject') !== false) {
                                                    $badgeClass = 'bg-danger';
                                                } elseif (stripos($log['action'], 'create') !== false || stripos($log['action'], 'approve') !== false) {
                                                    $badgeClass = 'bg-success';
                                                } elseif (stripos($log['action'], 'update') !== false || stripos($log['action'], 'change') !== false) {
                                                    $badgeClass = 'bg-warning';
                                                }
                                                ?>
                                                <span class="badge <?php echo $badgeClass; ?>">
                                                    <?php echo htmlspecialchars($log['action']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($log['table_affected']): ?>
                                                    <code><?php echo htmlspecialchars($log['table_affected']); ?></code>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo $log['record_id'] ?? '<span class="text-muted">-</span>'; ?>
                                            </td>
                                            <td>
                                                <small><?php echo htmlspecialchars($log['details'] ?? ''); ?></small>
                                            </td>
                                            <td>
                                                <small><code><?php echo htmlspecialchars($log['ip_address']); ?></code></small>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Pagination -->
                        <?php if ($totalPages > 1): ?>
                            <div class="card-footer bg-white">
                                <nav>
                                    <ul class="pagination mb-0 justify-content-center">
                                        <li class="page-item <?php echo $currentPage <= 1 ? 'disabled' : ''; ?>">
                                            <a class="page-link" href="?page=<?php echo $currentPage - 1; ?><?php echo !empty(array_filter($filters)) ? '&' . http_build_query(array_filter($filters)) : ''; ?>">
                                                Previous
                                            </a>
                                        </li>
                                        
                                        <?php
                                        $startPage = max(1, $currentPage - 2);
                                        $endPage = min($totalPages, $currentPage + 2);
                                        
                                        if ($startPage > 1): ?>
                                            <li class="page-item">
                                                <a class="page-link" href="?page=1<?php echo !empty(array_filter($filters)) ? '&' . http_build_query(array_filter($filters)) : ''; ?>">1</a>
                                            </li>
                                            <?php if ($startPage > 2): ?>
                                                <li class="page-item disabled"><span class="page-link">...</span></li>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        
                                        <?php for ($i = $startPage; $i <= $endPage; $i++): ?>
                                            <li class="page-item <?php echo $i === $currentPage ? 'active' : ''; ?>">
                                                <a class="page-link" href="?page=<?php echo $i; ?><?php echo !empty(array_filter($filters)) ? '&' . http_build_query(array_filter($filters)) : ''; ?>">
                                                    <?php echo $i; ?>
                                                </a>
                                            </li>
                                        <?php endfor; ?>
                                        
                                        <?php if ($endPage < $totalPages): ?>
                                            <?php if ($endPage < $totalPages - 1): ?>
                                                <li class="page-item disabled"><span class="page-link">...</span></li>
                                            <?php endif; ?>
                                            <li class="page-item">
                                                <a class="page-link" href="?page=<?php echo $totalPages; ?><?php echo !empty(array_filter($filters)) ? '&' . http_build_query(array_filter($filters)) : ''; ?>">
                                                    <?php echo $totalPages; ?>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                        
                                        <li class="page-item <?php echo $currentPage >= $totalPages ? 'disabled' : ''; ?>">
                                            <a class="page-link" href="?page=<?php echo $currentPage + 1; ?><?php echo !empty(array_filter($filters)) ? '&' . http_build_query(array_filter($filters)) : ''; ?>">
                                                Next
                                            </a>
                                        </li>
                                    </ul>
                                </nav>
                                <p class="text-center text-muted mt-2 mb-0">
                                    Showing <?php echo $offset + 1; ?> to <?php echo min($offset + $recordsPerPage, $totalRecords); ?> 
                                    of <?php echo number_format($totalRecords); ?> entries
                                </p>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-inbox" style="font-size: 5rem; color: #dee2e6;"></i>
                            <h4 class="mt-3 text-muted">No Audit Logs Found</h4>
                            <p class="text-muted">No logs match your current filters.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
