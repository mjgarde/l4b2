<?php
require_once '../config/config.php';
require_once '../config/db.php';
requireAdmin();

$success = $error = '';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCSRF($_POST['csrf_token'])) {
    $appointmentId = intval($_POST['appointment_id'] ?? 0);
    
    try {
        if (isset($_POST['confirm_appointment'])) {
            $appt = $db->prepare("SELECT * FROM appointments WHERE appointment_id = ?")->execute([$appointmentId]) ? $db->query("SELECT a.*, u.user_id FROM appointments a JOIN users u ON a.user_id = u.user_id WHERE a.appointment_id = $appointmentId")->fetch() : null;
            if ($appt) {
                $db->prepare("UPDATE appointments SET status = 'confirmed' WHERE appointment_id = ?")->execute([$appointmentId]);
                notifyAppointmentConfirmed($db, $appt['user_id'], $appointmentId, $appt['appointment_date'], $appt['appointment_time'], $_SESSION['user_id']);
                $success = "Appointment confirmed";
            }
        }
        elseif (isset($_POST['complete_appointment'])) {
            $appt = $db->query("SELECT user_id FROM appointments WHERE appointment_id = $appointmentId")->fetch();
            if ($appt) {
                $db->prepare("UPDATE appointments SET status = 'completed' WHERE appointment_id = ?")->execute([$appointmentId]);
                notifyAppointmentCompleted($db, $appt['user_id'], $appointmentId, $_SESSION['user_id']);
                $success = "Appointment completed";
            }
        }
        elseif (isset($_POST['cancel_appointment'])) {
            $reason = sanitize($_POST['cancel_reason']);
            $appt = $db->query("SELECT a.*, u.user_id FROM appointments a JOIN users u ON a.user_id = u.user_id WHERE a.appointment_id = $appointmentId")->fetch();
            if ($appt) {
                $db->prepare("UPDATE appointments SET status = 'cancelled', notes = CONCAT(COALESCE(notes,''), '\nCancelled: ', ?) WHERE appointment_id = ?")->execute([$reason, $appointmentId]);
                notifyAppointmentCancelled($db, $appt['user_id'], $appointmentId, $appt['appointment_date'], $reason, $_SESSION['user_id']);
                $success = "Appointment cancelled";
            }
        }
        elseif (isset($_POST['create_appointment'])) {
            $stmt = $db->prepare("INSERT INTO appointments (user_id, event_id, appointment_date, appointment_time, purpose, status, notes) VALUES (?, ?, ?, ?, ?, 'scheduled', ?)");
            $stmt->execute([intval($_POST['user_id']), $_POST['event_id'] ?: null, $_POST['appointment_date'], $_POST['appointment_time'], $_POST['purpose'], $_POST['notes']]);
            $newId = $db->lastInsertId();
            notifyAppointmentScheduled($db, intval($_POST['user_id']), $newId, $_POST['appointment_date'], $_POST['appointment_time'], $_POST['purpose']);
            $success = "Appointment created";
        }
    } catch(PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}

if (isset($_GET['delete'])) {
    $db->prepare("DELETE FROM appointments WHERE appointment_id = ?")->execute([intval($_GET['delete'])]);
    $success = "Appointment deleted";
}

$statusFilter = $_GET['status'] ?? '';
$dateFilter = $_GET['date'] ?? '';
$where = [];
$params = [];
if ($statusFilter) { $where[] = "a.status = ?"; $params[] = $statusFilter; }
if ($dateFilter) { $where[] = "DATE(a.appointment_date) = ?"; $params[] = $dateFilter; }
$whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$stmt = $db->prepare("SELECT a.*, u.username, u.full_name, u.phone, e.event_name, e.event_location FROM appointments a JOIN users u ON a.user_id = u.user_id LEFT JOIN events e ON a.event_id = e.event_id $whereSQL ORDER BY a.appointment_date DESC");
$stmt->execute($params);
$appointments = $stmt->fetchAll();

$stats = $db->query("SELECT COUNT(*) as total, SUM(status='scheduled') as scheduled, SUM(status='confirmed') as confirmed, SUM(status='completed') as completed, SUM(status='cancelled') as cancelled, SUM(DATE(appointment_date)=CURDATE()) as today, SUM(DATE(appointment_date)>=CURDATE() AND status IN ('scheduled','confirmed')) as upcoming FROM appointments")->fetch();

$users = $db->query("SELECT user_id, username, full_name FROM users WHERE user_role='user' AND status='active' ORDER BY full_name")->fetchAll();
$events = $db->query("SELECT event_id, event_name, event_date FROM events WHERE status IN ('upcoming','ongoing') AND event_date>=CURDATE() ORDER BY event_date")->fetchAll();

$pageTitle = 'Manage Appointments';
include '../includes/admin_header.php';
?>

<div class="container-fluid">
<div class="row">
<?php include '../includes/admin_sidebar.php'; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

<div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-3 border-bottom">
<h1 class="h2"><i class="bi bi-calendar-check text-primary me-2"></i>Manage Appointments</h1>
<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createModal"><i class="bi bi-plus-circle me-1"></i>Create</button>
</div>

<?php if($success): ?>
<div class="alert alert-success alert-dismissible fade show"><i class="bi bi-check-circle me-2"></i><?=$success?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; if($error): ?>
<div class="alert alert-danger alert-dismissible fade show"><i class="bi bi-exclamation-triangle me-2"></i><?=$error?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>

<div class="row mb-4">
<div class="col-md-2"><div class="card shadow-sm"><div class="card-body text-center"><i class="bi bi-calendar-check text-primary" style="font-size:2rem"></i><h3 class="mt-2"><?=number_format($stats['total'])?></h3><small class="text-muted">Total</small></div></div></div>
<div class="col-md-2"><div class="card shadow-sm"><div class="card-body text-center"><i class="bi bi-clock text-warning" style="font-size:2rem"></i><h3 class="mt-2"><?=number_format($stats['scheduled'])?></h3><small class="text-muted">Scheduled</small></div></div></div>
<div class="col-md-2"><div class="card shadow-sm"><div class="card-body text-center"><i class="bi bi-check-circle text-success" style="font-size:2rem"></i><h3 class="mt-2"><?=number_format($stats['confirmed'])?></h3><small class="text-muted">Confirmed</small></div></div></div>
<div class="col-md-2"><div class="card shadow-sm"><div class="card-body text-center"><i class="bi bi-check-all text-info" style="font-size:2rem"></i><h3 class="mt-2"><?=number_format($stats['completed'])?></h3><small class="text-muted">Completed</small></div></div></div>
<div class="col-md-2"><div class="card shadow-sm"><div class="card-body text-center"><i class="bi bi-calendar-day text-primary" style="font-size:2rem"></i><h3 class="mt-2"><?=number_format($stats['today'])?></h3><small class="text-muted">Today</small></div></div></div>
<div class="col-md-2"><div class="card shadow-sm"><div class="card-body text-center"><i class="bi bi-calendar-event text-success" style="font-size:2rem"></i><h3 class="mt-2"><?=number_format($stats['upcoming'])?></h3><small class="text-muted">Upcoming</small></div></div></div>
</div>

<div class="card shadow-sm mb-4">
<div class="card-header bg-light"><h5 class="mb-0"><i class="bi bi-filter me-2"></i>Filters</h5></div>
<div class="card-body"><form method="GET" class="row g-3">
<div class="col-md-4"><label class="form-label">Status</label>
<select name="status" class="form-select">
<option value="">All</option>
<option value="scheduled" <?=$statusFilter=='scheduled'?'selected':''?>>Scheduled</option>
<option value="confirmed" <?=$statusFilter=='confirmed'?'selected':''?>>Confirmed</option>
<option value="completed" <?=$statusFilter=='completed'?'selected':''?>>Completed</option>
<option value="cancelled" <?=$statusFilter=='cancelled'?'selected':''?>>Cancelled</option>
</select></div>
<div class="col-md-4"><label class="form-label">Date</label>
<input type="date" name="date" class="form-control" value="<?=htmlspecialchars($dateFilter)?>"></div>
<div class="col-md-4 d-flex align-items-end">
<button type="submit" class="btn btn-primary me-2"><i class="bi bi-search me-1"></i>Filter</button>
<a href="manage_appointments.php" class="btn btn-outline-secondary"><i class="bi bi-x-circle me-1"></i>Clear</a>
</div>
</form></div>
</div>

<div class="card shadow-sm">
<div class="card-header bg-white"><h5 class="mb-0">Appointments (<?=count($appointments)?>)</h5></div>
<div class="card-body p-0">
<?php if(count($appointments) > 0): ?>
<div class="table-responsive">
<table class="table table-hover mb-0">
<thead class="table-light"><tr><th>ID</th><th>User</th><th>Date & Time</th><th>Purpose</th><th>Status</th><th>Actions</th></tr></thead>
<tbody>
<?php foreach($appointments as $a): 
$badge = ['scheduled'=>'bg-warning','confirmed'=>'bg-success','completed'=>'bg-info','cancelled'=>'bg-danger'][$a['status']] ?? 'bg-secondary';
?>
<tr>
<td><?=$a['appointment_id']?></td>
<td><strong><?=htmlspecialchars($a['full_name'])?></strong><br><small class="text-muted">@<?=htmlspecialchars($a['username'])?></small></td>
<td><strong><?=date('M j, Y',strtotime($a['appointment_date']))?></strong><br><small><?=date('g:i A',strtotime($a['appointment_time']))?></small></td>
<td><span class="badge bg-info"><?=ucfirst($a['purpose'])?></span></td>
<td><span class="badge <?=$badge?>"><?=ucfirst($a['status'])?></span></td>
<td>
<div class="btn-group btn-group-sm">
<?php if($a['status']=='scheduled'): ?>
<form method="POST" class="d-inline"><input type="hidden" name="csrf_token" value="<?=getCSRFToken()?>"><input type="hidden" name="appointment_id" value="<?=$a['appointment_id']?>"><button type="submit" name="confirm_appointment" class="btn btn-success" onclick="return confirm('Confirm?')"><i class="bi bi-check"></i></button></form>
<?php endif; if(in_array($a['status'],['scheduled','confirmed'])): ?>
<form method="POST" class="d-inline"><input type="hidden" name="csrf_token" value="<?=getCSRFToken()?>"><input type="hidden" name="appointment_id" value="<?=$a['appointment_id']?>"><button type="submit" name="complete_appointment" class="btn btn-info" onclick="return confirm('Complete?')"><i class="bi bi-check-all"></i></button></form>
<button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#cancel<?=$a['appointment_id']?>"><i class="bi bi-x"></i></button>
<?php endif; ?>
<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#view<?=$a['appointment_id']?>"><i class="bi bi-eye"></i></button>
<?php if($a['status']=='cancelled'): ?>
<a href="?delete=<?=$a['appointment_id']?>" class="btn btn-danger" onclick="return confirm('Delete?')"><i class="bi bi-trash"></i></a>
<?php endif; ?>
</div>

<div class="modal fade" id="cancel<?=$a['appointment_id']?>"><div class="modal-dialog"><div class="modal-content"><form method="POST"><div class="modal-header"><h5>Cancel</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" name="csrf_token" value="<?=getCSRFToken()?>"><input type="hidden" name="appointment_id" value="<?=$a['appointment_id']?>"><label>Reason *</label><textarea name="cancel_reason" class="form-control" required></textarea></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button><button type="submit" name="cancel_appointment" class="btn btn-warning">Cancel</button></div></form></div></div></div>

<div class="modal fade" id="view<?=$a['appointment_id']?>"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><h5>Details #<?=$a['appointment_id']?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><p><strong>User:</strong> <?=htmlspecialchars($a['full_name'])?></p><p><strong>Date:</strong> <?=formatDate($a['appointment_date'])?> at <?=date('g:i A',strtotime($a['appointment_time']))?></p><p><strong>Purpose:</strong> <?=ucfirst($a['purpose'])?></p><p><strong>Status:</strong> <span class="badge <?=$badge?>"><?=ucfirst($a['status'])?></span></p><?php if($a['event_name']): ?><p><strong>Event:</strong> <?=htmlspecialchars($a['event_name'])?></p><?php endif; if($a['notes']): ?><hr><p><strong>Notes:</strong></p><p><?=nl2br(htmlspecialchars($a['notes']))?></p><?php endif; ?></div></div></div></div>

</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php else: ?>
<div class="text-center py-5"><i class="bi bi-calendar-x" style="font-size:5rem;color:#ddd"></i><h4 class="mt-3 text-muted">No Appointments</h4></div>
<?php endif; ?>
</div>
</div>

</main>
</div>
</div>

<div class="modal fade" id="createModal"><div class="modal-dialog modal-lg"><div class="modal-content"><form method="POST"><div class="modal-header"><h5>Create Appointment</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" name="csrf_token" value="<?=getCSRFToken()?>">
<div class="row"><div class="col-md-6 mb-3"><label>User *</label><select name="user_id" class="form-select" required><option value="">Select</option><?php foreach($users as $u): ?><option value="<?=$u['user_id']?>"><?=htmlspecialchars($u['full_name'])?> (@<?=htmlspecialchars($u['username'])?>)</option><?php endforeach; ?></select></div><div class="col-md-6 mb-3"><label>Event</label><select name="event_id" class="form-select"><option value="">None</option><?php foreach($events as $e): ?><option value="<?=$e['event_id']?>"><?=htmlspecialchars($e['event_name'])?> - <?=date('M j',strtotime($e['event_date']))?></option><?php endforeach; ?></select></div></div>
<div class="row"><div class="col-md-6 mb-3"><label>Date *</label><input type="date" name="appointment_date" class="form-control" min="<?=date('Y-m-d')?>" required></div><div class="col-md-6 mb-3"><label>Time *</label><input type="time" name="appointment_time" class="form-control" required></div></div>
<div class="mb-3"><label>Purpose *</label><select name="purpose" class="form-select" required><option value="donation">Donation</option><option value="consultation">Consultation</option><option value="other">Other</option></select></div>
<div class="mb-3"><label>Notes</label><textarea name="notes" class="form-control" rows="3"></textarea></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button><button type="submit" name="create_appointment" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i>Create</button></div></form></div></div></div>

<?php include '../includes/footer.php'; ?>
