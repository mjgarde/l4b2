<?php
require_once '../config/config.php';
require_once '../config/db.php';
requireAdmin();

$success = $error = '';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCSRF($_POST['csrf_token'])) {
    $eventId = intval($_POST['event_id'] ?? 0);
    
    try {
        // Create Event
        if (isset($_POST['create_event'])) {
            $stmt = $db->prepare("INSERT INTO events (event_name, event_description, event_date, event_location, organizer, max_participants, status) VALUES (?, ?, ?, ?, ?, ?, 'upcoming')");
            $stmt->execute([
                sanitize($_POST['event_name']),
                sanitize($_POST['event_description']),
                sanitize($_POST['event_date']),
                sanitize($_POST['event_location']),
                sanitize($_POST['organizer']),
                intval($_POST['max_participants'])
            ]);
            $newId = $db->lastInsertId();
            
            // Notify all users about new event
            $count = notifyNewEvent($db, $newId, sanitize($_POST['event_name']), 
                                    sanitize($_POST['event_date']), 
                                    sanitize($_POST['event_location']), 
                                    $_SESSION['user_id']);
            
            logAudit($db, $_SESSION['user_id'], 'Event Created', 'events', $newId, 
                    "Created event: " . sanitize($_POST['event_name']) . " - Notified $count users");
            
            $success = "Event created successfully and $count users notified";
        }
        
        // Update Event
        elseif (isset($_POST['update_event'])) {
            $updateDetails = sanitize($_POST['update_details']);
            
            $stmt = $db->prepare("UPDATE events SET event_name = ?, event_description = ?, event_date = ?, event_location = ?, organizer = ?, max_participants = ? WHERE event_id = ?");
            $stmt->execute([
                sanitize($_POST['event_name']),
                sanitize($_POST['event_description']),
                sanitize($_POST['event_date']),
                sanitize($_POST['event_location']),
                sanitize($_POST['organizer']),
                intval($_POST['max_participants']),
                $eventId
            ]);
            
            // Notify participants about update
            $count = notifyEventUpdate($db, $eventId, sanitize($_POST['event_name']), 
                                      $updateDetails, $_SESSION['user_id']);
            
            $success = "Event updated and $count participants notified";
        }
        
        // Cancel Event
        elseif (isset($_POST['cancel_event'])) {
            $reason = sanitize($_POST['cancel_reason']);
            
            // Get event name first
            $event = $db->query("SELECT event_name FROM events WHERE event_id = $eventId")->fetch();
            
            $stmt = $db->prepare("UPDATE events SET status = 'cancelled' WHERE event_id = ?");
            $stmt->execute([$eventId]);
            
            // Notify participants about cancellation
            $count = notifyEventCancellation($db, $eventId, $event['event_name'], 
                                           $reason, $_SESSION['user_id']);
            
            $success = "Event cancelled and $count participants notified";
        }
        
        // Mark as Ongoing
        elseif (isset($_POST['mark_ongoing'])) {
            $db->prepare("UPDATE events SET status = 'ongoing' WHERE event_id = ?")->execute([$eventId]);
            logAudit($db, $_SESSION['user_id'], 'Event Status Changed', 'events', $eventId, "Status changed to: ongoing");
            $success = "Event marked as ongoing";
        }
        
        // Mark as Completed
        elseif (isset($_POST['mark_completed'])) {
            $db->prepare("UPDATE events SET status = 'completed' WHERE event_id = ?")->execute([$eventId]);
            logAudit($db, $_SESSION['user_id'], 'Event Completed', 'events', $eventId, "Event marked as completed");
            $success = "Event marked as completed";
        }
        
    } catch(PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}

// Delete Event
if (isset($_GET['delete'])) {
    $eventId = intval($_GET['delete']);
    try {
        // First delete related appointments
        $db->prepare("DELETE FROM appointments WHERE event_id = ?")->execute([$eventId]);
        $db->prepare("DELETE FROM events WHERE event_id = ?")->execute([$eventId]);
        
        logAudit($db, $_SESSION['user_id'], 'Event Deleted', 'events', $eventId, 
                "Admin permanently deleted event");
        $success = "Event and related appointments deleted";
    } catch(PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}

// Get filter parameters
$statusFilter = $_GET['status'] ?? '';
$dateFilter = $_GET['date'] ?? '';

// Build query
$where = [];
$params = [];
if ($statusFilter) { $where[] = "status = ?"; $params[] = $statusFilter; }
if ($dateFilter) { $where[] = "DATE(event_date) = ?"; $params[] = $dateFilter; }
$whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// Get events
$stmt = $db->prepare("SELECT e.*, 
       (SELECT COUNT(*) FROM appointments WHERE event_id = e.event_id) as registered_count 
       FROM events e $whereSQL ORDER BY e.event_date DESC");
$stmt->execute($params);
$events = $stmt->fetchAll();

// Get statistics
$stats = $db->query("SELECT COUNT(*) as total, 
       SUM(status='upcoming') as upcoming, 
       SUM(status='ongoing') as ongoing, 
       SUM(status='completed') as completed,
       SUM(status='cancelled') as cancelled,
       SUM(DATE(event_date)=CURDATE()) as today,
       SUM(DATE(event_date)>=CURDATE() AND status='upcoming') as future 
       FROM events")->fetch();

$pageTitle = 'Manage Events';
include '../includes/admin_header.php';
?>

<style>
.stats-card-3d{background:#fff;border-radius:20px;padding:25px;box-shadow:0 10px 40px rgba(0,0,0,0.1);transition:all 0.4s;border-top:5px solid #28a745}
.stats-card-3d:hover{transform:translateY(-10px);box-shadow:0 20px 60px rgba(0,0,0,0.2)}
.stats-icon-3d{width:70px;height:70px;border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:2rem;background:linear-gradient(135deg,#28a745 0%,#20c997 100%);color:#fff;box-shadow:0 10px 30px rgba(40,167,69,0.4);animation:float 3s ease-in-out infinite}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
.stats-number{font-size:2.5rem;font-weight:800;background:linear-gradient(135deg,#28a745,#20c997);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.card-3d{border-radius:20px;border:none;box-shadow:0 15px 45px rgba(0,0,0,0.1);transition:all 0.4s}
.card-3d:hover{transform:translateY(-5px);box-shadow:0 20px 60px rgba(0,0,0,0.15)}
.card-header-3d{background:linear-gradient(135deg,#28a745,#20c997);color:#fff;border:none;padding:20px;border-radius:20px 20px 0 0}
.btn-3d{border-radius:12px;padding:10px 24px;font-weight:600;transition:all 0.3s;border:none;box-shadow:0 5px 15px rgba(0,0,0,0.2)}
.btn-3d:hover{transform:translateY(-3px);box-shadow:0 8px 25px rgba(0,0,0,0.3)}
.btn-gradient-primary{background:linear-gradient(135deg,#28a745,#20c997);color:#fff}
.table-3d tbody tr{background:#fff;box-shadow:0 5px 15px rgba(0,0,0,0.08);transition:all 0.3s;margin-bottom:10px}
.table-3d tbody tr:hover{transform:scale(1.01);box-shadow:0 8px 25px rgba(0,0,0,0.15)}
.table-3d tbody td{padding:20px 15px;border:none;vertical-align:middle}
.badge-3d{padding:8px 16px;border-radius:20px;font-weight:600;font-size:0.85rem;box-shadow:0 4px 12px rgba(0,0,0,0.15)}
.event-icon-3d{width:50px;height:50px;border-radius:50%;background:linear-gradient(135deg,#28a745,#20c997);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:1.2rem;box-shadow:0 5px 15px rgba(40,167,69,0.4);transition:all 0.3s ease}
.event-icon-3d:hover{transform:scale(1.1);box-shadow:0 8px 20px rgba(40,167,69,0.6)}
.filter-card-3d{background:#fff;border-radius:20px;padding:25px;box-shadow:0 10px 30px rgba(0,0,0,0.1);margin-bottom:30px}
.progress-3d{height:8px;border-radius:10px;background:#e9ecef;overflow:hidden}
.progress-fill-3d{background:linear-gradient(135deg,#28a745,#20c997);height:100%;transition:width 0.5s ease;border-radius:10px}
</style>

<div class="container-fluid" style="background:linear-gradient(135deg,#f5f7fa 0%,#c3cfe2 100%);min-height:100vh;padding-bottom:50px">
<div class="row">
<?php include '../includes/admin_sidebar.php'; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

<div style="background:linear-gradient(135deg,#28a745,#20c997);color:#fff;padding:30px;border-radius:20px;margin-bottom:30px;box-shadow:0 15px 40px rgba(40,167,69,0.3)">
<div class="d-flex justify-content-between align-items-center">
<div><h1 style="font-weight:800"><i class="bi bi-calendar-event me-3"></i>Event Management</h1>
<p class="mb-0 mt-2">Create and manage blood donation events</p></div>
<button class="btn btn-3d" style="background:#fff;color:#28a745" data-bs-toggle="modal" data-bs-target="#createModal">
<i class="bi bi-plus-circle me-2"></i>Create Event</button>
</div></div>

<?php if($success): ?>
<div class="alert alert-success alert-dismissible fade show" style="border-radius:15px;border:none;box-shadow:0 5px 15px rgba(25,135,84,0.3)">
<i class="bi bi-check-circle-fill me-2"></i><?=$success?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; if($error): ?>
<div class="alert alert-danger alert-dismissible fade show" style="border-radius:15px;border:none;box-shadow:0 5px 15px rgba(220,53,69,0.3)">
<i class="bi bi-exclamation-triangle-fill me-2"></i><?=$error?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>

<div class="row mb-4">
<div class="col-md-2 mb-3"><div class="stats-card-3d"><div class="d-flex flex-column align-items-center">
<div class="stats-icon-3d mb-2"><i class="bi bi-calendar-event"></i></div>
<div class="stats-number"><?=number_format($stats['total'])?></div>
<small class="text-muted" style="font-weight:600">Total Events</small></div></div></div>

<div class="col-md-2 mb-3"><div class="stats-card-3d"><div class="d-flex flex-column align-items-center">
<div class="stats-icon-3d mb-2" style="background:linear-gradient(135deg,#0d6efd,#0a58ca)"><i class="bi bi-calendar-plus"></i></div>
<div class="stats-number" style="background:linear-gradient(135deg,#0d6efd,#0a58ca);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><?=number_format($stats['upcoming'])?></div>
<small class="text-muted" style="font-weight:600">Upcoming</small></div></div></div>

<div class="col-md-2 mb-3"><div class="stats-card-3d"><div class="d-flex flex-column align-items-center">
<div class="stats-icon-3d mb-2" style="background:linear-gradient(135deg,#ffc107,#ff9800)"><i class="bi bi-calendar-check"></i></div>
<div class="stats-number" style="background:linear-gradient(135deg,#ffc107,#ff9800);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><?=number_format($stats['ongoing'])?></div>
<small class="text-muted" style="font-weight:600">Ongoing</small></div></div></div>

<div class="col-md-2 mb-3"><div class="stats-card-3d"><div class="d-flex flex-column align-items-center">
<div class="stats-icon-3d mb-2" style="background:linear-gradient(135deg,#17a2b8,#138496)"><i class="bi bi-calendar-check-fill"></i></div>
<div class="stats-number" style="background:linear-gradient(135deg,#17a2b8,#138496);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><?=number_format($stats['completed'])?></div>
<small class="text-muted" style="font-weight:600">Completed</small></div></div></div>

<div class="col-md-2 mb-3"><div class="stats-card-3d"><div class="d-flex flex-column align-items-center">
<div class="stats-icon-3d mb-2" style="background:linear-gradient(135deg,#6f42c1,#d63384)"><i class="bi bi-calendar-day"></i></div>
<div class="stats-number" style="background:linear-gradient(135deg,#6f42c1,#d63384);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><?=number_format($stats['today'])?></div>
<small class="text-muted" style="font-weight:600">Today</small></div></div></div>

<div class="col-md-2 mb-3"><div class="stats-card-3d"><div class="d-flex flex-column align-items-center">
<div class="stats-icon-3d mb-2" style="background:linear-gradient(135deg,#20c997,#17a2b8)"><i class="bi bi-calendar3"></i></div>
<div class="stats-number" style="background:linear-gradient(135deg,#20c997,#17a2b8);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><?=number_format($stats['future'])?></div>
<small class="text-muted" style="font-weight:600">Future</small></div></div></div>
</div>

<div class="filter-card-3d">
<h5 class="mb-3" style="font-weight:700"><i class="bi bi-funnel me-2" style="color:#28a745"></i>Filters</h5>
<form method="GET" class="row g-3">
<div class="col-md-5"><label class="form-label" style="font-weight:600">Status</label>
<select name="status" class="form-select" style="border-radius:12px;border:2px solid #e9ecef">
<option value="">All Status</option>
<option value="upcoming" <?=$statusFilter=='upcoming'?'selected':''?>>Upcoming</option>
<option value="ongoing" <?=$statusFilter=='ongoing'?'selected':''?>>Ongoing</option>
<option value="completed" <?=$statusFilter=='completed'?'selected':''?>>Completed</option>
<option value="cancelled" <?=$statusFilter=='cancelled'?'selected':''?>>Cancelled</option>
</select></div>
<div class="col-md-4"><label class="form-label" style="font-weight:600">Date</label>
<input type="date" name="date" class="form-control" style="border-radius:12px;border:2px solid #e9ecef" value="<?=htmlspecialchars($dateFilter)?>">
</div>
<div class="col-md-3 d-flex align-items-end">
<button type="submit" class="btn btn-3d btn-gradient-primary me-2"><i class="bi bi-search me-1"></i>Filter</button>
<a href="manage_events.php" class="btn btn-3d" style="background:#f8f9fa;color:#495057"><i class="bi bi-x-circle me-1"></i>Clear</a>
</div>
</form>
</div>

<div class="card-3d">
<div class="card-header-3d"><h5 class="mb-0" style="font-weight:700"><i class="bi bi-list-check me-2"></i>Events List (<?=count($events)?>)</h5></div>
<div class="card-body p-0">
<?php if(count($events) > 0): ?>
<div class="table-responsive">
<table class="table table-3d mb-0">
<thead><tr><th>Event Name</th><th>Date</th><th>Location</th><th>Participants</th><th>Status</th><th>Actions</th></tr></thead>
<tbody>
<?php foreach($events as $e): 
$badge = ['upcoming'=>'primary','ongoing'=>'warning','completed'=>'info','cancelled'=>'danger'][$e['status']] ?? 'secondary';
$percentage = $e['max_participants'] > 0 ? round(($e['registered_count'] / $e['max_participants']) * 100) : 0;
?>
<tr>
<td>
<div class="d-flex align-items-center">
<div class="event-icon-3d me-3"><i class="bi bi-calendar-event"></i></div>
<div><strong style="font-size:1.05rem"><?=htmlspecialchars($e['event_name'])?></strong><br>
<small class="text-muted"><?=htmlspecialchars(substr($e['event_description'], 0, 50))?>...</small></div></div>
</td>
<td>
<strong><?=date('M j, Y', strtotime($e['event_date']))?></strong><br>
<small class="text-muted"><i class="bi bi-calendar me-1"></i><?=date('l', strtotime($e['event_date']))?></small>
</td>
<td><i class="bi bi-geo-alt me-1"></i><?=htmlspecialchars($e['event_location'])?></td>
<td>
<div class="mb-2">
<a href="view_event.php?id=<?=$e['event_id']?>" class="text-decoration-none" title="View participants">
<strong style="color:#28a745;font-size:1.2rem"><?=$e['registered_count']?></strong>
</a> / <?=$e['max_participants']?>
<small class="text-muted">(<?=$percentage?>%)</small>
</div>
<div class="progress-3d">
<div class="progress-fill-3d" style="width:<?=$percentage?>%;background:<?=$percentage >= 80 ? 'linear-gradient(135deg,#dc3545,#ff6b6b)' : ($percentage >= 50 ? 'linear-gradient(135deg,#ffc107,#ff9800)' : 'linear-gradient(135deg,#28a745,#20c997)')?>"></div>
</div>
<?php if($e['registered_count'] > 0): ?>
<small class="text-muted"><i class="bi bi-people me-1"></i><?=$e['registered_count']?> users joined</small>
<?php endif; ?>
</td>
<td><span class="badge-3d bg-<?=$badge?>"><i class="bi bi-<?=$e['status']=='completed'?'check-circle':($e['status']=='upcoming'?'calendar-plus':'info-circle')?> me-1"></i><?=ucfirst($e['status'])?></span></td>
<td>
<div class="btn-group">
<?php if($e['status'] == 'upcoming'): ?>
<form method="POST" class="d-inline">
<input type="hidden" name="csrf_token" value="<?=getCSRFToken()?>">
<input type="hidden" name="event_id" value="<?=$e['event_id']?>">
<button type="submit" name="mark_ongoing" class="btn btn-sm btn-warning" style="border-radius:10px" title="Start Event" onclick="return confirm('Mark as ongoing?')">
<i class="bi bi-play-circle"></i>
</button>
</form>
<button class="btn btn-sm btn-primary" style="border-radius:10px" data-bs-toggle="modal" data-bs-target="#edit<?=$e['event_id']?>">
<i class="bi bi-pencil"></i>
</button>
<button class="btn btn-sm btn-danger" style="border-radius:10px" data-bs-toggle="modal" data-bs-target="#cancel<?=$e['event_id']?>">
<i class="bi bi-x-circle"></i>
</button>
<?php endif; if($e['status'] == 'ongoing'): ?>
<form method="POST" class="d-inline">
<input type="hidden" name="csrf_token" value="<?=getCSRFToken()?>">
<input type="hidden" name="event_id" value="<?=$e['event_id']?>">
<button type="submit" name="mark_completed" class="btn btn-sm btn-info" style="border-radius:10px" title="Complete Event" onclick="return confirm('Mark as completed?')">
<i class="bi bi-check-circle"></i>
</button>
</form>
<?php endif; ?>
<a href="view_event.php?id=<?=$e['event_id']?>" class="btn btn-sm btn-info" style="border-radius:10px" title="View Details">
<i class="bi bi-eye"></i>
</a>
<?php if(in_array($e['status'], ['cancelled', 'completed'])): ?>
<a href="?delete=<?=$e['event_id']?>" class="btn btn-sm btn-danger" style="border-radius:10px" onclick="return confirm('Permanently delete this event?')">
<i class="bi bi-trash"></i>
</a>
<?php endif; ?>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="edit<?=$e['event_id']?>">
<div class="modal-dialog modal-lg">
<div class="modal-content">
<form method="POST">
<div class="modal-header">
<h5 class="modal-title">Edit Event</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<input type="hidden" name="csrf_token" value="<?=getCSRFToken()?>">
<input type="hidden" name="event_id" value="<?=$e['event_id']?>">

<div class="mb-3">
<label class="form-label">Event Name *</label>
<input type="text" name="event_name" class="form-control" value="<?=htmlspecialchars($e['event_name'])?>" required>
</div>

<div class="mb-3">
<label class="form-label">Description *</label>
<textarea name="event_description" class="form-control" rows="3" required><?=htmlspecialchars($e['event_description'])?></textarea>
</div>

<div class="row">
<div class="col-md-6 mb-3">
<label class="form-label">Date *</label>
<input type="date" name="event_date" class="form-control" value="<?=$e['event_date']?>" required>
</div>
<div class="col-md-6 mb-3">
<label class="form-label">Location *</label>
<input type="text" name="event_location" class="form-control" value="<?=htmlspecialchars($e['event_location'])?>" required>
</div>
</div>

<div class="row">
<div class="col-md-6 mb-3">
<label class="form-label">Organizer *</label>
<input type="text" name="organizer" class="form-control" value="<?=htmlspecialchars($e['organizer'])?>" required>
</div>
<div class="col-md-6 mb-3">
<label class="form-label">Max Participants *</label>
<input type="number" name="max_participants" class="form-control" value="<?=$e['max_participants']?>" min="1" required>
</div>
</div>

<div class="mb-3">
<label class="form-label">Update Details (What changed?) *</label>
<textarea name="update_details" class="form-control" rows="2" placeholder="E.g., Date changed from... to..." required></textarea>
<small class="text-muted">This will be sent to all registered participants</small>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
<button type="submit" name="update_event" class="btn btn-primary">
<i class="bi bi-save me-1"></i>Save Changes
</button>
</div>
</form>
</div>
</div>
</div>

<!-- Cancel Modal -->
<div class="modal fade" id="cancel<?=$e['event_id']?>">
<div class="modal-dialog">
<div class="modal-content">
<form method="POST">
<div class="modal-header bg-danger text-white">
<h5 class="modal-title">Cancel Event</h5>
<button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<input type="hidden" name="csrf_token" value="<?=getCSRFToken()?>">
<input type="hidden" name="event_id" value="<?=$e['event_id']?>">
<p>Are you sure you want to cancel <strong><?=htmlspecialchars($e['event_name'])?></strong>?</p>
<p class="text-danger">All registered participants will be notified.</p>
<label class="form-label">Cancellation Reason *</label>
<textarea name="cancel_reason" class="form-control" rows="3" placeholder="E.g., Bad weather, venue unavailable..." required></textarea>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
<button type="submit" name="cancel_event" class="btn btn-danger">
<i class="bi bi-x-circle me-1"></i>Cancel Event
</button>
</div>
</form>
</div>
</div>
</div>

</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php else: ?>
<div class="text-center py-5">
<i class="bi bi-calendar-x" style="font-size:5rem;color:#ddd"></i>
<h4 class="mt-3 text-muted">No Events Found</h4>
<p class="text-muted">Create your first event to get started</p>
</div>
<?php endif; ?>
</div>
</div>

</main>
</div>
</div>

<!-- Create Event Modal -->
<div class="modal fade" id="createModal">
<div class="modal-dialog modal-lg">
<div class="modal-content">
<form method="POST">
<div class="modal-header bg-success text-white">
<h5 class="modal-title">Create New Event</h5>
<button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<input type="hidden" name="csrf_token" value="<?=getCSRFToken()?>">

<div class="mb-3">
<label class="form-label">Event Name *</label>
<input type="text" name="event_name" class="form-control" placeholder="Community Blood Drive" required>
</div>

<div class="mb-3">
<label class="form-label">Description *</label>
<textarea name="event_description" class="form-control" rows="3" placeholder="Join us for a community blood donation event..." required></textarea>
</div>

<div class="row">
<div class="col-md-6 mb-3">
<label class="form-label">Date *</label>
<input type="date" name="event_date" class="form-control" min="<?=date('Y-m-d')?>" required>
</div>
<div class="col-md-6 mb-3">
<label class="form-label">Location *</label>
<input type="text" name="event_location" class="form-control" placeholder="City Plaza" required>
</div>
</div>

<div class="row">
<div class="col-md-6 mb-3">
<label class="form-label">Organizer *</label>
<input type="text" name="organizer" class="form-control" value="Red Cross Koronadal" required>
</div>
<div class="col-md-6 mb-3">
<label class="form-label">Max Participants *</label>
<input type="number" name="max_participants" class="form-control" value="100" min="1" required>
</div>
</div>

<div class="alert alert-info mb-0">
<i class="bi bi-info-circle me-2"></i>
<strong>Note:</strong> All active users will be notified about this new event.
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
<button type="submit" name="create_event" class="btn btn-success">
<i class="bi bi-plus-circle me-1"></i>Create Event
</button>
</div>
</form>
</div>
</div>
</div>

<?php include '../includes/footer.php'; ?>
