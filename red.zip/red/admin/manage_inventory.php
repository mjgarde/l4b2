<?php
/**
 * Manage Blood Inventory - Admin
 * CRUD operations for blood inventory
 */

require_once '../config/config.php';
require_once '../config/db.php';

requireAdmin();

$error = '';
$success = '';

// Handle update inventory
if (isset($_POST['update_inventory'])) {
    if (!validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        $inventoryId = intval($_POST['inventory_id']);
        $quantityMl = intval($_POST['quantity_ml']);
        $expiryDate = sanitize($_POST['expiry_date']);
        $status = sanitize($_POST['status']);
        
        try {
            $updateSql = "UPDATE inventory SET quantity_ml = :quantity, expiry_date = :expiry, status = :status 
                         WHERE inventory_id = :inventory_id";
            $stmt = $db->prepare($updateSql);
            $result = $stmt->execute([
                ':quantity' => $quantityMl,
                ':expiry' => $expiryDate,
                ':status' => $status,
                ':inventory_id' => $inventoryId
            ]);
            
            if ($result) {
                logAudit($db, $_SESSION['user_id'], 'Inventory Updated', 'inventory', $inventoryId, 
                    'Inventory updated');
                $success = 'Inventory updated successfully!';
            }
        } catch(PDOException $e) {
            $error = 'Error updating inventory: ' . $e->getMessage();
        }
    }
}

// Handle add new inventory
if (isset($_POST['add_inventory'])) {
    if (!validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        $bloodTypeId = intval($_POST['blood_type_id']);
        $quantityMl = intval($_POST['quantity_ml']);
        $expiryDate = sanitize($_POST['expiry_date']);
        $status = sanitize($_POST['status']);
        
        try {
            $insertSql = "INSERT INTO inventory (blood_type_id, quantity_ml, expiry_date, status) 
                         VALUES (:blood_type_id, :quantity, :expiry, :status)";
            $stmt = $db->prepare($insertSql);
            $result = $stmt->execute([
                ':blood_type_id' => $bloodTypeId,
                ':quantity' => $quantityMl,
                ':expiry' => $expiryDate,
                ':status' => $status
            ]);
            
            if ($result) {
                logAudit($db, $_SESSION['user_id'], 'Inventory Added', 'inventory', $db->lastInsertId(), 
                    'New inventory record added');
                $success = 'Inventory added successfully!';
            }
        } catch(PDOException $e) {
            $error = 'Error adding inventory: ' . $e->getMessage();
        }
    }
}

// Handle delete
if (isset($_POST['delete_inventory'])) {
    if (!validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        $inventoryId = intval($_POST['inventory_id']);
        
        try {
            $deleteSql = "DELETE FROM inventory WHERE inventory_id = :inventory_id";
            $stmt = $db->prepare($deleteSql);
            $result = $stmt->execute([':inventory_id' => $inventoryId]);
            
            if ($result) {
                logAudit($db, $_SESSION['user_id'], 'Inventory Deleted', 'inventory', $inventoryId, 
                    'Inventory record deleted');
                $success = 'Inventory deleted successfully!';
            }
        } catch(PDOException $e) {
            $error = 'Error deleting inventory: ' . $e->getMessage();
        }
    }
}

// Get inventory
try {
    $inventorySql = "SELECT i.*, bt.blood_type 
                     FROM inventory i 
                     JOIN blood_types bt ON i.blood_type_id = bt.blood_type_id 
                     ORDER BY bt.blood_type, i.last_updated DESC";
    $stmt = $db->prepare($inventorySql);
    $stmt->execute();
    $inventory = $stmt->fetchAll();
} catch(PDOException $e) {
    $inventory = [];
}

// Get blood types
try {
    $bloodTypesSql = "SELECT * FROM blood_types ORDER BY blood_type";
    $stmt = $db->prepare($bloodTypesSql);
    $stmt->execute();
    $bloodTypes = $stmt->fetchAll();
} catch(PDOException $e) {
    $bloodTypes = [];
}

// Get summary by blood type
try {
    $summarySql = "SELECT bt.blood_type, bt.blood_type_id, SUM(i.quantity_ml) as total_ml, 
                   COUNT(*) as batch_count 
                   FROM inventory i 
                   JOIN blood_types bt ON i.blood_type_id = bt.blood_type_id 
                   WHERE i.status = 'available' 
                   GROUP BY bt.blood_type_id 
                   ORDER BY bt.blood_type";
    $stmt = $db->prepare($summarySql);
    $stmt->execute();
    $summary = $stmt->fetchAll();
} catch(PDOException $e) {
    $summary = [];
}

$pageTitle = 'Manage Inventory';
include '../includes/admin_header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include '../includes/admin_sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="bi bi-box-seam text-success me-2"></i>Blood Inventory</h1>
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addModal">
                    <i class="bi bi-plus-circle me-1"></i>Add Inventory
                </button>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="bi bi-check-circle-fill me-2"></i><?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Summary Cards -->
            <div class="row mb-4">
                <?php foreach ($summary as $item): ?>
                    <?php 
                        $units = floor($item['total_ml'] / 450);
                        $percentage = min(($units / 20) * 100, 100);
                        $statusClass = $percentage > 50 ? 'success' : ($percentage > 20 ? 'warning' : 'danger');
                    ?>
                    <div class="col-md-3 mb-3">
                        <div class="card border-0 shadow-sm">
                            <div class="card-body">
                                <h4 class="text-danger fw-bold mb-2"><?php echo $item['blood_type']; ?></h4>
                                <div class="progress mb-2" style="height: 20px;">
                                    <div class="progress-bar bg-<?php echo $statusClass; ?>" 
                                         role="progressbar" 
                                         style="width: <?php echo $percentage; ?>%">
                                        <?php echo $units; ?>
                                    </div>
                                </div>
                                <small class="text-muted"><?php echo $units; ?> units (<?php echo $item['total_ml']; ?>ml)</small><br>
                                <small class="text-muted"><?php echo $item['batch_count']; ?> batch(es)</small>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Inventory Table -->
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="inventoryTable">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Blood Type</th>
                                    <th>Quantity</th>
                                    <th>Units</th>
                                    <th>Expiry Date</th>
                                    <th>Status</th>
                                    <th>Last Updated</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($inventory) > 0): ?>
                                    <?php foreach ($inventory as $item): ?>
                                        <?php 
                                            $units = floor($item['quantity_ml'] / 450);
                                            $daysToExpiry = $item['expiry_date'] ? 
                                                            floor((strtotime($item['expiry_date']) - time()) / 86400) : null;
                                        ?>
                                        <tr class="<?php echo ($daysToExpiry !== null && $daysToExpiry < 7) ? 'table-warning' : ''; ?>">
                                            <td><?php echo $item['inventory_id']; ?></td>
                                            <td><span class="badge bg-danger fs-6"><?php echo $item['blood_type']; ?></span></td>
                                            <td><?php echo $item['quantity_ml']; ?>ml</td>
                                            <td><?php echo $units; ?> units</td>
                                            <td>
                                                <?php echo formatDate($item['expiry_date']); ?>
                                                <?php if ($daysToExpiry !== null && $daysToExpiry < 7): ?>
                                                    <br><small class="text-danger">Expires in <?php echo $daysToExpiry; ?> days</small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $item['status'] === 'available' ? 'success' : 
                                                         ($item['status'] === 'reserved' ? 'warning' : 'danger'); 
                                                ?>">
                                                    <?php echo ucfirst($item['status']); ?>
                                                </span>
                                            </td>
                                            <td><small><?php echo formatDateTime($item['last_updated']); ?></small></td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-primary" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#editModal<?php echo $item['inventory_id']; ?>">
                                                    <i class="bi bi-pencil"></i>
                                                </button>
                                                <button type="button" class="btn btn-sm btn-danger" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#deleteModal<?php echo $item['inventory_id']; ?>">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </td>
                                        </tr>

                                        <!-- Edit Modal -->
                                        <div class="modal fade" id="editModal<?php echo $item['inventory_id']; ?>" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Update Inventory</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <form method="POST">
                                                        <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">
                                                        <input type="hidden" name="inventory_id" value="<?php echo $item['inventory_id']; ?>">
                                                        <div class="modal-body">
                                                            <div class="mb-3">
                                                                <label class="form-label">Blood Type</label>
                                                                <input type="text" class="form-control" value="<?php echo $item['blood_type']; ?>" disabled>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">Quantity (ml)</label>
                                                                <input type="number" name="quantity_ml" class="form-control" 
                                                                       value="<?php echo $item['quantity_ml']; ?>" required min="0">
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">Expiry Date</label>
                                                                <input type="date" name="expiry_date" class="form-control" 
                                                                       value="<?php echo $item['expiry_date']; ?>" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">Status</label>
                                                                <select name="status" class="form-select" required>
                                                                    <option value="available" <?php echo $item['status'] === 'available' ? 'selected' : ''; ?>>Available</option>
                                                                    <option value="reserved" <?php echo $item['status'] === 'reserved' ? 'selected' : ''; ?>>Reserved</option>
                                                                    <option value="expired" <?php echo $item['status'] === 'expired' ? 'selected' : ''; ?>>Expired</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" name="update_inventory" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Delete Modal -->
                                        <div class="modal fade" id="deleteModal<?php echo $item['inventory_id']; ?>" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Confirm Delete</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Are you sure you want to delete this inventory record?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <form method="POST">
                                                            <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">
                                                            <input type="hidden" name="inventory_id" value="<?php echo $item['inventory_id']; ?>">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" name="delete_inventory" class="btn btn-danger">Delete</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-muted py-4">No inventory records</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Inventory</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Blood Type</label>
                        <select name="blood_type_id" class="form-select" required>
                            <option value="">Select Blood Type</option>
                            <?php foreach ($bloodTypes as $type): ?>
                                <option value="<?php echo $type['blood_type_id']; ?>">
                                    <?php echo $type['blood_type']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Quantity (ml)</label>
                        <input type="number" name="quantity_ml" class="form-control" required min="0" value="450">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Expiry Date</label>
                        <input type="date" name="expiry_date" class="form-control" required 
                               min="<?php echo date('Y-m-d'); ?>" value="<?php echo date('Y-m-d', strtotime('+42 days')); ?>">
                        <small class="form-text text-muted">Blood typically expires in 42 days</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select" required>
                            <option value="available" selected>Available</option>
                            <option value="reserved">Reserved</option>
                            <option value="expired">Expired</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_inventory" class="btn btn-success">Add</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
$(document).ready(function() {
    $('#inventoryTable').DataTable({
        "order": [[0, "desc"]],
        "pageLength": 25
    });
});
</script>

<?php include '../includes/footer.php'; ?>
