<?php
/**
 * Admin Notification Management
 * Send and manage notifications to users
 */

require_once '../config/config.php';
require_once '../config/db.php';
require_once '../config/notification_functions.php';

requireAdmin();

$success = '';
$error = '';

// Handle notification sending
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_notification'])) {
    if (!validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid security token';
    } else {
        $title = sanitize($_POST['title']);
        $message = sanitize($_POST['message']);
        $type = sanitize($_POST['type']);
        $recipient_type = sanitize($_POST['recipient_type']);
        
        if (empty($title) || empty($message)) {
            $error = 'Title and message are required';
        } else {
            $recipientCount = 0;
            
            try {
                if ($recipient_type === 'all_users') {
                    $recipientCount = notifyAllUsers($db, $title, $message, $type, $_SESSION['user_id']);
                } elseif ($recipient_type === 'all_donors') {
                    // Get all users who are donors
                    $sql = "SELECT DISTINCT u.user_id FROM users u 
                            JOIN donors_info di ON u.user_id = di.user_id 
                            WHERE u.status = 'active' AND u.user_role = 'user'";
                    $stmt = $db->prepare($sql);
                    $stmt->execute();
                    $donors = $stmt->fetchAll(PDO::FETCH_COLUMN);
                    
                    foreach ($donors as $userId) {
                        createNotification($db, $userId, $title, $message, $type);
                    }
                    $recipientCount = count($donors);
                    
                    logAudit($db, $_SESSION['user_id'], 'Notification Sent to Donors', 'notifications', null, 
                            "Sent to $recipientCount donors: $title");
                    
                } elseif ($recipient_type === 'eligible_donors') {
                    // Get eligible donors
                    $sql = "SELECT DISTINCT u.user_id FROM users u 
                            JOIN donors_info di ON u.user_id = di.user_id 
                            WHERE di.eligible_to_donate = 'Yes' 
                            AND u.status = 'active' AND u.user_role = 'user'";
                    $stmt = $db->prepare($sql);
                    $stmt->execute();
                    $eligibleDonors = $stmt->fetchAll(PDO::FETCH_COLUMN);
                    
                    foreach ($eligibleDonors as $userId) {
                        createNotification($db, $userId, $title, $message, $type);
                    }
                    $recipientCount = count($eligibleDonors);
                    
                    logAudit($db, $_SESSION['user_id'], 'Notification Sent to Eligible Donors', 'notifications', null, 
                            "Sent to $recipientCount eligible donors: $title");
                    
                } elseif ($recipient_type === 'specific_user' && !empty($_POST['user_id'])) {
                    $userId = intval($_POST['user_id']);
                    createNotification($db, $userId, $title, $message, $type);
                    $recipientCount = 1;
                    
                    logAudit($db, $_SESSION['user_id'], 'Notification Sent to User', 'notifications', null, 
                            "Sent to user ID $userId: $title");
                }
                
                if ($recipientCount > 0) {
                    $success = "Notification sent successfully to $recipientCount recipient(s)";
                } else {
                    $error = 'No recipients found for the selected criteria';
                }
                
            } catch(PDOException $e) {
                $error = 'Error sending notification: ' . $e->getMessage();
            }
        }
    }
}

// Handle automated reminders
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_donation_reminders'])) {
    $count = sendDonationReminders($db, $_SESSION['user_id']);
    $success = "Sent donation reminders to $count eligible donors";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_appointment_reminders'])) {
    $count = sendAppointmentReminders($db, 24, $_SESSION['user_id']);
    $success = "Sent appointment reminders to $count users";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_event_reminders'])) {
    $count = sendEventReminders($db, 3, $_SESSION['user_id']);
    $success = "Sent event reminders to $count participants";
}

// Get all users for dropdown
try {
    $usersSql = "SELECT user_id, username, full_name, email FROM users 
                 WHERE user_role = 'user' AND status = 'active' 
                 ORDER BY username";
    $stmt = $db->prepare($usersSql);
    $stmt->execute();
    $users = $stmt->fetchAll();
} catch(PDOException $e) {
    $users = [];
}

// Get notification statistics
try {
    $statsSql = "SELECT 
                 COUNT(*) as total_notifications,
                 COUNT(DISTINCT user_id) as unique_recipients,
                 SUM(CASE WHEN is_read = 'No' THEN 1 ELSE 0 END) as unread_count,
                 SUM(CASE WHEN DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) as today_count
                 FROM notifications";
    $stmt = $db->prepare($statsSql);
    $stmt->execute();
    $stats = $stmt->fetch();
} catch(PDOException $e) {
    $stats = ['total_notifications' => 0, 'unique_recipients' => 0, 'unread_count' => 0, 'today_count' => 0];
}

// Get recent notifications
try {
    $recentSql = "SELECT n.*, u.username, u.full_name 
                  FROM notifications n 
                  JOIN users u ON n.user_id = u.user_id 
                  ORDER BY n.created_at DESC 
                  LIMIT 10";
    $stmt = $db->prepare($recentSql);
    $stmt->execute();
    $recentNotifications = $stmt->fetchAll();
} catch(PDOException $e) {
    $recentNotifications = [];
}

$pageTitle = 'Manage Notifications';
include '../includes/admin_header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include '../includes/admin_sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <i class="bi bi-bell text-warning me-2"></i>Manage Notifications
                </h1>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="bi bi-check-circle-fill me-2"></i><?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Statistics -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <i class="bi bi-bell-fill text-primary" style="font-size: 2rem;"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="text-muted mb-1">Total Notifications</h6>
                                    <h3 class="mb-0"><?php echo number_format($stats['total_notifications']); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <i class="bi bi-envelope-open text-danger" style="font-size: 2rem;"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="text-muted mb-1">Unread</h6>
                                    <h3 class="mb-0"><?php echo number_format($stats['unread_count']); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <i class="bi bi-calendar-day text-success" style="font-size: 2rem;"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="text-muted mb-1">Sent Today</h6>
                                    <h3 class="mb-0"><?php echo number_format($stats['today_count']); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <i class="bi bi-people text-info" style="font-size: 2rem;"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="text-muted mb-1">Recipients</h6>
                                    <h3 class="mb-0"><?php echo number_format($stats['unique_recipients']); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Send Notification Form -->
                <div class="col-md-6 mb-4">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0">
                                <i class="bi bi-send me-2"></i>Send Notification
                            </h5>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">
                                
                                <div class="mb-3">
                                    <label class="form-label">Title *</label>
                                    <input type="text" name="title" class="form-control" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Message *</label>
                                    <textarea name="message" class="form-control" rows="4" required></textarea>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Type</label>
                                    <select name="type" class="form-select" required>
                                        <option value="info">Info</option>
                                        <option value="success">Success</option>
                                        <option value="warning">Warning</option>
                                        <option value="error">Error</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Recipients *</label>
                                    <select name="recipient_type" id="recipient_type" class="form-select" required>
                                        <option value="all_users">All Active Users</option>
                                        <option value="all_donors">All Donors</option>
                                        <option value="eligible_donors">Eligible Donors Only</option>
                                        <option value="specific_user">Specific User</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3" id="user_select_div" style="display: none;">
                                    <label class="form-label">Select User</label>
                                    <select name="user_id" class="form-select">
                                        <option value="">-- Select User --</option>
                                        <?php foreach ($users as $user): ?>
                                            <option value="<?php echo $user['user_id']; ?>">
                                                <?php echo htmlspecialchars($user['username']); ?> 
                                                - <?php echo htmlspecialchars($user['full_name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <button type="submit" name="send_notification" class="btn btn-primary w-100">
                                    <i class="bi bi-send me-1"></i>Send Notification
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Automated Reminders -->
                <div class="col-md-6 mb-4">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-success text-white">
                            <h5 class="mb-0">
                                <i class="bi bi-clock-history me-2"></i>Automated Reminders
                            </h5>
                        </div>
                        <div class="card-body">
                            <p class="text-muted">Send automated reminder notifications to users</p>
                            
                            <form method="POST" class="mb-3">
                                <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">
                                <button type="submit" name="send_donation_reminders" 
                                        class="btn btn-outline-success w-100 mb-2"
                                        onclick="return confirm('Send donation reminders to all eligible donors?')">
                                    <i class="bi bi-droplet me-1"></i>
                                    Send Donation Reminders
                                </button>
                                <small class="text-muted d-block mb-3">
                                    Reminds eligible donors (56+ days since last donation) to donate blood
                                </small>
                            </form>
                            
                            <form method="POST" class="mb-3">
                                <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">
                                <button type="submit" name="send_appointment_reminders" 
                                        class="btn btn-outline-success w-100 mb-2"
                                        onclick="return confirm('Send appointment reminders to users with upcoming appointments?')">
                                    <i class="bi bi-calendar-check me-1"></i>
                                    Send Appointment Reminders
                                </button>
                                <small class="text-muted d-block mb-3">
                                    Reminds users about appointments in the next 24 hours
                                </small>
                            </form>
                            
                            <form method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">
                                <button type="submit" name="send_event_reminders" 
                                        class="btn btn-outline-success w-100 mb-2"
                                        onclick="return confirm('Send event reminders to registered participants?')">
                                    <i class="bi bi-calendar-event me-1"></i>
                                    Send Event Reminders
                                </button>
                                <small class="text-muted d-block">
                                    Reminds participants about events in the next 3 days
                                </small>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Quick Stats -->
                    <div class="card border-0 shadow-sm mt-3">
                        <div class="card-header bg-info text-white">
                            <h5 class="mb-0">
                                <i class="bi bi-info-circle me-2"></i>Quick Statistics
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php
                            try {
                                // Count eligible donors
                                $eligibleSql = "SELECT COUNT(*) as count FROM donors_info 
                                               WHERE eligible_to_donate = 'Yes'";
                                $stmt = $db->prepare($eligibleSql);
                                $stmt->execute();
                                $eligibleCount = $stmt->fetch()['count'];
                                
                                // Count upcoming appointments
                                $appointmentsSql = "SELECT COUNT(*) as count FROM appointments 
                                                   WHERE status IN ('scheduled', 'confirmed') 
                                                   AND appointment_date >= CURDATE()";
                                $stmt = $db->prepare($appointmentsSql);
                                $stmt->execute();
                                $upcomingAppointments = $stmt->fetch()['count'];
                                
                                // Count upcoming events
                                $eventsSql = "SELECT COUNT(*) as count FROM events 
                                             WHERE status = 'upcoming' AND event_date >= CURDATE()";
                                $stmt = $db->prepare($eventsSql);
                                $stmt->execute();
                                $upcomingEvents = $stmt->fetch()['count'];
                            } catch(PDOException $e) {
                                $eligibleCount = $upcomingAppointments = $upcomingEvents = 0;
                            }
                            ?>
                            
                            <ul class="list-unstyled mb-0">
                                <li class="mb-2">
                                    <i class="bi bi-droplet-fill text-danger me-2"></i>
                                    <strong><?php echo $eligibleCount; ?></strong> Eligible Donors
                                </li>
                                <li class="mb-2">
                                    <i class="bi bi-calendar-check-fill text-primary me-2"></i>
                                    <strong><?php echo $upcomingAppointments; ?></strong> Upcoming Appointments
                                </li>
                                <li>
                                    <i class="bi bi-calendar-event-fill text-success me-2"></i>
                                    <strong><?php echo $upcomingEvents; ?></strong> Upcoming Events
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Notifications -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="bi bi-clock-history me-2"></i>Recent Notifications
                    </h5>
                </div>
                <div class="card-body p-0">
                    <?php if (count($recentNotifications) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Recipient</th>
                                        <th>Title</th>
                                        <th>Message</th>
                                        <th>Type</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recentNotifications as $notif): ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo htmlspecialchars($notif['username']); ?></strong><br>
                                                <small class="text-muted"><?php echo htmlspecialchars($notif['full_name']); ?></small>
                                            </td>
                                            <td><?php echo htmlspecialchars($notif['title']); ?></td>
                                            <td>
                                                <small><?php echo htmlspecialchars(substr($notif['message'], 0, 50)); ?>...</small>
                                            </td>
                                            <td>
                                                <?php
                                                $badgeClass = 'bg-info';
                                                switch ($notif['type']) {
                                                    case 'success': $badgeClass = 'bg-success'; break;
                                                    case 'warning': $badgeClass = 'bg-warning'; break;
                                                    case 'error': $badgeClass = 'bg-danger'; break;
                                                }
                                                ?>
                                                <span class="badge <?php echo $badgeClass; ?>">
                                                    <?php echo ucfirst($notif['type']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($notif['is_read'] === 'Yes'): ?>
                                                    <span class="badge bg-secondary">Read</span>
                                                <?php else: ?>
                                                    <span class="badge bg-primary">Unread</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <small><?php echo formatDateTime($notif['created_at']); ?></small>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-bell-slash" style="font-size: 5rem; color: #dee2e6;"></i>
                            <h4 class="mt-3 text-muted">No Recent Notifications</h4>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
document.getElementById('recipient_type').addEventListener('change', function() {
    var userSelectDiv = document.getElementById('user_select_div');
    if (this.value === 'specific_user') {
        userSelectDiv.style.display = 'block';
    } else {
        userSelectDiv.style.display = 'none';
    }
});
</script>

<?php include '../includes/footer.php'; ?>
