<?php
/**
 * Password Hash Generator
 * Use this to generate secure password hashes for admin users
 */

// Generate hash for admin123
$adminPassword = 'admin123';
$adminHash = password_hash($adminPassword, PASSWORD_BCRYPT, ['cost' => 12]);

// Generate hash for user123
$userPassword = 'user123';
$userHash = password_hash($userPassword, PASSWORD_BCRYPT, ['cost' => 12]);

echo "=== PASSWORD HASHES GENERATED ===\n\n";
echo "Admin Password: $adminPassword\n";
echo "Admin Hash: $adminHash\n\n";
echo "User Password: $userPassword\n";
echo "User Hash: $userHash\n\n";

// Verify the hashes work
echo "=== VERIFICATION ===\n";
echo "Admin password verification: " . (password_verify($adminPassword, $adminHash) ? 'SUCCESS' : 'FAILED') . "\n";
echo "User password verification: " . (password_verify($userPassword, $userHash) ? 'SUCCESS' : 'FAILED') . "\n";
?>
