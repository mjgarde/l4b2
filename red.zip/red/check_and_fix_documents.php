<?php
/**
 * Check and Fix Document Issues
 */

require_once 'config/config.php';
require_once 'config/db.php';

echo "<h2>🔍 Checking Document Issues...</h2>";
echo "<style>
    body { font-family: Arial; padding: 20px; }
    .error { background: #ffcccc; padding: 10px; margin: 10px 0; border-radius: 5px; }
    .success { background: #ccffcc; padding: 10px; margin: 10px 0; border-radius: 5px; }
    .info { background: #cce5ff; padding: 10px; margin: 10px 0; border-radius: 5px; }
    .warning { background: #fff3cd; padding: 10px; margin: 10px 0; border-radius: 5px; }
    pre { background: #f4f4f4; padding: 10px; border-radius: 5px; overflow-x: auto; }
    .btn { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; margin: 5px; }
    .btn-success { background: #28a745; }
    .btn-danger { background: #dc3545; }
</style>";

try {
    // Get all documents
    $sql = "SELECT d.*, u.full_name, u.username 
            FROM user_documents d 
            JOIN users u ON d.user_id = u.user_id 
            ORDER BY d.document_id";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $documents = $stmt->fetchAll();
    
    echo "<div class='info'><strong>📄 Total Documents in Database: " . count($documents) . "</strong></div>";
    
    $issuesFound = [];
    $fixedCount = 0;
    
    foreach ($documents as $doc) {
        $filePath = $doc['file_path'];
        $fullPath = __DIR__ . '/' . $filePath;
        $fileExists = file_exists($fullPath);
        
        echo "<hr>";
        echo "<h3>Document ID: {$doc['document_id']} - {$doc['full_name']}</h3>";
        echo "<strong>Type:</strong> {$doc['document_type']}<br>";
        echo "<strong>Current Path:</strong> <code>$filePath</code><br>";
        echo "<strong>Full Path:</strong> <code>$fullPath</code><br>";
        echo "<strong>File Exists:</strong> " . ($fileExists ? "✅ YES" : "❌ NO") . "<br>";
        
        if (!$fileExists) {
            echo "<div class='error'>⚠️ FILE NOT FOUND!</div>";
            
            // Try to find the correct file
            $fileName = basename($filePath);
            $documentType = $doc['document_type'];
            
            // Determine correct directory
            if ($documentType === 'medical_certificate') {
                $correctDir = 'uploads/medical_certificates/';
            } else {
                $correctDir = 'uploads/profile_photos/';
            }
            
            // Check if path needs fixing
            if (strpos($filePath, 'uploads/documents/') !== false) {
                $newPath = str_replace('uploads/documents/', $correctDir, $filePath);
                $issuesFound[] = [
                    'document_id' => $doc['document_id'],
                    'old_path' => $filePath,
                    'new_path' => $newPath
                ];
                echo "<div class='warning'>🔧 Suggested Fix: Change path to <code>$newPath</code></div>";
            }
            
            // Try to create sample file
            $targetPath = __DIR__ . '/' . $correctDir . $fileName;
            $targetDir = dirname($targetPath);
            
            if (!is_dir($targetDir)) {
                mkdir($targetDir, 0755, true);
            }
            
            // Look for existing sample files
            $existingFiles = glob($targetDir . '*.*');
            if (!empty($existingFiles) && !file_exists($targetPath)) {
                // Copy first available file as sample
                copy($existingFiles[0], $targetPath);
                echo "<div class='success'>✅ Created sample file: $targetPath</div>";
                $fixedCount++;
            }
        } else {
            echo "<div class='success'>✅ File exists and is accessible!</div>";
            
            // Show image preview if it's an image
            $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
                echo "<img src='$filePath' style='max-width: 200px; border: 2px solid #ccc; border-radius: 5px; margin-top: 10px;'>";
            }
        }
    }
    
    // Show SQL to fix paths
    if (!empty($issuesFound)) {
        echo "<hr><div class='warning'>";
        echo "<h3>🔧 SQL Fix Required</h3>";
        echo "<p>Copy and run this SQL in phpMyAdmin:</p>";
        echo "<pre>";
        foreach ($issuesFound as $issue) {
            echo "UPDATE user_documents SET file_path = '{$issue['new_path']}' WHERE document_id = {$issue['document_id']};\n";
        }
        echo "</pre>";
        echo "<a href='database/fix_document_paths.sql' class='btn'>View Fix SQL File</a>";
        echo "</div>";
    }
    
    echo "<hr>";
    echo "<div class='info'>";
    echo "<h3>📊 Summary</h3>";
    echo "<p>✅ Files Created/Fixed: $fixedCount</p>";
    echo "<p>⚠️ Issues Found: " . count($issuesFound) . "</p>";
    echo "</div>";
    
    echo "<div style='margin-top: 20px;'>";
    echo "<a href='admin/user_approvals.php' class='btn btn-success'>Go to User Approvals</a>";
    echo "<a href='javascript:location.reload()' class='btn'>Refresh This Page</a>";
    echo "</div>";
    
} catch(PDOException $e) {
    echo "<div class='error'>❌ Database Error: " . $e->getMessage() . "</div>";
}
?>
