# 🚀 QUICK START GUIDE

## ❌ Getting "An error occurred. Please try again."?

This usually means the **database hasn't been imported yet**!

---

## 📋 Step-by-Step Setup (5 minutes)

### Step 1: Start XAMPP ✅
1. Open **XAMPP Control Panel**
2. Click **Start** for **Apache**
3. Click **Start** for **MySQL**
4. Wait until both show "Running" (green)

### Step 2: Check Database Status 🔍
1. Open browser
2. Go to: **`http://localhost/Koronadal%20Red%20Cross/check_database.php`**
3. This will show you what's wrong

### Step 3: Import Database 📦

#### If database DOESN'T EXIST:
1. Open: **`http://localhost/phpmyadmin`**
2. Click **"Import"** tab at the top
3. Click **"Choose File"** button
4. Navigate to: `c:\xampp\htdocs\Koronadal Red Cross\database\koronadal_redcross.sql`
5. Click **"Go"** button at the bottom
6. Wait for success message ✅

#### If database EXISTS but passwords are wrong:
1. Open: **`http://localhost/phpmyadmin`**
2. Click on **`koronadal_redcross`** database (left sidebar)
3. Click **"SQL"** tab
4. Open file: `database/update_passwords.sql` with Notepad
5. Copy ALL the contents
6. Paste into SQL tab in phpMyAdmin
7. Click **"Go"** ✅

### Step 4: Test Login 🔐
1. Go to: **`http://localhost/Koronadal%20Red%20Cross/login.php`**
2. Enter:
   - **Username**: `admin`
   - **Password**: `admin123`
3. Click **Sign In**
4. Should redirect to Admin Dashboard ✅

---

## 🆘 Still Not Working?

### Run the Diagnostic Tool:
```
http://localhost/Koronadal%20Red%20Cross/check_database.php
```

This will tell you EXACTLY what's wrong!

### Common Issues:

#### 1. "Connection Error" message
- ❌ MySQL is not running
- ✅ Start MySQL in XAMPP Control Panel

#### 2. "Database does not exist"
- ❌ SQL file not imported
- ✅ Import `database/koronadal_redcross.sql` in phpMyAdmin

#### 3. "Invalid username or password"
- ❌ Wrong password hash in database
- ✅ Run `database/update_passwords.sql` in phpMyAdmin

#### 4. "Account is pending/suspended/inactive"
- ❌ User status is not 'active'
- ✅ Check user status in database, should be 'active'

---

## 📝 Correct Login Credentials

### Admin Account:
```
Username: admin
OR
Email: admin@koronadalredcross.org
Password: admin123
```

### Test User:
```
Username: jdoe
Email: jdoe@email.com
Password: user123
```

---

## 🎯 Quick Checklist

Before trying to login, make sure:

- [ ] XAMPP Apache is running (green)
- [ ] XAMPP MySQL is running (green)
- [ ] Database imported (check phpMyAdmin)
- [ ] Using correct credentials (admin/admin123)
- [ ] No typos in username/password
- [ ] Ran check_database.php to verify

---

## 💡 Pro Tips

1. **Copy-paste the credentials** - avoid typos!
2. **Check Caps Lock** - password is case-sensitive
3. **Clear browser cache** if issues persist
4. **Use Chrome/Firefox** for best compatibility
5. **Check browser console** (F12) for JavaScript errors

---

## 📞 Files That Can Help

| File | Purpose |
|------|---------|
| `check_database.php` | 🔍 Diagnose database issues |
| `database/koronadal_redcross.sql` | 📦 Main database import |
| `database/update_passwords.sql` | 🔑 Fix password issues |
| `CREDENTIALS.md` | 📋 All login credentials |
| `LOGIN_FIX_SUMMARY.md` | 📖 Detailed fix guide |

---

## ✅ Expected Result

After successful login:
- **Admin** → redirects to **Admin Dashboard**
- **Regular User** → redirects to **User Dashboard**

You should see:
- Welcome message with your name
- Navigation menu
- Dashboard statistics
- No error messages

---

## 🎉 That's It!

If you followed all steps and ran `check_database.php`, you should be able to login now!

**Need more help?** Check the error message from `check_database.php` - it will tell you exactly what to do!
