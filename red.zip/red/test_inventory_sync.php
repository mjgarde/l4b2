<?php
/**
 * TEST INVENTORY SYNC
 * Check if admin inventory matches user request page
 */

require_once 'config/config.php';
require_once 'config/db.php';

echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>Test Inventory Sync</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
</head>
<body class='p-4'>
<div class='container'>
    <h2 class='mb-4'>🔍 Testing Inventory Sync</h2>";

try {
    // Get blood types
    $bloodTypesSql = "SELECT * FROM blood_types ORDER BY blood_type";
    $stmt = $db->prepare($bloodTypesSql);
    $stmt->execute();
    $bloodTypes = $stmt->fetchAll();
    
    echo "<div class='alert alert-info'>Found " . count($bloodTypes) . " blood types</div>";
    
    // Get inventory using the SAME query as request.php
    $inventorySql = "SELECT bt.blood_type, bt.blood_type_id, SUM(i.quantity_ml) as available_ml 
                     FROM inventory i 
                     JOIN blood_types bt ON i.blood_type_id = bt.blood_type_id 
                     WHERE i.status = 'available' 
                     GROUP BY bt.blood_type_id 
                     ORDER BY bt.blood_type";
    $stmt = $db->prepare($inventorySql);
    $stmt->execute();
    $inventoryRaw = $stmt->fetchAll();
    
    // Convert to key-pair array like in request.php
    $inventory = [];
    foreach ($inventoryRaw as $row) {
        $inventory[$row['blood_type_id']] = $row['available_ml'];
    }
    
    echo "<div class='card mb-4'>
            <div class='card-header bg-primary text-white'>
                <h5 class='mb-0'>Inventory Query Results</h5>
            </div>
            <div class='card-body'>";
    
    if (empty($inventory)) {
        echo "<div class='alert alert-danger'>
                ❌ <strong>EMPTY INVENTORY!</strong><br>
                This is why user sees 'Not Available' for everything!
              </div>";
    } else {
        echo "<div class='alert alert-success'>
                ✅ Found inventory for " . count($inventory) . " blood type(s)
              </div>";
        
        echo "<table class='table table-striped'>
                <tr><th>Blood Type ID</th><th>Blood Type</th><th>Total ML</th><th>Units</th></tr>";
        
        foreach ($inventoryRaw as $row) {
            $units = floor($row['available_ml'] / 450);
            echo "<tr>
                    <td>{$row['blood_type_id']}</td>
                    <td><strong>{$row['blood_type']}</strong></td>
                    <td>{$row['available_ml']}ml</td>
                    <td><span class='badge bg-success'>$units units</span></td>
                  </tr>";
        }
        echo "</table>";
    }
    
    echo "</div></div>";
    
    // Test what user sees
    echo "<div class='card mb-4'>
            <div class='card-header bg-warning'>
                <h5 class='mb-0'>What User Sees (Simulated)</h5>
            </div>
            <div class='card-body'>
                <table class='table'>
                    <tr><th>Blood Type</th><th>Available ML</th><th>Units</th><th>Status</th></tr>";
    
    foreach ($bloodTypes as $type) {
        $available = isset($inventory[$type['blood_type_id']]) ? 
                    floor($inventory[$type['blood_type_id']] / 450) : 0;
        
        $status = $available > 0 ? 
            "<span class='badge bg-success'>✅ $available units available</span>" :
            "<span class='badge bg-danger'>❌ Not Available</span>";
        
        $ml = isset($inventory[$type['blood_type_id']]) ? $inventory[$type['blood_type_id']] : 0;
        
        echo "<tr>
                <td><strong>{$type['blood_type']}</strong></td>
                <td>{$ml}ml</td>
                <td>$available</td>
                <td>$status</td>
              </tr>";
    }
    
    echo "</table>
          </div>
        </div>";
    
    // Check raw inventory table
    echo "<div class='card mb-4'>
            <div class='card-header bg-info text-white'>
                <h5 class='mb-0'>Raw Inventory Table Data</h5>
            </div>
            <div class='card-body'>";
    
    $rawSql = "SELECT i.*, bt.blood_type 
               FROM inventory i 
               JOIN blood_types bt ON i.blood_type_id = bt.blood_type_id 
               ORDER BY bt.blood_type, i.inventory_id";
    $rawStmt = $db->query($rawSql);
    $rawData = $rawStmt->fetchAll();
    
    if (empty($rawData)) {
        echo "<div class='alert alert-danger'>
                ❌ <strong>INVENTORY TABLE IS EMPTY!</strong><br>
                <p>You need to add inventory first:</p>
                <ol>
                    <li>Run: <code>database/auto_add_inventory.php</code></li>
                    <li>OR manually add in Admin → Manage Inventory</li>
                </ol>
              </div>";
    } else {
        echo "<div class='alert alert-success'>✅ Found " . count($rawData) . " inventory record(s)</div>";
        echo "<table class='table table-sm'>
                <tr>
                    <th>ID</th>
                    <th>Blood Type</th>
                    <th>Quantity</th>
                    <th>Units</th>
                    <th>Status</th>
                    <th>Expiry</th>
                </tr>";
        
        foreach ($rawData as $item) {
            $units = floor($item['quantity_ml'] / 450);
            $statusClass = $item['status'] === 'available' ? 'success' : 'secondary';
            
            echo "<tr>
                    <td>{$item['inventory_id']}</td>
                    <td><strong>{$item['blood_type']}</strong></td>
                    <td>{$item['quantity_ml']}ml</td>
                    <td>$units</td>
                    <td><span class='badge bg-$statusClass'>{$item['status']}</span></td>
                    <td>{$item['expiry_date']}</td>
                  </tr>";
        }
        echo "</table>";
    }
    
    echo "</div></div>";
    
    // Solution
    if (empty($rawData)) {
        echo "<div class='alert alert-danger'>
                <h4>🚨 SOLUTION:</h4>
                <p><strong>The inventory table is EMPTY!</strong></p>
                <p>Click the button below to automatically add sample inventory:</p>
                <a href='database/auto_add_inventory.php' class='btn btn-success btn-lg'>
                    <i class='bi bi-plus-circle'></i> Add Sample Inventory Now
                </a>
              </div>";
    } else {
        echo "<div class='alert alert-success'>
                <h4>✅ GOOD NEWS!</h4>
                <p>Inventory data exists and should be showing correctly on the request page.</p>
                <p>If user still sees 'Not Available', try:</p>
                <ol>
                    <li>Hard refresh the request page (Ctrl + Shift + R)</li>
                    <li>Clear browser cache</li>
                    <li>Make sure you're logged in as a user (not admin)</li>
                </ol>
              </div>";
    }
    
} catch(PDOException $e) {
    echo "<div class='alert alert-danger'>
            ❌ Error: " . $e->getMessage() . "
          </div>";
}

echo "<div class='text-center mt-4'>
        <a href='admin/manage_inventory.php' class='btn btn-primary btn-lg'>View Admin Inventory</a>
        <a href='request.php' class='btn btn-success btn-lg'>View User Request Page</a>
        <a href='javascript:location.reload()' class='btn btn-secondary btn-lg'>Refresh</a>
      </div>";

echo "</div>
</body>
</html>";
?>
