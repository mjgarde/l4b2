<?php
/**
 * Fix Upload Paths - Complete Solution
 */

require_once 'config/config.php';
require_once 'config/db.php';

echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>Fix Upload Paths</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
    <style>
        body { padding: 30px; background: #f8f9fa; }
        .success { background: #d4edda; padding: 15px; margin: 10px 0; border-radius: 8px; border-left: 4px solid #28a745; }
        .error { background: #f8d7da; padding: 15px; margin: 10px 0; border-radius: 8px; border-left: 4px solid #dc3545; }
        .warning { background: #fff3cd; padding: 15px; margin: 10px 0; border-radius: 8px; border-left: 4px solid #ffc107; }
        .info { background: #d1ecf1; padding: 15px; margin: 10px 0; border-radius: 8px; border-left: 4px solid #17a2b8; }
        pre { background: #f4f4f4; padding: 10px; border-radius: 5px; }
    </style>
</head>
<body>
<div class='container'>
    <h2>🔧 Fixing Upload Paths</h2>
    <hr>";

try {
    // STEP 1: Check and create directories
    echo "<div class='info'><h4>Step 1: Creating/Checking Directories</h4>";
    
    $directories = [
        'uploads/medical_certificates',
        'uploads/profile_photos'
    ];
    
    foreach ($directories as $dir) {
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
            echo "✅ Created directory: <code>$dir</code><br>";
        } else {
            echo "✅ Directory exists: <code>$dir</code><br>";
        }
    }
    echo "</div>";
    
    // STEP 2: Get all documents from database
    echo "<div class='info'><h4>Step 2: Checking Documents in Database</h4>";
    
    $sql = "SELECT * FROM user_documents ORDER BY document_id";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $documents = $stmt->fetchAll();
    
    echo "Found " . count($documents) . " document(s)<br>";
    echo "</div>";
    
    // STEP 3: Fix paths
    echo "<div class='warning'><h4>Step 3: Fixing Paths</h4>";
    
    $fixed = 0;
    $errors = [];
    
    foreach ($documents as $doc) {
        $oldPath = $doc['file_path'];
        $newPath = $oldPath;
        $needsFix = false;
        
        // Fix singular to plural
        if (strpos($oldPath, 'uploads/medical_certificate/') !== false) {
            $newPath = str_replace('uploads/medical_certificate/', 'uploads/medical_certificates/', $oldPath);
            $needsFix = true;
        }
        
        if (strpos($oldPath, 'uploads/profile_photo/') !== false) {
            $newPath = str_replace('uploads/profile_photo/', 'uploads/profile_photos/', $oldPath);
            $needsFix = true;
        }
        
        // Fix old documents path
        if (strpos($oldPath, 'uploads/documents/') !== false) {
            if ($doc['document_type'] === 'medical_certificate') {
                $newPath = str_replace('uploads/documents/', 'uploads/medical_certificates/', $oldPath);
            } else {
                $newPath = str_replace('uploads/documents/', 'uploads/profile_photos/', $oldPath);
            }
            $needsFix = true;
        }
        
        if ($needsFix) {
            // Update database
            $updateSql = "UPDATE user_documents SET file_path = :new_path WHERE document_id = :doc_id";
            $updateStmt = $db->prepare($updateSql);
            $updateStmt->execute([
                ':new_path' => $newPath,
                ':doc_id' => $doc['document_id']
            ]);
            
            echo "<div class='success'>";
            echo "✅ Fixed Document ID {$doc['document_id']}<br>";
            echo "&nbsp;&nbsp;&nbsp;OLD: <code>$oldPath</code><br>";
            echo "&nbsp;&nbsp;&nbsp;NEW: <code>$newPath</code>";
            echo "</div>";
            
            $fixed++;
        }
    }
    
    if ($fixed === 0) {
        echo "<div class='success'>✅ All paths are already correct!</div>";
    } else {
        echo "<div class='success'><strong>✅ Fixed $fixed path(s)!</strong></div>";
    }
    
    echo "</div>";
    
    // STEP 4: Create sample files
    echo "<div class='info'><h4>Step 4: Creating Sample Files</h4>";
    
    // Function to create a simple image
    function createSampleImage($filepath, $text) {
        $width = 600;
        $height = 400;
        $image = imagecreatetruecolor($width, $height);
        
        // Colors
        $bg = imagecolorallocate($image, 230, 240, 255);
        $text_color = imagecolorallocate($image, 50, 50, 50);
        $border = imagecolorallocate($image, 100, 100, 100);
        
        // Fill background
        imagefill($image, 0, 0, $bg);
        
        // Draw border
        imagerectangle($image, 10, 10, $width-10, $height-10, $border);
        imagerectangle($image, 11, 11, $width-11, $height-11, $border);
        
        // Add text (centered)
        $lines = explode("\\n", $text);
        $y = ($height / 2) - (count($lines) * 10);
        foreach ($lines as $line) {
            imagestring($image, 5, 50, $y, $line, $text_color);
            $y += 30;
        }
        
        // Save
        imagejpeg($image, $filepath, 90);
        imagedestroy($image);
    }
    
    // Create sample medical certificate
    $medicalSample = 'uploads/medical_certificates/medical_cert_sample.jpg';
    if (!file_exists($medicalSample)) {
        createSampleImage($medicalSample, "SAMPLE MEDICAL CERTIFICATE\\nFor Testing Purposes");
        echo "✅ Created: <code>$medicalSample</code><br>";
    }
    
    // Create sample photo ID
    $photoSample = 'uploads/profile_photos/valid_id_sample.jpg';
    if (!file_exists($photoSample)) {
        createSampleImage($photoSample, "SAMPLE PHOTO ID / VALID ID\\nFor Testing Purposes");
        echo "✅ Created: <code>$photoSample</code><br>";
    }
    
    echo "</div>";
    
    // STEP 5: Verify all documents
    echo "<div class='info'><h4>Step 5: Verification</h4>";
    
    $sql = "SELECT * FROM user_documents ORDER BY document_id";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $documents = $stmt->fetchAll();
    
    echo "<table class='table table-striped'>";
    echo "<tr>
            <th>ID</th>
            <th>Type</th>
            <th>File Path</th>
            <th>Status</th>
          </tr>";
    
    foreach ($documents as $doc) {
        $fileExists = file_exists($doc['file_path']);
        $status = $fileExists ? 
            "<span class='badge bg-success'>✅ EXISTS</span>" : 
            "<span class='badge bg-danger'>❌ NOT FOUND</span>";
        
        echo "<tr>
                <td>{$doc['document_id']}</td>
                <td>{$doc['document_type']}</td>
                <td><small><code>{$doc['file_path']}</code></small></td>
                <td>$status</td>
              </tr>";
    }
    
    echo "</table>";
    echo "</div>";
    
    echo "<hr>";
    echo "<div class='success'>";
    echo "<h3>✅ All Done!</h3>";
    echo "<p>Document paths have been fixed and verified.</p>";
    echo "</div>";
    
    echo "<div class='mt-4'>";
    echo "<a href='admin/user_approvals.php' class='btn btn-success btn-lg'>Go to User Approvals</a>";
    echo "<a href='javascript:location.reload()' class='btn btn-primary btn-lg ms-2'>Refresh This Page</a>";
    echo "</div>";
    
} catch(Exception $e) {
    echo "<div class='error'>❌ Error: " . $e->getMessage() . "</div>";
}

echo "</div>
</body>
</html>";
?>
