<?php
/**
 * User Dashboard
 * Main dashboard for regular users
 */

require_once 'config/config.php';
require_once 'config/db.php';

// Require login
requireLogin();

// Check session timeout
if (!checkSessionTimeout()) {
    redirect('login.php');
}

$userId = $_SESSION['user_id'];

// Get user details
try {
    $userSql = "SELECT u.*, bt.blood_type, di.donor_id, di.last_donation_date, di.eligible_to_donate 
                FROM users u 
                LEFT JOIN blood_types bt ON u.blood_type_id = bt.blood_type_id 
                LEFT JOIN donors_info di ON u.user_id = di.user_id 
                WHERE u.user_id = :user_id";
    $userStmt = $db->prepare($userSql);
    $userStmt->execute([':user_id' => $userId]);
    $user = $userStmt->fetch();
} catch(PDOException $e) {
    $user = null;
}

// Get statistics
try {
    // Total donations
    $donationCountSql = "SELECT COUNT(*) as count FROM donations d 
                         JOIN donors_info di ON d.donor_id = di.donor_id 
                         WHERE di.user_id = :user_id";
    $stmt = $db->prepare($donationCountSql);
    $stmt->execute([':user_id' => $userId]);
    $donationCount = $stmt->fetch()['count'];
    
    // Total requests
    $requestCountSql = "SELECT COUNT(*) as count FROM requests WHERE user_id = :user_id";
    $stmt = $db->prepare($requestCountSql);
    $stmt->execute([':user_id' => $userId]);
    $requestCount = $stmt->fetch()['count'];
    
    // Pending requests
    $pendingRequestsSql = "SELECT COUNT(*) as count FROM requests 
                           WHERE user_id = :user_id AND status = 'pending'";
    $stmt = $db->prepare($pendingRequestsSql);
    $stmt->execute([':user_id' => $userId]);
    $pendingRequests = $stmt->fetch()['count'];
    
    // Unread notifications
    $unreadNotifications = getUnreadNotificationCount($db, $userId);
} catch(PDOException $e) {
    $donationCount = 0;
    $requestCount = 0;
    $pendingRequests = 0;
    $unreadNotifications = 0;
}

// Get recent donations
try {
    $recentDonationsSql = "SELECT d.*, bt.blood_type 
                           FROM donations d 
                           JOIN donors_info di ON d.donor_id = di.donor_id 
                           JOIN blood_types bt ON d.blood_type_id = bt.blood_type_id 
                           WHERE di.user_id = :user_id 
                           ORDER BY d.donation_date DESC LIMIT 5";
    $stmt = $db->prepare($recentDonationsSql);
    $stmt->execute([':user_id' => $userId]);
    $recentDonations = $stmt->fetchAll();
} catch(PDOException $e) {
    $recentDonations = [];
}

// Get recent requests
try {
    $recentRequestsSql = "SELECT r.*, bt.blood_type 
                          FROM requests r 
                          JOIN blood_types bt ON r.blood_type_id = bt.blood_type_id 
                          WHERE r.user_id = :user_id 
                          ORDER BY r.created_at DESC LIMIT 5";
    $stmt = $db->prepare($recentRequestsSql);
    $stmt->execute([':user_id' => $userId]);
    $recentRequests = $stmt->fetchAll();
} catch(PDOException $e) {
    $recentRequests = [];
}

// Get recent notifications
try {
    $notificationsSql = "SELECT * FROM notifications 
                        WHERE user_id = :user_id 
                        ORDER BY created_at DESC LIMIT 5";
    $stmt = $db->prepare($notificationsSql);
    $stmt->execute([':user_id' => $userId]);
    $notifications = $stmt->fetchAll();
} catch(PDOException $e) {
    $notifications = [];
}

// Get upcoming events
try {
    $upcomingEventsSql = "SELECT e.*, 
           (SELECT COUNT(*) FROM appointments WHERE event_id = e.event_id) as registered_count,
           (SELECT COUNT(*) FROM appointments WHERE event_id = e.event_id AND user_id = :user_id) as user_registered
           FROM events e 
           WHERE e.status = 'upcoming' AND e.event_date >= CURDATE()
           ORDER BY e.event_date ASC LIMIT 3";
    $stmt = $db->prepare($upcomingEventsSql);
    $stmt->execute([':user_id' => $userId]);
    $upcomingEvents = $stmt->fetchAll();
} catch(PDOException $e) {
    $upcomingEvents = [];
}

include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php include 'includes/user_sidebar.php'; ?>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="bi bi-speedometer2 me-2"></i>Dashboard</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <a href="donate.php" class="btn btn-sm btn-danger">
                            <i class="bi bi-droplet-fill me-1"></i>Donate Blood
                        </a>
                        <a href="request.php" class="btn btn-sm btn-outline-danger">
                            <i class="bi bi-bandaid me-1"></i>Request Blood
                        </a>
                    </div>
                </div>
            </div>

            <!-- Welcome Message -->
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <i class="bi bi-info-circle-fill me-2"></i>
                <strong>Welcome back, <?php echo htmlspecialchars($user['full_name']); ?>!</strong> 
                <?php if ($user['blood_type']): ?>
                    Your blood type is <strong><?php echo $user['blood_type']; ?></strong>.
                <?php endif; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>

            <!-- Statistics Cards -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="text-muted mb-1">Total Donations</p>
                                    <h3 class="mb-0 fw-bold"><?php echo $donationCount; ?></h3>
                                </div>
                                <div class="text-danger">
                                    <i class="bi bi-droplet-fill" style="font-size: 2.5rem;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 mb-3">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="text-muted mb-1">Total Requests</p>
                                    <h3 class="mb-0 fw-bold"><?php echo $requestCount; ?></h3>
                                </div>
                                <div class="text-primary">
                                    <i class="bi bi-bandaid" style="font-size: 2.5rem;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 mb-3">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="text-muted mb-1">Pending Requests</p>
                                    <h3 class="mb-0 fw-bold"><?php echo $pendingRequests; ?></h3>
                                </div>
                                <div class="text-warning">
                                    <i class="bi bi-clock-history" style="font-size: 2.5rem;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 mb-3">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="text-muted mb-1">Notifications</p>
                                    <h3 class="mb-0 fw-bold"><?php echo $unreadNotifications; ?></h3>
                                </div>
                                <div class="text-info">
                                    <i class="bi bi-bell-fill" style="font-size: 2.5rem;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Eligibility Status -->
            <?php if ($user['donor_id']): ?>
            <div class="row mb-4">
                <div class="col-md-12">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title fw-bold mb-3">
                                <i class="bi bi-clipboard-check me-2"></i>Donation Eligibility
                            </h5>
                            <?php if ($user['eligible_to_donate'] === 'Yes'): ?>
                                <div class="alert alert-success mb-0">
                                    <i class="bi bi-check-circle-fill me-2"></i>
                                    You are currently eligible to donate blood!
                                    <?php if ($user['last_donation_date']): ?>
                                        <br><small>Last donation: <?php echo formatDate($user['last_donation_date']); ?></small>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-warning mb-0">
                                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                                    You are currently not eligible to donate.
                                    <?php if ($user['last_donation_date']): ?>
                                        <br><small>Please wait at least <?php echo MIN_DONATION_INTERVAL_DAYS; ?> days after your last donation (<?php echo formatDate($user['last_donation_date']); ?>).</small>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Upcoming Events -->
            <?php if (count($upcomingEvents) > 0): ?>
            <div class="row mb-4">
                <div class="col-md-12">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-white d-flex justify-content-between align-items-center">
                            <h5 class="mb-0 fw-bold">
                                <i class="bi bi-calendar-event me-2 text-success"></i>Upcoming Blood Donation Events
                            </h5>
                            <a href="events.php" class="btn btn-sm btn-success">View All</a>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <?php foreach ($upcomingEvents as $event): 
                                    $percentage = $event['max_participants'] > 0 ? round(($event['registered_count'] / $event['max_participants']) * 100) : 0;
                                    $isRegistered = $event['user_registered'] > 0;
                                    $daysUntil = floor((strtotime($event['event_date']) - time()) / 86400);
                                ?>
                                <div class="col-md-4">
                                    <div class="card mb-3" style="border-left: 4px solid #28a745;">
                                        <div class="card-body">
                                            <h6 class="fw-bold text-success"><?php echo htmlspecialchars($event['event_name']); ?></h6>
                                            <p class="text-muted small mb-2">
                                                <i class="bi bi-calendar3 me-1"></i><?php echo date('M j, Y', strtotime($event['event_date'])); ?>
                                                <span class="badge bg-info text-dark ms-2">in <?php echo $daysUntil; ?> days</span>
                                            </p>
                                            <p class="text-muted small mb-2">
                                                <i class="bi bi-geo-alt me-1"></i><?php echo htmlspecialchars($event['event_location']); ?>
                                            </p>
                                            <div class="mb-2">
                                                <small class="text-muted"><?php echo $event['registered_count']; ?> / <?php echo $event['max_participants']; ?> joined</small>
                                                <div class="progress" style="height: 5px;">
                                                    <div class="progress-bar bg-success" style="width: <?php echo $percentage; ?>%"></div>
                                                </div>
                                            </div>
                                            <?php if ($isRegistered): ?>
                                                <span class="badge bg-success w-100">
                                                    <i class="bi bi-check-circle me-1"></i>You're Registered!
                                                </span>
                                            <?php else: ?>
                                                <a href="events.php" class="btn btn-sm btn-outline-success w-100">
                                                    <i class="bi bi-calendar-plus me-1"></i>Register Now
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="row">
                <!-- Recent Donations -->
                <div class="col-md-6 mb-4">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-white">
                            <h5 class="mb-0 fw-bold">
                                <i class="bi bi-droplet-half me-2"></i>Recent Donations
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php if (count($recentDonations) > 0): ?>
                                <div class="list-group list-group-flush">
                                    <?php foreach ($recentDonations as $donation): ?>
                                        <div class="list-group-item px-0">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <h6 class="mb-1">
                                                        <span class="badge bg-danger"><?php echo $donation['blood_type']; ?></span>
                                                        <?php echo $donation['quantity_ml']; ?>ml
                                                    </h6>
                                                    <small class="text-muted">
                                                        <i class="bi bi-calendar me-1"></i><?php echo formatDate($donation['donation_date']); ?>
                                                    </small>
                                                </div>
                                                <span class="badge bg-<?php 
                                                    echo $donation['status'] === 'completed' ? 'success' : 
                                                         ($donation['status'] === 'pending' ? 'warning' : 
                                                         ($donation['status'] === 'approved' ? 'info' : 'danger')); 
                                                ?>">
                                                    <?php echo ucfirst($donation['status']); ?>
                                                </span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <div class="text-center mt-3">
                                    <a href="donations.php" class="btn btn-sm btn-outline-danger">View All</a>
                                </div>
                            <?php else: ?>
                                <p class="text-muted text-center py-3 mb-0">No donations yet</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Recent Requests -->
                <div class="col-md-6 mb-4">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-white">
                            <h5 class="mb-0 fw-bold">
                                <i class="bi bi-bandaid me-2"></i>Recent Requests
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php if (count($recentRequests) > 0): ?>
                                <div class="list-group list-group-flush">
                                    <?php foreach ($recentRequests as $request): ?>
                                        <div class="list-group-item px-0">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <h6 class="mb-1">
                                                        <span class="badge bg-primary"><?php echo $request['blood_type']; ?></span>
                                                        <?php echo htmlspecialchars($request['patient_name']); ?>
                                                    </h6>
                                                    <small class="text-muted">
                                                        <i class="bi bi-hospital me-1"></i><?php echo htmlspecialchars($request['hospital_name']); ?>
                                                    </small>
                                                </div>
                                                <span class="badge bg-<?php 
                                                    echo $request['status'] === 'fulfilled' ? 'success' : 
                                                         ($request['status'] === 'pending' ? 'warning' : 
                                                         ($request['status'] === 'approved' ? 'info' : 'danger')); 
                                                ?>">
                                                    <?php echo ucfirst($request['status']); ?>
                                                </span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <div class="text-center mt-3">
                                    <a href="requests.php" class="btn btn-sm btn-outline-primary">View All</a>
                                </div>
                            <?php else: ?>
                                <p class="text-muted text-center py-3 mb-0">No requests yet</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Notifications -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-white">
                            <h5 class="mb-0 fw-bold">
                                <i class="bi bi-bell me-2"></i>Recent Notifications
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php if (count($notifications) > 0): ?>
                                <div class="list-group list-group-flush">
                                    <?php foreach ($notifications as $notification): ?>
                                        <div class="list-group-item px-0 <?php echo $notification['is_read'] === 'No' ? 'bg-light' : ''; ?>">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <div>
                                                    <h6 class="mb-1">
                                                        <?php if ($notification['is_read'] === 'No'): ?>
                                                            <span class="badge bg-primary">New</span>
                                                        <?php endif; ?>
                                                        <?php echo htmlspecialchars($notification['title']); ?>
                                                    </h6>
                                                    <p class="mb-1"><?php echo htmlspecialchars($notification['message']); ?></p>
                                                    <small class="text-muted">
                                                        <i class="bi bi-clock me-1"></i><?php echo formatDateTime($notification['created_at']); ?>
                                                    </small>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <div class="text-center mt-3">
                                    <a href="notifications.php" class="btn btn-sm btn-outline-info">View All</a>
                                </div>
                            <?php else: ?>
                                <p class="text-muted text-center py-3 mb-0">No notifications</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
