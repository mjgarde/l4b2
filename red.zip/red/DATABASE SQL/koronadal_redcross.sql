-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 20, 2026 at 10:57 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `koronadal_redcross`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `appointment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL,
  `purpose` enum('donation','consultation','other') DEFAULT 'donation',
  `status` enum('scheduled','confirmed','completed','cancelled') DEFAULT 'scheduled',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`appointment_id`, `user_id`, `event_id`, `appointment_date`, `appointment_time`, `purpose`, `status`, `notes`, `created_at`) VALUES
(1, 2, 1, '2024-12-15', '09:00:00', 'donation', 'confirmed', 'First time donor', '2025-10-28 20:41:52'),
(2, 3, 1, '2024-12-15', '10:30:00', 'donation', 'confirmed', 'Regular donor', '2025-10-28 20:41:52');

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `table_affected` varchar(50) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`log_id`, `user_id`, `action`, `table_affected`, `record_id`, `details`, `ip_address`, `created_at`) VALUES
(1, 1, 'Database Initialized', 'All Tables', NULL, 'Initial database setup with sample data', '127.0.0.1', '2025-10-28 20:41:52'),
(2, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 21:50:11'),
(3, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-28 21:52:51'),
(4, 1, 'User Login', 'users', 1, 'Successful login', '192.168.254.110', '2025-10-28 21:56:02'),
(5, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 21:56:22'),
(6, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 22:04:38'),
(7, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 2', '::1', '2025-10-28 22:12:32'),
(8, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 3', '::1', '2025-10-28 22:12:32'),
(9, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 4', '::1', '2025-10-28 22:12:32'),
(10, 1, 'Donation Reminders Sent', 'notifications', NULL, 'Sent reminders to 3 eligible donors', '::1', '2025-10-28 22:12:32'),
(11, 1, 'Event Status Changed', 'events', 1, 'Status changed to: ongoing', '::1', '2025-10-28 22:23:57'),
(12, 1, 'Event Status Changed', 'events', 1, 'Status changed to: ongoing', '::1', '2025-10-28 22:24:02'),
(13, 1, 'Event Status Changed', 'events', 1, 'Status changed to: ongoing', '::1', '2025-10-28 22:25:28'),
(14, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 2', '::1', '2025-10-28 22:28:23'),
(15, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 3', '::1', '2025-10-28 22:28:24'),
(16, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 4', '::1', '2025-10-28 22:28:24'),
(17, 1, 'Donation Reminders Sent', 'notifications', NULL, 'Sent reminders to 3 eligible donors', '::1', '2025-10-28 22:28:24'),
(18, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 2', '::1', '2025-10-28 22:29:36'),
(19, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 3', '::1', '2025-10-28 22:29:36'),
(20, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 4', '::1', '2025-10-28 22:29:36'),
(21, 1, 'Donation Reminders Sent', 'notifications', NULL, 'Sent reminders to 3 eligible donors', '::1', '2025-10-28 22:29:36'),
(22, 1, 'Inventory Updated', 'inventory', 1, 'Inventory updated', '::1', '2025-10-28 22:30:06'),
(23, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 2', '::1', '2025-10-28 22:31:50'),
(24, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 3', '::1', '2025-10-28 22:31:51'),
(25, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 4', '::1', '2025-10-28 22:31:51'),
(26, 1, 'Donation Reminders Sent', 'notifications', NULL, 'Sent reminders to 3 eligible donors', '::1', '2025-10-28 22:31:51'),
(27, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 2', '::1', '2025-10-28 22:32:15'),
(28, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 3', '::1', '2025-10-28 22:32:15'),
(29, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 4', '::1', '2025-10-28 22:32:16'),
(30, 1, 'Donation Reminders Sent', 'notifications', NULL, 'Sent reminders to 3 eligible donors', '::1', '2025-10-28 22:32:16'),
(31, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-28 22:34:31'),
(32, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 22:36:14'),
(33, 1, 'User Approval', 'users', 6, 'Approved user: kien', '::1', '2025-10-28 22:42:40'),
(34, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-28 22:45:38'),
(35, 6, 'User Login', 'users', 6, 'Successful login', '::1', '2025-10-28 22:45:53'),
(36, 6, 'User Logout', 'users', 6, 'User logged out', '::1', '2025-10-28 22:47:27'),
(37, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 22:47:29'),
(38, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-28 22:48:09'),
(39, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 22:48:15'),
(40, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-28 22:51:52'),
(41, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 22:57:04'),
(42, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 23:12:26'),
(43, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-28 23:23:57'),
(44, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 23:24:53'),
(45, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 23:31:18'),
(46, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-28 23:35:56'),
(47, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 23:37:22'),
(48, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 23:40:51'),
(49, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-28 23:41:04'),
(50, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 23:44:17'),
(51, 1, 'User Rejection', 'users', 11, 'Rejected user: tatin - Reason: ', '::1', '2025-10-28 23:44:36'),
(52, 1, 'User Rejection', 'users', 10, 'Rejected user: kbalais - Reason: ', '::1', '2025-10-28 23:45:03'),
(53, 1, 'Appointment Confirmed', 'appointments', 1, 'Admin confirmed appointment for user ID: 2', '::1', '2025-10-28 23:45:32'),
(54, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-28 23:45:52'),
(55, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 23:46:57'),
(56, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-28 23:47:03'),
(57, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 23:48:45'),
(58, 1, 'User Approval', 'users', 12, 'Approved user: wows', '::1', '2025-10-28 23:48:59'),
(59, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-28 23:50:32'),
(60, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 23:51:05'),
(61, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-28 23:53:13'),
(62, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 23:54:46'),
(63, 1, 'User Approval', 'users', 13, 'Approved user: adin', '::1', '2025-10-28 23:56:38'),
(64, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-28 23:56:40'),
(65, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 23:57:08'),
(66, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-28 23:57:14'),
(67, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-28 23:57:40'),
(68, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-28 23:58:53'),
(69, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-28 23:58:56'),
(70, 1, 'Event Completed', 'events', 1, 'Event marked as completed', '::1', '2025-10-29 00:11:03'),
(71, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 00:11:16'),
(72, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-29 00:11:40'),
(73, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-29 00:12:15'),
(74, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 00:12:16'),
(75, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 00:12:47'),
(76, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-29 00:13:02'),
(77, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-29 00:14:14'),
(78, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 00:14:19'),
(79, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 00:16:09'),
(80, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-29 00:16:22'),
(81, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-29 00:18:42'),
(82, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 00:18:44'),
(83, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 00:20:40'),
(84, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-29 00:20:53'),
(85, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-29 00:22:00'),
(86, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 00:22:03'),
(87, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 00:23:40'),
(88, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 00:23:42'),
(89, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 00:24:40'),
(90, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-29 00:24:54'),
(91, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-29 00:29:05'),
(92, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 00:29:07'),
(93, 1, 'User Login', 'users', 1, 'Successful login', '192.168.254.102', '2025-10-29 01:25:27'),
(94, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 01:26:56'),
(95, 1, 'User Status Updated', 'users', 13, 'Status updated to: active', '::1', '2025-10-29 01:37:47'),
(96, 12, 'User Login', 'users', 12, 'Successful login', '192.168.254.111', '2025-10-29 01:39:05'),
(97, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 01:42:13'),
(98, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-29 01:42:24'),
(99, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-29 01:44:09'),
(100, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 01:44:20'),
(101, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 01:46:04'),
(102, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 01:48:05'),
(103, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 01:48:19'),
(104, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-29 01:48:29'),
(105, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-29 01:49:22'),
(106, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 01:49:29'),
(107, 1, 'Inventory Added', 'inventory', 20, 'New inventory record added', '::1', '2025-10-29 01:51:46'),
(108, 1, 'Inventory Updated', 'inventory', 20, 'Inventory updated', '::1', '2025-10-29 01:52:18'),
(109, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 01:52:38'),
(110, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-29 01:52:46'),
(111, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-29 01:54:34'),
(112, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 01:54:40'),
(113, 1, 'Request Status Updated', 'requests', 2, 'Status changed to cancelled', '::1', '2025-10-29 02:02:52'),
(114, 1, 'Request Status Updated', 'requests', 2, 'Status changed to cancelled', '::1', '2025-10-29 02:03:54'),
(115, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 02:11:02'),
(116, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 02:11:58'),
(117, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-29 02:12:05'),
(118, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-29 02:14:34'),
(119, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 02:14:41'),
(120, 1, 'User Status Updated', 'users', 13, 'Status updated to: active', '::1', '2025-10-29 02:16:30'),
(121, 1, 'User Role Updated', 'users', 13, 'Role updated to: user', '::1', '2025-10-29 02:16:32'),
(122, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 02:17:56'),
(123, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-29 02:18:03'),
(124, 13, 'Blood Request Submitted', 'requests', 3, 'User submitted blood request for Trizzle Kien', '::1', '2025-10-29 02:19:12'),
(125, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-29 02:19:20'),
(126, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 02:19:34'),
(127, 1, 'Request Status Updated', 'requests', 3, 'Status changed to approved', '::1', '2025-10-29 02:20:30'),
(128, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 02:20:43'),
(129, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-29 02:20:51'),
(130, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-29 02:25:57'),
(131, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 02:26:16'),
(132, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 02:33:55'),
(133, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-29 02:34:04'),
(134, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-29 02:36:52'),
(135, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 02:36:57'),
(136, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 02:37:47'),
(137, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-29 02:38:04'),
(138, 13, 'Donation Submitted', 'donations', 29, 'User submitted new donation', '::1', '2025-10-29 02:40:55'),
(139, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-29 02:40:57'),
(140, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 02:41:05'),
(141, 1, 'Donation Status Updated', 'donations', 4, 'Status changed to approved', '::1', '2025-10-29 02:41:25'),
(142, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 02:41:48'),
(143, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 02:42:08'),
(144, 1, 'Donation Status Updated', 'donations', 4, 'Status changed to completed', '::1', '2025-10-29 02:42:28'),
(145, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 02:42:31'),
(146, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-29 02:42:38'),
(147, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-29 02:49:19'),
(148, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 02:50:13'),
(149, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 02:51:34'),
(150, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 02:52:34'),
(151, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 02:55:01'),
(152, 14, 'User Registration', 'users', 14, 'New user registered - Pending approval', '::1', '2025-10-29 02:56:21'),
(153, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 02:56:35'),
(154, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 03:03:17'),
(155, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 03:05:19'),
(156, 1, 'User Approval', 'users', 14, 'Approved user: mork', '::1', '2025-10-29 03:10:54'),
(157, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 03:11:09'),
(158, 15, 'User Registration', 'users', 15, 'New user registered - Pending approval', '::1', '2025-10-29 03:13:03'),
(159, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 03:13:12'),
(160, 1, 'User Rejection', 'users', 15, 'Rejected user: daddi - Reason: pok pok ka kasi forever', '::1', '2025-10-29 03:13:32'),
(161, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 2', '::1', '2025-10-29 04:20:56'),
(162, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 3', '::1', '2025-10-29 04:20:56'),
(163, NULL, 'Eligibility Notification Sent', 'notifications', NULL, 'Eligibility notification sent to user ID: 4', '::1', '2025-10-29 04:20:56'),
(164, 1, 'Donation Reminders Sent', 'notifications', NULL, 'Sent reminders to 3 eligible donors', '::1', '2025-10-29 04:20:56'),
(165, 1, 'Notification Sent to Donors', 'notifications', NULL, 'Sent to 4 donors: hi', '::1', '2025-10-29 04:21:25'),
(166, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 04:22:01'),
(167, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-29 04:22:09'),
(168, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-29 04:23:20'),
(169, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 04:23:30'),
(170, 1, 'Mass Notification Sent', 'notifications', NULL, 'Sent to 7 users: New Blood Drive Event', '::1', '2025-10-29 04:25:07'),
(171, 1, 'New Event Created', 'events', 3, 'Created event: Blood Awareness Seminar - Notified 7 users', '::1', '2025-10-29 04:25:07'),
(172, 1, 'Event Created', 'events', 3, 'Created event: Blood Awareness Seminar - Notified 7 users', '::1', '2025-10-29 04:25:07'),
(173, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 04:25:12'),
(174, 13, 'User Login', 'users', 13, 'Successful login', '::1', '2025-10-29 04:25:21'),
(175, 13, 'User Logout', 'users', 13, 'User logged out', '::1', '2025-10-29 04:26:48'),
(176, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 04:26:56'),
(177, 14, 'User Login', 'users', 14, 'Successful login', '::1', '2025-10-29 04:35:12'),
(178, 14, 'Blood Request Submitted', 'requests', 4, 'User submitted blood request for Taton', '::1', '2025-10-29 04:36:26'),
(179, 14, 'Blood Request Submitted', 'requests', 5, 'User submitted blood request for Taton', '::1', '2025-10-29 04:36:29'),
(180, 1, 'Request Status Updated', 'requests', 5, 'Status changed to approved', '::1', '2025-10-29 04:36:53'),
(181, 1, 'Request Status Updated', 'requests', 4, 'Status changed to rejected', '::1', '2025-10-29 04:38:06'),
(182, 1, 'Request Status Updated', 'requests', 5, 'Status changed to fulfilled', '::1', '2025-10-29 04:40:57'),
(183, 1, 'Request Status Updated', 'requests', 5, 'Status changed to fulfilled', '::1', '2025-10-29 04:41:08'),
(184, 14, 'Donation Submitted', 'donations', 60, 'User submitted new donation', '::1', '2025-10-29 04:43:14'),
(185, 1, 'Donation Status Updated', 'donations', 5, 'Status changed to approved', '::1', '2025-10-29 04:47:00'),
(186, 1, 'Donation Status Updated', 'donations', 5, 'Status changed to completed', '::1', '2025-10-29 04:47:18'),
(187, 1, 'Donation Status Updated', 'donations', 5, 'Status changed to rejected', '::1', '2025-10-29 04:47:51'),
(188, 1, 'Donation Status Updated', 'donations', 5, 'Status changed to rejected', '::1', '2025-10-29 04:47:52'),
(189, 1, 'Donation Status Updated', 'donations', 5, 'Status changed to rejected', '::1', '2025-10-29 04:54:36'),
(190, 1, 'Donation Status Updated', 'donations', 5, 'Status changed to approved', '::1', '2025-10-29 04:54:45'),
(191, 1, 'Donation Status Updated', 'donations', 5, 'Status changed to completed', '::1', '2025-10-29 04:55:28'),
(192, 1, 'Donation Status Updated', 'donations', 5, 'Status changed to rejected', '::1', '2025-10-29 04:55:42'),
(193, 1, 'Request Status Updated', 'requests', 2, 'Status changed to rejected', '::1', '2025-10-29 04:56:26'),
(194, 1, 'Request Status Updated', 'requests', 5, 'Status changed to rejected', '::1', '2025-10-29 04:56:46'),
(195, 1, 'Request Status Updated', 'requests', 5, 'Status changed to approved', '::1', '2025-10-29 04:57:02'),
(196, 1, 'Request Status Updated', 'requests', 5, 'Status changed to fulfilled', '::1', '2025-10-29 04:57:18'),
(197, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 04:58:19'),
(198, 16, 'User Registration', 'users', 16, 'New user registered - Pending approval', '::1', '2025-10-29 04:59:56'),
(199, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 05:00:10'),
(200, 1, 'User Rejection', 'users', 16, 'Rejected user: Nekki - Reason: happi kaayu kang bilaaana ka', '::1', '2025-10-29 05:00:42'),
(201, 1, 'User Logout', 'users', 1, 'User logged out', '::1', '2025-10-29 05:01:12'),
(202, 17, 'User Registration', 'users', 17, 'New user registered - Pending approval', '::1', '2025-10-29 05:04:33'),
(203, 1, 'User Login', 'users', 1, 'Successful login', '::1', '2025-10-29 05:04:49'),
(204, 1, 'User Rejection', 'users', 17, 'Rejected user: Carlo - Reason: Adtu kag police ha', '::1', '2025-10-29 05:05:29'),
(205, 14, 'User Logout', 'users', 14, 'User logged out', '::1', '2025-10-29 05:06:16'),
(206, 1, 'User Status Updated', 'users', 16, 'Status updated to: active', '::1', '2025-10-29 05:07:17'),
(207, 16, 'User Login', 'users', 16, 'Successful login', '::1', '2025-10-29 05:07:23'),
(208, 16, 'Blood Request Submitted', 'requests', 6, 'User submitted blood request for nekki bilaan', '::1', '2025-10-29 05:08:20'),
(209, 1, 'Request Status Updated', 'requests', 6, 'Status changed to rejected', '::1', '2025-10-29 05:08:55'),
(210, 1, 'Request Status Updated', 'requests', 6, 'Status changed to approved', '::1', '2025-10-29 05:09:32'),
(211, 1, 'Request Status Updated', 'requests', 6, 'Status changed to fulfilled', '::1', '2025-10-29 05:10:06'),
(212, 18, 'User Registration', 'users', 18, 'New user registered - Pending approval', '127.0.0.1', '2026-03-12 12:16:15'),
(213, NULL, 'User Login', 'users', 21, 'Successful login', '127.0.0.1', '2026-03-12 12:29:24'),
(214, NULL, 'User Login', 'users', 21, 'Successful login', '127.0.0.1', '2026-03-12 19:30:15'),
(215, NULL, 'User Logout', 'users', 21, 'User logged out', '127.0.0.1', '2026-03-12 19:59:55'),
(216, NULL, 'User Login', 'users', 21, 'Successful login', '127.0.0.1', '2026-03-12 20:15:12'),
(217, NULL, 'User Login', 'users', 21, 'Successful login', '127.0.0.1', '2026-03-12 20:51:49'),
(219, 22, 'User Login', 'users', 22, 'Successful login', '127.0.0.1', '2026-03-12 20:59:44'),
(220, 22, 'User Logout', 'users', 22, 'User logged out', '127.0.0.1', '2026-03-12 21:09:12'),
(221, 23, 'User Login', 'users', 23, 'Successful login', '127.0.0.1', '2026-03-12 21:09:28'),
(222, 22, 'User Login', 'users', 22, 'Successful login', '127.0.0.1', '2026-03-13 00:18:10'),
(223, 22, 'User Logout', 'users', 22, 'User logged out', '127.0.0.1', '2026-03-13 02:33:47'),
(224, 22, 'User Login', 'users', 22, 'Successful login', '192.168.144.87', '2026-03-13 02:38:27'),
(225, 22, 'User Login', 'users', 22, 'Successful login', '192.168.144.132', '2026-03-13 02:48:07'),
(226, 22, 'User Login', 'users', 22, 'Successful login', '127.0.0.1', '2026-03-13 02:49:57'),
(227, 23, 'User Login', 'users', 23, 'Successful login', '127.0.0.1', '2026-03-14 08:03:36'),
(228, 23, 'User Logout', 'users', 23, 'User logged out', '127.0.0.1', '2026-03-14 08:04:31'),
(229, 22, 'User Login', 'users', 22, 'Successful login', '127.0.0.1', '2026-03-14 08:05:39'),
(230, 22, 'User Logout', 'users', 22, 'User logged out', '127.0.0.1', '2026-03-14 08:08:36'),
(231, 22, 'User Login', 'users', 22, 'Successful login', '127.0.0.1', '2026-03-14 10:11:11'),
(232, 22, 'User Logout', 'users', 22, 'User logged out', '127.0.0.1', '2026-03-14 10:14:40'),
(233, 23, 'User Login', 'users', 23, 'Successful login', '127.0.0.1', '2026-03-14 10:14:48'),
(234, 22, 'User Login', 'users', 22, 'Successful login', '127.0.0.1', '2026-03-16 23:53:16'),
(235, 22, 'User Logout', 'users', 22, 'User logged out', '127.0.0.1', '2026-03-16 23:53:20'),
(236, 22, 'User Login', 'users', 22, 'Successful login', '127.0.0.1', '2026-03-20 21:25:27'),
(237, 22, 'User Logout', 'users', 22, 'User logged out', '127.0.0.1', '2026-03-20 21:26:25');

-- --------------------------------------------------------

--
-- Table structure for table `blood_types`
--

CREATE TABLE `blood_types` (
  `blood_type_id` int(11) NOT NULL,
  `blood_type` varchar(5) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blood_types`
--

INSERT INTO `blood_types` (`blood_type_id`, `blood_type`, `description`, `created_at`) VALUES
(1, 'A+', 'Blood Type A Positive', '2025-10-28 20:41:52'),
(2, 'A-', 'Blood Type A Negative', '2025-10-28 20:41:52'),
(3, 'B+', 'Blood Type B Positive', '2025-10-28 20:41:52'),
(4, 'B-', 'Blood Type B Negative', '2025-10-28 20:41:52'),
(5, 'AB+', 'Blood Type AB Positive', '2025-10-28 20:41:52'),
(6, 'AB-', 'Blood Type AB Negative', '2025-10-28 20:41:52'),
(7, 'O+', 'Blood Type O Positive', '2025-10-28 20:41:52'),
(8, 'O-', 'Blood Type O Negative', '2025-10-28 20:41:52');

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `donation_id` int(11) NOT NULL,
  `donor_id` int(11) NOT NULL,
  `blood_type_id` int(11) NOT NULL,
  `donation_date` date NOT NULL,
  `quantity_ml` int(11) NOT NULL,
  `donation_location` varchar(200) DEFAULT NULL,
  `status` enum('pending','approved','rejected','completed') DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`donation_id`, `donor_id`, `blood_type_id`, `donation_date`, `quantity_ml`, `donation_location`, `status`, `notes`, `created_at`, `updated_at`) VALUES
(1, 1, 2, '2024-08-15', 450, 'Koronadal Red Cross Center', 'completed', 'Successful donation', '2025-10-28 20:41:52', '2025-10-28 20:41:52'),
(2, 2, 3, '2024-09-01', 450, 'General Santos Hospital', 'completed', 'Successful donation', '2025-10-28 20:41:52', '2025-10-28 20:41:52'),
(3, 3, 7, '2024-07-20', 450, 'Koronadal Red Cross Center', 'completed', 'Successful donation', '2025-10-28 20:41:52', '2025-10-28 20:41:52'),
(4, 7, 2, '2025-10-29', 500, 'Koronadal Red Cross Center', 'completed', '', '2025-10-29 02:40:55', '2025-10-29 02:42:28'),
(5, 8, 5, '2025-10-29', 350, 'Koronadal Red Cross Center', 'rejected', '', '2025-10-29 04:43:14', '2025-10-29 04:55:40');

-- --------------------------------------------------------

--
-- Table structure for table `donors_info`
--

CREATE TABLE `donors_info` (
  `donor_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `blood_type_id` int(11) NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `weight` decimal(5,2) DEFAULT NULL,
  `medical_conditions` text DEFAULT NULL,
  `last_donation_date` date DEFAULT NULL,
  `eligible_to_donate` enum('Yes','No') DEFAULT 'Yes',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donors_info`
--

INSERT INTO `donors_info` (`donor_id`, `user_id`, `blood_type_id`, `date_of_birth`, `gender`, `weight`, `medical_conditions`, `last_donation_date`, `eligible_to_donate`, `created_at`, `updated_at`) VALUES
(1, 2, 2, '1990-05-15', 'Male', 75.50, 'None', '2024-08-15', 'Yes', '2025-10-28 20:41:52', '2025-10-28 20:41:52'),
(2, 3, 3, '1992-08-20', 'Female', 60.00, 'None', '2024-09-01', 'Yes', '2025-10-28 20:41:52', '2025-10-28 20:41:52'),
(3, 4, 7, '1988-03-10', 'Male', 80.00, 'Hypertension (controlled)', '2024-07-20', 'Yes', '2025-10-28 20:41:52', '2025-10-28 20:41:52'),
(6, 10, 1, '1995-05-15', 'Male', 72.00, 'Hypertension (controlled with medication)\nAllergic to penicillin', NULL, 'Yes', '2025-10-28 23:04:44', '2025-10-28 23:04:44'),
(7, 13, 2, '2005-09-02', 'Female', 50.00, 'none', '2025-10-29', 'Yes', '2025-10-29 02:40:55', '2025-10-29 02:42:28'),
(8, 14, 5, '2007-10-17', 'Male', 50.00, 'dasdasd', '2025-10-29', 'Yes', '2025-10-29 04:43:14', '2025-10-29 04:47:16');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` int(11) NOT NULL,
  `event_name` varchar(200) NOT NULL,
  `event_description` text DEFAULT NULL,
  `event_date` date NOT NULL,
  `event_location` varchar(200) DEFAULT NULL,
  `organizer` varchar(100) DEFAULT NULL,
  `max_participants` int(11) DEFAULT NULL,
  `current_participants` int(11) DEFAULT 0,
  `status` enum('upcoming','ongoing','completed','cancelled') DEFAULT 'upcoming',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `event_name`, `event_description`, `event_date`, `event_location`, `organizer`, `max_participants`, `current_participants`, `status`, `created_at`) VALUES
(1, 'Community Blood Drive', 'Monthly blood donation drive at the city plaza', '2024-12-15', 'Koronadal City Plaza', 'Red Cross Koronadal', 100, 45, 'completed', '2025-10-28 20:41:52'),
(2, 'Emergency Blood Collection', 'Emergency blood collection for disaster response', '2024-11-30', 'Red Cross Center', 'Red Cross Koronadal', 50, 20, 'upcoming', '2025-10-28 20:41:52'),
(3, 'Blood Awareness Seminar', 'An educational seminar to inform participants about the benefits, process, and myths of blood donation.', '2025-10-30', 'City Plaza', 'Red Cross Koronadal', 100, 0, 'upcoming', '2025-10-29 04:25:07');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `inventory_id` int(11) NOT NULL,
  `blood_type_id` int(11) NOT NULL,
  `quantity_ml` int(11) NOT NULL DEFAULT 0,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `expiry_date` date DEFAULT NULL,
  `status` enum('available','reserved','expired') DEFAULT 'available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`inventory_id`, `blood_type_id`, `quantity_ml`, `last_updated`, `expiry_date`, `status`) VALUES
(1, 1, 1800, '2025-10-29 05:10:04', '2025-12-03', 'available'),
(2, 1, 1800, '2025-10-29 00:17:09', '2025-11-28', 'available'),
(3, 1, 900, '2025-10-29 00:17:09', '2025-11-23', 'available'),
(4, 2, 1850, '2025-10-29 02:42:28', '2025-12-08', 'available'),
(5, 2, 1400, '2025-10-29 02:42:28', '2025-11-26', 'available'),
(6, 3, 3150, '2025-10-29 00:17:09', '2025-12-06', 'available'),
(7, 3, 2250, '2025-10-29 00:17:09', '2025-11-30', 'available'),
(8, 4, 900, '2025-10-29 00:17:09', '2025-12-03', 'available'),
(9, 4, 450, '2025-10-29 00:17:09', '2025-11-18', 'available'),
(10, 5, 1150, '2025-10-29 04:57:17', '2025-12-05', 'available'),
(11, 5, 2050, '2025-10-29 04:55:26', '2025-11-27', 'available'),
(12, 6, 450, '2025-10-29 00:17:09', '2025-12-10', 'available'),
(13, 6, 450, '2025-10-29 00:17:09', '2025-11-13', 'available'),
(14, 7, 4500, '2025-10-29 00:17:09', '2025-12-07', 'available'),
(15, 7, 3600, '2025-10-29 00:17:09', '2025-11-29', 'available'),
(16, 7, 2700, '2025-10-29 00:17:09', '2025-11-25', 'available'),
(17, 8, 2700, '2025-10-29 00:17:09', '2025-12-09', 'available'),
(18, 8, 1800, '2025-10-29 00:17:09', '2025-12-04', 'available'),
(19, 8, 900, '2025-10-29 00:17:09', '2025-11-16', 'available'),
(20, 2, 950, '2025-10-29 02:42:28', '2025-12-10', 'available');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `device_hash` varchar(64) NOT NULL,
  `type` varchar(10) NOT NULL DEFAULT 'admin',
  `attempts` int(11) DEFAULT 0,
  `ban_until` int(11) DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','error') DEFAULT 'info',
  `is_read` enum('Yes','No') DEFAULT 'No',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `user_id`, `title`, `message`, `type`, `is_read`, `created_at`) VALUES
(1, 2, 'Welcome!', 'Thank you for registering with Koronadal Red Cross Blood Donation System', 'success', 'Yes', '2025-10-28 20:41:52'),
(2, 2, 'Appointment Scheduled', 'Your donation appointment is scheduled for December 15, 2024', 'info', 'No', '2025-10-28 20:41:52'),
(3, 3, 'Request Approved', 'Your blood request has been approved', 'success', 'No', '2025-10-28 20:41:52'),
(4, 2, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-28 22:12:32'),
(5, 3, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-28 22:12:32'),
(6, 4, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-28 22:12:32'),
(7, 2, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-28 22:28:23'),
(8, 3, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-28 22:28:23'),
(9, 4, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-28 22:28:24'),
(10, 2, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-28 22:29:36'),
(11, 3, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-28 22:29:36'),
(12, 4, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-28 22:29:36'),
(13, 2, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-28 22:31:50'),
(14, 3, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-28 22:31:50'),
(15, 4, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-28 22:31:51'),
(16, 2, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-28 22:32:15'),
(17, 3, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-28 22:32:15'),
(18, 4, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-28 22:32:15'),
(19, 6, 'Account Approved!', 'Congratulations! Your account has been approved by the administrator. You can now log in and access all features.', 'success', 'No', '2025-10-28 22:42:40'),
(20, 11, 'Account Registration Rejected', 'We regret to inform you that your account registration has been rejected. Reason: . If you believe this is an error, please contact us.', 'error', 'No', '2025-10-28 23:44:36'),
(21, 10, 'Account Registration Rejected', 'We regret to inform you that your account registration has been rejected. Reason: . If you believe this is an error, please contact us.', 'error', 'No', '2025-10-28 23:45:03'),
(22, 2, 'Appointment Confirmed', 'Your appointment on December 15, 2024 at 9:00 AM has been confirmed. See you there!', 'success', 'No', '2025-10-28 23:45:32'),
(23, 12, 'Account Approved!', 'Congratulations! Your account has been approved by the administrator. You can now log in and access all features.', 'success', 'No', '2025-10-28 23:48:59'),
(24, 13, 'Account Approved!', 'Congratulations! Your account has been approved by the administrator. You can now log in and access all features.', 'success', 'No', '2025-10-28 23:56:38'),
(25, 3, 'Request Cancelled', 'Your blood request has been cancelled. ', 'info', 'No', '2025-10-29 02:02:52'),
(26, 3, 'Request Cancelled', 'Your blood request has been cancelled. ', 'info', 'No', '2025-10-29 02:03:54'),
(27, 13, 'Blood Request Submitted', 'Your blood request has been submitted and is being processed.', 'info', 'No', '2025-10-29 02:19:12'),
(28, 13, 'Request Approved', 'Your blood request has been approved. ', 'info', 'No', '2025-10-29 02:20:30'),
(29, 13, 'Donation Submitted', 'Your blood donation request has been submitted and is pending approval.', 'success', 'No', '2025-10-29 02:40:55'),
(31, 13, 'Donation Completed', 'Your blood donation has been completed.', 'success', 'No', '2025-10-29 02:42:28'),
(32, 14, 'Account Pending Approval', 'Thank you for registering! Your account is pending admin approval. You will be notified once your account is verified.', 'info', 'No', '2025-10-29 02:56:21'),
(33, 1, 'New User Registration', 'New user \'Mork mork\' (mork) has registered and is awaiting approval.', 'warning', 'No', '2025-10-29 02:56:21'),
(34, 14, 'Account Approved!', 'Congratulations! Your account has been approved by the administrator. You can now log in and access all features.', 'success', 'No', '2025-10-29 03:10:52'),
(35, 15, 'Account Pending Approval', 'Thank you for registering! Your account is pending admin approval. You will be notified once your account is verified.', 'info', 'No', '2025-10-29 03:13:03'),
(36, 1, 'New User Registration', 'New user \'Trizz\' (daddi) has registered and is awaiting approval.', 'warning', 'No', '2025-10-29 03:13:03'),
(37, 15, 'Account Registration Rejected', 'We regret to inform you that your account registration has been rejected. Reason: pok pok ka kasi forever. If you believe this is an error, please contact us.', 'error', 'No', '2025-10-29 03:13:31'),
(38, 15, 'Account Registration Rejected', 'We regret to inform you that your account registration has been rejected. Reason: pok pok ka kasi forever. If you believe this is an error, please contact us.', 'error', 'No', '2025-10-29 03:19:23'),
(39, 15, 'Account Registration Rejected', 'We regret to inform you that your account registration has been rejected. Reason: pok pok ka kasi forever. If you believe this is an error, please contact us.', 'error', 'No', '2025-10-29 03:19:26'),
(40, 2, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-29 04:20:56'),
(41, 3, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-29 04:20:56'),
(42, 4, 'You\'re Eligible to Donate!', 'Good news! It\'s been 56 days since your last donation. You\'re now eligible to donate blood again. Schedule your appointment today!', 'info', 'No', '2025-10-29 04:20:56'),
(43, 2, 'hi', 'wrtyw54', 'warning', 'No', '2025-10-29 04:21:25'),
(44, 3, 'hi', 'wrtyw54', 'warning', 'No', '2025-10-29 04:21:25'),
(45, 4, 'hi', 'wrtyw54', 'warning', 'No', '2025-10-29 04:21:25'),
(46, 13, 'hi', 'wrtyw54', 'warning', 'No', '2025-10-29 04:21:25'),
(47, 2, 'New Blood Drive Event', 'Join us for \'Blood Awareness Seminar\' on October 30, 2025 at City Plaza. Register now!', 'info', 'No', '2025-10-29 04:25:07'),
(48, 3, 'New Blood Drive Event', 'Join us for \'Blood Awareness Seminar\' on October 30, 2025 at City Plaza. Register now!', 'info', 'No', '2025-10-29 04:25:07'),
(49, 4, 'New Blood Drive Event', 'Join us for \'Blood Awareness Seminar\' on October 30, 2025 at City Plaza. Register now!', 'info', 'No', '2025-10-29 04:25:07'),
(50, 6, 'New Blood Drive Event', 'Join us for \'Blood Awareness Seminar\' on October 30, 2025 at City Plaza. Register now!', 'info', 'No', '2025-10-29 04:25:07'),
(51, 12, 'New Blood Drive Event', 'Join us for \'Blood Awareness Seminar\' on October 30, 2025 at City Plaza. Register now!', 'info', 'No', '2025-10-29 04:25:07'),
(52, 13, 'New Blood Drive Event', 'Join us for \'Blood Awareness Seminar\' on October 30, 2025 at City Plaza. Register now!', 'info', 'No', '2025-10-29 04:25:07'),
(53, 14, 'New Blood Drive Event', 'Join us for \'Blood Awareness Seminar\' on October 30, 2025 at City Plaza. Register now!', 'info', 'No', '2025-10-29 04:25:07'),
(54, 14, 'Blood Request Submitted', 'Your blood request has been submitted and is being processed.', 'info', 'No', '2025-10-29 04:36:26'),
(55, 14, 'Blood Request Submitted', 'Your blood request has been submitted and is being processed.', 'info', 'No', '2025-10-29 04:36:29'),
(56, 14, 'Request Approved', 'Your blood request has been approved. ', 'info', 'No', '2025-10-29 04:36:50'),
(57, 14, 'Request Rejected', 'Your blood request has been rejected. ', 'info', 'No', '2025-10-29 04:38:04'),
(58, 14, 'Request Fulfilled', 'Your blood request has been fulfilled. ', 'success', 'No', '2025-10-29 04:40:55'),
(59, 14, 'Request Fulfilled', 'Your blood request has been fulfilled. ', 'success', 'No', '2025-10-29 04:41:07'),
(60, 14, 'Donation Submitted', 'Your blood donation request has been submitted and is pending approval.', 'success', 'No', '2025-10-29 04:43:14'),
(61, 14, 'Donation Approved', 'Your blood donation has been approved.', 'info', 'No', '2025-10-29 04:46:57'),
(62, 14, 'Donation Completed', 'Your blood donation has been completed.', 'success', 'No', '2025-10-29 04:47:16'),
(63, 14, 'Donation Approved', 'Your blood donation has been approved.', 'info', 'No', '2025-10-29 04:54:44'),
(64, 14, 'Donation Completed', 'Your blood donation has been completed.', 'success', 'No', '2025-10-29 04:55:26'),
(65, 3, 'Request Rejected', 'Your blood request has been rejected. ', 'info', 'No', '2025-10-29 04:56:25'),
(66, 14, 'Request Rejected', 'Your blood request has been rejected. ', 'info', 'No', '2025-10-29 04:56:45'),
(67, 14, 'Request Approved', 'Your blood request has been approved. ', 'info', 'No', '2025-10-29 04:57:00'),
(68, 14, 'Request Fulfilled', 'Your blood request has been fulfilled. ', 'success', 'No', '2025-10-29 04:57:17'),
(69, 16, 'Account Pending Approval', 'Thank you for registering! Your account is pending admin approval. You will be notified once your account is verified.', 'info', 'No', '2025-10-29 04:59:56'),
(70, 1, 'New User Registration', 'New user \'Nekki Calumpag\' (Nekki) has registered and is awaiting approval.', 'warning', 'No', '2025-10-29 04:59:56'),
(71, 16, 'Account Registration Rejected', 'We regret to inform you that your account registration has been rejected. Reason: happi kaayu kang bilaaana ka. If you believe this is an error, please contact us.', 'error', 'No', '2025-10-29 05:00:41'),
(72, 17, 'Account Pending Approval', 'Thank you for registering! Your account is pending admin approval. You will be notified once your account is verified.', 'info', 'No', '2025-10-29 05:04:33'),
(73, 1, 'New User Registration', 'New user \'Carlo\' (Carlo) has registered and is awaiting approval.', 'warning', 'No', '2025-10-29 05:04:33'),
(74, 17, 'Account Registration Rejected', 'We regret to inform you that your account registration has been rejected. Reason: Adtu kag police ha. If you believe this is an error, please contact us.', 'error', 'No', '2025-10-29 05:05:28'),
(75, 17, 'Account Registration Rejected', 'We regret to inform you that your account registration has been rejected. Reason: Adtu kag police ha. If you believe this is an error, please contact us.', 'error', 'No', '2025-10-29 05:05:29'),
(76, 16, 'Blood Request Submitted', 'Your blood request has been submitted and is being processed.', 'info', 'No', '2025-10-29 05:08:20'),
(77, 16, 'Request Rejected', 'Your blood request has been rejected. kinsa kang bilaana ka', 'info', 'No', '2025-10-29 05:08:53'),
(78, 16, 'Request Approved', 'Your blood request has been approved. approve ang bilaan', 'info', 'No', '2025-10-29 05:09:31'),
(79, 16, 'Request Fulfilled', 'Your blood request has been fulfilled. saanool full kapla', 'success', 'No', '2025-10-29 05:10:04'),
(80, 18, 'Account Pending Approval', 'Thank you for registering! Your account is pending admin approval.', 'info', 'No', '2026-03-12 12:16:15'),
(81, 1, 'New User Registration', 'New user \'garde mj\' (gard) has registered and is awaiting approval.', 'warning', 'No', '2026-03-12 12:16:15');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `request_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `blood_type_id` int(11) NOT NULL,
  `patient_name` varchar(100) NOT NULL,
  `hospital_name` varchar(200) NOT NULL,
  `urgency` enum('Low','Medium','High','Critical') NOT NULL,
  `quantity_ml` int(11) NOT NULL,
  `required_date` date NOT NULL,
  `reason` text DEFAULT NULL,
  `status` enum('pending','approved','fulfilled','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `blood_type_id` int(11) DEFAULT NULL,
  `user_role` enum('admin','user') DEFAULT 'user',
  `status` enum('active','inactive','suspended','pending') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password_hash`, `full_name`, `phone`, `address`, `blood_type_id`, `user_role`, `status`, `created_at`, `last_login`) VALUES
(1, 'admin', 'admin@koronadalredcross.org', '$2y$12$fx5LnNgFBZtldV3o3/RQIuNUlFp.oPB56.89AUtyk.klCT8.UaJsu', 'System Administrator', '09171234567', 'Koronadal City, South Cotabato', 1, 'admin', 'active', '2025-10-28 20:41:52', '2025-10-29 05:04:49'),
(2, 'jdoe', 'jdoe@email.com', '$2y$12$WWi9h.bzZLaI9zW6gjKrGuE3xWI8vB80LkGFcdnfriftkzeM5zwQq', 'John Doe', '09181234567', 'Koronadal City', 2, 'user', 'active', '2025-10-28 20:41:52', NULL),
(3, 'msmith', 'msmith@email.com', '$2y$12$WWi9h.bzZLaI9zW6gjKrGuE3xWI8vB80LkGFcdnfriftkzeM5zwQq', 'Maria Smith', '09191234567', 'General Santos City', 3, 'user', 'active', '2025-10-28 20:41:52', NULL),
(4, 'rgarcia', 'rgarcia@email.com', '$2y$12$WWi9h.bzZLaI9zW6gjKrGuE3xWI8vB80LkGFcdnfriftkzeM5zwQq', 'Robert Garcia', '09201234567', 'Tacurong City', 7, 'user', 'active', '2025-10-28 20:41:52', NULL),
(6, 'kien', 'kien@gmail.com', '$2y$12$ECfjkcVE4RGI5gZJpxM9OOzKjz4r/LHCaSkMdhmDOxZkyTo7OeLKK', 'kien balais', '09261766157', 'Silway-8 Polomolok', 4, 'user', 'active', '2025-10-28 22:35:41', '2025-10-28 22:45:53'),
(10, 'kbalais', 'kien@email.com', '$2y$12$WWi9h.bzZLaI9zW6gjKrGuE3xWI8vB80LkGFcdnfriftkzeM5zwQq', 'Kien Balais', '09261765157', 'Koronadal City, South Cotabato', 1, 'user', 'inactive', '2025-10-28 23:04:44', NULL),
(11, 'tatin', 'tatin@gmail.com', '$2y$12$rCYr0GG9FnLoDUbIqHuzPeEEQhIkUBGJ8b0FziqudzEH6wSiyyBea', 'Trizzle Kien Balais', '09261766157', 'Silway-8', 3, 'user', 'inactive', '2025-10-28 23:37:11', NULL),
(12, 'wows', 'wows@gmail.com', '$2y$12$rejkT1XW7rO5Hf4ZxT5frOJSh6Z7C5nGDhaUA/aNojFhPczkd2rNG', 'Mark Lawrence', '09565597528', 'Silway-8 Polomolok', 7, 'user', 'active', '2025-10-28 23:48:23', '2025-10-29 01:39:05'),
(13, 'adin', 'adin@gmail.com', '$2y$12$NYEpdoUwLWgjJsxPq9TyWewBr4nNRtzsIrXIhlsbcdUvEU9P6rtle', 'Kent Waje', '09261766157', 'Silway-8 Polomolok', 1, 'user', 'active', '2025-10-28 23:54:38', '2025-10-29 04:25:21'),
(14, 'mork', 'mork@gmail.com', '$2y$12$T7b2tL4lNcsa0z1xBEASnebj7shfSGQTVk275qdSjNRWMdwBSJEoC', 'Mork mork', '09182256512', 'Prk.Miana, Poblacion, Polomolok, South Cotabato', 6, 'user', 'active', '2025-10-29 02:56:21', '2025-10-29 04:35:12'),
(15, 'daddi', 'mommi@gmail.com', '$2y$12$cePSkE5sZXbAwruuiGtHue8JyJwpiA2TegI0S7OYDN2WgsJv.sG12', 'Trizz', '09700731851', 'Prk.Pg-asa', 5, 'user', 'inactive', '2025-10-29 03:13:03', NULL),
(16, 'Nekki', 'nekki@gmail.com', '$2y$12$rsO4mvLNoNZTVB72fI3NE.Wy92Y2r2zRIUdBqbj/3fE5BfB6YnFDu', 'Nekki Calumpag', '09150830445', 'Prk.Pg-asa', 3, 'user', 'active', '2025-10-29 04:59:56', '2025-10-29 05:07:23'),
(17, 'Carlo', 'Carlo@gmail.com', '$2y$12$2AA6HoqiJ4nGizZM.6HtrO1Dwn6Y3M5EzZHZgIlLRsGeAGfAx9GZC', 'Carlo', '09078637063', 'Prk.Pg-asa', 8, 'user', 'inactive', '2025-10-29 05:04:33', NULL),
(18, 'gard', 'gard@s.c', '$2y$12$O331tOrrEpW9SGOEf0OtgOjIKBrB85QHvF/mmYbcEoGarL6tcuJLa', 'garde mj', '09505050500', 'Rizal (Bo.3) Banga, South Cotabato', 4, 'user', 'pending', '2026-03-12 12:16:15', NULL),
(22, 'admin1', 'admin1@a.c', '$2y$10$9k28231FwCVBZzTNDy1pguspsQTY9TWZj65msrcxCQFHOIHOxR0Tq', 'Juan Dele Cruz', '09030303033', 'Koronadal', NULL, 'admin', 'active', '2026-03-12 20:58:15', '2026-03-20 21:25:27'),
(23, 'user', 'user@g.c', '$2y$10$hRKGSbDXNqb6DyhXB2VlCeCLsO2ssQHzQEGH0H9jnPf/vpgPSt542', 'John Manuel', '09050505066', 'Koronadal', NULL, 'user', 'active', '2026-03-12 20:59:03', '2026-03-14 10:14:48');

-- --------------------------------------------------------

--
-- Table structure for table `user_documents`
--

CREATE TABLE `user_documents` (
  `document_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `document_type` enum('medical_certificate','valid_id') NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_documents`
--

INSERT INTO `user_documents` (`document_id`, `user_id`, `document_type`, `file_name`, `file_path`, `file_size`, `uploaded_at`) VALUES
(9, 10, 'medical_certificate', 'medical_certificate_kbalais.pdf', 'uploads/medical_certificates/medical_cert_sample.pdf', 245670, '2025-10-28 23:04:44'),
(10, 10, 'valid_id', 'drivers_license_kbalais.jpg', 'uploads/profile_photos/valid_id_sample.jpg', 189230, '2025-10-28 23:04:44'),
(11, 14, 'medical_certificate', 'medical_cert_6901f2d51cf13.jpg', 'uploads/medical_certificates/medical_cert_6901f2d51cf13.jpg', 13417, '2025-10-29 02:56:21'),
(12, 14, 'valid_id', 'photo_id_6901f2d5266f0.jpg', 'uploads/profile_photos/photo_id_6901f2d5266f0.jpg', 13417, '2025-10-29 02:56:21'),
(13, 15, 'medical_certificate', 'medical_cert_6901f6bf391e3.jpg', 'uploads/medical_certificates/medical_cert_6901f6bf391e3.jpg', 13417, '2025-10-29 03:13:03'),
(14, 15, 'valid_id', 'photo_id_6901f6bf438d2.jpg', 'uploads/profile_photos/photo_id_6901f6bf438d2.jpg', 13417, '2025-10-29 03:13:03'),
(15, 16, 'medical_certificate', 'medical_cert_69020fcbe6e66.jpg', 'uploads/medical_certificates/medical_cert_69020fcbe6e66.jpg', 13417, '2025-10-29 04:59:56'),
(16, 16, 'valid_id', 'photo_id_69020fcbf2f30.jpg', 'uploads/profile_photos/photo_id_69020fcbf2f30.jpg', 13417, '2025-10-29 04:59:56'),
(17, 17, 'medical_certificate', 'medical_cert_690210e1159f9.jpg', 'uploads/medical_certificates/medical_cert_690210e1159f9.jpg', 13417, '2025-10-29 05:04:33'),
(18, 17, 'valid_id', 'photo_id_690210e1204bb.jpg', 'uploads/profile_photos/photo_id_690210e1204bb.jpg', 13417, '2025-10-29 05:04:33'),
(19, 18, 'medical_certificate', 'medical_cert_69b2ae8eb9379.jpeg', 'uploads/medical_certificates/medical_cert_69b2ae8eb9379.jpeg', 7093, '2026-03-12 12:16:15'),
(20, 18, 'valid_id', 'photo_id_69b2ae8eb947b.jpeg', 'uploads/profile_photos/photo_id_69b2ae8eb947b.jpeg', 7093, '2026-03-12 12:16:15');

-- --------------------------------------------------------

--
-- Table structure for table `user_sessions`
--

CREATE TABLE `user_sessions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointment_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `event_id` (`event_id`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `blood_types`
--
ALTER TABLE `blood_types`
  ADD PRIMARY KEY (`blood_type_id`),
  ADD UNIQUE KEY `blood_type` (`blood_type`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`donation_id`),
  ADD KEY `donor_id` (`donor_id`),
  ADD KEY `blood_type_id` (`blood_type_id`);

--
-- Indexes for table `donors_info`
--
ALTER TABLE `donors_info`
  ADD PRIMARY KEY (`donor_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `blood_type_id` (`blood_type_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`inventory_id`),
  ADD KEY `blood_type_id` (`blood_type_id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_device` (`ip_address`,`device_hash`,`type`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `blood_type_id` (`blood_type_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `blood_type_id` (`blood_type_id`);

--
-- Indexes for table `user_documents`
--
ALTER TABLE `user_documents`
  ADD PRIMARY KEY (`document_id`),
  ADD KEY `idx_user_documents_user_id` (`user_id`),
  ADD KEY `idx_user_documents_type` (`document_type`);

--
-- Indexes for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=238;

--
-- AUTO_INCREMENT for table `blood_types`
--
ALTER TABLE `blood_types`
  MODIFY `blood_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `donation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `donors_info`
--
ALTER TABLE `donors_info`
  MODIFY `donor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `inventory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `user_documents`
--
ALTER TABLE `user_documents`
  MODIFY `document_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `user_sessions`
--
ALTER TABLE `user_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE SET NULL;

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `donations`
--
ALTER TABLE `donations`
  ADD CONSTRAINT `donations_ibfk_1` FOREIGN KEY (`donor_id`) REFERENCES `donors_info` (`donor_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `donations_ibfk_2` FOREIGN KEY (`blood_type_id`) REFERENCES `blood_types` (`blood_type_id`);

--
-- Constraints for table `donors_info`
--
ALTER TABLE `donors_info`
  ADD CONSTRAINT `donors_info_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `donors_info_ibfk_2` FOREIGN KEY (`blood_type_id`) REFERENCES `blood_types` (`blood_type_id`);

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`blood_type_id`) REFERENCES `blood_types` (`blood_type_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;