<?php
require_once 'config/db.php';

// Get user ID from URL (e.g., add_test_documents.php?user_id=5)
$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

if ($user_id == 0) {
    die("ERROR: Provide user_id in URL. Example: add_test_documents.php?user_id=5");
}

// Check if user exists
$checkSql = "SELECT user_id, username, full_name FROM users WHERE user_id = :user_id";
$checkStmt = $db->prepare($checkSql);
$checkStmt->execute([':user_id' => $user_id]);
$user = $checkStmt->fetch();

if (!$user) {
    die("ERROR: User with ID $user_id not found!");
}

echo "<h2>Adding Test Documents for User</h2>";
echo "<p><strong>User ID:</strong> " . $user['user_id'] . "</p>";
echo "<p><strong>Username:</strong> " . htmlspecialchars($user['username']) . "</p>";
echo "<p><strong>Full Name:</strong> " . htmlspecialchars($user['full_name']) . "</p>";
echo "<hr>";

// Create sample test files
$upload_dir_medical = 'uploads/medical_certificates/';
$upload_dir_id = 'uploads/profile_photos/';

if (!is_dir($upload_dir_medical)) {
    mkdir($upload_dir_medical, 0755, true);
}
if (!is_dir($upload_dir_id)) {
    mkdir($upload_dir_id, 0755, true);
}

// Create dummy medical certificate (1x1 pixel PNG)
$medical_filename = 'medical_cert_test_' . $user_id . '.png';
$medical_path = $upload_dir_medical . $medical_filename;
$dummy_image = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==');
file_put_contents($medical_path, $dummy_image);

// Create dummy photo ID (1x1 pixel PNG)
$id_filename = 'photo_id_test_' . $user_id . '.png';
$id_path = $upload_dir_id . $id_filename;
file_put_contents($id_path, $dummy_image);

// Insert medical certificate
$docSql1 = "INSERT INTO user_documents (user_id, document_type, file_name, file_path, file_size) 
            VALUES (:user_id, 'medical_certificate', :file_name, :file_path, :file_size)";
$stmt1 = $db->prepare($docSql1);
$stmt1->execute([
    ':user_id' => $user_id,
    ':file_name' => $medical_filename,
    ':file_path' => $medical_path,
    ':file_size' => filesize($medical_path)
]);

echo "<p>✓ Medical Certificate inserted (ID: " . $db->lastInsertId() . ")</p>";

// Insert photo ID
$docSql2 = "INSERT INTO user_documents (user_id, document_type, file_name, file_path, file_size) 
            VALUES (:user_id, 'valid_id', :file_name, :file_path, :file_size)";
$stmt2 = $db->prepare($docSql2);
$stmt2->execute([
    ':user_id' => $user_id,
    ':file_name' => $id_filename,
    ':file_path' => $id_path,
    ':file_size' => filesize($id_path)
]);

echo "<p>✓ Valid ID inserted (ID: " . $db->lastInsertId() . ")</p>";

echo "<hr>";
echo "<h3>SUCCESS! Test documents added.</h3>";
echo "<p><a href='admin/view_user_profile.php?id=$user_id'>View User Profile</a></p>";
echo "<p><a href='check_documents.php'>View All Documents</a></p>";
?>
