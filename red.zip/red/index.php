<?php
/**
 * Landing Page
 * Public home page
 */

require_once 'config/config.php';
require_once 'config/db.php';

// Redirect if logged in
if (isLoggedIn()) {
    if (isAdmin()) {
        redirect('admin/dashboard.php');
    } else {
        redirect('dashboard.php');
    }
}

// Get upcoming events
try {
    $eventsSql = "SELECT * FROM events WHERE status = 'upcoming' ORDER BY event_date ASC LIMIT 3";
    $eventsStmt = $db->prepare($eventsSql);
    $eventsStmt->execute();
    $events = $eventsStmt->fetchAll();
} catch(PDOException $e) {
    $events = [];
}

// Get blood inventory summary
try {
    $inventorySql = "SELECT bt.blood_type, SUM(i.quantity_ml) as total_ml 
                     FROM inventory i 
                     JOIN blood_types bt ON i.blood_type_id = bt.blood_type_id 
                     WHERE i.status = 'available' 
                     GROUP BY bt.blood_type_id 
                     ORDER BY bt.blood_type";
    $inventoryStmt = $db->prepare($inventorySql);
    $inventoryStmt->execute();
    $inventory = $inventoryStmt->fetchAll();
} catch(PDOException $e) {
    $inventory = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm fixed-top">
        <div class="container">
            <a class="navbar-brand fw-bold text-danger" href="index.php">
                <div class="logo-3d">
                    <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                        <defs>
                            <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#dc3545;stop-opacity:1" />
                                <stop offset="100%" style="stop-color:#a71d2a;stop-opacity:1" />
                            </linearGradient>
                        </defs>
                        <!-- Red Cross Symbol -->
                        <rect x="40" y="20" width="20" height="60" rx="3" fill="url(#logoGradient)"/>
                        <rect x="20" y="40" width="60" height="20" rx="3" fill="url(#logoGradient)"/>
                        <!-- Circle Border -->
                        <circle cx="50" cy="50" r="45" fill="none" stroke="url(#logoGradient)" stroke-width="3"/>
                    </svg>
                </div>
                <span class="gradient-text">Koronadal Red Cross</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#events">Events</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="btn btn-outline-danger ms-2" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="btn btn-danger ms-2" href="register.php">Register</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div style="height: 76px;"></div> <!-- Spacer for fixed navbar -->

    <!-- Hero Section -->
    <section class="hero-section bg-danger text-white py-5 position-relative">
        <div class="container py-5 position-relative" style="z-index: 2;">
            <div class="row align-items-center">
                <div class="col-lg-6 slide-in-left">
                    <h1 class="display-4 fw-bold mb-4" style="text-shadow: 0 5px 15px rgba(0,0,0,0.3);">
                        Save Lives Through <span style="color: #ffe8e8;">Blood Donation</span>
                    </h1>
                    <p class="lead mb-4" style="font-size: 1.3rem;">Join Koronadal Red Cross in our mission to provide safe blood to those in need. Every donation counts.</p>
                    <div class="d-flex gap-3 flex-wrap">
                        <a href="register.php" class="btn btn-light btn-lg">
                            <i class="bi bi-person-plus me-2"></i>Register Now
                        </a>
                        <a href="#about" class="btn btn-outline-light btn-lg">
                            <i class="bi bi-info-circle me-2"></i>Learn More
                        </a>
                    </div>
                    <div class="mt-5 d-flex gap-4 flex-wrap">
                        <div class="text-center">
                            <h2 class="fw-bold mb-0" style="font-size: 2.5rem;">10K+</h2>
                            <small style="opacity: 0.9;">Donations</small>
                        </div>
                        <div class="text-center">
                            <h2 class="fw-bold mb-0" style="font-size: 2.5rem;">5K+</h2>
                            <small style="opacity: 0.9;">Lives Saved</small>
                        </div>
                        <div class="text-center">
                            <h2 class="fw-bold mb-0" style="font-size: 2.5rem;">500+</h2>
                            <small style="opacity: 0.9;">Active Donors</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 text-center mt-5 mt-lg-0 slide-in-right">
                    <div class="hero-icon-3d">
                        <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" style="width: 400px; height: 400px;">
                            <defs>
                                <linearGradient id="heroGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                    <stop offset="0%" style="stop-color:#ffffff;stop-opacity:0.9" />
                                    <stop offset="100%" style="stop-color:#ffcccc;stop-opacity:0.8" />
                                </linearGradient>
                                <filter id="shadow">
                                    <feDropShadow dx="0" dy="10" stdDeviation="15" flood-opacity="0.3"/>
                                </filter>
                            </defs>
                            <!-- Heart Shape -->
                            <path d="M100,170 C100,170 30,120 30,80 C30,50 50,30 75,30 C85,30 95,35 100,45 C105,35 115,30 125,30 C150,30 170,50 170,80 C170,120 100,170 100,170 Z" 
                                  fill="url(#heroGradient)" filter="url(#shadow)" class="pulse-animation"/>
                            <!-- Pulse Lines -->
                            <polyline points="50,100 70,100 80,80 90,120 100,100 110,100" 
                                      stroke="white" stroke-width="4" fill="none" opacity="0.7"/>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="py-5" style="background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);">
        <div class="container py-4">
            <div class="row text-center mb-5 slide-in-up">
                <div class="col">
                    <h2 class="fw-bold mb-3" style="font-size: 2.5rem;">
                        <span class="gradient-text">Why Donate Blood?</span>
                    </h2>
                    <p class="text-muted" style="font-size: 1.2rem;">One donation can save up to three lives</p>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card feature-card-3d border-0 shadow-sm h-100 text-center p-4">
                        <div class="card-body">
                            <div class="mb-4" style="background: linear-gradient(135deg, #dc3545, #a71d2a); width: 80px; height: 80px; margin: 0 auto; border-radius: 20px; display: flex; align-items: center; justify-content: center; transform: rotate(45deg); box-shadow: 0 10px 30px rgba(220, 53, 69, 0.3);">
                                <i class="bi bi-heart-fill text-white" style="font-size: 2rem; transform: rotate(-45deg);"></i>
                            </div>
                            <h5 class="mt-3 fw-bold" style="font-size: 1.3rem;">Save Lives</h5>
                            <p class="text-muted">Your donation can help patients in surgeries, trauma cases, and chronic illnesses.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card feature-card-3d border-0 shadow-sm h-100 text-center p-4">
                        <div class="card-body">
                            <div class="mb-4" style="background: linear-gradient(135deg, #dc3545, #a71d2a); width: 80px; height: 80px; margin: 0 auto; border-radius: 20px; display: flex; align-items: center; justify-content: center; transform: rotate(45deg); box-shadow: 0 10px 30px rgba(220, 53, 69, 0.3);">
                                <i class="bi bi-shield-check text-white" style="font-size: 2rem; transform: rotate(-45deg);"></i>
                            </div>
                            <h5 class="mt-3 fw-bold" style="font-size: 1.3rem;">Safe Process</h5>
                            <p class="text-muted">All donations follow strict safety protocols with sterile equipment.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card feature-card-3d border-0 shadow-sm h-100 text-center p-4">
                        <div class="card-body">
                            <div class="mb-4" style="background: linear-gradient(135deg, #dc3545, #a71d2a); width: 80px; height: 80px; margin: 0 auto; border-radius: 20px; display: flex; align-items: center; justify-content: center; transform: rotate(45deg); box-shadow: 0 10px 30px rgba(220, 53, 69, 0.3);">
                                <i class="bi bi-clock-fill text-white" style="font-size: 2rem; transform: rotate(-45deg);"></i>
                            </div>
                            <h5 class="mt-3 fw-bold" style="font-size: 1.3rem;">Quick & Easy</h5>
                            <p class="text-muted">The entire donation process takes only about 10-15 minutes.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Blood Inventory Section -->
    <section class="py-5 parallax-bg" style="background: linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(240,242,245,0.9) 100%);">
        <div class="container py-4">
            <div class="row text-center mb-5">
                <div class="col">
                    <h2 class="fw-bold mb-3" style="font-size: 2.5rem;">
                        <span class="gradient-text">Current Blood Inventory</span>
                    </h2>
                    <p class="text-muted" style="font-size: 1.2rem;">Available blood units by type</p>
                </div>
            </div>
            <div class="row g-4">
                <?php foreach ($inventory as $item): ?>
                    <?php 
                        $units = floor($item['total_ml'] / 450);
                        $percentage = min(($units / 20) * 100, 100);
                        $statusClass = $percentage > 50 ? 'success' : ($percentage > 20 ? 'warning' : 'danger');
                    ?>
                    <div class="col-6 col-md-3">
                        <div class="card blood-type-card-3d border-0 shadow-sm text-center p-4" style="background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);">
                            <div class="mb-3" style="width: 60px; height: 60px; margin: 0 auto; background: linear-gradient(135deg, #dc3545, #a71d2a); border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 10px 30px rgba(220, 53, 69, 0.3);">
                                <h3 class="text-white fw-bold mb-0" style="font-size: 1.5rem;"><?php echo $item['blood_type']; ?></h3>
                            </div>
                            <div class="progress mb-3" style="height: 10px; border-radius: 10px; background: rgba(220, 53, 69, 0.1);">
                                <div class="progress-bar bg-<?php echo $statusClass; ?>" role="progressbar" 
                                     style="width: <?php echo $percentage; ?>%; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.2);" 
                                     aria-valuenow="<?php echo $percentage; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h4 class="fw-bold mb-0" style="color: #dc3545;"><?php echo $units; ?></h4>
                            <small class="text-muted">units available</small>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Events Section -->
    <section id="events" class="py-5" style="background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);">
        <div class="container py-4">
            <div class="row text-center mb-5">
                <div class="col">
                    <h2 class="fw-bold mb-3" style="font-size: 2.5rem;">
                        <span class="gradient-text">Upcoming Events</span>
                    </h2>
                    <p class="text-muted" style="font-size: 1.2rem;">Join our blood donation drives</p>
                </div>
            </div>
            <div class="row g-4">
                <?php foreach ($events as $event): ?>
                    <div class="col-md-4">
                        <div class="card border-0 shadow-sm h-100" style="border-radius: 1.5rem; overflow: hidden; background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);">
                            <div class="card-body p-4">
                                <div class="d-flex justify-content-between align-items-start mb-4">
                                    <span class="badge bg-danger" style="padding: 0.5rem 1rem; border-radius: 50px; font-size: 0.85rem;"><?php echo formatDate($event['event_date']); ?></span>
                                    <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #dc3545, #a71d2a); border-radius: 15px; display: flex; align-items: center; justify-content: center; transform: rotate(10deg); box-shadow: 0 5px 15px rgba(220, 53, 69, 0.3);">
                                        <i class="bi bi-calendar-event text-white" style="font-size: 1.5rem; transform: rotate(-10deg);"></i>
                                    </div>
                                </div>
                                <h5 class="fw-bold mb-3" style="color: #333; font-size: 1.3rem;"><?php echo htmlspecialchars($event['event_name']); ?></h5>
                                <p class="text-muted mb-4" style="line-height: 1.6;"><?php echo htmlspecialchars($event['event_description']); ?></p>
                                <div class="d-flex align-items-center mb-3" style="background: rgba(220, 53, 69, 0.05); padding: 0.75rem; border-radius: 10px;">
                                    <i class="bi bi-geo-alt text-danger me-2" style="font-size: 1.2rem;"></i>
                                    <small class="text-dark fw-medium"><?php echo htmlspecialchars($event['event_location']); ?></small>
                                </div>
                                <div class="d-flex align-items-center" style="background: rgba(220, 53, 69, 0.05); padding: 0.75rem; border-radius: 10px;">
                                    <i class="bi bi-people text-danger me-2" style="font-size: 1.2rem;"></i>
                                    <small class="text-dark fw-medium"><?php echo $event['current_participants']; ?> / <?php echo $event['max_participants']; ?> participants</small>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-5 parallax-bg" style="background: linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(240,242,245,0.9) 100%);">
        <div class="container py-4">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-5 mb-lg-0">
                    <div class="slide-in-left">
                        <h2 class="fw-bold mb-4" style="font-size: 2.5rem;">
                            <span class="gradient-text">About Koronadal Red Cross</span>
                        </h2>
                        <p class="mb-3" style="font-size: 1.1rem; line-height: 1.8; color: #555;">
                            The Philippine Red Cross Koronadal Chapter is dedicated to saving lives through blood donation programs and emergency response services.
                        </p>
                        <p class="mb-4" style="font-size: 1.1rem; line-height: 1.8; color: #555;">
                            Our modern blood donation system makes it easy for donors to schedule appointments and for patients to request blood when needed.
                        </p>
                        <a href="register.php" class="btn btn-danger btn-lg">
                            <i class="bi bi-person-plus me-2"></i>Join Us Today
                        </a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="row g-4 slide-in-right">
                        <div class="col-6">
                            <div class="card stats-card-3d border-0 shadow-sm text-center p-4">
                                <div class="mb-3" style="width: 60px; height: 60px; margin: 0 auto; background: linear-gradient(135deg, #dc3545, #a71d2a); border-radius: 15px; display: flex; align-items: center; justify-content: center; box-shadow: 0 10px 30px rgba(220, 53, 69, 0.3);">
                                    <i class="bi bi-droplet-fill text-white" style="font-size: 1.8rem;"></i>
                                </div>
                                <h3 class="fw-bold mb-2" style="font-size: 2rem;">10,000+</h3>
                                <p class="mb-0 text-muted fw-medium">Donations</p>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card stats-card-3d border-0 shadow-sm text-center p-4">
                                <div class="mb-3" style="width: 60px; height: 60px; margin: 0 auto; background: linear-gradient(135deg, #dc3545, #a71d2a); border-radius: 15px; display: flex; align-items: center; justify-content: center; box-shadow: 0 10px 30px rgba(220, 53, 69, 0.3);">
                                    <i class="bi bi-heart-pulse-fill text-white" style="font-size: 1.8rem;"></i>
                                </div>
                                <h3 class="fw-bold mb-2" style="font-size: 2rem;">5,000+</h3>
                                <p class="mb-0 text-muted fw-medium">Lives Saved</p>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card stats-card-3d border-0 shadow-sm text-center p-4">
                                <div class="mb-3" style="width: 60px; height: 60px; margin: 0 auto; background: linear-gradient(135deg, #dc3545, #a71d2a); border-radius: 15px; display: flex; align-items: center; justify-content: center; box-shadow: 0 10px 30px rgba(220, 53, 69, 0.3);">
                                    <i class="bi bi-people-fill text-white" style="font-size: 1.8rem;"></i>
                                </div>
                                <h3 class="fw-bold mb-2" style="font-size: 2rem;">500+</h3>
                                <p class="mb-0 text-muted fw-medium">Active Donors</p>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card stats-card-3d border-0 shadow-sm text-center p-4">
                                <div class="mb-3" style="width: 60px; height: 60px; margin: 0 auto; background: linear-gradient(135deg, #dc3545, #a71d2a); border-radius: 15px; display: flex; align-items: center; justify-content: center; box-shadow: 0 10px 30px rgba(220, 53, 69, 0.3);">
                                    <i class="bi bi-calendar-event-fill text-white" style="font-size: 1.8rem;"></i>
                                </div>
                                <h3 class="fw-bold mb-2" style="font-size: 2rem;">50+</h3>
                                <p class="mb-0 text-muted fw-medium">Events/Year</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="py-5" style="background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);">
        <div class="container py-4">
            <div class="row text-center mb-5">
                <div class="col">
                    <h2 class="fw-bold mb-3" style="font-size: 2.5rem;">
                        <span class="gradient-text">Contact Us</span>
                    </h2>
                    <p class="text-muted" style="font-size: 1.2rem;">Get in touch with us for any inquiries</p>
                </div>
            </div>
            <div class="row justify-content-center g-4">
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm text-center p-4 h-100" style="border-radius: 1.5rem; background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);">
                        <div class="mb-4" style="width: 80px; height: 80px; margin: 0 auto; background: linear-gradient(135deg, #dc3545, #a71d2a); border-radius: 20px; display: flex; align-items: center; justify-content: center; transform: rotate(45deg); box-shadow: 0 10px 30px rgba(220, 53, 69, 0.3);">
                            <i class="bi bi-geo-alt-fill text-white" style="font-size: 2rem; transform: rotate(-45deg);"></i>
                        </div>
                        <h5 class="mt-3 fw-bold" style="font-size: 1.3rem;">Address</h5>
                        <p class="text-muted mb-0" style="line-height: 1.8;">Koronadal City<br>South Cotabato, Philippines</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm text-center p-4 h-100" style="border-radius: 1.5rem; background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);">
                        <div class="mb-4" style="width: 80px; height: 80px; margin: 0 auto; background: linear-gradient(135deg, #dc3545, #a71d2a); border-radius: 20px; display: flex; align-items: center; justify-content: center; transform: rotate(45deg); box-shadow: 0 10px 30px rgba(220, 53, 69, 0.3);">
                            <i class="bi bi-telephone-fill text-white" style="font-size: 2rem; transform: rotate(-45deg);"></i>
                        </div>
                        <h5 class="mt-3 fw-bold" style="font-size: 1.3rem;">Phone</h5>
                        <p class="text-muted mb-0" style="line-height: 1.8;">(083) 228-1234</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm text-center p-4 h-100" style="border-radius: 1.5rem; background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);">
                        <div class="mb-4" style="width: 80px; height: 80px; margin: 0 auto; background: linear-gradient(135deg, #dc3545, #a71d2a); border-radius: 20px; display: flex; align-items: center; justify-content: center; transform: rotate(45deg); box-shadow: 0 10px 30px rgba(220, 53, 69, 0.3);">
                            <i class="bi bi-envelope-fill text-white" style="font-size: 2rem; transform: rotate(-45deg);"></i>
                        </div>
                        <h5 class="mt-3 fw-bold" style="font-size: 1.3rem;">Email</h5>
                        <p class="text-muted mb-0" style="line-height: 1.8;">info@koronadalredcross.org</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-5" style="background: linear-gradient(135deg, #2d3436 0%, #1e272e 100%) !important;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 mb-4 mb-md-0">
                    <div class="d-flex align-items-center mb-3">
                        <div class="logo-3d" style="width: 40px; height: 40px;">
                            <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                                <defs>
                                    <linearGradient id="footerLogoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                        <stop offset="0%" style="stop-color:#dc3545;stop-opacity:1" />
                                        <stop offset="100%" style="stop-color:#a71d2a;stop-opacity:1" />
                                    </linearGradient>
                                </defs>
                                <rect x="40" y="20" width="20" height="60" rx="3" fill="url(#footerLogoGradient)"/>
                                <rect x="20" y="40" width="60" height="20" rx="3" fill="url(#footerLogoGradient)"/>
                                <circle cx="50" cy="50" r="45" fill="none" stroke="url(#footerLogoGradient)" stroke-width="3"/>
                            </svg>
                        </div>
                        <h5 class="fw-bold mb-0 ms-3">Koronadal Red Cross</h5>
                    </div>
                    <p class="text-muted mb-3" style="font-size: 0.95rem;">Saving lives through blood donation</p>
                    <div class="d-flex gap-3">
                        <a href="#" class="btn btn-outline-light btn-sm" style="border-radius: 50%; width: 40px; height: 40px; padding: 0; display: flex; align-items: center; justify-content: center;">
                            <i class="bi bi-facebook"></i>
                        </a>
                        <a href="#" class="btn btn-outline-light btn-sm" style="border-radius: 50%; width: 40px; height: 40px; padding: 0; display: flex; align-items: center; justify-content: center;">
                            <i class="bi bi-twitter"></i>
                        </a>
                        <a href="#" class="btn btn-outline-light btn-sm" style="border-radius: 50%; width: 40px; height: 40px; padding: 0; display: flex; align-items: center; justify-content: center;">
                            <i class="bi bi-instagram"></i>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="mb-2" style="font-size: 0.95rem;">&copy; 2024 Koronadal Red Cross. All rights reserved.</p>
                    <p class="text-muted mb-0" style="font-size: 0.9rem;">Powered by PHP & Bootstrap</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Scroll animations
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        // Observe all sections
        document.querySelectorAll('section').forEach(section => {
            section.style.opacity = '0';
            section.style.transform = 'translateY(30px)';
            section.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
            observer.observe(section);
        });

        // Navbar scroll effect
        window.addEventListener('scroll', () => {
            const navbar = document.querySelector('.navbar');
            if (window.scrollY > 50) {
                navbar.style.boxShadow = '0 10px 40px rgba(0, 0, 0, 0.15)';
                navbar.style.background = 'rgba(255, 255, 255, 0.98)';
            } else {
                navbar.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.1)';
                navbar.style.background = 'rgba(255, 255, 255, 0.95)';
            }
        });

        // 3D card tilt effect
        document.querySelectorAll('.card').forEach(card => {
            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                const centerX = rect.width / 2;
                const centerY = rect.height / 2;
                
                const rotateX = (y - centerY) / 10;
                const rotateY = (centerX - x) / 10;
                
                card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-5px)`;
            });
            
            card.addEventListener('mouseleave', () => {
                card.style.transform = '';
            });
        });

        // Counter animation for stats
        const animateCounter = (element, target) => {
            let current = 0;
            const increment = target / 100;
            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    element.textContent = target.toLocaleString() + '+';
                    clearInterval(timer);
                } else {
                    element.textContent = Math.floor(current).toLocaleString() + '+';
                }
            }, 20);
        };

        // Trigger counter animation when stats section is visible
        const statsObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const counters = entry.target.querySelectorAll('h3, h2');
                    counters.forEach(counter => {
                        const text = counter.textContent.replace(/[^0-9]/g, '');
                        if (text) {
                            const target = parseInt(text);
                            animateCounter(counter, target);
                        }
                    });
                    statsObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });

        document.querySelectorAll('.stats-card-3d, .hero-section').forEach(section => {
            statsObserver.observe(section);
        });
    </script>
</body>
</html>
