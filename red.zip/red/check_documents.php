<?php
require_once 'config/db.php';

// Check all documents in the database
echo "<h2>User Documents in Database</h2>";
$sql = "SELECT ud.*, u.username, u.full_name 
        FROM user_documents ud 
        LEFT JOIN users u ON ud.user_id = u.user_id 
        ORDER BY ud.created_at DESC";
$stmt = $db->query($sql);
$documents = $stmt->fetchAll();

echo "<table border='1' cellpadding='10'>";
echo "<tr><th>Doc ID</th><th>User ID</th><th>Username</th><th>Full Name</th><th>Type</th><th>File Name</th><th>File Path</th><th>File Size</th><th>Created</th><th>File Exists?</th></tr>";

if (count($documents) > 0) {
    foreach ($documents as $doc) {
        $fileExists = file_exists($doc['file_path']) ? '✓ YES' : '✗ NO';
        echo "<tr>";
        echo "<td>" . $doc['document_id'] . "</td>";
        echo "<td>" . $doc['user_id'] . "</td>";
        echo "<td>" . htmlspecialchars($doc['username'] ?? 'N/A') . "</td>";
        echo "<td>" . htmlspecialchars($doc['full_name'] ?? 'N/A') . "</td>";
        echo "<td>" . $doc['document_type'] . "</td>";
        echo "<td>" . htmlspecialchars($doc['file_name']) . "</td>";
        echo "<td>" . htmlspecialchars($doc['file_path']) . "</td>";
        echo "<td>" . number_format($doc['file_size']) . " bytes</td>";
        echo "<td>" . $doc['created_at'] . "</td>";
        echo "<td>" . $fileExists . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='10'>NO DOCUMENTS FOUND IN DATABASE!</td></tr>";
}
echo "</table>";

echo "<hr>";
echo "<h2>All Users</h2>";
$userSql = "SELECT user_id, username, full_name, email FROM users ORDER BY user_id";
$userStmt = $db->query($userSql);
$users = $userStmt->fetchAll();

echo "<table border='1' cellpadding='10'>";
echo "<tr><th>User ID</th><th>Username</th><th>Full Name</th><th>Email</th></tr>";
foreach ($users as $user) {
    echo "<tr>";
    echo "<td>" . $user['user_id'] . "</td>";
    echo "<td>" . htmlspecialchars($user['username']) . "</td>";
    echo "<td>" . htmlspecialchars($user['full_name']) . "</td>";
    echo "<td>" . htmlspecialchars($user['email']) . "</td>";
    echo "</tr>";
}
echo "</table>";
?>
