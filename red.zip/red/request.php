<?php
/**
 * Blood Request Form
 * Users can request blood for patients
 */

require_once 'config/config.php';
require_once 'config/db.php';

requireLogin();

$userId = $_SESSION['user_id'];
$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_request'])) {
    if (!validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        $bloodTypeId = intval($_POST['blood_type_id']);
        $patientName = sanitize($_POST['patient_name']);
        $hospitalName = sanitize($_POST['hospital_name']);
        $urgency = sanitize($_POST['urgency']);
        $quantityMl = intval($_POST['quantity_ml']); // From hidden field (calculated in JS)
        $requiredDate = sanitize($_POST['required_date']);
        $reason = sanitize($_POST['reason']);
        
        // Validation
        if (empty($patientName) || empty($hospitalName) || empty($urgency) || empty($requiredDate)) {
            $error = 'Please fill in all required fields';
        } elseif ($quantityMl < 450) {
            $error = 'Minimum request quantity is 450ml';
        } else {
            try {
                $insertSql = "INSERT INTO requests (user_id, blood_type_id, patient_name, hospital_name, urgency, quantity_ml, required_date, reason, status) 
                             VALUES (:user_id, :blood_type_id, :patient_name, :hospital_name, :urgency, :quantity_ml, :required_date, :reason, 'pending')";
                
                $stmt = $db->prepare($insertSql);
                $result = $stmt->execute([
                    ':user_id' => $userId,
                    ':blood_type_id' => $bloodTypeId,
                    ':patient_name' => $patientName,
                    ':hospital_name' => $hospitalName,
                    ':urgency' => $urgency,
                    ':quantity_ml' => $quantityMl,
                    ':required_date' => $requiredDate,
                    ':reason' => $reason
                ]);
                
                if ($result) {
                    $requestId = $db->lastInsertId();
                    
                    // Create notification
                    createNotification($db, $userId, 'Blood Request Submitted', 
                        'Your blood request has been submitted and is being processed.', 'info');
                    
                    // Log audit
                    logAudit($db, $userId, 'Blood Request Submitted', 'requests', $requestId, 
                        'User submitted blood request for ' . $patientName);
                    
                    $success = 'Blood request submitted successfully! You will be notified once it is processed.';
                } else {
                    $error = 'Error submitting request. Please try again.';
                }
            } catch(PDOException $e) {
                $error = 'Error: ' . $e->getMessage();
            }
        }
    }
}

// Get blood types
try {
    $bloodTypesSql = "SELECT * FROM blood_types ORDER BY blood_type";
    $stmt = $db->prepare($bloodTypesSql);
    $stmt->execute();
    $bloodTypes = $stmt->fetchAll();
} catch(PDOException $e) {
    $bloodTypes = [];
}

// Get blood inventory with blood_type_id as key
try {
    $inventorySql = "SELECT bt.blood_type_id, SUM(i.quantity_ml) as available_ml 
                     FROM inventory i 
                     JOIN blood_types bt ON i.blood_type_id = bt.blood_type_id 
                     WHERE i.status = 'available' 
                     GROUP BY bt.blood_type_id 
                     ORDER BY bt.blood_type";
    $stmt = $db->prepare($inventorySql);
    $stmt->execute();
    $inventory = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch(PDOException $e) {
    $inventory = [];
}

$pageTitle = 'Request Blood';
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include 'includes/user_sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="bi bi-bandaid text-primary me-2"></i>Request Blood</h1>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="bi bi-check-circle-fill me-2"></i><?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Blood Availability Summary -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card border-0 shadow-sm bg-light">
                        <div class="card-body">
                            <h6 class="fw-bold mb-3"><i class="bi bi-droplet-fill text-danger me-2"></i>Current Blood Availability</h6>
                            <div class="row g-2">
                                <?php foreach ($bloodTypes as $type): ?>
                                    <?php 
                                        $available = isset($inventory[$type['blood_type_id']]) ? 
                                                    floor($inventory[$type['blood_type_id']] / 450) : 0;
                                        $statusClass = $available > 5 ? 'success' : ($available > 0 ? 'warning' : 'danger');
                                        $icon = $available > 0 ? 'check-circle-fill' : 'x-circle-fill';
                                    ?>
                                    <div class="col-6 col-md-3">
                                        <div class="d-flex align-items-center p-2 bg-white rounded">
                                            <i class="bi bi-<?php echo $icon; ?> text-<?php echo $statusClass; ?> me-2"></i>
                                            <div>
                                                <strong class="d-block"><?php echo $type['blood_type']; ?></strong>
                                                <small class="text-<?php echo $statusClass; ?>">
                                                    <?php echo $available > 0 ? "$available units" : "Not available"; ?>
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="alert alert-info mt-3 mb-0">
                                <small>
                                    <i class="bi bi-info-circle me-1"></i>
                                    <strong>Note:</strong> Inventory is updated in real-time. If your required blood type is unavailable, please contact us directly for urgent cases.
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-8">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body p-4">
                            <h5 class="card-title fw-bold mb-4 text-white">Blood Request Form</h5>
                            
                            <form method="POST" action="" id="requestForm">
                                <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">
                                
                                <h6 class="fw-bold mb-3 text-white">Patient Information</h6>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label text-white">Patient Name <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="patient_name" required>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label text-white">Hospital/Facility <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="hospital_name" required>
                                    </div>
                                </div>
                                
                                <hr class="my-4">
                                
                                <h6 class="fw-bold mb-3 text-white">Blood Requirements</h6>
                                
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label class="form-label text-white">Blood Type Required <span class="text-danger">*</span></label>
                                        <select class="form-select form-select-lg" name="blood_type_id" id="bloodTypeSelect" required>
                                            <option value="">Select Blood Type</option>
                                            <?php foreach ($bloodTypes as $type): ?>
                                                <?php 
                                                    $available = isset($inventory[$type['blood_type_id']]) ? 
                                                                floor($inventory[$type['blood_type_id']] / 450) : 0;
                                                    $isAvailable = $available > 0;
                                                ?>
                                                <option value="<?php echo $type['blood_type_id']; ?>" 
                                                        data-available="<?php echo $available; ?>"
                                                        data-blood-type="<?php echo htmlspecialchars($type['blood_type']); ?>">
                                                    <?php echo $type['blood_type']; ?> 
                                                    <?php if ($isAvailable): ?>
                                                        - ✅ <?php echo $available; ?> units available
                                                    <?php else: ?>
                                                        - ⚠️ Not Available (request will be pending)
                                                    <?php endif; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="form-text">
                                            <i class="bi bi-info-circle text-white"></i> 
                                            Select blood type first to see available quantities
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Quantity Section - Hidden by default -->
                                <div id="quantitySection" style="display: none;">
                                    <div class="alert alert-info">
                                        <i class="bi bi-droplet-fill me-2"></i>
                                        <strong id="selectedBloodType"></strong> - 
                                        <span id="availableUnits"></span> units available 
                                        (<span id="availableMl"></span> ml)
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label text-white">Number of Units Required <span class="text-danger">*</span></label>
                                            <input type="number" 
                                                   class="form-control form-control-lg" 
                                                   name="quantity_units" 
                                                   id="quantityInput" 
                                                   min="1" 
                                                   max="1" 
                                                   step="1"
                                                   placeholder="Enter units (1 unit = 450ml)"
                                                   required>
                                            <input type="hidden" name="quantity_ml" id="quantityMlHidden">
                                            <div class="form-text">
                                                <span id="quantityWarning"></span>
                                                <span id="mlDisplay" class="fw-bold text-primary"></span>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Urgency Level <span class="text-danger">*</span></label>
                                            <select class="form-select" name="urgency" required>
                                                <option value="">Select Urgency</option>
                                                <option value="Low">Low</option>
                                                <option value="Medium">Medium</option>
                                                <option value="High">High</option>
                                                <option value="Critical">Critical</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Required Date <span class="text-danger">*</span></label>
                                            <input type="date" class="form-control" name="required_date" 
                                                   min="<?php echo date('Y-m-d'); ?>" required>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label text-white">Reason for Request <span class="text-danger">*</span></label>
                                    <textarea class="form-control" name="reason" rows="3" required 
                                              placeholder="e.g., Surgery, Emergency, Chronic illness"></textarea>
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="terms" required>
                                    <label class="form-check-label text-white" for="terms">
                                        I confirm that all information provided is accurate and complete.
                                    </label>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <button type="submit" name="submit_request" class="btn btn-primary btn-lg">
                                        <i class="bi bi-bandaid me-2"></i>Submit Request
                                    </button>
                                    <a href="dashboard.php" class="btn btn-outline-secondary">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h6 class="fw-bold mb-3">Blood Availability</h6>
                            <div class="list-group list-group-flush">
                                <?php foreach ($bloodTypes as $type): ?>
                                    <?php 
                                        $available = isset($inventory[$type['blood_type_id']]) ? 
                                                    floor($inventory[$type['blood_type_id']] / 450) : 0;
                                        $statusClass = $available > 5 ? 'success' : ($available > 2 ? 'warning' : 'danger');
                                    ?>
                                    <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                        <span class="fw-bold"><?php echo $type['blood_type']; ?></span>
                                        <span class="badge bg-<?php echo $statusClass; ?>">
                                            <?php echo $available; ?> units
                                        </span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h6 class="fw-bold mb-3">Important Information</h6>
                            <ul class="list-unstyled small">
                                <li class="mb-2">
                                    <i class="bi bi-info-circle-fill text-info me-2"></i>
                                    1 unit = 450ml of blood
                                </li>
                                <li class="mb-2">
                                    <i class="bi bi-info-circle-fill text-info me-2"></i>
                                    Request processing time: 2-24 hours
                                </li>
                                <li class="mb-2">
                                    <i class="bi bi-info-circle-fill text-info me-2"></i>
                                    Critical requests are prioritized
                                </li>
                                <li class="mb-2">
                                    <i class="bi bi-info-circle-fill text-info me-2"></i>
                                    You'll be notified once approved
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
// Dynamic quantity input based on blood type availability
document.getElementById('bloodTypeSelect').addEventListener('change', function() {
    const selectedOption = this.options[this.selectedIndex];
    const available = parseInt(selectedOption.dataset.available) || 0;
    const bloodType = selectedOption.dataset.bloodType;
    
    const quantitySection = document.getElementById('quantitySection');
    const quantityInput = document.getElementById('quantityInput');
    const quantityMlHidden = document.getElementById('quantityMlHidden');
    const selectedBloodTypeDisplay = document.getElementById('selectedBloodType');
    const availableUnitsDisplay = document.getElementById('availableUnits');
    const availableMlDisplay = document.getElementById('availableMl');
    const quantityWarning = document.getElementById('quantityWarning');
    const mlDisplay = document.getElementById('mlDisplay');
    
    if (this.value === '') {
        // Hide quantity section if no blood type selected
        quantitySection.style.display = 'none';
        return;
    }
    
    // Show quantity section
    quantitySection.style.display = 'block';
    selectedBloodTypeDisplay.textContent = bloodType;
    availableUnitsDisplay.textContent = available;
    availableMlDisplay.textContent = (available * 450);
    
    // Set max limit for input
    if (available > 0) {
        quantityInput.max = available;
        quantityInput.value = '';
        mlDisplay.textContent = '';
        
        // Show warning if limited stock
        if (available < 3) {
            quantityWarning.innerHTML = '<i class="bi bi-exclamation-triangle text-warning me-1"></i> Limited stock - Max ' + available + ' units | ';
        } else {
            quantityWarning.innerHTML = '<i class="bi bi-check-circle text-success me-1"></i> Stock available - Max ' + available + ' units | ';
        }
    } else {
        // No stock - allow up to 10 units but will be pending
        quantityInput.max = 10;
        quantityInput.value = '';
        mlDisplay.textContent = '';
        quantityWarning.innerHTML = '<i class="bi bi-exclamation-circle text-danger me-1"></i> <strong>Out of stock</strong> - Request will be pending | ';
    }
});

// Real-time quantity validation and ml calculation
document.getElementById('quantityInput').addEventListener('input', function() {
    const selectedOption = document.getElementById('bloodTypeSelect').options[document.getElementById('bloodTypeSelect').selectedIndex];
    const available = parseInt(selectedOption.dataset.available) || 0;
    const units = parseInt(this.value) || 0;
    const ml = units * 450;
    
    const mlDisplay = document.getElementById('mlDisplay');
    const quantityMlHidden = document.getElementById('quantityMlHidden');
    
    // Update ml display
    if (units > 0) {
        mlDisplay.textContent = '= ' + ml + ' ml';
        quantityMlHidden.value = ml;
    } else {
        mlDisplay.textContent = '';
        quantityMlHidden.value = '';
    }
    
    // Enforce max limit
    if (available > 0 && units > available) {
        this.value = available;
        alert('⚠️ Cannot exceed available stock!\n\nMaximum available: ' + available + ' units (' + (available * 450) + ' ml)');
        mlDisplay.textContent = '= ' + (available * 450) + ' ml';
        quantityMlHidden.value = available * 450;
    }
    
    // Enforce minimum
    if (units < 0) {
        this.value = 1;
    }
});

// Prevent manual entry beyond max
document.getElementById('quantityInput').addEventListener('blur', function() {
    const selectedOption = document.getElementById('bloodTypeSelect').options[document.getElementById('bloodTypeSelect').selectedIndex];
    const available = parseInt(selectedOption.dataset.available) || 0;
    const units = parseInt(this.value) || 0;
    
    if (available > 0 && units > available) {
        this.value = available;
        document.getElementById('mlDisplay').textContent = '= ' + (available * 450) + ' ml';
        document.getElementById('quantityMlHidden').value = available * 450;
    }
});

// Validate on form submission
document.getElementById('requestForm').addEventListener('submit', function(e) {
    const selectedOption = document.getElementById('bloodTypeSelect').options[document.getElementById('bloodTypeSelect').selectedIndex];
    const available = parseInt(selectedOption.dataset.available) || 0;
    const units = parseInt(document.getElementById('quantityInput').value) || 0;
    const ml = units * 450;
    
    // Update hidden field
    document.getElementById('quantityMlHidden').value = ml;
    
    if (available > 0 && units > available) {
        e.preventDefault();
        alert('❌ Cannot submit request!\n\n' +
              'You requested: ' + units + ' units (' + ml + ' ml)\n' +
              'Available: ' + available + ' units (' + (available * 450) + ' ml)\n\n' +
              'Please enter a quantity within available stock.');
        return false;
    }
    
    if (units < 1) {
        e.preventDefault();
        alert('❌ Please enter a valid quantity (at least 1 unit).');
        return false;
    }
    
    if (available === 0) {
        const confirm = window.confirm(
            '⚠️ NOTICE: Out of Stock\n\n' +
            'The selected blood type is currently OUT OF STOCK.\n\n' +
            'Your request for ' + units + ' units (' + ml + ' ml) will be submitted but marked as PENDING until stock becomes available.\n\n' +
            'For urgent/critical cases, please contact the Red Cross directly.\n\n' +
            'Do you want to proceed with this request?'
        );
        
        if (!confirm) {
            e.preventDefault();
            return false;
        }
    }
});
</script>

<?php include 'includes/footer.php'; ?>
