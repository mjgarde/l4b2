<?php
/**
 * CHECK REGISTRATION → DOCUMENTS FLOW
 * Debug kung bakit hindi nag-save ang documents
 */

require_once 'config/config.php';
require_once 'config/db.php';

echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>Check Registration Documents</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css'>
    <style>
        body { padding: 30px; background: #f0f2f5; }
        .section { background: white; padding: 25px; margin: 20px 0; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
        .success { border-left: 5px solid #28a745; background: #d4edda; }
        .error { border-left: 5px solid #dc3545; background: #f8d7da; }
        .warning { border-left: 5px solid #ffc107; background: #fff3cd; }
        .info { border-left: 5px solid #17a2b8; background: #d1ecf1; }
        code { background: #f4f4f4; padding: 3px 8px; border-radius: 4px; color: #e83e8c; font-size: 0.9rem; }
        pre { background: #2d2d2d; color: #f8f8f2; padding: 15px; border-radius: 8px; overflow-x: auto; }
    </style>
</head>
<body>
<div class='container'>
    <h1 class='mb-4'><i class='bi bi-bug-fill'></i> Registration → Documents Debug</h1>
    <p class='lead'>Checking why documents are not showing in admin</p>
    <hr>";

try {
    // STEP 1: Check recent users
    echo "<div class='section info'>
            <h3><i class='bi bi-1-circle-fill'></i> Recent Users (Last 5)</h3>";
    
    $userSql = "SELECT user_id, username, full_name, email, status, created_at 
                FROM users 
                ORDER BY created_at DESC 
                LIMIT 5";
    $users = $db->query($userSql)->fetchAll();
    
    if (empty($users)) {
        echo "<div class='error'>❌ NO USERS FOUND! Database might be empty.</div>";
    } else {
        echo "<table class='table table-striped'>
                <tr><th>ID</th><th>Username</th><th>Name</th><th>Status</th><th>Registered</th><th>Has Documents?</th></tr>";
        
        foreach ($users as $user) {
            // Check if user has documents
            $docCheckSql = "SELECT COUNT(*) as cnt FROM user_documents WHERE user_id = ?";
            $docCheckStmt = $db->prepare($docCheckSql);
            $docCheckStmt->execute([$user['user_id']]);
            $docCount = $docCheckStmt->fetch()['cnt'];
            
            $docBadge = $docCount > 0 ? 
                "<span class='badge bg-success'>✅ $docCount docs</span>" : 
                "<span class='badge bg-danger'>❌ 0 docs</span>";
            
            echo "<tr>
                    <td>{$user['user_id']}</td>
                    <td><code>{$user['username']}</code></td>
                    <td>{$user['full_name']}</td>
                    <td><span class='badge bg-warning'>{$user['status']}</span></td>
                    <td><small>{$user['created_at']}</small></td>
                    <td>$docBadge</td>
                  </tr>";
        }
        echo "</table>";
    }
    echo "</div>";
    
    // STEP 2: Check ALL documents in database
    echo "<div class='section info'>
            <h3><i class='bi bi-2-circle-fill'></i> All Documents in Database</h3>";
    
    $allDocsSql = "SELECT d.*, u.username, u.full_name 
                   FROM user_documents d 
                   LEFT JOIN users u ON d.user_id = u.user_id 
                   ORDER BY d.created_at DESC";
    $allDocs = $db->query($allDocsSql)->fetchAll();
    
    if (empty($allDocs)) {
        echo "<div class='error'>
                <h4>❌ NO DOCUMENTS IN DATABASE!</h4>
                <p><strong>This means:</strong></p>
                <ul>
                    <li>Documents are NOT being saved during registration</li>
                    <li>The file upload code is not working</li>
                    <li>OR files are uploaded but not saved to database</li>
                </ul>
                <p><strong>Let's check the registration code...</strong></p>
              </div>";
    } else {
        echo "<div class='success'>✅ Found " . count($allDocs) . " document(s)</div>";
        echo "<table class='table table-sm'>
                <tr><th>ID</th><th>User</th><th>Type</th><th>File</th><th>Path</th><th>Exists?</th></tr>";
        
        foreach ($allDocs as $doc) {
            $exists = file_exists($doc['file_path']) ? '✅' : '❌';
            echo "<tr>
                    <td>{$doc['document_id']}</td>
                    <td><small>{$doc['full_name']}<br>@{$doc['username']}</small></td>
                    <td>{$doc['document_type']}</td>
                    <td><small>{$doc['file_name']}</small></td>
                    <td><code>{$doc['file_path']}</code></td>
                    <td>$exists</td>
                  </tr>";
        }
        echo "</table>";
    }
    echo "</div>";
    
    // STEP 3: Check register.php code
    echo "<div class='section warning'>
            <h3><i class='bi bi-3-circle-fill'></i> Registration Code Analysis</h3>";
    
    $registerFile = 'register.php';
    if (!file_exists($registerFile)) {
        echo "<div class='error'>❌ register.php NOT FOUND!</div>";
    } else {
        $registerCode = file_get_contents($registerFile);
        
        echo "<div class='mb-3'><strong>Checking key components:</strong></div>";
        
        $checks = [
            'Has $_FILES handling' => strpos($registerCode, '$_FILES[') !== false,
            'Uploads medical_certificate' => strpos($registerCode, 'medical_certificate') !== false,
            'Uploads photo_id' => strpos($registerCode, 'photo_id') !== false,
            'Uses move_uploaded_file()' => strpos($registerCode, 'move_uploaded_file') !== false,
            'Saves to user_documents table' => strpos($registerCode, 'INSERT INTO user_documents') !== false,
            'Gets lastInsertId()' => strpos($registerCode, 'lastInsertId()') !== false,
            'Has upload directory check' => strpos($registerCode, 'is_dir') !== false && strpos($registerCode, 'mkdir') !== false
        ];
        
        foreach ($checks as $check => $result) {
            $icon = $result ? '✅' : '❌';
            $class = $result ? 'success' : 'danger';
            echo "<div class='alert alert-$class'>$icon $check</div>";
        }
        
        // Check if document insert is AFTER user insert
        if (strpos($registerCode, 'lastInsertId()') !== false && 
            strpos($registerCode, 'INSERT INTO user_documents') !== false) {
            
            $lastIdPos = strpos($registerCode, 'lastInsertId()');
            $docInsertPos = strpos($registerCode, 'INSERT INTO user_documents');
            
            if ($docInsertPos > $lastIdPos) {
                echo "<div class='alert alert-success'>✅ Document insert is AFTER getting user ID (correct order)</div>";
            } else {
                echo "<div class='alert alert-danger'>❌ Document insert is BEFORE getting user ID (wrong order!)</div>";
            }
        }
    }
    echo "</div>";
    
    // STEP 4: Test Query that Admin Uses
    echo "<div class='section info'>
            <h3><i class='bi bi-4-circle-fill'></i> Admin Query Test</h3>";
    
    echo "<p>This is what the admin page queries:</p>";
    
    $pendingSql = "SELECT * FROM users WHERE status = 'pending' ORDER BY created_at DESC LIMIT 5";
    $pending = $db->query($pendingSql)->fetchAll();
    
    if (empty($pending)) {
        echo "<div class='warning'>⚠️ No pending users</div>";
    } else {
        echo "<div class='success'>✅ Found " . count($pending) . " pending user(s)</div>";
        
        foreach ($pending as $user) {
            echo "<div class='card mb-3'>
                    <div class='card-header bg-primary text-white'>
                        <strong>{$user['full_name']}</strong> (@{$user['username']})
                    </div>
                    <div class='card-body'>";
            
            // Get documents
            $docSql = "SELECT * FROM user_documents WHERE user_id = :user_id ORDER BY document_type";
            $docStmt = $db->prepare($docSql);
            $docStmt->execute([':user_id' => $user['user_id']]);
            $docs = $docStmt->fetchAll();
            
            echo "<p><strong>Documents Query:</strong> <code>SELECT * FROM user_documents WHERE user_id = {$user['user_id']}</code></p>";
            echo "<p><strong>Result:</strong> " . count($docs) . " document(s) found</p>";
            
            if (empty($docs)) {
                echo "<div class='alert alert-danger'>
                        ❌ <strong>No documents uploaded</strong><br>
                        <small>This is what admin sees!</small>
                      </div>";
            } else {
                echo "<div class='alert alert-success'>✅ Documents found:</div>";
                foreach ($docs as $doc) {
                    echo "<li>{$doc['document_type']}: {$doc['file_name']}</li>";
                }
            }
            
            echo "</div></div>";
        }
    }
    echo "</div>";
    
    // STEP 5: SQL Fix
    echo "<div class='section warning'>
            <h3><i class='bi bi-5-circle-fill'></i> Recommended Actions</h3>";
    
    $totalUsers = $db->query("SELECT COUNT(*) as cnt FROM users")->fetch()['cnt'];
    $totalDocs = $db->query("SELECT COUNT(*) as cnt FROM user_documents")->fetch()['cnt'];
    
    echo "<div class='row'>
            <div class='col-md-6'>
                <div class='alert alert-info text-center'>
                    <h2>$totalUsers</h2>
                    <p class='mb-0'>Total Users</p>
                </div>
            </div>
            <div class='col-md-6'>
                <div class='alert alert-info text-center'>
                    <h2>$totalDocs</h2>
                    <p class='mb-0'>Total Documents</p>
                </div>
            </div>
          </div>";
    
    if ($totalUsers > 0 && $totalDocs == 0) {
        echo "<div class='alert alert-danger'>
                <h4>🚨 PROBLEM IDENTIFIED!</h4>
                <p><strong>Users exist but NO documents in database!</strong></p>
                <p>This means the document upload code in <code>register.php</code> is NOT saving to the database.</p>
                <hr>
                <h5>Solutions:</h5>
                <ol>
                    <li>Check if <code>user_documents</code> table exists</li>
                    <li>Verify the INSERT query in register.php is executing</li>
                    <li>Check for PHP errors during registration</li>
                    <li>Test with a NEW registration</li>
                </ol>
              </div>";
    } else if ($totalDocs > 0) {
        echo "<div class='alert alert-success'>
                <h4>✅ Documents ARE being saved!</h4>
                <p>The issue might be:</p>
                <ul>
                    <li>User's documents were uploaded BEFORE the fix</li>
                    <li>Admin page query might need refresh</li>
                    <li>Try registering a NEW user to test</li>
                </ul>
              </div>";
    }
    
    echo "</div>";
    
    // Action buttons
    echo "<div class='text-center mt-4'>
            <a href='register.php' class='btn btn-primary btn-lg'><i class='bi bi-person-plus-fill'></i> Test New Registration</a>
            <a href='admin/user_approvals.php' class='btn btn-success btn-lg'><i class='bi bi-shield-check'></i> Go to User Approvals</a>
            <a href='javascript:location.reload()' class='btn btn-secondary btn-lg'><i class='bi bi-arrow-clockwise'></i> Refresh</a>
          </div>";
    
} catch(Exception $e) {
    echo "<div class='section error'>
            <h3>❌ Error</h3>
            <p>" . $e->getMessage() . "</p>
            <pre>" . $e->getTraceAsString() . "</pre>
          </div>";
}

echo "</div>
</body>
</html>";
?>
