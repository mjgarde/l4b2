/**
 * Real-time Notification System
 * Handles notification updates and display
 */

class NotificationManager {
    constructor() {
        this.updateInterval = 30000; // Update every 30 seconds
        this.notificationBadge = document.getElementById('notificationBadge');
        this.notificationDropdown = document.getElementById('notificationDropdown');
        this.init();
    }

    init() {
        // Initial load
        this.updateNotificationCount();
        
        // Set up auto-refresh
        setInterval(() => {
            this.updateNotificationCount();
        }, this.updateInterval);
        
        // Set up event listeners
        this.setupEventListeners();
    }

    async updateNotificationCount() {
        try {
            const response = await fetch('api/notifications.php?action=get_count');
            const data = await response.json();
            
            if (data.success) {
                this.updateBadge(data.count);
            }
        } catch (error) {
            console.error('Error updating notification count:', error);
        }
    }

    async loadRecentNotifications() {
        try {
            const response = await fetch('api/notifications.php?action=get_recent&limit=5');
            const data = await response.json();
            
            if (data.success && this.notificationDropdown) {
                this.renderNotifications(data.notifications);
            }
        } catch (error) {
            console.error('Error loading notifications:', error);
        }
    }

    updateBadge(count) {
        if (this.notificationBadge) {
            if (count > 0) {
                this.notificationBadge.textContent = count > 99 ? '99+' : count;
                this.notificationBadge.style.display = 'inline-block';
            } else {
                this.notificationBadge.style.display = 'none';
            }
        }
    }

    renderNotifications(notifications) {
        if (!this.notificationDropdown) return;

        if (notifications.length === 0) {
            this.notificationDropdown.innerHTML = `
                <div class="dropdown-item text-center text-muted py-3">
                    <i class="bi bi-bell-slash"></i>
                    <p class="mb-0 small mt-2">No notifications</p>
                </div>
            `;
            return;
        }

        let html = '';
        notifications.forEach(notif => {
            const iconClass = this.getIconClass(notif.type);
            const badgeClass = this.getBadgeClass(notif.type);
            const unreadBadge = notif.is_read === 'No' ? '<span class="badge bg-primary ms-2">New</span>' : '';
            
            html += `
                <div class="dropdown-item notification-item ${notif.is_read === 'No' ? 'unread' : ''}" 
                     data-notification-id="${notif.id}">
                    <div class="d-flex align-items-start">
                        <i class="bi ${iconClass} me-2 mt-1"></i>
                        <div class="flex-grow-1">
                            <strong>${this.escapeHtml(notif.title)}</strong>
                            ${unreadBadge}
                            <p class="mb-1 small">${this.escapeHtml(notif.message)}</p>
                            <small class="text-muted">${notif.created_at}</small>
                        </div>
                    </div>
                </div>
            `;
        });

        html += `
            <div class="dropdown-divider"></div>
            <a href="notifications.php" class="dropdown-item text-center text-primary">
                <strong>View All Notifications</strong>
            </a>
        `;

        this.notificationDropdown.innerHTML = html;
    }

    async markAsRead(notificationId) {
        try {
            const formData = new FormData();
            formData.append('notification_id', notificationId);

            const response = await fetch('api/notifications.php?action=mark_read', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.updateNotificationCount();
                this.loadRecentNotifications();
            }
        } catch (error) {
            console.error('Error marking notification as read:', error);
        }
    }

    async markAllAsRead() {
        try {
            const response = await fetch('api/notifications.php?action=mark_all_read', {
                method: 'POST'
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.updateNotificationCount();
                this.loadRecentNotifications();
                this.showToast('All notifications marked as read', 'success');
            }
        } catch (error) {
            console.error('Error marking all as read:', error);
        }
    }

    async deleteNotification(notificationId) {
        if (!confirm('Delete this notification?')) return;

        try {
            const formData = new FormData();
            formData.append('notification_id', notificationId);

            const response = await fetch('api/notifications.php?action=delete', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.updateNotificationCount();
                this.loadRecentNotifications();
                this.showToast('Notification deleted', 'success');
            }
        } catch (error) {
            console.error('Error deleting notification:', error);
        }
    }

    setupEventListeners() {
        // Load notifications when dropdown is opened
        const notificationToggle = document.querySelector('[data-bs-toggle="dropdown"][href="#notificationDropdown"]');
        if (notificationToggle) {
            notificationToggle.addEventListener('click', () => {
                this.loadRecentNotifications();
            });
        }

        // Handle notification clicks
        if (this.notificationDropdown) {
            this.notificationDropdown.addEventListener('click', (e) => {
                const notificationItem = e.target.closest('.notification-item');
                if (notificationItem) {
                    const notificationId = notificationItem.dataset.notificationId;
                    if (notificationItem.classList.contains('unread')) {
                        this.markAsRead(notificationId);
                    }
                }
            });
        }

        // Mark all as read button
        const markAllReadBtn = document.getElementById('markAllReadBtn');
        if (markAllReadBtn) {
            markAllReadBtn.addEventListener('click', () => {
                this.markAllAsRead();
            });
        }
    }

    getIconClass(type) {
        const icons = {
            'info': 'bi-info-circle-fill text-info',
            'success': 'bi-check-circle-fill text-success',
            'warning': 'bi-exclamation-triangle-fill text-warning',
            'error': 'bi-x-circle-fill text-danger'
        };
        return icons[type] || icons['info'];
    }

    getBadgeClass(type) {
        const badges = {
            'info': 'bg-info',
            'success': 'bg-success',
            'warning': 'bg-warning',
            'error': 'bg-danger'
        };
        return badges[type] || badges['info'];
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    showToast(message, type = 'info') {
        // Simple toast notification
        const toast = document.createElement('div');
        toast.className = `alert alert-${type} position-fixed top-0 end-0 m-3`;
        toast.style.zIndex = '9999';
        toast.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        document.body.appendChild(toast);

        setTimeout(() => {
            toast.remove();
        }, 3000);
    }
}

// Initialize notification manager when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.notificationManager = new NotificationManager();
});

// Play notification sound (optional)
function playNotificationSound() {
    const audio = new Audio('assets/sounds/notification.mp3');
    audio.play().catch(e => console.log('Could not play notification sound'));
}

// Desktop notification (optional, requires permission)
function showDesktopNotification(title, message) {
    if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(title, {
            body: message,
            icon: 'assets/images/logo.png'
        });
    }
}

// Request notification permission
function requestNotificationPermission() {
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }
}
