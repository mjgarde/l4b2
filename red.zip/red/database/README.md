# Database Setup Guide

## 📦 Quick Setup

### Step 1: Start XAMPP
1. Open XAMPP Control Panel
2. Start **Apache** and **MySQL** services

### Step 2: Import Database

#### Option A: Using phpMyAdmin (Recommended)
1. Open browser and go to: `http://localhost/phpmyadmin`
2. Click on **"Import"** tab
3. Click **"Choose File"** and select: `koronadal_redcross.sql`
4. Click **"Go"** at the bottom
5. Wait for success message ✅

#### Option B: Using MySQL Command Line
```bash
# Login to MySQL
c:\xampp\mysql\bin\mysql.exe -u root -p

# Run these commands:
SOURCE c:/xampp/htdocs/Koronadal Red Cross/database/koronadal_redcross.sql;
exit;
```

### Step 3: Verify Database
1. In phpMyAdmin, you should see `koronadal_redcross` database
2. It should have 10 tables with sample data

### Step 4: Test Login
1. Open: `http://localhost/Koronadal Red Cross/login.php`
2. Use these credentials:
   - **Username**: `admin`
   - **Password**: `admin123`

---

## 🔧 If You Have Issues

### Problem: "Wrong Password" Error
**Solution**: Run the password update script

1. In phpMyAdmin, click on `koronadal_redcross` database
2. Click on **SQL** tab
3. Copy and paste contents from `update_passwords.sql`
4. Click **Go**

### Problem: Database Already Exists
**Solution**: Drop and re-import

```sql
DROP DATABASE IF EXISTS koronadal_redcross;
SOURCE c:/xampp/htdocs/Koronadal Red Cross/database/koronadal_redcross.sql;
```

### Problem: Can't Find SQL File
**Path**: `c:\xampp\htdocs\Koronadal Red Cross\database\koronadal_redcross.sql`

---

## 📋 Database Structure

### Tables (10 total):
1. **blood_types** - Blood type reference data (A+, A-, B+, etc.)
2. **users** - User accounts (admin and regular users)
3. **donors_info** - Donor profile information
4. **donations** - Blood donation records
5. **requests** - Blood request records
6. **inventory** - Blood inventory management
7. **events** - Blood drive events
8. **appointments** - Donation appointments
9. **notifications** - User notifications
10. **audit_logs** - System activity logs

### Sample Data Included:
- ✅ 8 Blood Types (A+, A-, B+, B-, AB+, AB-, O+, O-)
- ✅ 1 Admin User
- ✅ 3 Regular Users
- ✅ 3 Donor Profiles
- ✅ 3 Donation Records
- ✅ Sample Inventory Data
- ✅ 2 Sample Requests
- ✅ 2 Sample Events
- ✅ Sample Appointments & Notifications

---

## 🔐 Default Credentials

See `CREDENTIALS.md` in the root folder for complete login information.

**Quick Reference:**
- Admin: `admin` / `admin123`
- User: `jdoe` / `user123`

---

## 📊 ER Diagram Overview

```
users (1) ----< (N) donors_info
users (1) ----< (N) requests
users (1) ----< (N) appointments
users (1) ----< (N) notifications
users (1) ----< (N) audit_logs

blood_types (1) ----< (N) users
blood_types (1) ----< (N) donors_info
blood_types (1) ----< (N) donations
blood_types (1) ----< (N) requests
blood_types (1) ----< (N) inventory

donors_info (1) ----< (N) donations

events (1) ----< (N) appointments
```

---

## 🛠️ Maintenance Scripts

### Generate New Password Hashes
```bash
c:\xampp\php\php.exe generate_password.php
```

### Update Passwords
```bash
# In MySQL or phpMyAdmin SQL tab
SOURCE c:/xampp/htdocs/Koronadal Red Cross/database/update_passwords.sql;
```

### Backup Database
```bash
c:\xampp\mysql\bin\mysqldump.exe -u root koronadal_redcross > backup.sql
```

---

## 📝 Notes

- All passwords use bcrypt hashing with cost factor 12
- Timestamps use Asia/Manila timezone
- Foreign keys have proper CASCADE and SET NULL constraints
- Sample data includes realistic Filipino names and locations
