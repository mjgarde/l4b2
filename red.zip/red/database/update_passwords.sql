-- Update existing user passwords with correct hashes
-- Run this if you already imported the database before

USE koronadal_redcross;

-- Update Admin password to: admin123
UPDATE users 
SET password_hash = '$2y$12$fx5LnNgFBZtldV3o3/RQIuNUlFp.oPB56.89AUtyk.klCT8.UaJsu' 
WHERE username = 'admin';

-- Update Regular users password to: user123
UPDATE users 
SET password_hash = '$2y$12$WWi9h.bzZLaI9zW6gjKrGuE3xWI8vB80LkGFcdnfriftkzeM5zwQq' 
WHERE username IN ('jdoe', 'msmith', 'rgarcia');

-- Verify update
SELECT user_id, username, email, user_role, status FROM users;
