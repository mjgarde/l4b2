-- ===================================================================
-- RUN THIS SECOND - Insert user with documents
-- I-run mo to AFTER ng 1_CREATE_TABLE_FIRST.sql
-- ===================================================================

-- Delete old test user kung meron
DELETE FROM user_documents WHERE user_id IN (SELECT user_id FROM users WHERE username = 'kbalais');
DELETE FROM donors_info WHERE user_id IN (SELECT user_id FROM users WHERE username = 'kbalais');
DELETE FROM users WHERE username = 'kbalais';

-- Insert new pending user
-- Username: kbalais
-- Password: user123
INSERT INTO users (username, email, password_hash, full_name, phone, address, blood_type_id, user_role, status) 
VALUES ('kbalais', 'kien@email.com', '$2y$12$WWi9h.bzZLaI9zW6gjKrGuE3xWI8vB80LkGFcdnfriftkzeM5zwQq', 
        'Kien Balais', '09261765157', 'Koronadal City, South Cotabato', 1, 'user', 'pending');

-- Get the new user ID
SET @user_id = LAST_INSERT_ID();

-- Insert medical information
INSERT INTO donors_info (user_id, date_of_birth, gender, weight, blood_type_id, medical_conditions, eligible_to_donate) 
VALUES (@user_id, '1995-05-15', 'Male', 72, 1, 
        'Hypertension (controlled with medication)\nAllergic to penicillin', 'Yes');

-- Insert uploaded documents (Medical Certificate + Valid ID)
INSERT INTO user_documents (user_id, document_type, file_name, file_path, file_size) 
VALUES 
(@user_id, 'medical_certificate', 'medical_certificate_kbalais.pdf', 'uploads/documents/medical_cert_sample.pdf', 245670),
(@user_id, 'valid_id', 'drivers_license_kbalais.jpg', 'uploads/documents/valid_id_sample.jpg', 189230);

-- ===================================================================
-- SUCCESS! Check results below
-- ===================================================================

SELECT '✅ User created successfully!' as message;

-- Show user info
SELECT 
    u.user_id,
    u.username,
    u.full_name,
    u.email,
    u.status as user_status,
    bt.blood_type,
    di.gender,
    di.weight,
    COUNT(ud.document_id) as total_documents
FROM users u
LEFT JOIN blood_types bt ON u.blood_type_id = bt.blood_type_id
LEFT JOIN donors_info di ON u.user_id = di.user_id
LEFT JOIN user_documents ud ON u.user_id = ud.user_id
WHERE u.username = 'kbalais'
GROUP BY u.user_id;

-- Show documents
SELECT 
    document_type as 'Document Type',
    file_name as 'File Name',
    CONCAT(ROUND(file_size/1024, 2), ' KB') as 'File Size'
FROM user_documents 
WHERE user_id = @user_id
ORDER BY document_type;

SELECT '👆 Now go to admin/user_approvals.php to see the result!' as next_step;
