-- ===================================================================
-- SUPER SIMPLE: Add Documents (Copy-Paste EACH SECTION ONE BY ONE)
-- ===================================================================

-- SECTION 1: Check users (COPY AND RUN THIS FIRST)
-- ===================================================================
SELECT user_id, username, full_name, status 
FROM users 
WHERE status = 'pending';


-- SECTION 2: Clear old documents (COPY AND RUN THIS SECOND)
-- ===================================================================
DELETE FROM user_documents;


-- SECTION 3: Add documents for user_id = 1 (CHANGE THE NUMBER!)
-- ===================================================================
INSERT INTO user_documents (user_id, document_type, file_name, file_path, file_size, status)
VALUES 
(1, 'medical_certificate', 'medical_cert_sample.jpg', 'uploads/medical_certificates/medical_cert_sample.jpg', 250000, 'pending'),
(1, 'id_card', 'valid_id_sample.jpg', 'uploads/profile_photos/valid_id_sample.jpg', 184790, 'pending');


-- SECTION 4: Add documents for user_id = 2 (CHANGE THE NUMBER!)
-- ===================================================================
INSERT INTO user_documents (user_id, document_type, file_name, file_path, file_size, status)
VALUES 
(2, 'medical_certificate', 'medical_cert_sample.jpg', 'uploads/medical_certificates/medical_cert_sample.jpg', 250000, 'pending'),
(2, 'id_card', 'valid_id_sample.jpg', 'uploads/profile_photos/valid_id_sample.jpg', 184790, 'pending');


-- SECTION 5: Add documents for user_id = 3 (CHANGE THE NUMBER!)
-- ===================================================================
INSERT INTO user_documents (user_id, document_type, file_name, file_path, file_size, status)
VALUES 
(3, 'medical_certificate', 'medical_cert_sample.jpg', 'uploads/medical_certificates/medical_cert_sample.jpg', 250000, 'pending'),
(3, 'id_card', 'valid_id_sample.jpg', 'uploads/profile_photos/valid_id_sample.jpg', 184790, 'pending');


-- SECTION 6: Verify (COPY AND RUN THIS LAST)
-- ===================================================================
SELECT 
    u.user_id,
    u.username,
    u.full_name,
    d.document_type,
    d.file_name
FROM users u
LEFT JOIN user_documents d ON u.user_id = d.user_id
WHERE u.status = 'pending'
ORDER BY u.user_id;
