-- Update User Status to include 'pending' for admin approval
-- Run this SQL to update the existing database

USE koronadal_redcross;

-- Modify the users table status enum to include 'pending'
ALTER TABLE users 
MODIFY COLUMN status ENUM('active', 'inactive', 'suspended', 'pending') DEFAULT 'pending';

-- Update any existing 'active' users that should remain active
-- (Admins and already verified users keep their active status)
-- New registrations will default to 'pending'
