-- Koronadal Red Cross Blood Donation and Request System
-- Database Schema with Sample Data

CREATE DATABASE IF NOT EXISTS koronadal_redcross;
USE koronadal_redcross;

-- Table 1: Blood Types
CREATE TABLE blood_types (
    blood_type_id INT PRIMARY KEY AUTO_INCREMENT,
    blood_type VARCHAR(5) NOT NULL UNIQUE,
    description VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table 2: Users
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    blood_type_id INT,
    user_role ENUM('admin', 'user') DEFAULT 'user',
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    FOREIGN KEY (blood_type_id) REFERENCES blood_types(blood_type_id)
);

-- Table 3: Donors Info
CREATE TABLE donors_info (
    donor_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    blood_type_id INT NOT NULL,
    date_of_birth DATE NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    weight DECIMAL(5,2),
    medical_conditions TEXT,
    last_donation_date DATE,
    eligible_to_donate ENUM('Yes', 'No') DEFAULT 'Yes',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (blood_type_id) REFERENCES blood_types(blood_type_id)
);

-- Table 4: Donations
CREATE TABLE donations (
    donation_id INT PRIMARY KEY AUTO_INCREMENT,
    donor_id INT NOT NULL,
    blood_type_id INT NOT NULL,
    donation_date DATE NOT NULL,
    quantity_ml INT NOT NULL,
    donation_location VARCHAR(200),
    status ENUM('pending', 'approved', 'rejected', 'completed') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (donor_id) REFERENCES donors_info(donor_id) ON DELETE CASCADE,
    FOREIGN KEY (blood_type_id) REFERENCES blood_types(blood_type_id)
);

-- Table 5: Blood Requests
CREATE TABLE requests (
    request_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    blood_type_id INT NOT NULL,
    patient_name VARCHAR(100) NOT NULL,
    hospital_name VARCHAR(200) NOT NULL,
    urgency ENUM('Low', 'Medium', 'High', 'Critical') NOT NULL,
    quantity_ml INT NOT NULL,
    required_date DATE NOT NULL,
    reason TEXT,
    status ENUM('pending', 'approved', 'fulfilled', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (blood_type_id) REFERENCES blood_types(blood_type_id)
);

-- Table 6: Blood Inventory
CREATE TABLE inventory (
    inventory_id INT PRIMARY KEY AUTO_INCREMENT,
    blood_type_id INT NOT NULL,
    quantity_ml INT NOT NULL DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    expiry_date DATE,
    status ENUM('available', 'reserved', 'expired') DEFAULT 'available',
    FOREIGN KEY (blood_type_id) REFERENCES blood_types(blood_type_id)
);

-- Table 7: Events
CREATE TABLE events (
    event_id INT PRIMARY KEY AUTO_INCREMENT,
    event_name VARCHAR(200) NOT NULL,
    event_description TEXT,
    event_date DATE NOT NULL,
    event_location VARCHAR(200),
    organizer VARCHAR(100),
    max_participants INT,
    current_participants INT DEFAULT 0,
    status ENUM('upcoming', 'ongoing', 'completed', 'cancelled') DEFAULT 'upcoming',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table 8: Appointments
CREATE TABLE appointments (
    appointment_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    event_id INT,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    purpose ENUM('donation', 'consultation', 'other') DEFAULT 'donation',
    status ENUM('scheduled', 'confirmed', 'completed', 'cancelled') DEFAULT 'scheduled',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE SET NULL
);

-- Table 9: Notifications
CREATE TABLE notifications (
    notification_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('info', 'success', 'warning', 'error') DEFAULT 'info',
    is_read ENUM('Yes', 'No') DEFAULT 'No',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Table 10: Audit Logs
CREATE TABLE audit_logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    table_affected VARCHAR(50),
    record_id INT,
    details TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- Insert Blood Types
INSERT INTO blood_types (blood_type, description) VALUES
('A+', 'Blood Type A Positive'),
('A-', 'Blood Type A Negative'),
('B+', 'Blood Type B Positive'),
('B-', 'Blood Type B Negative'),
('AB+', 'Blood Type AB Positive'),
('AB-', 'Blood Type AB Negative'),
('O+', 'Blood Type O Positive'),
('O-', 'Blood Type O Negative');

-- Insert Admin User (password: admin123)
INSERT INTO users (username, email, password_hash, full_name, phone, address, blood_type_id, user_role, status) VALUES
('admin', 'admin@koronadalredcross.org', '$2y$12$fx5LnNgFBZtldV3o3/RQIuNUlFp.oPB56.89AUtyk.klCT8.UaJsu', 'System Administrator', '09171234567', 'Koronadal City, South Cotabato', 1, 'admin', 'active');

-- Insert Sample Regular Users (password: user123)
INSERT INTO users (username, email, password_hash, full_name, phone, address, blood_type_id, user_role, status) VALUES
('jdoe', 'jdoe@email.com', '$2y$12$WWi9h.bzZLaI9zW6gjKrGuE3xWI8vB80LkGFcdnfriftkzeM5zwQq', 'John Doe', '09181234567', 'Koronadal City', 2, 'user', 'active'),
('msmith', 'msmith@email.com', '$2y$12$WWi9h.bzZLaI9zW6gjKrGuE3xWI8vB80LkGFcdnfriftkzeM5zwQq', 'Maria Smith', '09191234567', 'General Santos City', 3, 'user', 'active'),
('rgarcia', 'rgarcia@email.com', '$2y$12$WWi9h.bzZLaI9zW6gjKrGuE3xWI8vB80LkGFcdnfriftkzeM5zwQq', 'Robert Garcia', '09201234567', 'Tacurong City', 7, 'user', 'active');

-- Insert Sample Donor Info
INSERT INTO donors_info (user_id, blood_type_id, date_of_birth, gender, weight, medical_conditions, last_donation_date, eligible_to_donate) VALUES
(2, 2, '1990-05-15', 'Male', 75.5, 'None', '2024-08-15', 'Yes'),
(3, 3, '1992-08-20', 'Female', 60.0, 'None', '2024-09-01', 'Yes'),
(4, 7, '1988-03-10', 'Male', 80.0, 'Hypertension (controlled)', '2024-07-20', 'Yes');

-- Insert Sample Donations
INSERT INTO donations (donor_id, blood_type_id, donation_date, quantity_ml, donation_location, status, notes) VALUES
(1, 2, '2024-08-15', 450, 'Koronadal Red Cross Center', 'completed', 'Successful donation'),
(2, 3, '2024-09-01', 450, 'General Santos Hospital', 'completed', 'Successful donation'),
(3, 7, '2024-07-20', 450, 'Koronadal Red Cross Center', 'completed', 'Successful donation');

-- Insert Sample Blood Inventory
INSERT INTO inventory (blood_type_id, quantity_ml, expiry_date, status) VALUES
(1, 2250, '2024-12-31', 'available'),
(2, 1800, '2024-12-31', 'available'),
(3, 2700, '2024-12-31', 'available'),
(4, 900, '2024-12-31', 'available'),
(5, 1350, '2024-12-31', 'available'),
(6, 450, '2024-12-31', 'available'),
(7, 3600, '2024-12-31', 'available'),
(8, 1800, '2024-12-31', 'available');

-- Insert Sample Requests
INSERT INTO requests (user_id, blood_type_id, patient_name, hospital_name, urgency, quantity_ml, required_date, reason, status) VALUES
(2, 7, 'Jane Doe', 'South Cotabato Provincial Hospital', 'High', 450, '2024-11-15', 'Surgery', 'pending'),
(3, 2, 'Pedro Santos', 'General Santos Medical Center', 'Critical', 900, '2024-11-05', 'Emergency', 'approved');

-- Insert Sample Events
INSERT INTO events (event_name, event_description, event_date, event_location, organizer, max_participants, current_participants, status) VALUES
('Community Blood Drive', 'Monthly blood donation drive at the city plaza', '2024-12-15', 'Koronadal City Plaza', 'Red Cross Koronadal', 100, 45, 'upcoming'),
('Emergency Blood Collection', 'Emergency blood collection for disaster response', '2024-11-30', 'Red Cross Center', 'Red Cross Koronadal', 50, 20, 'upcoming');

-- Insert Sample Appointments
INSERT INTO appointments (user_id, event_id, appointment_date, appointment_time, purpose, status, notes) VALUES
(2, 1, '2024-12-15', '09:00:00', 'donation', 'scheduled', 'First time donor'),
(3, 1, '2024-12-15', '10:30:00', 'donation', 'confirmed', 'Regular donor');

-- Insert Sample Notifications
INSERT INTO notifications (user_id, title, message, type, is_read) VALUES
(2, 'Welcome!', 'Thank you for registering with Koronadal Red Cross Blood Donation System', 'success', 'Yes'),
(2, 'Appointment Scheduled', 'Your donation appointment is scheduled for December 15, 2024', 'info', 'No'),
(3, 'Request Approved', 'Your blood request has been approved', 'success', 'No');

-- Insert Audit Log Entry
INSERT INTO audit_logs (user_id, action, table_affected, details, ip_address) VALUES
(1, 'Database Initialized', 'All Tables', 'Initial database setup with sample data', '127.0.0.1');
