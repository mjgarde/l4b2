<?php
/**
 * Create Sample Document Files
 * This script creates sample files for testing document uploads
 */

// Define paths
$baseDir = dirname(__DIR__);
$medicalCertsDir = $baseDir . '/uploads/medical_certificates/';
$profilePhotosDir = $baseDir . '/uploads/profile_photos/';

// Find existing sample files
$existingMedicalCert = glob($medicalCertsDir . 'medical_cert_*.jpeg');
$existingPhotoId = glob($profilePhotosDir . 'photo_id_*.jpeg');

// Sample file names from database
$sampleFiles = [
    'medical_cert_sample.pdf' => $medicalCertsDir . 'medical_cert_sample.pdf',
    'medical_cert_sample.jpg' => $medicalCertsDir . 'medical_cert_sample.jpg',
    'valid_id_sample.jpg' => $profilePhotosDir . 'valid_id_sample.jpg',
];

// Create sample PDF content
$pdfContent = "%PDF-1.4
1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj
2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj
3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj
4 0 obj<</Length 44>>stream
BT /F1 24 Tf 100 700 Td (Sample Medical Certificate) Tj ET
endstream endobj
5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj
xref
0 6
0000000000 65535 f 
0000000009 00000 n 
0000000056 00000 n 
0000000115 00000 n 
0000000244 00000 n 
0000000337 00000 n 
trailer<</Size 6/Root 1 0 R>>
startxref
408
%%EOF";

echo "<h2>Creating Sample Files...</h2>";

// Create PDF sample
if (!file_exists($sampleFiles['medical_cert_sample.pdf'])) {
    file_put_contents($sampleFiles['medical_cert_sample.pdf'], $pdfContent);
    echo "✓ Created: medical_cert_sample.pdf<br>";
} else {
    echo "✓ Already exists: medical_cert_sample.pdf<br>";
}

// Copy existing JPEG files to sample names
if (!empty($existingMedicalCert) && !file_exists($sampleFiles['medical_cert_sample.jpg'])) {
    copy($existingMedicalCert[0], $sampleFiles['medical_cert_sample.jpg']);
    echo "✓ Created: medical_cert_sample.jpg<br>";
} else if (file_exists($sampleFiles['medical_cert_sample.jpg'])) {
    echo "✓ Already exists: medical_cert_sample.jpg<br>";
}

if (!empty($existingPhotoId) && !file_exists($sampleFiles['valid_id_sample.jpg'])) {
    copy($existingPhotoId[0], $sampleFiles['valid_id_sample.jpg']);
    echo "✓ Created: valid_id_sample.jpg<br>";
} else if (file_exists($sampleFiles['valid_id_sample.jpg'])) {
    echo "✓ Already exists: valid_id_sample.jpg<br>";
}

echo "<h3 style='color: green;'>✓ Sample files created successfully!</h3>";
echo "<p><a href='../admin/user_approvals.php'>Go to User Approvals</a></p>";
?>
