<?php
/**
 * Check Current Document Paths in Database
 */

require_once '../config/config.php';
require_once '../config/db.php';

echo "<h2>Current Document Paths in Database</h2>";
echo "<style>
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    th { background-color: #4CAF50; color: white; }
    .wrong { background-color: #ffcccc; }
    .correct { background-color: #ccffcc; }
</style>";

try {
    $sql = "SELECT 
                document_id,
                user_id,
                document_type,
                file_name,
                file_path,
                file_size,
                CASE 
                    WHEN file_path LIKE 'uploads/documents/%' THEN 'WRONG PATH ❌'
                    WHEN file_path LIKE 'uploads/medical_certificates/%' OR file_path LIKE 'uploads/profile_photos/%' THEN 'CORRECT ✓'
                    ELSE 'UNKNOWN'
                END as path_status
            FROM user_documents
            ORDER BY path_status DESC, document_type";
    
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $documents = $stmt->fetchAll();
    
    if (empty($documents)) {
        echo "<p style='color: orange;'>⚠️ No documents found in database</p>";
    } else {
        echo "<table>";
        echo "<tr>
                <th>ID</th>
                <th>User ID</th>
                <th>Type</th>
                <th>File Name</th>
                <th>File Path</th>
                <th>Status</th>
                <th>File Exists?</th>
              </tr>";
        
        foreach ($documents as $doc) {
            $fileExists = file_exists('../' . $doc['file_path']) ? '✓ Yes' : '❌ No';
            $rowClass = ($doc['path_status'] == 'WRONG PATH ❌') ? 'wrong' : 'correct';
            
            echo "<tr class='$rowClass'>";
            echo "<td>" . $doc['document_id'] . "</td>";
            echo "<td>" . $doc['user_id'] . "</td>";
            echo "<td>" . htmlspecialchars($doc['document_type']) . "</td>";
            echo "<td>" . htmlspecialchars($doc['file_name']) . "</td>";
            echo "<td>" . htmlspecialchars($doc['file_path']) . "</td>";
            echo "<td><strong>" . $doc['path_status'] . "</strong></td>";
            echo "<td>" . $fileExists . "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
        
        // Count wrong paths
        $wrongCount = 0;
        foreach ($documents as $doc) {
            if ($doc['path_status'] == 'WRONG PATH ❌') {
                $wrongCount++;
            }
        }
        
        if ($wrongCount > 0) {
            echo "<div style='background: #ffcccc; padding: 15px; margin-top: 20px; border-radius: 8px;'>";
            echo "<h3>⚠️ PROBLEMA: May $wrongCount wrong paths pa!</h3>";
            echo "<p><strong>Kailangan mo i-run yung SQL fix:</strong></p>";
            echo "<ol>";
            echo "<li>Buksan ang phpMyAdmin</li>";
            echo "<li>Piliin ang database: <code>blood_donation_system</code></li>";
            echo "<li>Click ang 'SQL' tab</li>";
            echo "<li>Copy-paste yung SQL sa baba:</li>";
            echo "</ol>";
            echo "<textarea style='width: 100%; height: 150px; font-family: monospace;'>";
            echo "UPDATE user_documents 
SET file_path = REPLACE(file_path, 'uploads/documents/', 'uploads/medical_certificates/')
WHERE document_type = 'medical_certificate' 
AND file_path LIKE 'uploads/documents/%';

UPDATE user_documents 
SET file_path = REPLACE(file_path, 'uploads/documents/', 'uploads/profile_photos/')
WHERE document_type IN ('valid_id', 'id_card') 
AND file_path LIKE 'uploads/documents/%';";
            echo "</textarea>";
            echo "<p><button onclick=\"location.reload()\">Refresh after running SQL</button></p>";
            echo "</div>";
        } else {
            echo "<div style='background: #ccffcc; padding: 15px; margin-top: 20px; border-radius: 8px;'>";
            echo "<h3>✓ All paths are correct!</h3>";
            echo "<p>Lahat ng document paths ay tama na. Pero kung wala pa rin ang files, kailangan mo na i-run ang:</p>";
            echo "<p><a href='create_sample_files.php' style='background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Create Sample Files</a></p>";
            echo "</div>";
        }
    }
} catch(PDOException $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}

echo "<p style='margin-top: 30px;'><a href='../admin/user_approvals.php'>← Back to User Approvals</a></p>";
?>
