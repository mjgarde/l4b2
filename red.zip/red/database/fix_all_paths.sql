-- ===================================================================
-- FIX ALL DOCUMENT PATHS
-- Fixes singular/plural directory names and old paths
-- ===================================================================

-- Fix: medical_certificate → medical_certificates (singular to plural)
UPDATE user_documents 
SET file_path = REPLACE(file_path, 'uploads/medical_certificate/', 'uploads/medical_certificates/')
WHERE file_path LIKE 'uploads/medical_certificate/%';

-- Fix: profile_photo → profile_photos (singular to plural)
UPDATE user_documents 
SET file_path = REPLACE(file_path, 'uploads/profile_photo/', 'uploads/profile_photos/')
WHERE file_path LIKE 'uploads/profile_photo/%';

-- Fix: Old documents folder → medical_certificates
UPDATE user_documents 
SET file_path = REPLACE(file_path, 'uploads/documents/', 'uploads/medical_certificates/')
WHERE document_type = 'medical_certificate' 
AND file_path LIKE 'uploads/documents/%';

-- Fix: Old documents folder → profile_photos
UPDATE user_documents 
SET file_path = REPLACE(file_path, 'uploads/documents/', 'uploads/profile_photos/')
WHERE document_type IN ('id_card', 'valid_id', 'photo_id') 
AND file_path LIKE 'uploads/documents/%';

-- Show all current paths
SELECT 
    document_id,
    document_type,
    file_name,
    file_path,
    CONCAT(ROUND(file_size/1024, 2), ' KB') as size
FROM user_documents
ORDER BY document_type, document_id;

-- Success message
SELECT '✅ All document paths have been fixed!' AS message;
