-- ===================================================================
-- RUN THIS FIRST - Create user_documents table
-- I-run mo to BAGO ang insert_pending_user_with_documents.sql
-- ===================================================================

-- Create table kung wala pa
CREATE TABLE IF NOT EXISTS user_documents (
    document_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    document_type ENUM('medical_certificate', 'valid_id') NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INT NOT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_document_type (document_type)
);

-- Check if table was created
SELECT 'SUCCESS! Table created!' as message;
SHOW TABLES LIKE 'user_documents';
