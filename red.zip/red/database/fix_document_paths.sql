-- ===================================================================
-- FIX DOCUMENT PATHS - Update incorrect paths to correct directories
-- ===================================================================

-- Update Medical Certificate paths
UPDATE user_documents 
SET file_path = REPLACE(file_path, 'uploads/documents/', 'uploads/medical_certificates/')
WHERE document_type = 'medical_certificate' 
AND file_path LIKE 'uploads/documents/%';

-- Update Photo ID/Valid ID paths  
UPDATE user_documents 
SET file_path = REPLACE(file_path, 'uploads/documents/', 'uploads/profile_photos/')
WHERE document_type IN ('valid_id', 'id_card') 
AND file_path LIKE 'uploads/documents/%';

-- Verify the changes
SELECT 
    document_id,
    user_id,
    document_type,
    file_name,
    file_path,
    file_size
FROM user_documents
ORDER BY document_type, user_id;

-- Show success message
SELECT 'Document paths have been updated successfully!' AS message;
