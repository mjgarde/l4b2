<?php
/**
 * AUTO ADD SAMPLE BLOOD INVENTORY
 * One-click solution to populate inventory
 */

require_once '../config/config.php';
require_once '../config/db.php';

echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>Add Sample Inventory</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css'>
</head>
<body class='p-5'>
<div class='container'>
    <h2 class='mb-4'><i class='bi bi-droplet-fill text-danger'></i> Adding Sample Blood Inventory...</h2>";

try {
    // Clear existing inventory
    $db->exec("TRUNCATE TABLE inventory");
    echo "<div class='alert alert-info'>🗑️ Cleared existing inventory</div>";
    
    // Sample inventory data: [blood_type_id, quantity_ml, days_to_expiry]
    $inventoryData = [
        // A+ (id=1) - 11 units total
        [1, 2250, 35], [1, 1800, 30], [1, 900, 25],
        
        // A- (id=2) - 5 units total
        [2, 1350, 40], [2, 900, 28],
        
        // B+ (id=3) - 12 units total
        [3, 3150, 38], [3, 2250, 32],
        
        // B- (id=4) - 3 units total
        [4, 900, 35], [4, 450, 20],
        
        // AB+ (id=5) - 7 units total
        [5, 1800, 37], [5, 1350, 29],
        
        // AB- (id=6) - 2 units total
        [6, 450, 42], [6, 450, 15],
        
        // O+ (id=7) - 24 units total (most common)
        [7, 4500, 39], [7, 3600, 31], [7, 2700, 27],
        
        // O- (id=8) - 12 units total (universal donor)
        [8, 2700, 41], [8, 1800, 36], [8, 900, 18]
    ];
    
    $insertSql = "INSERT INTO inventory (blood_type_id, quantity_ml, expiry_date, status, last_updated) 
                  VALUES (:blood_type_id, :quantity_ml, DATE_ADD(CURDATE(), INTERVAL :days DAY), 'available', NOW())";
    $stmt = $db->prepare($insertSql);
    
    $totalBatches = 0;
    foreach ($inventoryData as $data) {
        list($bloodTypeId, $quantityMl, $days) = $data;
        
        $stmt->execute([
            ':blood_type_id' => $bloodTypeId,
            ':quantity_ml' => $quantityMl,
            ':days' => $days
        ]);
        
        $totalBatches++;
    }
    
    echo "<div class='alert alert-success'>
            ✅ <strong>Added $totalBatches inventory batches!</strong>
          </div>";
    
    // Show summary per blood type
    $summarySql = "SELECT 
                        bt.blood_type,
                        COUNT(i.inventory_id) as batches,
                        SUM(i.quantity_ml) as total_ml,
                        FLOOR(SUM(i.quantity_ml) / 450) as total_units
                   FROM inventory i
                   JOIN blood_types bt ON i.blood_type_id = bt.blood_type_id
                   WHERE i.status = 'available'
                   GROUP BY bt.blood_type_id
                   ORDER BY bt.blood_type";
    
    $summaryStmt = $db->query($summarySql);
    $summary = $summaryStmt->fetchAll();
    
    echo "<div class='card'>
            <div class='card-header bg-primary text-white'>
                <h5 class='mb-0'><i class='bi bi-bar-chart-fill'></i> Inventory Summary</h5>
            </div>
            <div class='card-body'>
                <div class='row'>";
    
    foreach ($summary as $row) {
        $units = $row['total_units'];
        $percentage = min(($units / 20) * 100, 100);
        $statusClass = $percentage > 50 ? 'success' : ($percentage > 20 ? 'warning' : 'danger');
        
        echo "<div class='col-md-3 mb-3'>
                <div class='card border-0 shadow-sm'>
                    <div class='card-body text-center'>
                        <h3 class='text-danger fw-bold'>{$row['blood_type']}</h3>
                        <div class='progress mb-2' style='height: 25px;'>
                            <div class='progress-bar bg-$statusClass' style='width: {$percentage}%'>
                                <strong>{$units} units</strong>
                            </div>
                        </div>
                        <small class='text-muted'>{$row['batches']} batch(es) | {$row['total_ml']}ml</small>
                    </div>
                </div>
              </div>";
    }
    
    echo "      </div>
            </div>
          </div>";
    
    // Grand total
    $totalSql = "SELECT 
                    COUNT(*) as total_batches,
                    SUM(quantity_ml) as total_ml,
                    FLOOR(SUM(quantity_ml) / 450) as total_units
                 FROM inventory
                 WHERE status = 'available'";
    $totalStmt = $db->query($totalSql);
    $total = $totalStmt->fetch();
    
    echo "<div class='alert alert-success mt-4'>
            <h4>📊 Grand Total:</h4>
            <ul class='mb-0'>
                <li><strong>Total Batches:</strong> {$total['total_batches']}</li>
                <li><strong>Total Volume:</strong> " . number_format($total['total_ml']) . "ml</li>
                <li><strong>Total Units:</strong> {$total['total_units']} units (450ml each)</li>
            </ul>
          </div>";
    
    echo "<div class='alert alert-info mt-4'>
            <h5><i class='bi bi-info-circle'></i> What's Next?</h5>
            <ol class='mb-0'>
                <li>Go to <strong>Admin → Manage Inventory</strong> to see the blood stock</li>
                <li>Users can now see available units in the <strong>Request Blood</strong> form</li>
                <li>Dropdown will show: <code>A+ (11 units available)</code></li>
            </ol>
          </div>";
    
} catch(PDOException $e) {
    echo "<div class='alert alert-danger'>
            <h4>❌ Error</h4>
            <p>" . $e->getMessage() . "</p>
          </div>";
}

echo "<div class='text-center mt-4'>
        <a href='../admin/manage_inventory.php' class='btn btn-success btn-lg'>
            <i class='bi bi-box-seam'></i> View Inventory in Admin
        </a>
        <a href='../request.php' class='btn btn-primary btn-lg'>
            <i class='bi bi-bandaid'></i> Test Request Form
        </a>
        <a href='javascript:location.reload()' class='btn btn-secondary btn-lg'>
            <i class='bi bi-arrow-clockwise'></i> Run Again
        </a>
      </div>";

echo "</div>
</body>
</html>";
?>
