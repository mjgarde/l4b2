-- ===================================================================
-- ADD SAMPLE BLOOD INVENTORY
-- Para makita ang available units sa dropdown
-- ===================================================================

-- First, clear any existing inventory
TRUNCATE TABLE inventory;

-- Add sample inventory for each blood type
-- 1 unit = 450ml, adding 5-10 units per blood type

-- A+ Blood Type (blood_type_id = 1)
INSERT INTO inventory (blood_type_id, quantity_ml, expiry_date, status, last_updated)
VALUES 
(1, 2250, DATE_ADD(CURDATE(), INTERVAL 35 DAY), 'available', NOW()),  -- 5 units
(1, 1800, DATE_ADD(CURDATE(), INTERVAL 30 DAY), 'available', NOW()),  -- 4 units
(1, 900, DATE_ADD(CURDATE(), INTERVAL 25 DAY), 'available', NOW());   -- 2 units

-- A- Blood Type (blood_type_id = 2)
INSERT INTO inventory (blood_type_id, quantity_ml, expiry_date, status, last_updated)
VALUES 
(2, 1350, DATE_ADD(CURDATE(), INTERVAL 40 DAY), 'available', NOW()),  -- 3 units
(2, 900, DATE_ADD(CURDATE(), INTERVAL 28 DAY), 'available', NOW());   -- 2 units

-- B+ Blood Type (blood_type_id = 3)
INSERT INTO inventory (blood_type_id, quantity_ml, expiry_date, status, last_updated)
VALUES 
(3, 3150, DATE_ADD(CURDATE(), INTERVAL 38 DAY), 'available', NOW()),  -- 7 units
(3, 2250, DATE_ADD(CURDATE(), INTERVAL 32 DAY), 'available', NOW());  -- 5 units

-- B- Blood Type (blood_type_id = 4)
INSERT INTO inventory (blood_type_id, quantity_ml, expiry_date, status, last_updated)
VALUES 
(4, 900, DATE_ADD(CURDATE(), INTERVAL 35 DAY), 'available', NOW()),   -- 2 units
(4, 450, DATE_ADD(CURDATE(), INTERVAL 20 DAY), 'available', NOW());   -- 1 unit

-- AB+ Blood Type (blood_type_id = 5)
INSERT INTO inventory (blood_type_id, quantity_ml, expiry_date, status, last_updated)
VALUES 
(5, 1800, DATE_ADD(CURDATE(), INTERVAL 37 DAY), 'available', NOW()),  -- 4 units
(5, 1350, DATE_ADD(CURDATE(), INTERVAL 29 DAY), 'available', NOW());  -- 3 units

-- AB- Blood Type (blood_type_id = 6)
INSERT INTO inventory (blood_type_id, quantity_ml, expiry_date, status, last_updated)
VALUES 
(6, 450, DATE_ADD(CURDATE(), INTERVAL 42 DAY), 'available', NOW()),   -- 1 unit
(6, 450, DATE_ADD(CURDATE(), INTERVAL 15 DAY), 'available', NOW());   -- 1 unit

-- O+ Blood Type (blood_type_id = 7)
INSERT INTO inventory (blood_type_id, quantity_ml, expiry_date, status, last_updated)
VALUES 
(7, 4500, DATE_ADD(CURDATE(), INTERVAL 39 DAY), 'available', NOW()),  -- 10 units
(7, 3600, DATE_ADD(CURDATE(), INTERVAL 31 DAY), 'available', NOW()),  -- 8 units
(7, 2700, DATE_ADD(CURDATE(), INTERVAL 27 DAY), 'available', NOW());  -- 6 units

-- O- Blood Type (blood_type_id = 8)
INSERT INTO inventory (blood_type_id, quantity_ml, expiry_date, status, last_updated)
VALUES 
(8, 2700, DATE_ADD(CURDATE(), INTERVAL 41 DAY), 'available', NOW()),  -- 6 units
(8, 1800, DATE_ADD(CURDATE(), INTERVAL 36 DAY), 'available', NOW()),  -- 4 units
(8, 900, DATE_ADD(CURDATE(), INTERVAL 18 DAY), 'available', NOW());   -- 2 units

-- ===================================================================
-- VERIFY: Check total available units per blood type
-- ===================================================================
SELECT 
    bt.blood_type,
    COUNT(i.inventory_id) as batches,
    SUM(i.quantity_ml) as total_ml,
    FLOOR(SUM(i.quantity_ml) / 450) as total_units,
    MIN(i.expiry_date) as earliest_expiry
FROM inventory i
JOIN blood_types bt ON i.blood_type_id = bt.blood_type_id
WHERE i.status = 'available'
GROUP BY bt.blood_type_id
ORDER BY bt.blood_type;

-- Show grand total
SELECT 
    COUNT(*) as total_batches,
    SUM(quantity_ml) as total_ml,
    FLOOR(SUM(quantity_ml) / 450) as total_units
FROM inventory
WHERE status = 'available';

-- Success message
SELECT '✅ Sample inventory added! Refresh your request page to see available units.' as message;
