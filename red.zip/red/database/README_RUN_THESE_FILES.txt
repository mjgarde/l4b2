╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║  SIMPLE 2-STEP SETUP - Para Makita ang Documents            ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝

📌 STEP 1: Create Table
   File: 1_CREATE_TABLE_FIRST.sql
   
   1. Open phpMyAdmin
   2. Select database: koronadal_redcross
   3. Click "SQL" tab
   4. Copy ALL content from: 1_CREATE_TABLE_FIRST.sql
   5. Paste and click "Go"
   
   ✅ Result: Table "user_documents" created!

────────────────────────────────────────────────────────────────

📌 STEP 2: Insert Test User
   File: 2_INSERT_USER_WITH_DOCUMENTS.sql
   
   1. Stay in phpMyAdmin (same database)
   2. Click "SQL" tab
   3. Copy ALL content from: 2_INSERT_USER_WITH_DOCUMENTS.sql
   4. Paste and click "Go"
   
   ✅ Result: User "kbalais" created with documents!

────────────────────────────────────────────────────────────────

📌 STEP 3: View Result
   
   Open in browser:
   http://localhost/Koronadal%20Red%20Cross/admin/user_approvals.php
   
   MAKIKITA MO NA:
   
   ┌─────────────────────────────────────┐
   │ [KB] Kien Balais 🩸 Donor [Pending]│
   │                                      │
   │ 📄 Uploaded Documents:               │
   │                                      │
   │ 🏥 Medical Certificate               │
   │    medical_certificate_kbalais.pdf   │
   │    245.67 KB         [👁️ View]       │
   │                                      │
   │ 🪪 Valid ID                          │
   │    drivers_license_kbalais.jpg       │
   │    189.23 KB         [👁️ View]       │
   │                                      │
   │ [✅ APPROVE]  [❌ DECLINE]           │
   └─────────────────────────────────────┘

────────────────────────────────────────────────────────────────

📝 TEST LOGIN CREDENTIALS:
   Username: kbalais
   Password: user123

────────────────────────────────────────────────────────────────

⚠️ IMPORTANT NOTES:

1. Run files IN ORDER (1 then 2)
2. Kung may error sa Step 1, ibig sabihin table exists na
3. Kung may error sa Step 2, delete muna old user:
   DELETE FROM users WHERE username = 'kbalais';
4. Refresh browser page after running SQL

────────────────────────────────────────────────────────────────

✅ FILES TO USE:

database/
├── 1_CREATE_TABLE_FIRST.sql      ← Run FIRST
└── 2_INSERT_USER_WITH_DOCUMENTS.sql  ← Run SECOND

────────────────────────────────────────────────────────────────

🎉 TAPOS NA! 

After running both files, go to:
admin/user_approvals.php

MAKIKITA MO NA ANG DOCUMENTS! 🚀

════════════════════════════════════════════════════════════════
