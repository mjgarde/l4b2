<?php
/**
 * Notifications Page
 * View and manage user notifications
 */

require_once 'config/config.php';
require_once 'config/db.php';

requireLogin();

$userId = $_SESSION['user_id'];
$success = '';

// Mark as read
if (isset($_GET['mark_read'])) {
    $notificationId = intval($_GET['mark_read']);
    try {
        $updateSql = "UPDATE notifications SET is_read = 'Yes' WHERE notification_id = :notification_id AND user_id = :user_id";
        $stmt = $db->prepare($updateSql);
        $stmt->execute([
            ':notification_id' => $notificationId,
            ':user_id' => $userId
        ]);
        $success = 'Notification marked as read';
    } catch(PDOException $e) {
        // Silent fail
    }
}

// Mark all as read
if (isset($_POST['mark_all_read'])) {
    try {
        $updateSql = "UPDATE notifications SET is_read = 'Yes' WHERE user_id = :user_id AND is_read = 'No'";
        $stmt = $db->prepare($updateSql);
        $stmt->execute([':user_id' => $userId]);
        $success = 'All notifications marked as read';
    } catch(PDOException $e) {
        // Silent fail
    }
}

// Delete notification
if (isset($_GET['delete'])) {
    $notificationId = intval($_GET['delete']);
    try {
        $deleteSql = "DELETE FROM notifications WHERE notification_id = :notification_id AND user_id = :user_id";
        $stmt = $db->prepare($deleteSql);
        $stmt->execute([
            ':notification_id' => $notificationId,
            ':user_id' => $userId
        ]);
        $success = 'Notification deleted';
    } catch(PDOException $e) {
        // Silent fail
    }
}

// Get notifications
try {
    $notificationsSql = "SELECT * FROM notifications WHERE user_id = :user_id ORDER BY created_at DESC";
    $stmt = $db->prepare($notificationsSql);
    $stmt->execute([':user_id' => $userId]);
    $notifications = $stmt->fetchAll();
    
    $unreadCount = 0;
    foreach ($notifications as $notif) {
        if ($notif['is_read'] === 'No') {
            $unreadCount++;
        }
    }
} catch(PDOException $e) {
    $notifications = [];
    $unreadCount = 0;
}

$pageTitle = 'Notifications';
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include 'includes/user_sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <i class="bi bi-bell text-info me-2"></i>Notifications
                    <?php if ($unreadCount > 0): ?>
                        <span class="badge bg-danger"><?php echo $unreadCount; ?></span>
                    <?php endif; ?>
                </h1>
                <?php if ($unreadCount > 0): ?>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">
                        <button type="submit" name="mark_all_read" class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-check-all me-1"></i>Mark All as Read
                        </button>
                    </form>
                <?php endif; ?>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="bi bi-check-circle-fill me-2"></i><?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-12">
                    <?php if (count($notifications) > 0): ?>
                        <div class="list-group">
                            <?php foreach ($notifications as $notification): ?>
                                <div class="list-group-item list-group-item-action <?php echo $notification['is_read'] === 'No' ? 'list-group-item-light' : ''; ?>">
                                    <div class="d-flex w-100 justify-content-between align-items-start">
                                        <div class="flex-grow-1">
                                            <div class="d-flex align-items-center mb-2">
                                                <?php if ($notification['is_read'] === 'No'): ?>
                                                    <span class="badge bg-primary me-2">New</span>
                                                <?php endif; ?>
                                                
                                                <?php
                                                $iconClass = '';
                                                $badgeClass = '';
                                                switch ($notification['type']) {
                                                    case 'success':
                                                        $iconClass = 'bi-check-circle-fill text-success';
                                                        $badgeClass = 'bg-success';
                                                        break;
                                                    case 'warning':
                                                        $iconClass = 'bi-exclamation-triangle-fill text-warning';
                                                        $badgeClass = 'bg-warning text-dark';
                                                        break;
                                                    case 'error':
                                                        $iconClass = 'bi-x-circle-fill text-danger';
                                                        $badgeClass = 'bg-danger';
                                                        break;
                                                    default:
                                                        $iconClass = 'bi-info-circle-fill text-info';
                                                        $badgeClass = 'bg-info';
                                                }
                                                ?>
                                                
                                                <i class="bi <?php echo $iconClass; ?> me-2" style="font-size: 1.5rem;"></i>
                                                <h5 class="mb-0"><?php echo htmlspecialchars($notification['title']); ?></h5>
                                            </div>
                                            
                                            <p class="mb-2"><?php echo htmlspecialchars($notification['message']); ?></p>
                                            
                                            <small class="text-muted">
                                                <i class="bi bi-clock me-1"></i><?php echo formatDateTime($notification['created_at']); ?>
                                            </small>
                                        </div>
                                        
                                        <div class="d-flex flex-column gap-1 ms-3">
                                            <?php if ($notification['is_read'] === 'No'): ?>
                                                <a href="?mark_read=<?php echo $notification['notification_id']; ?>" 
                                                   class="btn btn-sm btn-outline-primary" 
                                                   title="Mark as read">
                                                    <i class="bi bi-check"></i>
                                                </a>
                                            <?php endif; ?>
                                            <a href="?delete=<?php echo $notification['notification_id']; ?>" 
                                               class="btn btn-sm btn-outline-danger" 
                                               title="Delete"
                                               onclick="return confirm('Are you sure you want to delete this notification?')">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="card border-0 shadow-sm">
                            <div class="card-body text-center py-5">
                                <i class="bi bi-bell-slash" style="font-size: 5rem; color: #dee2e6;"></i>
                                <h4 class="mt-3 text-muted">No Notifications</h4>
                                <p class="text-muted">You're all caught up! No notifications to display.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
