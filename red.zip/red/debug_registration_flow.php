<?php
/**
 * DEBUG REGISTRATION FLOW
 * Comprehensive check from registration to admin view
 */

require_once 'config/config.php';
require_once 'config/db.php';

echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>Debug Registration Flow</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css'>
    <style>
        body { padding: 30px; background: #f8f9fa; font-family: Arial, sans-serif; }
        .section { background: white; padding: 20px; margin: 20px 0; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { background: #d4edda; border-left: 4px solid #28a745; }
        .error { background: #f8d7da; border-left: 4px solid #dc3545; }
        .warning { background: #fff3cd; border-left: 4px solid #ffc107; }
        .info { background: #d1ecf1; border-left: 4px solid #17a2b8; }
        h3 { color: #333; margin-bottom: 15px; }
        code { background: #f4f4f4; padding: 2px 6px; border-radius: 3px; color: #e83e8c; }
        .badge { font-size: 0.85rem; }
        table { font-size: 0.9rem; }
    </style>
</head>
<body>
<div class='container-fluid'>
    <h1 class='mb-4'><i class='bi bi-bug'></i> Debug Registration Flow</h1>
    <p class='lead'>Complete diagnostic from user registration → document upload → admin view</p>
    <hr>";

try {
    // STEP 1: Check Database Structure
    echo "<div class='section info'>
            <h3><i class='bi bi-1-circle'></i> Database Structure Check</h3>";
    
    // Check tables
    $tables = ['users', 'user_documents'];
    foreach ($tables as $table) {
        $check = $db->query("SHOW TABLES LIKE '$table'")->fetch();
        if ($check) {
            echo "<span class='badge bg-success'>✅ $table</span> ";
            
            // Count records
            $count = $db->query("SELECT COUNT(*) as cnt FROM $table")->fetch()['cnt'];
            echo "<small>($count records)</small><br>";
        } else {
            echo "<span class='badge bg-danger'>❌ $table NOT FOUND</span><br>";
        }
    }
    
    echo "</div>";
    
    // STEP 2: Check Recent Registrations
    echo "<div class='section info'>
            <h3><i class='bi bi-2-circle'></i> Recent User Registrations</h3>";
    
    $recentUsers = $db->query("SELECT user_id, username, full_name, email, status, 
                                      DATE_FORMAT(created_at, '%Y-%m-%d %H:%i') as registered
                               FROM users 
                               ORDER BY created_at DESC 
                               LIMIT 5")->fetchAll();
    
    if (empty($recentUsers)) {
        echo "<div class='warning'>⚠️ No users found in database!</div>";
    } else {
        echo "<table class='table table-striped'>
                <tr><th>ID</th><th>Username</th><th>Full Name</th><th>Status</th><th>Registered</th><th>Has Documents?</th></tr>";
        
        foreach ($recentUsers as $user) {
            // Check documents
            $docCount = $db->query("SELECT COUNT(*) as cnt FROM user_documents WHERE user_id = {$user['user_id']}")->fetch()['cnt'];
            $docBadge = $docCount > 0 ? 
                "<span class='badge bg-success'>✅ $docCount docs</span>" : 
                "<span class='badge bg-danger'>❌ No docs</span>";
            
            $statusColor = $user['status'] === 'pending' ? 'warning' : ($user['status'] === 'active' ? 'success' : 'secondary');
            
            echo "<tr>
                    <td>{$user['user_id']}</td>
                    <td><code>{$user['username']}</code></td>
                    <td>{$user['full_name']}</td>
                    <td><span class='badge bg-$statusColor'>{$user['status']}</span></td>
                    <td><small>{$user['registered']}</small></td>
                    <td>$docBadge</td>
                  </tr>";
        }
        echo "</table>";
    }
    
    echo "</div>";
    
    // STEP 3: Check Document Uploads
    echo "<div class='section info'>
            <h3><i class='bi bi-3-circle'></i> Document Upload Records</h3>";
    
    $documents = $db->query("SELECT d.*, u.username, u.full_name 
                            FROM user_documents d 
                            JOIN users u ON d.user_id = u.user_id 
                            ORDER BY d.created_at DESC 
                            LIMIT 10")->fetchAll();
    
    if (empty($documents)) {
        echo "<div class='error'>❌ <strong>NO DOCUMENTS FOUND IN DATABASE!</strong></div>";
        echo "<div class='warning'>
                <p><strong>This means:</strong></p>
                <ul>
                    <li>Documents are not being saved to the database during registration</li>
                    <li>The registration process may have an error</li>
                    <li>File upload code may not be executing</li>
                </ul>
              </div>";
    } else {
        echo "<div class='success'>✅ Found " . count($documents) . " document(s)</div>";
        
        echo "<table class='table table-sm'>
                <tr>
                    <th>Doc ID</th>
                    <th>User</th>
                    <th>Type</th>
                    <th>File Path</th>
                    <th>File Exists?</th>
                    <th>Size</th>
                </tr>";
        
        foreach ($documents as $doc) {
            $fileExists = file_exists($doc['file_path']);
            $existsBadge = $fileExists ? 
                "<span class='badge bg-success'>✅</span>" : 
                "<span class='badge bg-danger'>❌</span>";
            
            echo "<tr>
                    <td>{$doc['document_id']}</td>
                    <td><small>{$doc['full_name']}<br>@{$doc['username']}</small></td>
                    <td><small>{$doc['document_type']}</small></td>
                    <td><small><code>{$doc['file_path']}</code></small></td>
                    <td>$existsBadge</td>
                    <td><small>" . round($doc['file_size']/1024, 2) . " KB</small></td>
                  </tr>";
        }
        echo "</table>";
    }
    
    echo "</div>";
    
    // STEP 4: Check Upload Directories
    echo "<div class='section info'>
            <h3><i class='bi bi-4-circle'></i> Upload Directories Status</h3>";
    
    $uploadDirs = [
        'uploads/medical_certificates' => 'Medical Certificates',
        'uploads/profile_photos' => 'Photo IDs / Valid IDs',
        'uploads/documents' => 'Old/Legacy Documents'
    ];
    
    foreach ($uploadDirs as $dir => $label) {
        $exists = is_dir($dir);
        $writable = $exists ? is_writable($dir) : false;
        
        echo "<div class='mb-2'>";
        echo "<strong>$label</strong> <code>$dir</code><br>";
        
        if ($exists) {
            echo "<span class='badge bg-success'>✅ Exists</span> ";
            echo $writable ? 
                "<span class='badge bg-success'>✅ Writable</span> " : 
                "<span class='badge bg-danger'>❌ Not Writable</span> ";
            
            $files = glob($dir . '/*.*');
            echo "<span class='badge bg-info'>" . count($files) . " files</span>";
            
            // Show first 3 files
            if (!empty($files)) {
                echo "<br><small>";
                foreach (array_slice($files, 0, 3) as $file) {
                    echo "&nbsp;&nbsp;&nbsp;📄 " . basename($file) . "<br>";
                }
                if (count($files) > 3) {
                    echo "&nbsp;&nbsp;&nbsp;... and " . (count($files) - 3) . " more";
                }
                echo "</small>";
            }
        } else {
            echo "<span class='badge bg-danger'>❌ NOT FOUND</span>";
        }
        
        echo "</div>";
    }
    
    echo "</div>";
    
    // STEP 5: Check register.php code
    echo "<div class='section info'>
            <h3><i class='bi bi-5-circle'></i> Registration Code Check</h3>";
    
    $registerFile = 'register.php';
    if (file_exists($registerFile)) {
        $registerCode = file_get_contents($registerFile);
        
        $checks = [
            'Has file upload code' => strpos($registerCode, '$_FILES') !== false,
            'Saves to user_documents table' => strpos($registerCode, 'user_documents') !== false,
            'Handles medical certificate' => strpos($registerCode, 'medical_certificate') !== false,
            'Handles photo ID' => strpos($registerCode, 'photo_id') !== false || strpos($registerCode, 'valid_id') !== false,
            'Uses move_uploaded_file' => strpos($registerCode, 'move_uploaded_file') !== false,
            'Has upload directory' => strpos($registerCode, 'uploads/') !== false
        ];
        
        foreach ($checks as $check => $result) {
            $badge = $result ? 
                "<span class='badge bg-success'>✅</span>" : 
                "<span class='badge bg-danger'>❌</span>";
            echo "$badge $check<br>";
        }
        
    } else {
        echo "<div class='error'>❌ register.php not found!</div>";
    }
    
    echo "</div>";
    
    // STEP 6: Test Query (what admin sees)
    echo "<div class='section info'>
            <h3><i class='bi bi-6-circle'></i> Admin View Query Test</h3>";
    
    $adminQuery = "SELECT u.*, 
                          (SELECT COUNT(*) FROM user_documents WHERE user_id = u.user_id) as doc_count
                   FROM users u 
                   WHERE u.status = 'pending' 
                   ORDER BY u.created_at DESC 
                   LIMIT 5";
    
    $adminUsers = $db->query($adminQuery)->fetchAll();
    
    if (empty($adminUsers)) {
        echo "<div class='warning'>⚠️ No pending users (this is what admin sees)</div>";
    } else {
        echo "<div class='success'>✅ Admin would see " . count($adminUsers) . " pending user(s)</div>";
        
        echo "<table class='table table-striped'>
                <tr><th>User</th><th>Status</th><th>Doc Count</th><th>Documents</th></tr>";
        
        foreach ($adminUsers as $user) {
            // Get actual documents
            $docs = $db->query("SELECT * FROM user_documents WHERE user_id = {$user['user_id']}")->fetchAll();
            
            $docList = empty($docs) ? 
                "<span class='badge bg-danger'>❌ No documents uploaded</span>" : 
                "<span class='badge bg-success'>✅ {$user['doc_count']} document(s)</span>";
            
            echo "<tr>
                    <td><strong>{$user['full_name']}</strong><br><small>@{$user['username']}</small></td>
                    <td><span class='badge bg-warning'>{$user['status']}</span></td>
                    <td>{$user['doc_count']}</td>
                    <td>$docList</td>
                  </tr>";
            
            // Show document details
            if (!empty($docs)) {
                foreach ($docs as $doc) {
                    $exists = file_exists($doc['file_path']) ? '✅' : '❌';
                    echo "<tr>
                            <td colspan='4' class='ps-5'>
                                <small>
                                    $exists {$doc['document_type']}: 
                                    <code>{$doc['file_path']}</code>
                                </small>
                            </td>
                          </tr>";
                }
            }
        }
        echo "</table>";
    }
    
    echo "</div>";
    
    // DIAGNOSIS SUMMARY
    echo "<div class='section warning'>
            <h3><i class='bi bi-clipboard-check'></i> Diagnosis Summary</h3>";
    
    $totalUsers = $db->query("SELECT COUNT(*) as cnt FROM users")->fetch()['cnt'];
    $totalDocs = $db->query("SELECT COUNT(*) as cnt FROM user_documents")->fetch()['cnt'];
    $pendingUsers = $db->query("SELECT COUNT(*) as cnt FROM users WHERE status = 'pending'")->fetch()['cnt'];
    
    echo "<ul class='mb-0'>";
    echo "<li><strong>Total Users:</strong> $totalUsers</li>";
    echo "<li><strong>Total Documents:</strong> $totalDocs</li>";
    echo "<li><strong>Pending Approvals:</strong> $pendingUsers</li>";
    
    if ($totalUsers > 0 && $totalDocs === 0) {
        echo "<li class='text-danger'><strong>⚠️ PROBLEM FOUND:</strong> Users exist but NO documents in database!</li>";
        echo "<li class='text-danger'>→ The file upload code in register.php is not saving to database</li>";
    }
    
    echo "</ul>";
    
    echo "</div>";
    
    // ACTION BUTTONS
    echo "<div class='text-center mt-4'>
            <a href='register.php' class='btn btn-primary btn-lg'><i class='bi bi-person-plus'></i> Test Registration</a>
            <a href='admin/user_approvals.php' class='btn btn-success btn-lg'><i class='bi bi-shield-check'></i> Admin Approvals</a>
            <a href='javascript:location.reload()' class='btn btn-secondary btn-lg'><i class='bi bi-arrow-clockwise'></i> Refresh</a>
          </div>";
    
} catch(Exception $e) {
    echo "<div class='section error'>
            <h3>❌ Error</h3>
            <p>" . $e->getMessage() . "</p>
          </div>";
}

echo "</div>
</body>
</html>";
?>
