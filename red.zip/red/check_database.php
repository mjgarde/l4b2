<?php
/**
 * Database Connection Checker
 * Use this to diagnose database issues
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>🔍 Database Connection Checker</h2>";
echo "<hr>";

// Step 1: Check if config files exist
echo "<h3>Step 1: Config Files</h3>";
if (file_exists('config/config.php')) {
    echo "✅ config.php exists<br>";
    require_once 'config/config.php';
} else {
    echo "❌ config.php NOT FOUND<br>";
    die();
}

if (file_exists('config/db.php')) {
    echo "✅ db.php exists<br>";
} else {
    echo "❌ db.php NOT FOUND<br>";
    die();
}

// Step 2: Check database connection
echo "<h3>Step 2: Database Connection</h3>";
echo "Host: " . DB_HOST . "<br>";
echo "Database: " . DB_NAME . "<br>";
echo "User: " . DB_USER . "<br>";
echo "Password: " . (empty(DB_PASS) ? "(empty)" : "***") . "<br><br>";

try {
    $dsn = "mysql:host=" . DB_HOST . ";charset=" . DB_CHARSET;
    $pdo = new PDO($dsn, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "✅ Connected to MySQL server<br>";
    
    // Step 3: Check if database exists
    echo "<h3>Step 3: Database Exists?</h3>";
    $stmt = $pdo->query("SHOW DATABASES LIKE '" . DB_NAME . "'");
    $dbExists = $stmt->rowCount() > 0;
    
    if ($dbExists) {
        echo "✅ Database <strong>" . DB_NAME . "</strong> exists<br>";
        
        // Step 4: Check tables
        echo "<h3>Step 4: Database Tables</h3>";
        $pdo->exec("USE " . DB_NAME);
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        if (count($tables) > 0) {
            echo "✅ Found " . count($tables) . " tables:<br>";
            echo "<ul>";
            foreach ($tables as $table) {
                echo "<li>$table</li>";
            }
            echo "</ul>";
            
            // Step 5: Check users table
            echo "<h3>Step 5: Users Data</h3>";
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
            $userCount = $stmt->fetch()['count'];
            echo "Total users: <strong>$userCount</strong><br><br>";
            
            if ($userCount > 0) {
                $stmt = $pdo->query("SELECT username, email, user_role, status FROM users");
                $users = $stmt->fetchAll();
                echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
                echo "<tr><th>Username</th><th>Email</th><th>Role</th><th>Status</th></tr>";
                foreach ($users as $user) {
                    echo "<tr>";
                    echo "<td>" . $user['username'] . "</td>";
                    echo "<td>" . $user['email'] . "</td>";
                    echo "<td>" . $user['user_role'] . "</td>";
                    echo "<td>" . $user['status'] . "</td>";
                    echo "</tr>";
                }
                echo "</table><br>";
                
                // Step 6: Test password verification
                echo "<h3>Step 6: Password Verification Test</h3>";
                $stmt = $pdo->query("SELECT password_hash FROM users WHERE username = 'admin'");
                $admin = $stmt->fetch();
                if ($admin && password_verify('admin123', $admin['password_hash'])) {
                    echo "✅ Admin password hash is correct<br>";
                } else {
                    echo "❌ Admin password hash is WRONG<br>";
                    echo "👉 Run database/update_passwords.sql to fix this<br>";
                }
                
                echo "<h3>✅ Everything looks good!</h3>";
                echo "<p><strong>Try logging in with:</strong></p>";
                echo "<ul>";
                echo "<li>Username: <strong>admin</strong></li>";
                echo "<li>Password: <strong>admin123</strong></li>";
                echo "</ul>";
                echo "<a href='login.php' style='display:inline-block;padding:10px 20px;background:red;color:white;text-decoration:none;border-radius:5px;margin-right:10px;'>Go to Login Page</a>";
                echo "<a href='index.php' style='display:inline-block;padding:10px 20px;background:#333;color:white;text-decoration:none;border-radius:5px;'>Go to Home Page</a>";
            } else {
                echo "❌ No users found in database<br>";
                echo "👉 You need to import the SQL file!<br>";
            }
            
        } else {
            echo "❌ No tables found in database<br>";
            echo "👉 You need to import the SQL file!<br>";
        }
        
    } else {
        echo "❌ Database <strong>" . DB_NAME . "</strong> does NOT exist<br>";
        echo "<h3>🔧 How to Fix:</h3>";
        echo "<ol>";
        echo "<li>Open phpMyAdmin: <a href='http://localhost/phpmyadmin' target='_blank'>http://localhost/phpmyadmin</a></li>";
        echo "<li>Click 'Import' tab</li>";
        echo "<li>Choose file: <code>database/koronadal_redcross.sql</code></li>";
        echo "<li>Click 'Go' button</li>";
        echo "<li>Refresh this page</li>";
        echo "</ol>";
    }
    
} catch(PDOException $e) {
    echo "❌ Database Connection Failed<br>";
    echo "<strong>Error:</strong> " . $e->getMessage() . "<br><br>";
    
    echo "<h3>🔧 Troubleshooting:</h3>";
    echo "<ol>";
    echo "<li>Is XAMPP MySQL running? Check XAMPP Control Panel</li>";
    echo "<li>Is the MySQL port correct? (default: 3306)</li>";
    echo "<li>Check database credentials in config/config.php</li>";
    echo "</ol>";
}

echo "<hr>";
echo "<small>Diagnostic tool for Koronadal Red Cross System</small>";
?>
