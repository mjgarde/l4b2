<?php
require_once 'config/config.php';
require_once 'config/db.php';

if (isLoggedIn()) {
    $db->prepare("DELETE FROM user_sessions WHERE user_id = ?")
       ->execute([$_SESSION['user_id']]);

    logAudit($db, $_SESSION['user_id'], 'User Logout', 'users', $_SESSION['user_id'], 'User logged out');
}

session_unset();
session_destroy();

$_SESSION = [];
session_start();
$_SESSION['success'] = 'You have been logged out successfully.';
redirect('login.php');
?>