<?php
/**
 * Test Approve/Decline Buttons
 */

require_once 'config/config.php';
require_once 'config/db.php';

// Check admin authentication
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    die('Please login as admin first: <a href="login.php">Login</a>');
}

$message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $userId = intval($_POST['user_id']);
    $action = $_POST['action'];
    
    if ($action === 'approve') {
        $sql = "UPDATE users SET status = 'active' WHERE user_id = :user_id";
        $stmt = $db->prepare($sql);
        $stmt->execute([':user_id' => $userId]);
        $message = "✅ User approved!";
    } elseif ($action === 'reject') {
        $reason = $_POST['reason'] ?? 'No reason provided';
        $sql = "UPDATE users SET status = 'inactive' WHERE user_id = :user_id";
        $stmt = $db->prepare($sql);
        $stmt->execute([':user_id' => $userId]);
        $message = "❌ User rejected! Reason: $reason";
    }
}

// Get pending users
$sql = "SELECT * FROM users WHERE status = 'pending' LIMIT 1";
$stmt = $db->prepare($sql);
$stmt->execute();
$user = $stmt->fetch();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Test Approve/Decline Buttons</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body class="p-4">
<div class="container">
    <h2>🧪 Test Approve/Decline Buttons</h2>
    
    <?php if ($message): ?>
        <div class="alert alert-info"><?= $message ?></div>
    <?php endif; ?>
    
    <?php if ($user): ?>
        <div class="card mb-4">
            <div class="card-header bg-warning">
                <h4><?= htmlspecialchars($user['full_name']) ?></h4>
                <small>@<?= htmlspecialchars($user['username']) ?> - <?= $user['email'] ?></small>
            </div>
            <div class="card-body">
                <p><strong>Status:</strong> <span class="badge bg-warning"><?= $user['status'] ?></span></p>
                
                <hr>
                
                <!-- Test APPROVE Button -->
                <h5>Test 1: APPROVE Button</h5>
                <form method="POST" class="mb-3" onsubmit="return confirm('Approve this user?')">
                    <input type="hidden" name="user_id" value="<?= $user['user_id'] ?>">
                    <input type="hidden" name="action" value="approve">
                    <button type="submit" class="btn btn-success btn-lg">
                        <i class="bi bi-check-circle"></i> APPROVE
                    </button>
                </form>
                
                <hr>
                
                <!-- Test DECLINE Button with Modal -->
                <h5>Test 2: DECLINE Button (with Modal)</h5>
                <button type="button" class="btn btn-danger btn-lg" data-bs-toggle="modal" data-bs-target="#testModal">
                    <i class="bi bi-x-circle"></i> DECLINE (OPEN MODAL)
                </button>
                
                <!-- Modal -->
                <div class="modal fade" id="testModal" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Reject User</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <form method="POST">
                                <div class="modal-body">
                                    <input type="hidden" name="user_id" value="<?= $user['user_id'] ?>">
                                    <input type="hidden" name="action" value="reject">
                                    
                                    <p>Reject: <strong><?= htmlspecialchars($user['full_name']) ?></strong></p>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Reason:</label>
                                        <textarea name="reason" class="form-control" rows="3"></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                        CANCEL
                                    </button>
                                    <button type="submit" class="btn btn-danger">
                                        CONFIRM REJECTION
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <hr>
                
                <!-- Direct Form Test -->
                <h5>Test 3: Direct DECLINE (No Modal)</h5>
                <form method="POST" onsubmit="return confirm('Reject this user?')">
                    <input type="hidden" name="user_id" value="<?= $user['user_id'] ?>">
                    <input type="hidden" name="action" value="reject">
                    <input type="hidden" name="reason" value="Test rejection">
                    <button type="submit" class="btn btn-danger btn-lg">
                        <i class="bi bi-x-circle"></i> DECLINE (DIRECT)
                    </button>
                </form>
            </div>
        </div>
        
        <div class="alert alert-info">
            <strong>Instructions:</strong>
            <ol>
                <li>Click "APPROVE" - Should approve immediately</li>
                <li>Click "DECLINE (OPEN MODAL)" - Should open modal with Cancel/Confirm buttons</li>
                <li>Click "DECLINE (DIRECT)" - Should reject immediately</li>
            </ol>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">
            <i class="bi bi-exclamation-triangle"></i> No pending users found!
            <br><br>
            <a href="register.php" class="btn btn-primary">Register a new user</a>
        </div>
    <?php endif; ?>
    
    <hr>
    <a href="admin/user_approvals.php" class="btn btn-secondary">← Back to User Approvals</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
console.log('✅ Page loaded');

// Test modal
document.getElementById('testModal')?.addEventListener('show.bs.modal', function() {
    console.log('✅ Modal opening...');
});

document.getElementById('testModal')?.addEventListener('shown.bs.modal', function() {
    console.log('✅ Modal opened successfully!');
});

// Test buttons
document.querySelectorAll('button, .btn').forEach(btn => {
    btn.addEventListener('click', function() {
        console.log('✅ Button clicked:', this.textContent.trim());
    });
});
</script>
</body>
</html>
