<?php
require_once 'config/config.php';
require_once 'config/db.php';

if (isLoggedIn()) {
    if (isAdmin()) {
        redirect('admin/dashboard.php');
    } else {
        redirect('dashboard.php');
    }
}

$error   = '';
$success = '';

$MAX_ATTEMPTS = 5;
$BAN_SECONDS  = 20;
$type         = 'redcross';

function is_safe_input($val) {
    $blocked = ["'", '"', ';', '--', '#', '/*', '*/', 'SELECT', 'INSERT', 'UPDATE',
                'DELETE', 'DROP', 'UNION', 'OR ', 'AND ', '<script', '</script',
                '<', '>', '\\', '/', '=', '%', '&', '|', '`', 'EXEC', 'CAST',
                'CHAR(', 'alert(', 'onerror', 'onload'];
    $upper = strtoupper($val);
    foreach ($blocked as $b) {
        if (str_contains($upper, strtoupper($b))) return false;
    }
    return true;
}

$ip          = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$ua          = $_SERVER['HTTP_USER_AGENT']      ?? '';
$lang        = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '';
$encoding    = $_SERVER['HTTP_ACCEPT_ENCODING'] ?? '';
$device_hash = hash('sha256', $ua . $lang . $encoding);

$stmt = $db->prepare("SELECT attempts, ban_until FROM login_attempts WHERE ip_address = ? AND device_hash = ? AND type = ?");
$stmt->execute([$ip, $device_hash, $type]);
$row = $stmt->fetch();

$attempts  = $row ? (int)$row['attempts']  : 0;
$ban_until = $row ? (int)$row['ban_until'] : 0;

$isBanned       = $ban_until > time();
$banSecondsLeft = max(0, $ban_until - time());

if ($row && !$isBanned && $ban_until > 0) {
    $db->prepare("DELETE FROM login_attempts WHERE ip_address = ? AND device_hash = ? AND type = ?")
       ->execute([$ip, $device_hash, $type]);
    $attempts = 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($isBanned) {
        $error = "Too many failed attempts. Please wait {$banSecondsLeft} second(s) before trying again.";

    } elseif (!isset($_POST['csrf_token']) || !validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid request. Please try again.';

    } else {
        $username = sanitize($_POST['username']);
        $password = $_POST['password'];

        if (empty($username) || empty($password)) {
            $error = 'Please enter both username and password';
        } elseif (!is_safe_input($username) || !is_safe_input($password)) {
            $error = 'Invalid characters detected in input.';
        } else {
            try {
                $sql = "SELECT u.*, bt.blood_type 
                        FROM users u 
                        LEFT JOIN blood_types bt ON u.blood_type_id = bt.blood_type_id 
                        WHERE u.username = :username OR u.email = :email";
                $stmt = $db->prepare($sql);
                $stmt->execute([':username' => $username, ':email' => $username]);
                $user = $stmt->fetch();

                if ($user && verifyPassword($password, $user['password_hash'])) {
                    $db->prepare("DELETE FROM login_attempts WHERE ip_address = ? AND device_hash = ? AND type = ?")
                       ->execute([$ip, $device_hash, $type]);
                    $attempts = 0;

                    if ($user['status'] === 'pending') {
                        $error = 'Your account is pending admin approval. Please wait for verification.';
                    } elseif ($user['status'] === 'suspended') {
                        $error = 'Your account has been suspended. Please contact the administrator.';
                    } elseif ($user['status'] === 'inactive') {
                        $error = 'Your account is inactive. Please contact the administrator.';
                    } elseif ($user['status'] !== 'active') {
                        $error = 'Your account is ' . $user['status'] . '. Please contact administrator.';
                    } else {
                        $existing = $db->prepare("SELECT session_id FROM user_sessions WHERE user_id = ?");
                        $existing->execute([$user['user_id']]);
                        $active = $existing->fetch();

                        if ($active) {
                            $error = 'This account is already logged in on another device. Please log out from that device first.';
                        } else {
                            $_SESSION['user_id']       = $user['user_id'];
                            $_SESSION['username']      = $user['username'];
                            $_SESSION['full_name']     = $user['full_name'];
                            $_SESSION['email']         = $user['email'];
                            $_SESSION['user_role']     = $user['user_role'];
                            $_SESSION['blood_type']    = $user['blood_type'];
                            $_SESSION['last_activity'] = time();

                            $db->prepare("INSERT INTO user_sessions (user_id, session_id) VALUES (?, ?) ON DUPLICATE KEY UPDATE session_id = ?")
                               ->execute([$user['user_id'], session_id(), session_id()]);

                            $db->prepare("UPDATE users SET last_login = NOW() WHERE user_id = :user_id")
                               ->execute([':user_id' => $user['user_id']]);

                            logAudit($db, $user['user_id'], 'User Login', 'users', $user['user_id'], 'Successful login');

                            if ($user['user_role'] === 'admin') {
                                redirect('admin/dashboard.php');
                            } else {
                                redirect('dashboard.php');
                            }
                        }
                    }

                } else {
                    $attempts++;

                    if ($attempts >= $MAX_ATTEMPTS) {
                        $ban_until      = time() + $BAN_SECONDS;
                        $isBanned       = true;
                        $banSecondsLeft = $BAN_SECONDS;
                        $error          = "Too many failed attempts. Please wait {$BAN_SECONDS} second(s) before trying again.";

                        $db->prepare("
                            INSERT INTO login_attempts (ip_address, device_hash, type, attempts, ban_until)
                            VALUES (?, ?, ?, ?, ?)
                            ON DUPLICATE KEY UPDATE attempts = ?, ban_until = ?
                        ")->execute([$ip, $device_hash, $type, $attempts, $ban_until, $attempts, $ban_until]);
                    } else {
                        $remaining = $MAX_ATTEMPTS - $attempts;
                        $error     = "Invalid username or password. {$remaining} attempt(s) remaining before temporary lockout.";

                        $db->prepare("
                            INSERT INTO login_attempts (ip_address, device_hash, type, attempts, ban_until)
                            VALUES (?, ?, ?, ?, 0)
                            ON DUPLICATE KEY UPDATE attempts = ?
                        ")->execute([$ip, $device_hash, $type, $attempts, $attempts]);
                    }
                }

            } catch(PDOException $e) {
                if (defined('SHOW_ERRORS') && SHOW_ERRORS) {
                    $error = 'Database Error: ' . $e->getMessage();
                } else {
                    $error = 'An error occurred. Please try again.';
                }
                error_log("Login error: " . $e->getMessage());
            }
        }
    }
}

if (isset($_SESSION['success'])) { $success = $_SESSION['success']; unset($_SESSION['success']); }
if (isset($_SESSION['error']))   { $error   = $_SESSION['error'];   unset($_SESSION['error']); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login - <?= SITE_NAME ?></title>
<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:Arial,Helvetica,sans-serif}
body{background:linear-gradient(135deg,#2D3748,#1A202C);min-height:100vh}
.container{width:100%;padding:15px;margin:auto}
.row{display:flex;flex-wrap:wrap}
.justify-content-center{justify-content:center}
.align-items-center{align-items:center}
.min-vh-100{min-height:100vh}
.col-12{width:100%}
.col-sm-10{width:83%}
.col-md-8{width:66%}
.col-lg-6{width:50%}
.col-xl-5{width:42%}
.card{background:white;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,0.2)}
.card-body{padding:30px}
.text-center{text-align:center}
.text-muted{color:#6c757d}
.text-danger{color:#dc3545}
.mb-4{margin-bottom:20px}
.mb-3{margin-bottom:15px}
.mt-3{margin-top:10px}
.mt-4{margin-top:20px}
.small{font-size:12px}
.btn{display:inline-block;padding:10px 15px;border-radius:5px;border:none;cursor:pointer;text-decoration:none;font-size:14px}
.btn-danger{background:#dc3545;color:white}
.btn-danger:hover{background:#c82333}
.btn-danger:disabled{background:#e57380;cursor:not-allowed}
.btn-outline-secondary{border:1px solid #6c757d;background:transparent;color:#6c757d}
.btn-outline-secondary:hover{background:#f1f1f1}
.btn-sm{font-size:12px;padding:6px 12px}
.w-100{width:100%}
.form-label{display:block;margin-bottom:5px;font-weight:bold}
.form-control{width:100%;padding:10px;border:1px solid #ccc;border-radius:5px;font-size:14px}
.form-control:focus{outline:none;border-color:#dc3545}
.form-control:disabled{background:#f5f5f5;cursor:not-allowed}
.input-group{display:flex}
.input-group-text{padding:10px;background:#f8f9fa;border:1px solid #ccc;border-right:none;border-radius:5px 0 0 5px}
.input-group .form-control{border-left:none;border-radius:0}
.input-group button{border-left:none;border-radius:0 5px 5px 0}
.form-check{display:flex;align-items:center;gap:5px}
.d-flex{display:flex}
.justify-content-between{justify-content:space-between}
.alert{padding:15px;border-radius:10px;margin-bottom:15px}
.alert-danger{background:#f8d7da;color:#842029}
.alert-success{background:#d1e7dd;color:#0f5132}
.alert-warning{background:#fff3cd;color:#664d03}
.alert-banned{background:#1a202c;color:#fc8181;border:1px solid #fc8181;border-radius:10px;padding:15px;margin-bottom:15px;text-align:center}
.countdown-num{font-size:2rem;font-weight:bold;color:#fc8181;display:block;margin:5px 0}
.attempt-bar{height:6px;border-radius:3px;background:#e9ecef;margin-top:8px;overflow:hidden}
.attempt-fill{height:100%;border-radius:3px;background:#dc3545;transition:width 0.3s}
</style>
</head>
<body>

<div class="container">
<div class="row justify-content-center align-items-center min-vh-100">
<div class="col-12 col-sm-10 col-md-8 col-lg-6 col-xl-5">
<div class="card">
<div class="card-body">

<div class="mb-4">
<a href="index.php" class="btn btn-outline-secondary btn-sm">Back to Home</a>
</div>

<div class="text-center mb-4">
<h3 class="mt-3">Welcome Back</h3>
<p class="text-muted">Koronadal Red Cross</p>
</div>

<?php if ($isBanned): ?>
<div class="alert-banned">
    <strong>Device Temporarily Locked</strong>
    <span class="countdown-num" id="countdown"><?= $banSecondsLeft ?></span>
    <small>seconds remaining. Please wait before trying again.</small>
</div>
<?php elseif ($error): ?>
    <?php if (strpos($error, 'pending') !== false): ?>
    <div class="alert alert-warning">
        <strong>Account Pending Approval</strong>
        <p><?= $error ?></p>
        <p class="small">An administrator will review your registration soon.</p>
    </div>
    <?php else: ?>
    <div class="alert alert-danger">
        <?= htmlspecialchars($error) ?>
        <?php if ($attempts > 0 && !$isBanned): ?>
        <div class="attempt-bar">
            <div class="attempt-fill" style="width:<?= ($attempts / $MAX_ATTEMPTS) * 100 ?>%"></div>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
<?php endif; ?>

<?php if ($success): ?>
<div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<form method="POST" action="" id="loginForm">
<input type="hidden" name="csrf_token" value="<?= getCSRFToken() ?>">

<div class="mb-4">
<label class="form-label">Username</label>
<div class="input-group">
<span class="input-group-text">@</span>
<input type="text" class="form-control" id="username" name="username"
    placeholder="Enter your username"
    required <?= $isBanned ? 'disabled' : '' ?>>
</div>
</div>

<div class="mb-4">
<label class="form-label">Password</label>
<div class="input-group">
<span class="input-group-text">*</span>
<input type="password" class="form-control" id="password" name="password"
    placeholder="Enter your password"
    required <?= $isBanned ? 'disabled' : '' ?>>
<button class="btn btn-outline-secondary" type="button" id="togglePassword"
    <?= $isBanned ? 'disabled' : '' ?>>Show</button>
</div>
</div>

<div class="mb-4 d-flex justify-content-between align-items-center">
<div class="form-check">
<input type="checkbox" id="rememberMe">
<label for="rememberMe">Remember me</label>
</div>
</div>

<button type="submit" class="btn btn-danger w-100 mb-3"
    id="submitBtn" <?= $isBanned ? 'disabled' : '' ?>>
    Sign In
</button>

<div class="text-center">
<p>Don't have an account? <a href="register.php" class="text-danger">Register</a></p>
</div>
</form>

</div>
</div>
</div>
</div>
</div>

<script>
document.getElementById('togglePassword').addEventListener('click', function() {
    const password = document.getElementById('password');
    if (password.type === 'password') {
        password.type = 'text';
        this.textContent = 'Hide';
    } else {
        password.type = 'password';
        this.textContent = 'Show';
    }
});

const blocked = ["'", '"', ';', '--', '<', '>', '\\', '=', '`', '|', '&', '%', '#', '/'];
document.querySelectorAll('input[type=text], input[type=password]').forEach(input => {
    input.addEventListener('input', function () {
        blocked.forEach(c => { this.value = this.value.split(c).join(''); });
    });
    input.addEventListener('paste', function (e) {
        e.preventDefault();
        let text = (e.clipboardData || window.clipboardData).getData('text');
        blocked.forEach(c => { text = text.split(c).join(''); });
        this.value += text;
    });
});

<?php if ($isBanned): ?>
(function() {
    let seconds       = <?= $banSecondsLeft ?>;
    const countdownEl = document.getElementById('countdown');
    const timer = setInterval(function() {
        seconds--;
        if (countdownEl) countdownEl.textContent = seconds;
        if (seconds <= 0) { clearInterval(timer); location.reload(); }
    }, 1000);
})();
<?php endif; ?>
</script>

</body>
</html>