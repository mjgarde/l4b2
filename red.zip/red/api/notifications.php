<?php
/**
 * Notifications API
 * AJAX endpoint for real-time notification management
 */

require_once '../config/config.php';
require_once '../config/db.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$userId = $_SESSION['user_id'];
$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'get_count':
            // Get unread notification count
            $count = getUnreadNotificationCount($db, $userId);
            echo json_encode([
                'success' => true,
                'count' => $count
            ]);
            break;
            
        case 'get_recent':
            // Get recent notifications
            $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 5;
            $notifications = getUserNotifications($db, $userId, $limit, 0, false);
            
            $formattedNotifications = [];
            foreach ($notifications as $notif) {
                $formattedNotifications[] = [
                    'id' => $notif['notification_id'],
                    'title' => $notif['title'],
                    'message' => $notif['message'],
                    'type' => $notif['type'],
                    'is_read' => $notif['is_read'],
                    'created_at' => formatDateTime($notif['created_at']),
                    'created_at_raw' => $notif['created_at']
                ];
            }
            
            echo json_encode([
                'success' => true,
                'notifications' => $formattedNotifications
            ]);
            break;
            
        case 'mark_read':
            // Mark notification as read
            if (!isset($_POST['notification_id'])) {
                echo json_encode(['success' => false, 'message' => 'Missing notification ID']);
                exit;
            }
            
            $notificationId = intval($_POST['notification_id']);
            $result = markNotificationAsRead($db, $notificationId, $userId);
            
            echo json_encode([
                'success' => $result,
                'message' => $result ? 'Notification marked as read' : 'Failed to mark as read'
            ]);
            break;
            
        case 'mark_all_read':
            // Mark all notifications as read
            $result = markAllNotificationsAsRead($db, $userId);
            
            echo json_encode([
                'success' => $result,
                'message' => $result ? 'All notifications marked as read' : 'Failed to mark all as read'
            ]);
            break;
            
        case 'delete':
            // Delete notification
            if (!isset($_POST['notification_id'])) {
                echo json_encode(['success' => false, 'message' => 'Missing notification ID']);
                exit;
            }
            
            $notificationId = intval($_POST['notification_id']);
            $result = deleteNotification($db, $notificationId, $userId);
            
            echo json_encode([
                'success' => $result,
                'message' => $result ? 'Notification deleted' : 'Failed to delete notification'
            ]);
            break;
            
        case 'get_stats':
            // Get notification statistics
            $stats = getNotificationStats($db, $userId);
            
            echo json_encode([
                'success' => true,
                'stats' => $stats
            ]);
            break;
            
        default:
            echo json_encode([
                'success' => false,
                'message' => 'Invalid action'
            ]);
            break;
    }
    
} catch(Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?>
