<?php
/**
 * API: Submit Donation via AJAX
 * Returns JSON response
 */

header('Content-Type: application/json');

require_once '../config/config.php';
require_once '../config/db.php';

// Check if user is logged in
if (!isLoggedIn()) {
    jsonResponse(false, 'Unauthorized access');
}

// Check if POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Invalid request method');
}

// Validate CSRF token
if (!isset($_POST['csrf_token']) || !validateCSRF($_POST['csrf_token'])) {
    jsonResponse(false, 'Invalid CSRF token');
}

$userId = $_SESSION['user_id'];
$donationDate = sanitize($_POST['donation_date']);
$quantityMl = intval($_POST['quantity_ml']);
$location = sanitize($_POST['donation_location']);
$notes = sanitize($_POST['notes']);
$bloodTypeId = intval($_POST['blood_type_id']);

// Basic validation
if (empty($donationDate) || $quantityMl < 350 || empty($location)) {
    jsonResponse(false, 'Please fill in all required fields');
}

try {
    // Get user's donor info
    $donorSql = "SELECT * FROM donors_info WHERE user_id = :user_id";
    $stmt = $db->prepare($donorSql);
    $stmt->execute([':user_id' => $userId]);
    $donor = $stmt->fetch();
    
    if ($donor) {
        // Check eligibility
        $age = calculateAge($donor['date_of_birth']);
        $eligibility = isDonorEligible($donor['last_donation_date'], $age, $donor['weight']);
        
        if (!$eligibility['eligible']) {
            jsonResponse(false, 'Not eligible: ' . $eligibility['reason']);
        }
        
        $donorId = $donor['donor_id'];
    } else {
        // Create new donor record if needed
        if (!isset($_POST['date_of_birth']) || !isset($_POST['gender']) || !isset($_POST['weight'])) {
            jsonResponse(false, 'Missing donor information');
        }
        
        $dob = sanitize($_POST['date_of_birth']);
        $gender = sanitize($_POST['gender']);
        $weight = floatval($_POST['weight']);
        
        $age = calculateAge($dob);
        $eligibility = isDonorEligible(null, $age, $weight);
        
        if (!$eligibility['eligible']) {
            jsonResponse(false, 'Not eligible: ' . $eligibility['reason']);
        }
        
        // Insert donor info
        $insertDonorSql = "INSERT INTO donors_info (user_id, blood_type_id, date_of_birth, gender, weight) 
                          VALUES (:user_id, :blood_type_id, :dob, :gender, :weight)";
        $stmt = $db->prepare($insertDonorSql);
        $stmt->execute([
            ':user_id' => $userId,
            ':blood_type_id' => $bloodTypeId,
            ':dob' => $dob,
            ':gender' => $gender,
            ':weight' => $weight
        ]);
        
        $donorId = $db->lastInsertId();
    }
    
    // Insert donation
    $insertSql = "INSERT INTO donations (donor_id, blood_type_id, donation_date, quantity_ml, donation_location, notes, status) 
                 VALUES (:donor_id, :blood_type_id, :donation_date, :quantity_ml, :location, :notes, 'pending')";
    $stmt = $db->prepare($insertSql);
    $result = $stmt->execute([
        ':donor_id' => $donorId,
        ':blood_type_id' => $bloodTypeId,
        ':donation_date' => $donationDate,
        ':quantity_ml' => $quantityMl,
        ':location' => $location,
        ':notes' => $notes
    ]);
    
    if ($result) {
        $donationId = $db->lastInsertId();
        
        // Create notification
        createNotification($db, $userId, 'Donation Submitted', 
            'Your blood donation request has been submitted successfully.', 'success');
        
        // Log audit
        logAudit($db, $userId, 'Donation Submitted via AJAX', 'donations', $donationId, 
            'User submitted donation via AJAX');
        
        jsonResponse(true, 'Donation submitted successfully!', ['donation_id' => $donationId]);
    } else {
        jsonResponse(false, 'Failed to submit donation');
    }
    
} catch(PDOException $e) {
    error_log("Donation submission error: " . $e->getMessage());
    jsonResponse(false, 'Database error occurred');
}
?>
