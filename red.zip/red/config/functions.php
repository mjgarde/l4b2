<?php
/**
 * Common Functions
 * Security, validation, and utility functions
 */

/**
 * Sanitize input data
 */
function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/**
 * Validate CSRF Token
 */
function validateCSRF($token) {
    if (!isset($_SESSION['csrf_token']) || $token !== $_SESSION['csrf_token']) {
        return false;
    }
    return true;
}

/**
 * Generate CSRF Token
 */
function getCSRFToken() {
    return $_SESSION['csrf_token'] ?? '';
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Check if user is admin
 */
function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * Redirect to specific page
 */
function redirect($page) {
    header("Location: " . BASE_URL . $page);
    exit();
}

/**
 * Require login
 */
function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['error'] = 'Please log in to access this page';
        redirect('login.php');
    }
}

/**
 * Require admin access
 */
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        $_SESSION['error'] = 'Access denied. Admin privileges required.';
        redirect('dashboard.php');
    }
}

/**
 * Validate email
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Validate phone number (Philippine format)
 */
function validatePhone($phone) {
    // Remove spaces and dashes
    $phone = preg_replace('/[\s\-]/', '', $phone);
    // Check if it matches Philippine phone format
    return preg_match('/^(09|\+639)\d{9}$/', $phone);
}

/**
 * Hash password securely
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
}

/**
 * Verify password
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Format date for display
 */
function formatDate($date, $format = 'F j, Y') {
    return date($format, strtotime($date));
}

/**
 * Format datetime for display
 */
function formatDateTime($datetime, $format = 'F j, Y g:i A') {
    return date($format, strtotime($datetime));
}

/**
 * Calculate age from date of birth
 */
function calculateAge($dob) {
    $birthDate = new DateTime($dob);
    $today = new DateTime();
    $age = $today->diff($birthDate);
    return $age->y;
}

/**
 * Check if donor is eligible to donate
 */
function isDonorEligible($lastDonationDate, $age, $weight) {
    // Check age
    if ($age < MIN_DONOR_AGE || $age > MAX_DONOR_AGE) {
        return ['eligible' => false, 'reason' => 'Age requirement not met'];
    }
    
    // Check weight
    if ($weight < MIN_DONOR_WEIGHT_KG) {
        return ['eligible' => false, 'reason' => 'Weight requirement not met'];
    }
    
    // Check last donation date
    if (!empty($lastDonationDate)) {
        $lastDate = new DateTime($lastDonationDate);
        $today = new DateTime();
        $daysSince = $today->diff($lastDate)->days;
        
        if ($daysSince < MIN_DONATION_INTERVAL_DAYS) {
            $daysRemaining = MIN_DONATION_INTERVAL_DAYS - $daysSince;
            return ['eligible' => false, 'reason' => "Must wait $daysRemaining more days"];
        }
    }
    
    return ['eligible' => true, 'reason' => 'Eligible to donate'];
}

/**
 * Log audit trail
 */
function logAudit($db, $userId, $action, $tableAffected = null, $recordId = null, $details = null) {
    try {
        $sql = "INSERT INTO audit_logs (user_id, action, table_affected, record_id, details, ip_address) 
                VALUES (:user_id, :action, :table_affected, :record_id, :details, :ip_address)";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':user_id' => $userId,
            ':action' => $action,
            ':table_affected' => $tableAffected,
            ':record_id' => $recordId,
            ':details' => $details,
            ':ip_address' => $_SERVER['REMOTE_ADDR']
        ]);
    } catch(PDOException $e) {
        // Silently fail - don't break the application
        error_log("Audit log error: " . $e->getMessage());
    }
}

/**
 * Create notification
 */
function createNotification($db, $userId, $title, $message, $type = 'info') {
    try {
        $sql = "INSERT INTO notifications (user_id, title, message, type) 
                VALUES (:user_id, :title, :message, :type)";
        
        $stmt = $db->prepare($sql);
        return $stmt->execute([
            ':user_id' => $userId,
            ':title' => $title,
            ':message' => $message,
            ':type' => $type
        ]);
    } catch(PDOException $e) {
        error_log("Notification error: " . $e->getMessage());
        return false;
    }
}

/**
 * Get unread notification count
 */
function getUnreadNotificationCount($db, $userId) {
    try {
        $sql = "SELECT COUNT(*) as count FROM notifications 
                WHERE user_id = :user_id AND is_read = 'No'";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([':user_id' => $userId]);
        $result = $stmt->fetch();
        
        return $result['count'];
    } catch(PDOException $e) {
        return 0;
    }
}

/**
 * JSON response for AJAX requests
 */
function jsonResponse($success, $message, $data = null) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit();
}

/**
 * Check session timeout
 */
function checkSessionTimeout() {
    if (isset($_SESSION['last_activity'])) {
        $inactive = time() - $_SESSION['last_activity'];
        if ($inactive >= SESSION_TIMEOUT) {
            session_unset();
            session_destroy();
            return false;
        }
    }
    $_SESSION['last_activity'] = time();
    return true;
}
?>
