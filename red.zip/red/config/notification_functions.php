<?php
/**
 * Notification and Audit Log Functions
 * Comprehensive functions for managing notifications and audit logs
 */

// ============================
// USER NOTIFICATION FUNCTIONS
// ============================

/**
 * Send welcome notification to new user
 */
function notifyUserRegistration($db, $userId, $fullName) {
    $title = "Welcome to Koronadal Red Cross!";
    $message = "Hi $fullName! Thank you for registering with Koronadal Red Cross Blood Donation System. Your account has been created successfully.";
    createNotification($db, $userId, $title, $message, 'success');
    logAudit($db, $userId, 'User Registration', 'users', $userId, "New user registered: $fullName");
}

/**
 * Notify user about account status change
 */
function notifyUserStatusChange($db, $userId, $newStatus, $adminId) {
    $statusText = ucfirst($newStatus);
    $title = "Account Status Updated";
    $message = "Your account status has been changed to: $statusText";
    $type = ($newStatus === 'active') ? 'success' : 'warning';
    
    createNotification($db, $userId, $title, $message, $type);
    logAudit($db, $adminId, 'User Status Changed', 'users', $userId, "User status changed to: $newStatus");
}

/**
 * Notify user about profile update
 */
function notifyUserProfileUpdate($db, $userId) {
    $title = "Profile Updated";
    $message = "Your profile information has been successfully updated.";
    createNotification($db, $userId, $title, $message, 'success');
    logAudit($db, $userId, 'Profile Updated', 'users', $userId, "User updated their profile information");
}

/**
 * Notify user about password change
 */
function notifyUserPasswordChange($db, $userId) {
    $title = "Password Changed";
    $message = "Your password has been successfully changed. If you didn't make this change, please contact us immediately.";
    createNotification($db, $userId, $title, $message, 'warning');
    logAudit($db, $userId, 'Password Changed', 'users', $userId, "User changed their password");
}

/**
 * Send notification to all users
 */
function notifyAllUsers($db, $title, $message, $type = 'info', $adminId = null) {
    try {
        $sql = "SELECT user_id FROM users WHERE user_role = 'user' AND status = 'active'";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        foreach ($users as $userId) {
            createNotification($db, $userId, $title, $message, $type);
        }
        
        if ($adminId) {
            logAudit($db, $adminId, 'Mass Notification Sent', 'notifications', null, "Sent to " . count($users) . " users: $title");
        }
        
        return count($users);
    } catch(PDOException $e) {
        error_log("Mass notification error: " . $e->getMessage());
        return 0;
    }
}

// ============================
// DONOR NOTIFICATION FUNCTIONS
// ============================

/**
 * Notify donor about new donation submission
 */
function notifyDonationSubmitted($db, $userId, $donationId, $donationDate) {
    $title = "Donation Submitted";
    $message = "Your blood donation scheduled for " . date('F j, Y', strtotime($donationDate)) . " has been submitted and is pending approval.";
    createNotification($db, $userId, $title, $message, 'info');
    logAudit($db, $userId, 'Donation Submitted', 'donations', $donationId, "New donation submitted for approval");
}

/**
 * Notify donor about donation approval
 */
function notifyDonationApproved($db, $userId, $donationId, $donationDate, $adminId) {
    $title = "Donation Approved";
    $message = "Great news! Your blood donation scheduled for " . date('F j, Y', strtotime($donationDate)) . " has been approved. Thank you for your contribution!";
    createNotification($db, $userId, $title, $message, 'success');
    logAudit($db, $adminId, 'Donation Approved', 'donations', $donationId, "Admin approved donation for user ID: $userId");
}

/**
 * Notify donor about donation rejection
 */
function notifyDonationRejected($db, $userId, $donationId, $reason, $adminId) {
    $title = "Donation Not Approved";
    $message = "We regret to inform you that your donation submission was not approved. Reason: $reason. Please contact us for more information.";
    createNotification($db, $userId, $title, $message, 'error');
    logAudit($db, $adminId, 'Donation Rejected', 'donations', $donationId, "Admin rejected donation. Reason: $reason");
}

/**
 * Notify donor about donation completion
 */
function notifyDonationCompleted($db, $userId, $donationId, $adminId) {
    $title = "Donation Completed";
    $message = "Thank you! Your blood donation has been completed successfully. Your contribution will help save lives!";
    createNotification($db, $userId, $title, $message, 'success');
    logAudit($db, $adminId, 'Donation Completed', 'donations', $donationId, "Donation marked as completed");
}

/**
 * Remind eligible donors to donate
 */
function notifyDonationEligibility($db, $userId, $lastDonationDate) {
    $title = "You're Eligible to Donate!";
    $message = "Good news! It's been 56 days since your last donation. You're now eligible to donate blood again. Schedule your appointment today!";
    createNotification($db, $userId, $title, $message, 'info');
    logAudit($db, null, 'Eligibility Notification Sent', 'notifications', null, "Eligibility notification sent to user ID: $userId");
}

/**
 * Send donation reminder to eligible donors
 */
function sendDonationReminders($db, $adminId = null) {
    try {
        $sql = "SELECT DISTINCT u.user_id, u.full_name, di.last_donation_date 
                FROM users u 
                JOIN donors_info di ON u.user_id = di.user_id 
                WHERE di.eligible_to_donate = 'Yes' 
                AND u.status = 'active'
                AND (di.last_donation_date IS NULL OR DATEDIFF(CURDATE(), di.last_donation_date) >= " . MIN_DONATION_INTERVAL_DAYS . ")";
        
        $stmt = $db->prepare($sql);
        $stmt->execute();
        $eligibleDonors = $stmt->fetchAll();
        
        $count = 0;
        foreach ($eligibleDonors as $donor) {
            notifyDonationEligibility($db, $donor['user_id'], $donor['last_donation_date']);
            $count++;
        }
        
        if ($adminId) {
            logAudit($db, $adminId, 'Donation Reminders Sent', 'notifications', null, "Sent reminders to $count eligible donors");
        }
        
        return $count;
    } catch(PDOException $e) {
        error_log("Donation reminder error: " . $e->getMessage());
        return 0;
    }
}

// ============================
// EVENT NOTIFICATION FUNCTIONS
// ============================

/**
 * Notify all users about new event
 */
function notifyNewEvent($db, $eventId, $eventName, $eventDate, $eventLocation, $adminId) {
    $title = "New Blood Drive Event";
    $message = "Join us for '$eventName' on " . date('F j, Y', strtotime($eventDate)) . " at $eventLocation. Register now!";
    
    $count = notifyAllUsers($db, $title, $message, 'info', $adminId);
    logAudit($db, $adminId, 'New Event Created', 'events', $eventId, "Created event: $eventName - Notified $count users");
    
    return $count;
}

/**
 * Notify registered participants about event update
 */
function notifyEventUpdate($db, $eventId, $eventName, $updateDetails, $adminId) {
    try {
        // Get all users with appointments for this event
        $sql = "SELECT DISTINCT u.user_id FROM users u 
                JOIN appointments a ON u.user_id = a.user_id 
                WHERE a.event_id = :event_id AND a.status != 'cancelled'";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([':event_id' => $eventId]);
        $participants = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $title = "Event Update: $eventName";
        $message = "The event '$eventName' has been updated. $updateDetails";
        
        foreach ($participants as $userId) {
            createNotification($db, $userId, $title, $message, 'warning');
        }
        
        logAudit($db, $adminId, 'Event Updated', 'events', $eventId, "Updated event: $eventName - Notified " . count($participants) . " participants");
        
        return count($participants);
    } catch(PDOException $e) {
        error_log("Event update notification error: " . $e->getMessage());
        return 0;
    }
}

/**
 * Notify participants about event cancellation
 */
function notifyEventCancellation($db, $eventId, $eventName, $reason, $adminId) {
    try {
        $sql = "SELECT DISTINCT u.user_id FROM users u 
                JOIN appointments a ON u.user_id = a.user_id 
                WHERE a.event_id = :event_id AND a.status != 'cancelled'";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([':event_id' => $eventId]);
        $participants = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $title = "Event Cancelled: $eventName";
        $message = "We regret to inform you that '$eventName' has been cancelled. Reason: $reason. We apologize for any inconvenience.";
        
        foreach ($participants as $userId) {
            createNotification($db, $userId, $title, $message, 'error');
        }
        
        logAudit($db, $adminId, 'Event Cancelled', 'events', $eventId, "Cancelled event: $eventName - Notified " . count($participants) . " participants");
        
        return count($participants);
    } catch(PDOException $e) {
        error_log("Event cancellation notification error: " . $e->getMessage());
        return 0;
    }
}

/**
 * Send event reminder to participants
 */
function sendEventReminders($db, $daysBefore = 3, $adminId = null) {
    try {
        $sql = "SELECT DISTINCT e.event_id, e.event_name, e.event_date, e.event_location, 
                a.user_id, a.appointment_time
                FROM events e
                JOIN appointments a ON e.event_id = a.event_id
                WHERE e.status = 'upcoming'
                AND a.status IN ('scheduled', 'confirmed')
                AND DATEDIFF(e.event_date, CURDATE()) = :days_before";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([':days_before' => $daysBefore]);
        $reminders = $stmt->fetchAll();
        
        foreach ($reminders as $reminder) {
            $title = "Event Reminder: " . $reminder['event_name'];
            $message = "Reminder: You have an appointment for '" . $reminder['event_name'] . "' on " . 
                       date('F j, Y', strtotime($reminder['event_date'])) . " at " . 
                       date('g:i A', strtotime($reminder['appointment_time'])) . 
                       " at " . $reminder['event_location'];
            
            createNotification($db, $reminder['user_id'], $title, $message, 'info');
        }
        
        if ($adminId && count($reminders) > 0) {
            logAudit($db, $adminId, 'Event Reminders Sent', 'notifications', null, 
                    "Sent " . count($reminders) . " event reminders for events in $daysBefore days");
        }
        
        return count($reminders);
    } catch(PDOException $e) {
        error_log("Event reminder error: " . $e->getMessage());
        return 0;
    }
}

// ====================================
// APPOINTMENT NOTIFICATION FUNCTIONS
// ====================================

/**
 * Notify user about new appointment
 */
function notifyAppointmentScheduled($db, $userId, $appointmentId, $appointmentDate, $appointmentTime, $purpose) {
    $title = "Appointment Scheduled";
    $message = "Your appointment for " . ucfirst($purpose) . " has been scheduled on " . 
               date('F j, Y', strtotime($appointmentDate)) . " at " . 
               date('g:i A', strtotime($appointmentTime));
    
    createNotification($db, $userId, $title, $message, 'success');
    logAudit($db, $userId, 'Appointment Scheduled', 'appointments', $appointmentId, 
            "User scheduled appointment for $purpose");
}

/**
 * Notify user about appointment confirmation
 */
function notifyAppointmentConfirmed($db, $userId, $appointmentId, $appointmentDate, $appointmentTime, $adminId) {
    $title = "Appointment Confirmed";
    $message = "Your appointment on " . date('F j, Y', strtotime($appointmentDate)) . 
               " at " . date('g:i A', strtotime($appointmentTime)) . " has been confirmed. See you there!";
    
    createNotification($db, $userId, $title, $message, 'success');
    logAudit($db, $adminId, 'Appointment Confirmed', 'appointments', $appointmentId, 
            "Admin confirmed appointment for user ID: $userId");
}

/**
 * Notify user about appointment cancellation
 */
function notifyAppointmentCancelled($db, $userId, $appointmentId, $appointmentDate, $reason, $cancelledBy) {
    $title = "Appointment Cancelled";
    $message = "Your appointment on " . date('F j, Y', strtotime($appointmentDate)) . 
               " has been cancelled. Reason: $reason";
    
    createNotification($db, $userId, $title, $message, 'warning');
    logAudit($db, $cancelledBy, 'Appointment Cancelled', 'appointments', $appointmentId, 
            "Appointment cancelled. Reason: $reason");
}

/**
 * Notify user about appointment completion
 */
function notifyAppointmentCompleted($db, $userId, $appointmentId, $adminId) {
    $title = "Appointment Completed";
    $message = "Your appointment has been completed. Thank you for your time and contribution!";
    
    createNotification($db, $userId, $title, $message, 'success');
    logAudit($db, $adminId, 'Appointment Completed', 'appointments', $appointmentId, 
            "Appointment marked as completed");
}

/**
 * Send appointment reminders
 */
function sendAppointmentReminders($db, $hoursBefore = 24, $adminId = null) {
    try {
        $sql = "SELECT a.appointment_id, a.user_id, a.appointment_date, a.appointment_time, 
                a.purpose, e.event_name, e.event_location
                FROM appointments a
                LEFT JOIN events e ON a.event_id = e.event_id
                WHERE a.status IN ('scheduled', 'confirmed')
                AND TIMESTAMPDIFF(HOUR, NOW(), CONCAT(a.appointment_date, ' ', a.appointment_time)) BETWEEN 0 AND :hours_before";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([':hours_before' => $hoursBefore]);
        $reminders = $stmt->fetchAll();
        
        foreach ($reminders as $reminder) {
            $location = $reminder['event_location'] ?? 'Koronadal Red Cross Center';
            $title = "Appointment Reminder";
            $message = "Reminder: You have an appointment for " . ucfirst($reminder['purpose']) . 
                       " tomorrow on " . date('F j, Y', strtotime($reminder['appointment_date'])) . 
                       " at " . date('g:i A', strtotime($reminder['appointment_time'])) . 
                       " at $location";
            
            createNotification($db, $reminder['user_id'], $title, $message, 'info');
        }
        
        if ($adminId && count($reminders) > 0) {
            logAudit($db, $adminId, 'Appointment Reminders Sent', 'notifications', null, 
                    "Sent " . count($reminders) . " appointment reminders");
        }
        
        return count($reminders);
    } catch(PDOException $e) {
        error_log("Appointment reminder error: " . $e->getMessage());
        return 0;
    }
}

// ====================================
// BLOOD REQUEST NOTIFICATION FUNCTIONS
// ====================================

/**
 * Notify user about blood request submission
 */
function notifyRequestSubmitted($db, $userId, $requestId, $bloodType, $patientName) {
    $title = "Blood Request Submitted";
    $message = "Your blood request for $bloodType blood for patient $patientName has been submitted and is under review.";
    
    createNotification($db, $userId, $title, $message, 'info');
    logAudit($db, $userId, 'Blood Request Submitted', 'requests', $requestId, 
            "User submitted blood request for $bloodType");
}

/**
 * Notify user about blood request approval
 */
function notifyRequestApproved($db, $userId, $requestId, $bloodType, $patientName, $adminId) {
    $title = "Blood Request Approved";
    $message = "Your blood request for $bloodType blood for patient $patientName has been approved. We will contact you shortly with further details.";
    
    createNotification($db, $userId, $title, $message, 'success');
    logAudit($db, $adminId, 'Blood Request Approved', 'requests', $requestId, 
            "Admin approved blood request for user ID: $userId");
}

/**
 * Notify user about blood request fulfillment
 */
function notifyRequestFulfilled($db, $userId, $requestId, $bloodType, $patientName, $adminId) {
    $title = "Blood Request Fulfilled";
    $message = "Great news! Your blood request for $bloodType blood for patient $patientName has been fulfilled.";
    
    createNotification($db, $userId, $title, $message, 'success');
    logAudit($db, $adminId, 'Blood Request Fulfilled', 'requests', $requestId, 
            "Blood request fulfilled for user ID: $userId");
}

/**
 * Notify user about blood request rejection
 */
function notifyRequestRejected($db, $userId, $requestId, $reason, $adminId) {
    $title = "Blood Request Not Approved";
    $message = "We regret to inform you that your blood request could not be approved. Reason: $reason. Please contact us for more information.";
    
    createNotification($db, $userId, $title, $message, 'error');
    logAudit($db, $adminId, 'Blood Request Rejected', 'requests', $requestId, 
            "Admin rejected blood request. Reason: $reason");
}

// ====================================
// ADMIN AUDIT LOG FUNCTIONS
// ====================================

/**
 * Log inventory update
 */
function logInventoryUpdate($db, $adminId, $inventoryId, $bloodType, $oldQuantity, $newQuantity) {
    $change = $newQuantity - $oldQuantity;
    $action = $change > 0 ? 'Inventory Increased' : 'Inventory Decreased';
    $details = "Blood type: $bloodType, Changed from $oldQuantity ml to $newQuantity ml (Change: $change ml)";
    
    logAudit($db, $adminId, $action, 'inventory', $inventoryId, $details);
}

/**
 * Log user management action
 */
function logUserManagement($db, $adminId, $action, $targetUserId, $details) {
    logAudit($db, $adminId, $action, 'users', $targetUserId, $details);
}

/**
 * Log admin login
 */
function logAdminLogin($db, $adminId, $username) {
    logAudit($db, $adminId, 'Admin Login', 'users', $adminId, "Admin user '$username' logged in");
}

/**
 * Log admin logout
 */
function logAdminLogout($db, $adminId, $username) {
    logAudit($db, $adminId, 'Admin Logout', 'users', $adminId, "Admin user '$username' logged out");
}

/**
 * Get audit logs with filters
 */
function getAuditLogs($db, $filters = [], $limit = 50, $offset = 0) {
    try {
        $sql = "SELECT al.*, u.username, u.full_name 
                FROM audit_logs al 
                LEFT JOIN users u ON al.user_id = u.user_id 
                WHERE 1=1";
        
        $params = [];
        
        // Filter by user
        if (!empty($filters['user_id'])) {
            $sql .= " AND al.user_id = :user_id";
            $params[':user_id'] = $filters['user_id'];
        }
        
        // Filter by action
        if (!empty($filters['action'])) {
            $sql .= " AND al.action LIKE :action";
            $params[':action'] = '%' . $filters['action'] . '%';
        }
        
        // Filter by table
        if (!empty($filters['table'])) {
            $sql .= " AND al.table_affected = :table";
            $params[':table'] = $filters['table'];
        }
        
        // Filter by date range
        if (!empty($filters['date_from'])) {
            $sql .= " AND DATE(al.created_at) >= :date_from";
            $params[':date_from'] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $sql .= " AND DATE(al.created_at) <= :date_to";
            $params[':date_to'] = $filters['date_to'];
        }
        
        $sql .= " ORDER BY al.created_at DESC LIMIT :limit OFFSET :offset";
        
        $stmt = $db->prepare($sql);
        
        // Bind all parameters
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        
        $stmt->execute();
        return $stmt->fetchAll();
        
    } catch(PDOException $e) {
        error_log("Get audit logs error: " . $e->getMessage());
        return [];
    }
}

/**
 * Get audit log statistics
 */
function getAuditLogStats($db, $dateFrom = null, $dateTo = null) {
    try {
        $sql = "SELECT 
                COUNT(*) as total_actions,
                COUNT(DISTINCT user_id) as unique_users,
                COUNT(DISTINCT DATE(created_at)) as active_days,
                table_affected,
                COUNT(*) as action_count
                FROM audit_logs 
                WHERE 1=1";
        
        $params = [];
        
        if ($dateFrom) {
            $sql .= " AND DATE(created_at) >= :date_from";
            $params[':date_from'] = $dateFrom;
        }
        
        if ($dateTo) {
            $sql .= " AND DATE(created_at) <= :date_to";
            $params[':date_to'] = $dateTo;
        }
        
        $sql .= " GROUP BY table_affected";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchAll();
        
    } catch(PDOException $e) {
        error_log("Get audit stats error: " . $e->getMessage());
        return [];
    }
}

// ====================================
// NOTIFICATION MANAGEMENT FUNCTIONS
// ====================================

/**
 * Get all notifications for a user with pagination
 */
function getUserNotifications($db, $userId, $limit = 20, $offset = 0, $unreadOnly = false) {
    try {
        $sql = "SELECT * FROM notifications WHERE user_id = :user_id";
        
        if ($unreadOnly) {
            $sql .= " AND is_read = 'No'";
        }
        
        $sql .= " ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
        
        $stmt = $db->prepare($sql);
        $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
        
    } catch(PDOException $e) {
        error_log("Get user notifications error: " . $e->getMessage());
        return [];
    }
}

/**
 * Mark notification as read
 */
function markNotificationAsRead($db, $notificationId, $userId) {
    try {
        $sql = "UPDATE notifications SET is_read = 'Yes' 
                WHERE notification_id = :notification_id AND user_id = :user_id";
        
        $stmt = $db->prepare($sql);
        return $stmt->execute([
            ':notification_id' => $notificationId,
            ':user_id' => $userId
        ]);
    } catch(PDOException $e) {
        error_log("Mark notification read error: " . $e->getMessage());
        return false;
    }
}

/**
 * Mark all notifications as read for a user
 */
function markAllNotificationsAsRead($db, $userId) {
    try {
        $sql = "UPDATE notifications SET is_read = 'Yes' 
                WHERE user_id = :user_id AND is_read = 'No'";
        
        $stmt = $db->prepare($sql);
        return $stmt->execute([':user_id' => $userId]);
    } catch(PDOException $e) {
        error_log("Mark all notifications read error: " . $e->getMessage());
        return false;
    }
}

/**
 * Delete notification
 */
function deleteNotification($db, $notificationId, $userId) {
    try {
        $sql = "DELETE FROM notifications 
                WHERE notification_id = :notification_id AND user_id = :user_id";
        
        $stmt = $db->prepare($sql);
        return $stmt->execute([
            ':notification_id' => $notificationId,
            ':user_id' => $userId
        ]);
    } catch(PDOException $e) {
        error_log("Delete notification error: " . $e->getMessage());
        return false;
    }
}

/**
 * Delete old read notifications (cleanup function)
 */
function cleanupOldNotifications($db, $daysOld = 30) {
    try {
        $sql = "DELETE FROM notifications 
                WHERE is_read = 'Yes' 
                AND DATEDIFF(CURDATE(), created_at) > :days_old";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([':days_old' => $daysOld]);
        
        $deletedCount = $stmt->rowCount();
        
        if ($deletedCount > 0) {
            logAudit($db, null, 'Notification Cleanup', 'notifications', null, 
                    "Deleted $deletedCount old read notifications (older than $daysOld days)");
        }
        
        return $deletedCount;
    } catch(PDOException $e) {
        error_log("Cleanup notifications error: " . $e->getMessage());
        return 0;
    }
}

/**
 * Get notification statistics for a user
 */
function getNotificationStats($db, $userId) {
    try {
        $sql = "SELECT 
                COUNT(*) as total_notifications,
                SUM(CASE WHEN is_read = 'No' THEN 1 ELSE 0 END) as unread_count,
                SUM(CASE WHEN is_read = 'Yes' THEN 1 ELSE 0 END) as read_count,
                type,
                COUNT(*) as type_count
                FROM notifications 
                WHERE user_id = :user_id
                GROUP BY type";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([':user_id' => $userId]);
        
        return $stmt->fetchAll();
        
    } catch(PDOException $e) {
        error_log("Get notification stats error: " . $e->getMessage());
        return [];
    }
}
?>
