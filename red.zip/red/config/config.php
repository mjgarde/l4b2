<?php
/**
 * Koronadal Red Cross - Configuration File
 * Contains database and application settings
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'koronadal_redcross');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Application Configuration
define('SITE_NAME', 'Koronadal Red Cross Blood Donation System');
define('BASE_URL', 'http://localhost/red/');
define('ADMIN_EMAIL', 'admin@koronadalredcross.org');

// Security Configuration
define('PASSWORD_MIN_LENGTH', 8);
define('SESSION_TIMEOUT', 3600); // 1 hour in seconds

// File Upload Configuration
define('MAX_FILE_SIZE', 5242880); // 5MB in bytes
define('ALLOWED_FILE_TYPES', ['jpg', 'jpeg', 'png', 'pdf']);

// Donation Configuration
define('MIN_DONATION_INTERVAL_DAYS', 56);
define('MIN_DONOR_WEIGHT_KG', 50);
define('MIN_DONOR_AGE', 18);
define('MAX_DONOR_AGE', 65);
define('STANDARD_DONATION_ML', 450);

// Timezone
date_default_timezone_set('Asia/Manila');

// Error Reporting (set to 0 in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Show detailed errors (set to false in production)
define('SHOW_ERRORS', true);

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Auto-load common functions
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/notification_functions.php';
?>
