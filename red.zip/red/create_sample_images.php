<?php
/**
 * Create Sample Image Files for Testing
 */

echo "<h2>🖼️ Creating Sample Images...</h2>";
echo "<style>
    body { font-family: Arial; padding: 20px; }
    .success { background: #ccffcc; padding: 10px; margin: 10px 0; border-radius: 5px; }
    .error { background: #ffcccc; padding: 10px; margin: 10px 0; border-radius: 5px; }
    .info { background: #cce5ff; padding: 10px; margin: 10px 0; border-radius: 5px; }
    img { border: 2px solid #ccc; margin: 10px; border-radius: 5px; }
</style>";

// Create directories if they don't exist
$dirs = [
    'uploads/medical_certificates',
    'uploads/profile_photos',
    'uploads/documents'
];

foreach ($dirs as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
        echo "<div class='success'>✅ Created directory: $dir</div>";
    }
}

// Function to create a sample image
function createSampleImage($filepath, $text, $bgColor = [200, 230, 255]) {
    $width = 600;
    $height = 400;
    
    // Create image
    $image = imagecreatetruecolor($width, $height);
    
    // Colors
    $backgroundColor = imagecolorallocate($image, $bgColor[0], $bgColor[1], $bgColor[2]);
    $textColor = imagecolorallocate($image, 50, 50, 50);
    $borderColor = imagecolorallocate($image, 100, 100, 100);
    
    // Fill background
    imagefill($image, 0, 0, $backgroundColor);
    
    // Draw border
    imagerectangle($image, 10, 10, $width-10, $height-10, $borderColor);
    imagerectangle($image, 11, 11, $width-11, $height-11, $borderColor);
    
    // Add text
    $lines = explode("\n", $text);
    $y = ($height / 2) - (count($lines) * 15);
    
    foreach ($lines as $line) {
        $bbox = imagettfbbox(16, 0, __DIR__ . '/assets/fonts/arial.ttf', $line);
        if ($bbox === false) {
            // Fallback if TTF not available
            imagestring($image, 5, ($width / 2) - (strlen($line) * 5), $y, $line, $textColor);
        } else {
            $textWidth = $bbox[2] - $bbox[0];
            $x = ($width / 2) - ($textWidth / 2);
            imagettftext($image, 16, 0, $x, $y + 20, $textColor, __DIR__ . '/assets/fonts/arial.ttf', $line);
        }
        $y += 30;
    }
    
    // Save as JPEG
    $ext = strtolower(pathinfo($filepath, PATHINFO_EXTENSION));
    if ($ext === 'jpg' || $ext === 'jpeg') {
        imagejpeg($image, $filepath, 90);
    } else if ($ext === 'png') {
        imagepng($image, $filepath, 8);
    }
    
    imagedestroy($image);
}

// Sample files to create
$sampleFiles = [
    [
        'path' => 'uploads/medical_certificates/medical_cert_sample.jpg',
        'text' => "SAMPLE\nMEDICAL CERTIFICATE\n\nThis is a sample document\nfor testing purposes",
        'color' => [255, 230, 230]
    ],
    [
        'path' => 'uploads/profile_photos/valid_id_sample.jpg',
        'text' => "SAMPLE\nVALID ID / PHOTO ID\n\nThis is a sample document\nfor testing purposes",
        'color' => [230, 230, 255]
    ],
    [
        'path' => 'uploads/documents/medical_cert_sample.pdf',
        'text' => 'PDF',
        'color' => [255, 200, 200]
    ]
];

echo "<div class='info'><h3>📝 Creating Sample Files...</h3></div>";

foreach ($sampleFiles as $file) {
    $filepath = $file['path'];
    
    // Skip PDF files (would need additional library)
    if (pathinfo($filepath, PATHINFO_EXTENSION) === 'pdf') {
        echo "<div class='info'>⏭️ Skipping PDF: $filepath (needs PDF library)</div>";
        continue;
    }
    
    try {
        createSampleImage($filepath, $file['text'], $file['color']);
        
        if (file_exists($filepath)) {
            $filesize = filesize($filepath);
            echo "<div class='success'>";
            echo "✅ Created: <strong>$filepath</strong> (" . number_format($filesize / 1024, 2) . " KB)<br>";
            echo "<img src='$filepath' width='200'>";
            echo "</div>";
        }
    } catch (Exception $e) {
        echo "<div class='error'>❌ Error creating $filepath: " . $e->getMessage() . "</div>";
    }
}

// Also copy existing files if available
$existingMedical = glob('uploads/medical_certificates/medical_cert_*.jpeg');
$existingPhoto = glob('uploads/profile_photos/photo_id_*.jpeg');

if (!empty($existingMedical)) {
    $source = $existingMedical[0];
    $target = 'uploads/medical_certificates/medical_cert_sample.jpg';
    if (!file_exists($target)) {
        copy($source, $target);
        echo "<div class='success'>✅ Copied existing medical cert to sample</div>";
    }
}

if (!empty($existingPhoto)) {
    $source = $existingPhoto[0];
    $target = 'uploads/profile_photos/valid_id_sample.jpg';
    if (!file_exists($target)) {
        copy($source, $target);
        echo "<div class='success'>✅ Copied existing photo ID to sample</div>";
    }
}

echo "<hr>";
echo "<div class='success'><h3>✅ Done!</h3></div>";
echo "<p><a href='check_and_fix_documents.php' style='background: #007bff; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none;'>Check Document Status</a></p>";
echo "<p><a href='admin/user_approvals.php' style='background: #28a745; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none;'>Go to User Approvals</a></p>";
?>
