<?php
/**
 * Test Complete Registration → Admin Flow
 * Verify that user info and documents match properly
 */

require_once 'config/config.php';
require_once 'config/db.php';

echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>Test Complete Flow</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css'>
    <style>
        body { padding: 30px; background: #f0f2f5; }
        .user-card { background: white; border-radius: 15px; padding: 25px; margin: 20px 0; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
        .doc-card { background: #f8f9fa; border-left: 4px solid #007bff; padding: 15px; margin: 10px 0; border-radius: 8px; }
        .success { border-left-color: #28a745; background: #d4edda; }
        .error { border-left-color: #dc3545; background: #f8d7da; }
        .warning { border-left-color: #ffc107; background: #fff3cd; }
        .info { border-left-color: #17a2b8; background: #d1ecf1; }
        .badge-xl { font-size: 1rem; padding: 8px 15px; }
        img { max-width: 200px; border-radius: 8px; box-shadow: 0 3px 10px rgba(0,0,0,0.2); }
    </style>
</head>
<body>
<div class='container'>
    <h1 class='mb-4'><i class='bi bi-diagram-3-fill'></i> Complete Registration → Admin Flow Test</h1>
    <p class='lead'>Verify that user information and documents match correctly</p>
    <hr>";

try {
    // Get all users with pending status (what admin sees)
    $sql = "SELECT * FROM users WHERE status = 'pending' ORDER BY created_at DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $users = $stmt->fetchAll();
    
    if (empty($users)) {
        echo "<div class='alert alert-warning'>
                <i class='bi bi-exclamation-triangle'></i> 
                <strong>No pending users found!</strong><br>
                <small>Register a new user to test the flow.</small><br>
                <a href='register.php' class='btn btn-primary mt-2'>Go to Registration</a>
              </div>";
    } else {
        echo "<div class='alert alert-info'>
                <i class='bi bi-info-circle'></i> 
                Found <strong>" . count($users) . "</strong> pending user(s)
              </div>";
        
        // Loop through each user
        foreach ($users as $user) {
            echo "<div class='user-card'>";
            
            // User Header
            echo "<div class='d-flex justify-content-between align-items-start mb-3'>
                    <div>
                        <h3 class='mb-1'>{$user['full_name']}</h3>
                        <p class='text-muted mb-0'>
                            <i class='bi bi-person'></i> @{$user['username']} | 
                            <i class='bi bi-envelope'></i> {$user['email']}
                        </p>
                    </div>
                    <span class='badge badge-xl bg-warning'>PENDING</span>
                  </div>";
            
            // User Details
            echo "<div class='row mb-4'>
                    <div class='col-md-6'>
                        <p class='mb-1'><strong><i class='bi bi-telephone'></i> Phone:</strong> {$user['phone']}</p>
                        <p class='mb-1'><strong><i class='bi bi-geo-alt'></i> Address:</strong> {$user['address']}</p>
                    </div>
                    <div class='col-md-6'>
                        <p class='mb-1'><strong><i class='bi bi-calendar'></i> Registered:</strong> {$user['created_at']}</p>
                        <p class='mb-1'><strong><i class='bi bi-droplet'></i> Blood Type:</strong> ";
            
            if ($user['blood_type_id']) {
                $btSql = "SELECT blood_type FROM blood_types WHERE blood_type_id = :id";
                $btStmt = $db->prepare($btSql);
                $btStmt->execute([':id' => $user['blood_type_id']]);
                $bt = $btStmt->fetch();
                echo $bt ? $bt['blood_type'] : 'Not specified';
            } else {
                echo 'Not specified';
            }
            
            echo "</p>
                    </div>
                  </div>";
            
            // Documents Section
            echo "<hr><h5><i class='bi bi-file-earmark-check'></i> Uploaded Documents</h5>";
            
            // Fetch documents for this user
            $docSql = "SELECT * FROM user_documents WHERE user_id = :user_id ORDER BY document_type";
            $docStmt = $db->prepare($docSql);
            $docStmt->execute([':user_id' => $user['user_id']]);
            $documents = $docStmt->fetchAll();
            
            if (empty($documents)) {
                echo "<div class='doc-card error'>
                        <i class='bi bi-exclamation-circle'></i> 
                        <strong>⚠️ NO DOCUMENTS FOUND IN DATABASE!</strong>
                        <p class='mb-0 mt-2'><small>This user registered but documents were not saved to the database.</small></p>
                      </div>";
            } else {
                echo "<div class='doc-card success'>
                        <i class='bi bi-check-circle'></i> 
                        <strong>✅ Found " . count($documents) . " document(s)</strong>
                      </div>";
                
                // Show each document
                foreach ($documents as $doc) {
                    $fileExists = file_exists($doc['file_path']);
                    $docType = $doc['document_type'] === 'medical_certificate' ? 'Medical Certificate' : 'Photo ID / Valid ID';
                    $icon = $doc['document_type'] === 'medical_certificate' ? 'file-earmark-medical' : 'card-image';
                    
                    echo "<div class='doc-card " . ($fileExists ? 'info' : 'warning') . "'>
                            <div class='row align-items-center'>
                                <div class='col-md-6'>
                                    <h6><i class='bi bi-$icon'></i> $docType</h6>
                                    <p class='mb-1'><strong>File:</strong> <code>{$doc['file_name']}</code></p>
                                    <p class='mb-1'><strong>Path:</strong> <small><code>{$doc['file_path']}</code></small></p>
                                    <p class='mb-1'><strong>Size:</strong> " . round($doc['file_size']/1024, 2) . " KB</p>
                                    <p class='mb-0'><strong>Uploaded:</strong> {$doc['created_at']}</p>
                                </div>
                                <div class='col-md-6 text-center'>";
                    
                    if ($fileExists) {
                        $ext = strtolower(pathinfo($doc['file_path'], PATHINFO_EXTENSION));
                        $isImage = in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp']);
                        
                        echo "<span class='badge bg-success mb-2'>✅ FILE EXISTS</span><br>";
                        
                        if ($isImage) {
                            echo "<img src='{$doc['file_path']}' alt='Document Preview' class='mb-2'><br>";
                        }
                        
                        echo "<a href='{$doc['file_path']}' target='_blank' class='btn btn-sm btn-primary'>
                                <i class='bi bi-eye'></i> View File
                              </a>";
                    } else {
                        echo "<span class='badge bg-danger mb-2'>❌ FILE NOT FOUND</span><br>";
                        echo "<small class='text-danger'>File does not exist at specified path</small>";
                    }
                    
                    echo "      </div>
                            </div>
                          </div>";
                }
            }
            
            // Admin Actions Preview
            echo "<hr>
                    <div class='d-flex gap-2'>
                        <button class='btn btn-success flex-fill'>
                            <i class='bi bi-check-circle'></i> Approve
                        </button>
                        <button class='btn btn-danger flex-fill'>
                            <i class='bi bi-x-circle'></i> Decline
                        </button>
                    </div>";
            
            echo "</div>"; // End user-card
        }
    }
    
    // Summary Statistics
    echo "<hr>";
    echo "<div class='user-card info'>
            <h4><i class='bi bi-graph-up'></i> Summary Statistics</h4>";
    
    $stats = [
        'Total Users' => $db->query("SELECT COUNT(*) as cnt FROM users")->fetch()['cnt'],
        'Pending Users' => $db->query("SELECT COUNT(*) as cnt FROM users WHERE status = 'pending'")->fetch()['cnt'],
        'Active Users' => $db->query("SELECT COUNT(*) as cnt FROM users WHERE status = 'active'")->fetch()['cnt'],
        'Total Documents' => $db->query("SELECT COUNT(*) as cnt FROM user_documents")->fetch()['cnt'],
        'Medical Certificates' => $db->query("SELECT COUNT(*) as cnt FROM user_documents WHERE document_type = 'medical_certificate'")->fetch()['cnt'],
        'Photo IDs' => $db->query("SELECT COUNT(*) as cnt FROM user_documents WHERE document_type = 'id_card'")->fetch()['cnt']
    ];
    
    echo "<div class='row'>";
    foreach ($stats as $label => $value) {
        echo "<div class='col-md-4 mb-3'>
                <div class='text-center p-3' style='background: #f8f9fa; border-radius: 10px;'>
                    <h2 class='mb-0'>$value</h2>
                    <small class='text-muted'>$label</small>
                </div>
              </div>";
    }
    echo "</div>";
    
    echo "</div>";
    
    // Action Buttons
    echo "<div class='text-center mt-4'>
            <a href='register.php' class='btn btn-primary btn-lg'><i class='bi bi-person-plus'></i> Test Registration</a>
            <a href='admin/user_approvals.php' class='btn btn-success btn-lg'><i class='bi bi-shield-check'></i> Go to Admin Panel</a>
            <a href='javascript:location.reload()' class='btn btn-secondary btn-lg'><i class='bi bi-arrow-clockwise'></i> Refresh</a>
          </div>";
    
} catch(Exception $e) {
    echo "<div class='alert alert-danger'>
            <h4>❌ Error</h4>
            <p>" . $e->getMessage() . "</p>
          </div>";
}

echo "</div>
</body>
</html>";
?>
