<?php
/**
 * My Donations Page
 * View user's donation history
 */

require_once 'config/config.php';
require_once 'config/db.php';

requireLogin();

$userId = $_SESSION['user_id'];

// Get user's donations
try {
    $donationsSql = "SELECT d.*, bt.blood_type, di.donor_id 
                     FROM donations d 
                     JOIN donors_info di ON d.donor_id = di.donor_id 
                     JOIN blood_types bt ON d.blood_type_id = bt.blood_type_id 
                     WHERE di.user_id = :user_id 
                     ORDER BY d.donation_date DESC";
    $stmt = $db->prepare($donationsSql);
    $stmt->execute([':user_id' => $userId]);
    $donations = $stmt->fetchAll();
} catch(PDOException $e) {
    $donations = [];
}

// Get statistics
try {
    $totalDonationsSql = "SELECT COUNT(*) as count, SUM(d.quantity_ml) as total_ml 
                          FROM donations d 
                          JOIN donors_info di ON d.donor_id = di.donor_id 
                          WHERE di.user_id = :user_id AND d.status = 'completed'";
    $stmt = $db->prepare($totalDonationsSql);
    $stmt->execute([':user_id' => $userId]);
    $stats = $stmt->fetch();
    
    $totalDonations = $stats['count'];
    $totalMl = $stats['total_ml'];
    $livesSaved = floor($totalDonations * 3); // Average 3 lives per donation
} catch(PDOException $e) {
    $totalDonations = 0;
    $totalMl = 0;
    $livesSaved = 0;
}

// Check donation eligibility (90-day rule)
$canDonate = true;
$nextDonationDate = null;
$daysSinceLastDonation = null;

try {
    $donorSql = "SELECT donor_id FROM donors_info WHERE user_id = :user_id";
    $stmt = $db->prepare($donorSql);
    $stmt->execute([':user_id' => $userId]);
    $donorInfo = $stmt->fetch();
    
    if ($donorInfo) {
        $checkSql = "SELECT donation_date 
                     FROM donations 
                     WHERE donor_id = :donor_id 
                     AND status = 'completed' 
                     ORDER BY donation_date DESC 
                     LIMIT 1";
        $stmt = $db->prepare($checkSql);
        $stmt->execute([':donor_id' => $donorInfo['donor_id']]);
        $lastCompletedDonation = $stmt->fetch();
        
        if ($lastCompletedDonation) {
            $lastDate = new DateTime($lastCompletedDonation['donation_date']);
            $today = new DateTime();
            $interval = $today->diff($lastDate);
            $daysSinceLastDonation = $interval->days;
            
            if ($daysSinceLastDonation < MIN_DONATION_INTERVAL_DAYS) {
                $canDonate = false;
                $daysRemaining = MIN_DONATION_INTERVAL_DAYS - $daysSinceLastDonation;
                $nextDonationDate = $lastDate->modify('+' . MIN_DONATION_INTERVAL_DAYS . ' days')->format('F j, Y');
            }
        }
    }
} catch(PDOException $e) {
    // Continue if error
}

$pageTitle = 'My Donations';
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include 'includes/user_sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="bi bi-droplet-half text-danger me-2"></i>My Donations</h1>
                <div>
                    <?php if ($canDonate): ?>
                        <a href="donate.php" class="btn btn-danger">
                            <i class="bi bi-plus-circle me-1"></i>New Donation
                        </a>
                        <span class="badge bg-success ms-2">
                            <i class="bi bi-check-circle me-1"></i>Eligible to Donate
                        </span>
                    <?php else: ?>
                        <button class="btn btn-secondary" disabled>
                            <i class="bi bi-lock-fill me-1"></i>Donation Locked
                        </button>
                        <span class="badge bg-warning text-dark ms-2">
                            <i class="bi bi-clock-history me-1"></i>Next: <?php echo $nextDonationDate; ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (!$canDonate && $nextDonationDate): ?>
                <div class="alert alert-warning mb-4">
                    <i class="bi bi-exclamation-triangle me-2"></i>
                    <strong>Donation Temporarily Unavailable:</strong> 
                    You donated <?php echo $daysSinceLastDonation; ?> days ago. 
                    You can donate again on <strong><?php echo $nextDonationDate; ?></strong> 
                    (<?php echo MIN_DONATION_INTERVAL_DAYS - $daysSinceLastDonation; ?> days remaining).
                </div>
            <?php endif; ?>

            <!-- Statistics Cards -->
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="card border-0 shadow-sm bg-danger text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="mb-1 opacity-75">Total Donations</p>
                                    <h3 class="mb-0 fw-bold"><?php echo $totalDonations; ?></h3>
                                </div>
                                <i class="bi bi-droplet-fill" style="font-size: 2.5rem; opacity: 0.5;"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 mb-3">
                    <div class="card border-0 shadow-sm bg-success text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="mb-1 opacity-75">Total Volume</p>
                                    <h3 class="mb-0 fw-bold"><?php echo $totalMl; ?>ml</h3>
                                </div>
                                <i class="bi bi-heart-pulse-fill" style="font-size: 2.5rem; opacity: 0.5;"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 mb-3">
                    <div class="card border-0 shadow-sm bg-info text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="mb-1 opacity-75">Lives Saved</p>
                                    <h3 class="mb-0 fw-bold">~<?php echo $livesSaved; ?></h3>
                                </div>
                                <i class="bi bi-people-fill" style="font-size: 2.5rem; opacity: 0.5;"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Donations Table -->
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <?php if (count($donations) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover" id="donationsTable">
                                <thead class="table-light">
                                    <tr>
                                        <th>Date</th>
                                        <th>Blood Type</th>
                                        <th>Quantity</th>
                                        <th>Location</th>
                                        <th>Status</th>
                                        <th>Submitted</th>
                                        <th>Notes</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($donations as $donation): ?>
                                        <tr>
                                            <td><?php echo formatDate($donation['donation_date']); ?></td>
                                            <td><span class="badge bg-danger fs-6"><?php echo $donation['blood_type']; ?></span></td>
                                            <td><?php echo $donation['quantity_ml']; ?>ml</td>
                                            <td><small><?php echo htmlspecialchars($donation['donation_location']); ?></small></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $donation['status'] === 'completed' ? 'success' : 
                                                         ($donation['status'] === 'pending' ? 'warning text-dark' : 
                                                         ($donation['status'] === 'approved' ? 'info' : 'danger')); 
                                                ?>">
                                                    <?php echo ucfirst($donation['status']); ?>
                                                </span>
                                            </td>
                                            <td><small><?php echo formatDateTime($donation['created_at']); ?></small></td>
                                            <td>
                                                <?php if (!empty($donation['notes'])): ?>
                                                    <button type="button" class="btn btn-sm btn-outline-secondary" 
                                                            data-bs-toggle="popover" 
                                                            data-bs-trigger="hover"
                                                            data-bs-content="<?php echo htmlspecialchars($donation['notes']); ?>">
                                                        <i class="bi bi-info-circle"></i>
                                                    </button>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-droplet" style="font-size: 5rem; color: #dee2e6;"></i>
                            <h4 class="mt-3 text-muted">No Donations Yet</h4>
                            <p class="text-muted">Start saving lives by making your first donation!</p>
                            <a href="donate.php" class="btn btn-danger">
                                <i class="bi bi-droplet-fill me-2"></i>Donate Now
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Achievement Section -->
            <?php if ($totalDonations > 0): ?>
            <div class="row mt-4">
                <div class="col-md-12">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title fw-bold mb-4">
                                <i class="bi bi-trophy-fill text-warning me-2"></i>Your Achievements
                            </h5>
                            <div class="row text-center">
                                <?php if ($totalDonations >= 1): ?>
                                <div class="col-md-3 mb-3">
                                    <div class="p-3 border rounded">
                                        <i class="bi bi-award-fill text-success" style="font-size: 3rem;"></i>
                                        <h6 class="mt-2">First Timer</h6>
                                        <small class="text-muted">Made your first donation</small>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <?php if ($totalDonations >= 5): ?>
                                <div class="col-md-3 mb-3">
                                    <div class="p-3 border rounded">
                                        <i class="bi bi-heart-fill text-danger" style="font-size: 3rem;"></i>
                                        <h6 class="mt-2">Life Saver</h6>
                                        <small class="text-muted">5 donations completed</small>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <?php if ($totalDonations >= 10): ?>
                                <div class="col-md-3 mb-3">
                                    <div class="p-3 border rounded">
                                        <i class="bi bi-star-fill text-warning" style="font-size: 3rem;"></i>
                                        <h6 class="mt-2">Hero</h6>
                                        <small class="text-muted">10 donations completed</small>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <?php if ($totalDonations >= 20): ?>
                                <div class="col-md-3 mb-3">
                                    <div class="p-3 border rounded">
                                        <i class="bi bi-gem text-primary" style="font-size: 3rem;"></i>
                                        <h6 class="mt-2">Legend</h6>
                                        <small class="text-muted">20+ donations completed</small>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </main>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
$(document).ready(function() {
    $('#donationsTable').DataTable({
        "order": [[0, "desc"]],
        "pageLength": 25
    });
    
    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
});
</script>

<?php include 'includes/footer.php'; ?>
