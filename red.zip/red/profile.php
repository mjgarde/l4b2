<?php
/**
 * User Profile Page
 * View and edit profile information
 */

require_once 'config/config.php';
require_once 'config/db.php';

requireLogin();

$userId = $_SESSION['user_id'];
$error = '';
$success = '';

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    if (!validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        $fullName = sanitize($_POST['full_name']);
        $email = sanitize($_POST['email']);
        $phone = sanitize($_POST['phone']);
        $address = sanitize($_POST['address']);
        $bloodTypeId = intval($_POST['blood_type_id']);
        
        if (!validateEmail($email)) {
            $error = 'Invalid email format';
        } elseif (!empty($phone) && !validatePhone($phone)) {
            $error = 'Invalid phone number format';
        } else {
            try {
                $updateSql = "UPDATE users SET full_name = :full_name, email = :email, 
                             phone = :phone, address = :address, blood_type_id = :blood_type_id 
                             WHERE user_id = :user_id";
                $stmt = $db->prepare($updateSql);
                $result = $stmt->execute([
                    ':full_name' => $fullName,
                    ':email' => $email,
                    ':phone' => $phone,
                    ':address' => $address,
                    ':blood_type_id' => $bloodTypeId > 0 ? $bloodTypeId : null,
                    ':user_id' => $userId
                ]);
                
                if ($result) {
                    $_SESSION['full_name'] = $fullName;
                    $_SESSION['email'] = $email;
                    
                    logAudit($db, $userId, 'Profile Updated', 'users', $userId, 'User updated profile information');
                    $success = 'Profile updated successfully!';
                }
            } catch(PDOException $e) {
                $error = 'Error updating profile: ' . $e->getMessage();
            }
        }
    }
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    if (!validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        $currentPassword = $_POST['current_password'];
        $newPassword = $_POST['new_password'];
        $confirmPassword = $_POST['confirm_password'];
        
        if (strlen($newPassword) < PASSWORD_MIN_LENGTH) {
            $error = 'New password must be at least ' . PASSWORD_MIN_LENGTH . ' characters';
        } elseif ($newPassword !== $confirmPassword) {
            $error = 'New passwords do not match';
        } else {
            try {
                // Verify current password
                $verifySql = "SELECT password_hash FROM users WHERE user_id = :user_id";
                $stmt = $db->prepare($verifySql);
                $stmt->execute([':user_id' => $userId]);
                $user = $stmt->fetch();
                
                if (verifyPassword($currentPassword, $user['password_hash'])) {
                    $newHash = hashPassword($newPassword);
                    $updateSql = "UPDATE users SET password_hash = :password_hash WHERE user_id = :user_id";
                    $stmt = $db->prepare($updateSql);
                    $result = $stmt->execute([
                        ':password_hash' => $newHash,
                        ':user_id' => $userId
                    ]);
                    
                    if ($result) {
                        logAudit($db, $userId, 'Password Changed', 'users', $userId, 'User changed password');
                        $success = 'Password changed successfully!';
                    }
                } else {
                    $error = 'Current password is incorrect';
                }
            } catch(PDOException $e) {
                $error = 'Error changing password: ' . $e->getMessage();
            }
        }
    }
}

// Get user data
try {
    $userSql = "SELECT u.*, bt.blood_type FROM users u 
                LEFT JOIN blood_types bt ON u.blood_type_id = bt.blood_type_id 
                WHERE u.user_id = :user_id";
    $stmt = $db->prepare($userSql);
    $stmt->execute([':user_id' => $userId]);
    $user = $stmt->fetch();
} catch(PDOException $e) {
    $user = null;
}

// Get blood types
try {
    $bloodTypesSql = "SELECT * FROM blood_types ORDER BY blood_type";
    $stmt = $db->prepare($bloodTypesSql);
    $stmt->execute();
    $bloodTypes = $stmt->fetchAll();
} catch(PDOException $e) {
    $bloodTypes = [];
}

$pageTitle = 'My Profile';
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include 'includes/user_sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="bi bi-person-circle text-white-2"></i>My Profile</h1>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="bi bi-check-circle-fill me-2"></i><?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="row">
                <!-- Profile Information -->
                <div class="col-md-8">
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-header bg-white">
                            <h5 class="mb-0 fw-bold">Profile Information</h5>
                        </div>
                        <div class="card-body p-4">
                            <form method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label text-white">Username</label>
                                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                                        <small class="text-muted">Username cannot be changed</small>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label text-white">Email <span class="text-danger">*</span></label>
                                        <input type="email" class="form-control" name="email" 
                                               value="<?php echo htmlspecialchars($user['email']); ?>" required>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label text-white">Full Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="full_name" 
                                           value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label text-white">Phone Number</label>
                                        <input type="tel" class="form-control" name="phone" 
                                               value="<?php echo htmlspecialchars($user['phone']); ?>" 
                                               placeholder="09XXXXXXXXX">
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label text-white">Blood Type</label>
                                        <select class="form-select" name="blood_type_id">
                                            <option value="">Not Specified</option>
                                            <?php foreach ($bloodTypes as $type): ?>
                                                <option value="<?php echo $type['blood_type_id']; ?>"
                                                        <?php echo $user['blood_type_id'] == $type['blood_type_id'] ? 'selected' : ''; ?>>
                                                    <?php echo $type['blood_type']; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label text-white">Address</label>
                                    <textarea class="form-control" name="address" rows="3"><?php echo htmlspecialchars($user['address']); ?></textarea>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" name="update_profile" class="btn btn-primary">
                                        <i class="bi bi-save me-2 text-white"></i>Save Changes
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Change Password -->
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-white">
                            <h5 class="mb-0 fw-bold text-white">Change Password</h5>
                        </div>
                        <div class="card-body p-4">
                            <form method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">
                                
                                <div class="mb-3">
                                    <label class="form-label text-white">Current Password <span class="text-danger">*</span></label>
                                    <input type="password" class="form-control" name="current_password" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label text-white">New Password <span class="text-danger">*</span></label>
                                    <input type="password" class="form-control" name="new_password" required 
                                           minlength="<?php echo PASSWORD_MIN_LENGTH; ?>">
                                    <small class="text-muted">Minimum <?php echo PASSWORD_MIN_LENGTH; ?> characters</small>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label text-white">Confirm New Password <span class="text-danger">*</span></label>
                                    <input type="password" class="form-control" name="confirm_password" required>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" name="change_password" class="btn btn-danger">
                                        <i class="bi bi-key me-2"></i>Change Password
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Profile Summary -->
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body text-center p-4">
                            <div class="mb-3">
                                <i class="bi bi-person-circle text-primary" style="font-size: 5rem;"></i>
                            </div>
                            <h4 class="fw-bold"><?php echo htmlspecialchars($user['full_name']); ?></h4>
                            <p class="text-muted mb-2">@<?php echo htmlspecialchars($user['username']); ?></p>
                            <?php if ($user['blood_type']): ?>
                                <span class="badge bg-danger fs-5"><?php echo $user['blood_type']; ?></span>
                            <?php endif; ?>
                            <hr>
                            <div class="text-start">
                                <p class="mb-1"><i class="bi bi-envelope me-2"></i><small><?php echo htmlspecialchars($user['email']); ?></small></p>
                                <?php if ($user['phone']): ?>
                                    <p class="mb-1"><i class="bi bi-phone me-2"></i><small><?php echo htmlspecialchars($user['phone']); ?></small></p>
                                <?php endif; ?>
                                <p class="mb-1"><i class="bi bi-shield-check me-2"></i><small>Account: <?php echo ucfirst($user['status']); ?></small></p>
                                <p class="mb-0"><i class="bi bi-calendar me-2"></i><small>Joined: <?php echo formatDate($user['created_at']); ?></small></p>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h6 class="fw-bold mb-3 text-white">Quick Actions</h6>
                            <div class="d-grid gap-2">
                                <a href="donate.php" class="btn btn-danger btn-sm">
                                    <i class="bi bi-droplet-fill me-2"></i>Donate Blood
                                </a>
                                <a href="request.php" class="btn btn-primary btn-sm">
                                    <i class="bi bi-bandaid me-2"></i>Request Blood
                                </a>
                                <a href="notifications.php" class="btn btn-info btn-sm">
                                    <i class="bi bi-bell me-2"></i>View Notifications
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
