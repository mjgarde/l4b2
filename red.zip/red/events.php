<?php
require_once 'config/config.php';
require_once 'config/db.php';

// Require login
requireLogin();

$success = $error = '';

// Handle event registration
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register_event'])) {
    if (!validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        $eventId = intval($_POST['event_id']);
        $userId = $_SESSION['user_id'];
        
        try {
            // Check if already registered
            $checkSql = "SELECT * FROM appointments WHERE user_id = :user_id AND event_id = :event_id";
            $checkStmt = $db->prepare($checkSql);
            $checkStmt->execute([':user_id' => $userId, ':event_id' => $eventId]);
            
            if ($checkStmt->rowCount() > 0) {
                $error = 'You are already registered for this event!';
            } else {
                // Check event capacity
                $eventSql = "SELECT e.*, (SELECT COUNT(*) FROM appointments WHERE event_id = e.event_id) as registered 
                            FROM events e WHERE e.event_id = :event_id";
                $eventStmt = $db->prepare($eventSql);
                $eventStmt->execute([':event_id' => $eventId]);
                $event = $eventStmt->fetch();
                
                if ($event['registered'] >= $event['max_participants']) {
                    $error = 'Sorry, this event is already full!';
                } else {
                    // Register for event
                    $insertSql = "INSERT INTO appointments (user_id, event_id, appointment_date, appointment_time, purpose, status) 
                                 VALUES (:user_id, :event_id, :date, '09:00:00', 'donation', 'scheduled')";
                    $insertStmt = $db->prepare($insertSql);
                    $result = $insertStmt->execute([
                        ':user_id' => $userId,
                        ':event_id' => $eventId,
                        ':date' => $event['event_date']
                    ]);
                    
                    if ($result) {
                        // Update event participant count
                        $db->prepare("UPDATE events SET current_participants = current_participants + 1 WHERE event_id = ?")->execute([$eventId]);
                        
                        // Create notification
                        createNotification($db, $userId, 'Event Registration Confirmed', 
                            "You have successfully registered for: " . $event['event_name'], 'success');
                        
                        logAudit($db, $userId, 'Event Registration', 'appointments', $db->lastInsertId(), 
                            "Registered for event: " . $event['event_name']);
                        
                        $success = 'Successfully registered for the event!';
                    }
                }
            }
        } catch(PDOException $e) {
            $error = 'Error: ' . $e->getMessage();
        }
    }
}

// Handle unregister
if (isset($_GET['unregister'])) {
    $appointmentId = intval($_GET['unregister']);
    $userId = $_SESSION['user_id'];
    
    try {
        // Get appointment details
        $apt = $db->query("SELECT a.*, e.event_name FROM appointments a JOIN events e ON a.event_id = e.event_id WHERE a.appointment_id = $appointmentId AND a.user_id = $userId")->fetch();
        
        if ($apt) {
            $db->prepare("DELETE FROM appointments WHERE appointment_id = ? AND user_id = ?")->execute([$appointmentId, $userId]);
            $db->prepare("UPDATE events SET current_participants = current_participants - 1 WHERE event_id = ?")->execute([$apt['event_id']]);
            
            createNotification($db, $userId, 'Event Registration Cancelled', 
                "You have cancelled your registration for: " . $apt['event_name'], 'info');
            
            $success = 'Registration cancelled successfully';
        }
    } catch(PDOException $e) {
        $error = 'Error: ' . $e->getMessage();
    }
}

// Get upcoming events
$upcomingEvents = $db->query("SELECT e.*, 
       (SELECT COUNT(*) FROM appointments WHERE event_id = e.event_id) as registered_count,
       (SELECT COUNT(*) FROM appointments WHERE event_id = e.event_id AND user_id = {$_SESSION['user_id']}) as user_registered
       FROM events e 
       WHERE e.status = 'upcoming' AND e.event_date >= CURDATE()
       ORDER BY e.event_date ASC")->fetchAll();

// Get ongoing events
$ongoingEvents = $db->query("SELECT e.*, 
       (SELECT COUNT(*) FROM appointments WHERE event_id = e.event_id) as registered_count,
       (SELECT COUNT(*) FROM appointments WHERE event_id = e.event_id AND user_id = {$_SESSION['user_id']}) as user_registered
       FROM events e 
       WHERE e.status = 'ongoing'
       ORDER BY e.event_date ASC")->fetchAll();

// Get user's registered events
$myEvents = $db->prepare("SELECT e.*, a.appointment_id, a.status as appointment_status, a.created_at as registered_at
             FROM appointments a 
             JOIN events e ON a.event_id = e.event_id 
             WHERE a.user_id = :user_id AND e.status IN ('upcoming', 'ongoing')
             ORDER BY e.event_date ASC");
$myEvents->execute([':user_id' => $_SESSION['user_id']]);
$myRegisteredEvents = $myEvents->fetchAll();

$pageTitle = 'Blood Donation Events';
include 'includes/header.php';
?>

<style>
body { background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); min-height: 100vh; }
.page-header-3d { background: linear-gradient(135deg, #28a745, #20c997); color: #fff; padding: 40px; border-radius: 20px; margin-bottom: 30px; box-shadow: 0 15px 40px rgba(40,167,69,0.3); }
.event-card-3d { background: #fff; border-radius: 20px; padding: 30px; margin-bottom: 25px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); transition: all 0.3s; border-left: 5px solid #28a745; }
.event-card-3d:hover { transform: translateY(-5px); box-shadow: 0 15px 40px rgba(0,0,0,0.15); }
.event-icon-3d { width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, #28a745, #20c997); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 2.5rem; box-shadow: 0 8px 20px rgba(40,167,69,0.4); }
.btn-3d { border-radius: 12px; padding: 12px 30px; font-weight: 600; transition: all 0.3s; border: none; box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
.btn-3d:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(0,0,0,0.3); }
.progress-bar-3d { height: 8px; border-radius: 10px; background: #e9ecef; overflow: hidden; }
.progress-fill { background: linear-gradient(135deg, #28a745, #20c997); height: 100%; transition: width 0.5s ease; border-radius: 10px; }
.badge-3d { padding: 8px 16px; border-radius: 20px; font-weight: 600; font-size: 0.9rem; box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
.stats-box { background: linear-gradient(135deg, #28a745, #20c997); color: #fff; padding: 20px; border-radius: 15px; text-align: center; box-shadow: 0 8px 20px rgba(40,167,69,0.3); }
.stats-number { font-size: 2.5rem; font-weight: 800; }
.back-button { background: #fff; color: #333; font-weight: 600; border: 2px solid #dee2e6; transition: all 0.3s; }
.back-button:hover { background: #28a745; color: #fff; border-color: #28a745; transform: translateX(-3px); box-shadow: 0 5px 15px rgba(40,167,69,0.3); }
</style>

<div class="container py-4">
    <!-- Back Button -->
    <div class="mb-3">
        <a href="dashboard.php" class="btn back-button" style="border-radius: 10px; padding: 10px 24px; font-size: 0.95rem;">
            <i class="bi bi-arrow-left me-2"></i>Back to Dashboard
        </a>
    </div>
    
    <!-- Page Header -->
    <div class="page-header-3d">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 style="font-weight: 800"><i class="bi bi-calendar-event me-3"></i>Blood Donation Events</h1>
                <p class="mb-0 mt-2">Register for upcoming blood donation drives and events</p>
            </div>
            <div class="event-icon-3d">
                <i class="bi bi-calendar-heart"></i>
            </div>
        </div>
    </div>

    <?php if($success): ?>
    <div class="alert alert-success alert-dismissible fade show" style="border-radius:15px;border:none;box-shadow:0 5px 15px rgba(25,135,84,0.3)">
        <i class="bi bi-check-circle-fill me-2"></i><?=$success?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; if($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" style="border-radius:15px;border:none;box-shadow:0 5px 15px rgba(220,53,69,0.3)">
        <i class="bi bi-exclamation-triangle-fill me-2"></i><?=$error?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- My Registered Events -->
    <?php if(count($myRegisteredEvents) > 0): ?>
    <div class="mb-4">
        <h4 style="font-weight: 700; margin-bottom: 20px"><i class="bi bi-bookmark-check-fill me-2" style="color: #28a745"></i>My Registered Events</h4>
        <div class="row">
            <?php foreach($myRegisteredEvents as $event): 
            $percentage = $event['max_participants'] > 0 ? round((($event['registered_count'] ?? 0) / $event['max_participants']) * 100) : 0;
            $daysUntil = floor((strtotime($event['event_date']) - time()) / 86400);
            ?>
            <div class="col-md-6">
                <div class="event-card-3d" style="border-left-color: #20c997">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <h5 style="font-weight: 700; color: #28a745"><?=htmlspecialchars($event['event_name'])?></h5>
                        <span class="badge badge-3d bg-success">Registered</span>
                    </div>
                    <p class="text-muted mb-3"><?=htmlspecialchars($event['event_description'])?></p>
                    
                    <div class="row mb-3">
                        <div class="col-6">
                            <small class="text-muted"><i class="bi bi-calendar3 me-1"></i>Date</small><br>
                            <strong><?=date('M j, Y', strtotime($event['event_date']))?></strong>
                            <?php if($daysUntil >= 0): ?>
                            <br><small class="text-success">in <?=$daysUntil?> days</small>
                            <?php endif; ?>
                        </div>
                        <div class="col-6">
                            <small class="text-muted"><i class="bi bi-geo-alt me-1"></i>Location</small><br>
                            <strong><?=htmlspecialchars($event['event_location'])?></strong>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <small class="text-muted">Participants: <strong><?=$event['registered_count']?> / <?=$event['max_participants']?></strong></small>
                            <small class="text-muted"><?=$percentage?>%</small>
                        </div>
                        <div class="progress-bar-3d">
                            <div class="progress-fill" style="width: <?=$percentage?>%"></div>
                        </div>
                    </div>
                    
                    <div class="d-flex gap-2">
                        <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#view<?=$event['event_id']?>">
                            <i class="bi bi-eye me-1"></i>View Details
                        </button>
                        <a href="?unregister=<?=$event['appointment_id']?>" class="btn btn-danger btn-sm" onclick="return confirm('Cancel registration?')">
                            <i class="bi bi-x-circle me-1"></i>Cancel Registration
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Ongoing Events -->
    <?php if(count($ongoingEvents) > 0): ?>
    <div class="mb-4">
        <h4 style="font-weight: 700; margin-bottom: 20px"><i class="bi bi-calendar-check me-2" style="color: #ffc107"></i>Ongoing Events</h4>
        <div class="row">
            <?php foreach($ongoingEvents as $event): 
            $percentage = $event['max_participants'] > 0 ? round(($event['registered_count'] / $event['max_participants']) * 100) : 0;
            ?>
            <div class="col-md-6">
                <div class="event-card-3d" style="border-left-color: #ffc107">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <h5 style="font-weight: 700; color: #ffc107"><?=htmlspecialchars($event['event_name'])?></h5>
                        <span class="badge badge-3d bg-warning text-dark">Ongoing</span>
                    </div>
                    <p class="text-muted mb-3"><?=htmlspecialchars($event['event_description'])?></p>
                    
                    <div class="row mb-3">
                        <div class="col-6">
                            <small class="text-muted"><i class="bi bi-calendar3 me-1"></i>Date</small><br>
                            <strong><?=date('M j, Y', strtotime($event['event_date']))?></strong>
                        </div>
                        <div class="col-6">
                            <small class="text-muted"><i class="bi bi-geo-alt me-1"></i>Location</small><br>
                            <strong><?=htmlspecialchars($event['event_location'])?></strong>
                        </div>
                    </div>
                    
                    <button class="btn btn-info btn-sm w-100" data-bs-toggle="modal" data-bs-target="#view<?=$event['event_id']?>">
                        <i class="bi bi-eye me-1"></i>View Details
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Upcoming Events -->
    <div class="mb-4">
        <h4 style="font-weight: 700; margin-bottom: 20px"><i class="bi bi-calendar-plus me-2" style="color: #28a745"></i>Upcoming Events</h4>
        <?php if(count($upcomingEvents) > 0): ?>
        <div class="row">
            <?php foreach($upcomingEvents as $event): 
            $percentage = $event['max_participants'] > 0 ? round(($event['registered_count'] / $event['max_participants']) * 100) : 0;
            $isFull = $event['registered_count'] >= $event['max_participants'];
            $isRegistered = $event['user_registered'] > 0;
            $daysUntil = floor((strtotime($event['event_date']) - time()) / 86400);
            ?>
            <div class="col-md-6 col-lg-4">
                <div class="event-card-3d">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <h5 style="font-weight: 700; color: #28a745"><?=htmlspecialchars($event['event_name'])?></h5>
                        <?php if($isRegistered): ?>
                        <span class="badge badge-3d bg-success"><i class="bi bi-check me-1"></i>Joined</span>
                        <?php elseif($isFull): ?>
                        <span class="badge badge-3d bg-danger">Full</span>
                        <?php endif; ?>
                    </div>
                    
                    <p class="text-muted mb-3"><?=htmlspecialchars(substr($event['event_description'], 0, 100))?>...</p>
                    
                    <div class="row mb-3">
                        <div class="col-12 mb-2">
                            <small class="text-muted"><i class="bi bi-calendar3 me-1"></i>Date</small><br>
                            <strong><?=date('M j, Y', strtotime($event['event_date']))?></strong>
                            <br><small class="text-success fw-bold">in <?=$daysUntil?> days</small>
                        </div>
                        <div class="col-12 mb-2">
                            <small class="text-muted"><i class="bi bi-geo-alt me-1"></i>Location</small><br>
                            <strong><?=htmlspecialchars($event['event_location'])?></strong>
                        </div>
                        <div class="col-12">
                            <small class="text-muted"><i class="bi bi-person me-1"></i>Organizer</small><br>
                            <strong><?=htmlspecialchars($event['organizer'])?></strong>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <small class="text-muted">Participants</small>
                            <small><strong><?=$event['registered_count']?></strong> / <?=$event['max_participants']?> (<?=$percentage?>%)</small>
                        </div>
                        <div class="progress-bar-3d">
                            <div class="progress-fill" style="width: <?=$percentage?>%; background: <?=$percentage>=80?'linear-gradient(135deg, #dc3545, #ff6b6b)':'linear-gradient(135deg, #28a745, #20c997)'?>"></div>
                        </div>
                    </div>
                    
                    <div class="d-flex gap-2">
                        <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#view<?=$event['event_id']?>">
                            <i class="bi bi-eye me-1"></i>Details
                        </button>
                        <?php if(!$isRegistered && !$isFull): ?>
                        <button class="btn btn-success btn-sm flex-grow-1" data-bs-toggle="modal" data-bs-target="#register<?=$event['event_id']?>">
                            <i class="bi bi-calendar-check me-1"></i>Register
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- View Modal -->
            <div class="modal fade" id="view<?=$event['event_id']?>">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content" style="border-radius: 20px">
                        <div class="modal-header" style="background: linear-gradient(135deg, #28a745, #20c997); color: #fff; border-radius: 20px 20px 0 0">
                            <h5 class="modal-title"><?=htmlspecialchars($event['event_name'])?></h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <p><strong><i class="bi bi-calendar3 me-2"></i>Date:</strong><br><?=date('l, F j, Y', strtotime($event['event_date']))?></p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong><i class="bi bi-geo-alt me-2"></i>Location:</strong><br><?=htmlspecialchars($event['event_location'])?></p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong><i class="bi bi-person me-2"></i>Organizer:</strong><br><?=htmlspecialchars($event['organizer'])?></p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong><i class="bi bi-people me-2"></i>Capacity:</strong><br><?=$event['registered_count']?> / <?=$event['max_participants']?> participants</p>
                                </div>
                            </div>
                            <hr>
                            <p><strong>Description:</strong></p>
                            <p><?=nl2br(htmlspecialchars($event['event_description']))?></p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Register Modal -->
            <?php if(!$isRegistered && !$isFull): ?>
            <div class="modal fade" id="register<?=$event['event_id']?>">
                <div class="modal-dialog">
                    <div class="modal-content" style="border-radius: 20px">
                        <div class="modal-header" style="background: linear-gradient(135deg, #28a745, #20c997); color: #fff; border-radius: 20px 20px 0 0">
                            <h5 class="modal-title">Register for Event</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <form method="POST">
                            <div class="modal-body">
                                <input type="hidden" name="csrf_token" value="<?=getCSRFToken()?>">
                                <input type="hidden" name="event_id" value="<?=$event['event_id']?>">
                                
                                <h5><?=htmlspecialchars($event['event_name'])?></h5>
                                <p class="text-muted"><?=date('F j, Y', strtotime($event['event_date']))?> at <?=htmlspecialchars($event['event_location'])?></p>
                                
                                <div class="alert alert-info">
                                    <i class="bi bi-info-circle me-2"></i>
                                    By registering, you confirm your attendance for this blood donation event.
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" name="register_event" class="btn btn-success btn-3d">
                                    <i class="bi bi-check-circle me-1"></i>Confirm Registration
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="event-card-3d text-center py-5">
            <i class="bi bi-calendar-x" style="font-size: 5rem; color: #ddd"></i>
            <h4 class="mt-3 text-muted">No Upcoming Events</h4>
            <p class="text-muted">Check back later for new blood donation events</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
