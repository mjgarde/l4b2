<?php
/**
 * Test Document Upload Flow
 * Shows the complete flow from registration to admin approval
 */

require_once 'config/config.php';
require_once 'config/db.php';

echo "<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Document Flow Test</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css'>
    <style>
        body { padding: 30px; background: #f8f9fa; }
        .flow-step { background: white; padding: 20px; margin: 20px 0; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .step-number { background: #007bff; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; margin-right: 15px; }
        .success { background: #d4edda; border-left: 4px solid #28a745; }
        .warning { background: #fff3cd; border-left: 4px solid #ffc107; }
        .error { background: #f8d7da; border-left: 4px solid #dc3545; }
        .info { background: #d1ecf1; border-left: 4px solid #17a2b8; }
        table { background: white; }
        .badge-success { background: #28a745; }
        .badge-warning { background: #ffc107; color: #000; }
        .badge-danger { background: #dc3545; }
    </style>
</head>
<body>
<div class='container'>
    <h1 class='mb-4'><i class='bi bi-diagram-3'></i> Document Upload Flow Test</h1>
    <p class='lead'>Testing the connection from Registration → Database → Admin Approval</p>
    <hr>";

try {
    // STEP 1: Check database structure
    echo "<div class='flow-step'>
            <div class='d-flex align-items-center mb-3'>
                <div class='step-number'>1</div>
                <h3 class='mb-0'>Database Structure Check</h3>
            </div>";
    
    $tableCheck = $db->query("SHOW TABLES LIKE 'user_documents'")->fetch();
    
    if ($tableCheck) {
        echo "<div class='alert success'><i class='bi bi-check-circle'></i> ✅ <strong>user_documents</strong> table exists</div>";
        
        // Get table structure
        $columns = $db->query("SHOW COLUMNS FROM user_documents")->fetchAll();
        echo "<table class='table table-sm'><tr><th>Column</th><th>Type</th></tr>";
        foreach ($columns as $col) {
            echo "<tr><td>" . $col['Field'] . "</td><td>" . $col['Type'] . "</td></tr>";
        }
        echo "</table>";
    } else {
        echo "<div class='alert error'><i class='bi bi-x-circle'></i> ❌ <strong>user_documents</strong> table NOT found</div>";
    }
    
    echo "</div>";
    
    // STEP 2: Check registration page file uploads
    echo "<div class='flow-step'>
            <div class='d-flex align-items-center mb-3'>
                <div class='step-number'>2</div>
                <h3 class='mb-0'>Registration Page Setup</h3>
            </div>";
    
    $registerFile = 'register.php';
    if (file_exists($registerFile)) {
        $registerContent = file_get_contents($registerFile);
        
        $checks = [
            'Medical Certificate Upload' => strpos($registerContent, 'medical_certificate') !== false,
            'Photo ID Upload' => strpos($registerContent, 'photo_id') !== false,
            'Database Insert' => strpos($registerContent, 'user_documents') !== false,
            'Upload Directory' => strpos($registerContent, 'uploads/') !== false
        ];
        
        foreach ($checks as $check => $result) {
            $icon = $result ? 'check-circle' : 'x-circle';
            $class = $result ? 'success' : 'error';
            $status = $result ? '✅' : '❌';
            echo "<div class='alert $class'><i class='bi bi-$icon'></i> $status <strong>$check</strong></div>";
        }
    }
    
    echo "</div>";
    
    // STEP 3: Check upload directories
    echo "<div class='flow-step'>
            <div class='d-flex align-items-center mb-3'>
                <div class='step-number'>3</div>
                <h3 class='mb-0'>Upload Directories</h3>
            </div>";
    
    $directories = [
        'uploads/medical_certificates' => 'Medical Certificates',
        'uploads/profile_photos' => 'Photo IDs / Valid IDs',
        'uploads/documents' => 'General Documents (legacy)'
    ];
    
    foreach ($directories as $dir => $label) {
        $exists = is_dir($dir);
        $writable = $exists ? is_writable($dir) : false;
        
        $icon = $exists ? 'check-circle' : 'x-circle';
        $class = $exists ? 'success' : 'warning';
        $status = $exists ? '✅' : '⚠️';
        
        echo "<div class='alert $class'><i class='bi bi-$icon'></i> $status <strong>$label</strong>: <code>$dir</code>";
        
        if ($exists) {
            $files = glob($dir . '/*.*');
            echo " <span class='badge badge-success'>" . count($files) . " files</span>";
            
            if (!$writable) {
                echo " <span class='badge badge-danger'>NOT WRITABLE</span>";
            }
        } else {
            echo " <span class='badge badge-danger'>NOT FOUND</span>";
        }
        
        echo "</div>";
    }
    
    echo "</div>";
    
    // STEP 4: Check documents in database
    echo "<div class='flow-step'>
            <div class='d-flex align-items-center mb-3'>
                <div class='step-number'>4</div>
                <h3 class='mb-0'>Documents in Database</h3>
            </div>";
    
    $sql = "SELECT d.*, u.full_name, u.username, u.status as user_status 
            FROM user_documents d 
            JOIN users u ON d.user_id = u.user_id 
            ORDER BY d.created_at DESC 
            LIMIT 10";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $documents = $stmt->fetchAll();
    
    if (empty($documents)) {
        echo "<div class='alert warning'><i class='bi bi-exclamation-triangle'></i> ⚠️ No documents found in database. Register a new user to test.</div>";
    } else {
        echo "<div class='alert success'><i class='bi bi-check-circle'></i> ✅ Found " . count($documents) . " document(s)</div>";
        
        echo "<table class='table table-striped'>";
        echo "<tr>
                <th>User</th>
                <th>Status</th>
                <th>Document Type</th>
                <th>File Path</th>
                <th>File Exists?</th>
                <th>Size</th>
              </tr>";
        
        foreach ($documents as $doc) {
            $fileExists = file_exists($doc['file_path']);
            $fileIcon = $fileExists ? '✅' : '❌';
            $userStatusBadge = $doc['user_status'] === 'pending' ? 'badge-warning' : 'badge-success';
            
            echo "<tr>
                    <td><strong>{$doc['full_name']}</strong><br><small>{$doc['username']}</small></td>
                    <td><span class='badge $userStatusBadge'>{$doc['user_status']}</span></td>
                    <td>{$doc['document_type']}</td>
                    <td><small>{$doc['file_path']}</small></td>
                    <td>$fileIcon</td>
                    <td>" . number_format($doc['file_size'] / 1024, 2) . " KB</td>
                  </tr>";
        }
        
        echo "</table>";
    }
    
    echo "</div>";
    
    // STEP 5: Check admin page
    echo "<div class='flow-step'>
            <div class='d-flex align-items-center mb-3'>
                <div class='step-number'>5</div>
                <h3 class='mb-0'>Admin Approval Page</h3>
            </div>";
    
    $adminFile = 'admin/user_approvals.php';
    if (file_exists($adminFile)) {
        $adminContent = file_get_contents($adminFile);
        
        $checks = [
            'Fetches user_documents' => strpos($adminContent, 'user_documents') !== false,
            'Displays Medical Certificate' => strpos($adminContent, 'medical_certificate') !== false,
            'Displays Photo ID' => strpos($adminContent, 'id_card') !== false || strpos($adminContent, 'Photo ID') !== false,
            'View Button' => strpos($adminContent, 'view-document-btn') !== false,
            'Image Preview Modal' => strpos($adminContent, 'imagePreviewModal') !== false
        ];
        
        foreach ($checks as $check => $result) {
            $icon = $result ? 'check-circle' : 'x-circle';
            $class = $result ? 'success' : 'error';
            $status = $result ? '✅' : '❌';
            echo "<div class='alert $class'><i class='bi bi-$icon'></i> $status <strong>$check</strong></div>";
        }
    }
    
    echo "</div>";
    
    // STEP 6: Summary
    echo "<div class='flow-step info'>
            <h3><i class='bi bi-clipboard-check'></i> Flow Summary</h3>
            <ol class='mb-0'>
                <li><strong>User registers</strong> → Uploads Medical Certificate & Photo ID → <code>register.php</code></li>
                <li><strong>Files saved</strong> → <code>uploads/medical_certificates/</code> & <code>uploads/profile_photos/</code></li>
                <li><strong>Database record</strong> → <code>user_documents</code> table (with file paths)</li>
                <li><strong>Admin reviews</strong> → <code>admin/user_approvals.php</code></li>
                <li><strong>Admin clicks View</strong> → Modal opens showing uploaded image</li>
            </ol>
          </div>";
    
    // Action buttons
    echo "<div class='text-center mt-4'>
            <a href='register.php' class='btn btn-primary btn-lg me-2'><i class='bi bi-person-plus'></i> Test Registration</a>
            <a href='admin/user_approvals.php' class='btn btn-success btn-lg'><i class='bi bi-shield-check'></i> Go to Admin Approvals</a>
          </div>";
    
} catch(PDOException $e) {
    echo "<div class='alert error'>❌ Database Error: " . $e->getMessage() . "</div>";
}

echo "</div>
</body>
</html>";
?>
