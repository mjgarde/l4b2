<?php
/**
 * Test View Button Connection
 * Debug kung bakit hindi gumagana ang VIEW button
 */

require_once 'config/config.php';
require_once 'config/db.php';

echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>Test View Button</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css'>
</head>
<body class='p-4'>
<div class='container'>
    <h2>🔍 Testing View Button Connection</h2>
    <hr>";

try {
    // Get Kien Balais documents
    $sql = "SELECT d.*, u.full_name, u.username 
            FROM user_documents d 
            JOIN users u ON d.user_id = u.user_id 
            WHERE u.username = 'kbalais' OR u.full_name LIKE '%Kien%'
            ORDER BY d.document_type";
    
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $documents = $stmt->fetchAll();
    
    if (empty($documents)) {
        echo "<div class='alert alert-warning'>⚠️ No documents found for Kien Balais</div>";
        
        // Show all users with documents
        echo "<h4>All Users with Documents:</h4>";
        $allSql = "SELECT DISTINCT u.username, u.full_name 
                   FROM users u 
                   JOIN user_documents d ON u.user_id = d.user_id";
        $allStmt = $db->prepare($allSql);
        $allStmt->execute();
        $allUsers = $allStmt->fetchAll();
        
        foreach ($allUsers as $user) {
            echo "<li>{$user['full_name']} (@{$user['username']})</li>";
        }
    } else {
        echo "<div class='alert alert-success'>✅ Found " . count($documents) . " document(s) for Kien Balais</div>";
        
        foreach ($documents as $doc) {
            echo "<div class='card mb-4'>
                    <div class='card-header bg-primary text-white'>
                        <h5>Document: " . htmlspecialchars($doc['document_type']) . "</h5>
                    </div>
                    <div class='card-body'>";
            
            echo "<table class='table'>
                    <tr><th>User:</th><td>{$doc['full_name']} (@{$doc['username']})</td></tr>
                    <tr><th>File Name:</th><td>{$doc['file_name']}</td></tr>
                    <tr><th>File Path (DB):</th><td><code>{$doc['file_path']}</code></td></tr>
                    <tr><th>File Size:</th><td>" . number_format($doc['file_size'] / 1024, 2) . " KB</td></tr>";
            
            // Check if file exists
            $fullPath = $doc['file_path'];
            $fileExists = file_exists($fullPath);
            
            echo "<tr><th>File Exists?:</th><td>";
            if ($fileExists) {
                echo "<span class='badge bg-success'>✅ YES</span>";
                
                // Get file extension
                $ext = strtolower(pathinfo($fullPath, PATHINFO_EXTENSION));
                $isImage = in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp']);
                
                echo "<br><strong>Extension:</strong> $ext";
                echo "<br><strong>Is Image?:</strong> " . ($isImage ? 'YES' : 'NO');
                
                // Show image preview
                if ($isImage) {
                    echo "<br><br><strong>Preview:</strong><br>";
                    echo "<img src='$fullPath' style='max-width: 300px; border: 2px solid #ccc; border-radius: 8px;'>";
                }
                
                // Show what the VIEW button data would be
                echo "<br><br><strong>View Button Data:</strong>";
                echo "<pre>";
                echo "data-file-path=\"$fullPath\"\n";
                echo "data-file-name=\"" . ($doc['document_type'] === 'medical_certificate' ? 'Medical Certificate' : 'Photo ID') . "\"";
                echo "</pre>";
                
            } else {
                echo "<span class='badge bg-danger'>❌ NO</span>";
                echo "<br><small class='text-danger'>File not found at: $fullPath</small>";
                
                // Try to find the file
                echo "<br><br><strong>Searching for file...</strong>";
                
                $searchDirs = [
                    'uploads/medical_certificates/',
                    'uploads/profile_photos/',
                    'uploads/documents/'
                ];
                
                $fileName = basename($fullPath);
                foreach ($searchDirs as $dir) {
                    if (is_dir($dir)) {
                        $files = glob($dir . '*.*');
                        echo "<br>📁 $dir (" . count($files) . " files)";
                        
                        foreach ($files as $file) {
                            if (basename($file) === $fileName) {
                                echo "<br>&nbsp;&nbsp;&nbsp;✅ FOUND: <code>$file</code>";
                            }
                        }
                    }
                }
            }
            
            echo "</td></tr></table>";
            
            // Test the VIEW button
            if ($fileExists && $isImage) {
                echo "<button class='btn btn-primary view-test-btn' 
                        data-file-path='$fullPath'
                        data-file-name='" . ($doc['document_type'] === 'medical_certificate' ? 'Medical Certificate' : 'Photo ID') . "'>
                        <i class='bi bi-eye'></i> TEST VIEW BUTTON
                      </button>";
            }
            
            echo "</div></div>";
        }
    }
    
} catch(PDOException $e) {
    echo "<div class='alert alert-danger'>❌ Error: " . $e->getMessage() . "</div>";
}

echo "</div>

<!-- Test Modal -->
<div class='modal fade' id='testModal' tabindex='-1'>
    <div class='modal-dialog modal-lg modal-dialog-centered'>
        <div class='modal-content'>
            <div class='modal-header bg-info text-white'>
                <h5 class='modal-title' id='testModalTitle'>Document Preview</h5>
                <button type='button' class='btn-close btn-close-white' data-bs-dismiss='modal'></button>
            </div>
            <div class='modal-body text-center'>
                <img id='testImage' src='' style='max-width: 100%; border-radius: 8px;'>
            </div>
            <div class='modal-footer'>
                <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Close</button>
            </div>
        </div>
    </div>
</div>

<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js'></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const modal = new bootstrap.Modal(document.getElementById('testModal'));
    const testImage = document.getElementById('testImage');
    const modalTitle = document.getElementById('testModalTitle');
    
    document.querySelectorAll('.view-test-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const filePath = this.getAttribute('data-file-path');
            const fileName = this.getAttribute('data-file-name');
            
            console.log('Button clicked!');
            console.log('File path:', filePath);
            console.log('File name:', fileName);
            
            modalTitle.textContent = fileName;
            testImage.src = filePath;
            
            modal.show();
        });
    });
    
    testImage.addEventListener('load', function() {
        console.log('✅ Image loaded successfully!');
    });
    
    testImage.addEventListener('error', function() {
        console.error('❌ Image failed to load!');
        this.src = '';
        this.parentElement.innerHTML = '<div class=\"alert alert-danger\">Failed to load image</div>';
    });
});
</script>
</body>
</html>";
?>
