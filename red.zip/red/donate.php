<?php
/**
 * Blood Donation Form
 * Users can submit donation information
 */

require_once 'config/config.php';
require_once 'config/db.php';

requireLogin();

$userId = $_SESSION['user_id'];
$error = '';
$success = '';

// Get user info and donor info
try {
    $userSql = "SELECT u.*, di.donor_id, di.date_of_birth, di.gender, di.weight, 
                di.last_donation_date, di.eligible_to_donate, bt.blood_type, bt.blood_type_id 
                FROM users u 
                LEFT JOIN donors_info di ON u.user_id = di.user_id 
                LEFT JOIN blood_types bt ON di.blood_type_id = bt.blood_type_id 
                WHERE u.user_id = :user_id";
    $stmt = $db->prepare($userSql);
    $stmt->execute([':user_id' => $userId]);
    $user = $stmt->fetch();
} catch(PDOException $e) {
    $error = 'Error loading user information';
}

// Check for completed donations in the last 90 days
$canDonate = true;
$nextDonationDate = null;
$daysSinceLastDonation = null;

if ($user && $user['donor_id']) {
    try {
        $checkSql = "SELECT donation_date 
                     FROM donations 
                     WHERE donor_id = :donor_id 
                     AND status = 'completed' 
                     ORDER BY donation_date DESC 
                     LIMIT 1";
        $stmt = $db->prepare($checkSql);
        $stmt->execute([':donor_id' => $user['donor_id']]);
        $lastCompletedDonation = $stmt->fetch();
        
        if ($lastCompletedDonation) {
            $lastDate = new DateTime($lastCompletedDonation['donation_date']);
            $today = new DateTime();
            $interval = $today->diff($lastDate);
            $daysSinceLastDonation = $interval->days;
            
            if ($daysSinceLastDonation < MIN_DONATION_INTERVAL_DAYS) {
                $canDonate = false;
                $daysRemaining = MIN_DONATION_INTERVAL_DAYS - $daysSinceLastDonation;
                $nextDonationDate = $lastDate->modify('+' . MIN_DONATION_INTERVAL_DAYS . ' days')->format('F j, Y');
            }
        }
    } catch(PDOException $e) {
        // Continue if error
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_donation'])) {
    if (!validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } elseif (!$canDonate) {
        $error = 'You cannot donate blood at this time. You must wait ' . MIN_DONATION_INTERVAL_DAYS . ' days (' . (MIN_DONATION_INTERVAL_DAYS / 30) . ' months) after your last completed donation. Your next eligible donation date is: ' . $nextDonationDate;
    } else {
        $donationDate = sanitize($_POST['donation_date']);
        $quantityMl = intval($_POST['quantity_ml']);
        $location = sanitize($_POST['donation_location']);
        $notes = sanitize($_POST['notes']);
        $bloodTypeId = intval($_POST['blood_type_id']);
        
        // If donor info doesn't exist, create it
        if (!$user['donor_id']) {
            $dob = sanitize($_POST['date_of_birth']);
            $gender = sanitize($_POST['gender']);
            $weight = floatval($_POST['weight']);
            $medicalConditions = sanitize($_POST['medical_conditions']);
            
            // Validate donor eligibility
            $age = calculateAge($dob);
            $eligibility = isDonorEligible(null, $age, $weight);
            
            if (!$eligibility['eligible']) {
                $error = 'You are not eligible to donate: ' . $eligibility['reason'];
            } else {
                try {
                    // Create donor info
                    $insertDonorSql = "INSERT INTO donors_info (user_id, blood_type_id, date_of_birth, gender, weight, medical_conditions, eligible_to_donate) 
                                      VALUES (:user_id, :blood_type_id, :dob, :gender, :weight, :medical_conditions, 'Yes')";
                    $stmt = $db->prepare($insertDonorSql);
                    $stmt->execute([
                        ':user_id' => $userId,
                        ':blood_type_id' => $bloodTypeId,
                        ':dob' => $dob,
                        ':gender' => $gender,
                        ':weight' => $weight,
                        ':medical_conditions' => $medicalConditions
                    ]);
                    
                    $donorId = $db->lastInsertId();
                    
                    // Insert donation
                    $insertDonationSql = "INSERT INTO donations (donor_id, blood_type_id, donation_date, quantity_ml, donation_location, notes, status) 
                                         VALUES (:donor_id, :blood_type_id, :donation_date, :quantity_ml, :location, :notes, 'pending')";
                    $stmt = $db->prepare($insertDonationSql);
                    $stmt->execute([
                        ':donor_id' => $donorId,
                        ':blood_type_id' => $bloodTypeId,
                        ':donation_date' => $donationDate,
                        ':quantity_ml' => $quantityMl,
                        ':location' => $location,
                        ':notes' => $notes
                    ]);
                    
                    // Create notification
                    createNotification($db, $userId, 'Donation Submitted', 
                        'Your blood donation request has been submitted and is pending approval.', 'success');
                    
                    // Log audit
                    logAudit($db, $userId, 'Donation Submitted', 'donations', $db->lastInsertId(), 
                        'User submitted new donation');
                    
                    $success = 'Donation submitted successfully! Awaiting approval.';
                } catch(PDOException $e) {
                    $error = 'Error submitting donation: ' . $e->getMessage();
                }
            }
        } else {
            // Existing donor
            $age = calculateAge($user['date_of_birth']);
            $eligibility = isDonorEligible($user['last_donation_date'], $age, $user['weight']);
            
            if (!$eligibility['eligible']) {
                $error = 'You are not eligible to donate: ' . $eligibility['reason'];
            } else {
                try {
                    $insertDonationSql = "INSERT INTO donations (donor_id, blood_type_id, donation_date, quantity_ml, donation_location, notes, status) 
                                         VALUES (:donor_id, :blood_type_id, :donation_date, :quantity_ml, :location, :notes, 'pending')";
                    $stmt = $db->prepare($insertDonationSql);
                    $stmt->execute([
                        ':donor_id' => $user['donor_id'],
                        ':blood_type_id' => $bloodTypeId,
                        ':donation_date' => $donationDate,
                        ':quantity_ml' => $quantityMl,
                        ':location' => $location,
                        ':notes' => $notes
                    ]);
                    
                    createNotification($db, $userId, 'Donation Submitted', 
                        'Your blood donation request has been submitted and is pending approval.', 'success');
                    
                    logAudit($db, $userId, 'Donation Submitted', 'donations', $db->lastInsertId(), 
                        'User submitted new donation');
                    
                    $success = 'Donation submitted successfully! Awaiting approval.';
                } catch(PDOException $e) {
                    $error = 'Error submitting donation: ' . $e->getMessage();
                }
            }
        }
    }
}

// Get blood types
try {
    $bloodTypesSql = "SELECT * FROM blood_types ORDER BY blood_type";
    $stmt = $db->prepare($bloodTypesSql);
    $stmt->execute();
    $bloodTypes = $stmt->fetchAll();
} catch(PDOException $e) {
    $bloodTypes = [];
}

$pageTitle = 'Donate Blood';
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include 'includes/user_sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="bi bi-droplet-fill text-danger me-2"></i>Donate Blood</h1>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="bi bi-check-circle-fill me-2"></i><?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (!$canDonate && $nextDonationDate): ?>
                <div class="alert alert-warning border-0 shadow-sm">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-exclamation-triangle-fill me-3" style="font-size: 2rem;"></i>
                        <div>
                            <h5 class="alert-heading mb-2">
                                <i class="bi bi-clock-history me-2"></i>Donation Not Yet Available
                            </h5>
                            <p class="mb-2">
                                <strong>You must wait <?php echo MIN_DONATION_INTERVAL_DAYS; ?> days (<?php echo round(MIN_DONATION_INTERVAL_DAYS / 30); ?> months) between blood donations.</strong>
                            </p>
                            <hr>
                            <p class="mb-1">
                                <i class="bi bi-calendar-check me-2"></i>
                                <strong>Last Completed Donation:</strong> 
                                <?php echo $daysSinceLastDonation; ?> days ago
                            </p>
                            <p class="mb-1">
                                <i class="bi bi-calendar-event me-2"></i>
                                <strong>Next Eligible Date:</strong> 
                                <span class="badge bg-primary"><?php echo $nextDonationDate; ?></span>
                            </p>
                            <p class="mb-0 text-muted">
                                <small>
                                    <i class="bi bi-info-circle me-1"></i>
                                    This waiting period is for your health and safety. Regular blood donation helps save lives!
                                </small>
                            </p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-8">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body p-4">
                            <h5 class="card-title fw-bold mb-4 text-white">Blood Donation Form</h5>
                            
                            <form method="POST" action="" id="donationForm">
                                <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">
                                
                                <?php if (!$user['donor_id']): ?>
                                    <div class="alert alert-info">
                                        <i class="bi bi-info-circle me-2"></i>
                                        Since this is your first donation, please provide additional information.
                                    </div>
                                    
                                    <h6 class="fw-bold mb-3 text-white">Donor Information</h6>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label text-white">Date of Birth <span class="text-danger">*</span></label>
                                            <input type="date" class="form-control" name="date_of_birth" required 
                                                   max="<?php echo date('Y-m-d', strtotime('-18 years')); ?>">
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label text-white">Gender <span class="text-danger">*</span></label>
                                            <select class="form-select" name="gender" required>
                                                <option value="">Select Gender</option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                                <option value="Other">Other</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label text-white">Weight (kg) <span class="text-danger">*</span></label>
                                            <input type="number" class="form-control" name="weight" 
                                                   min="<?php echo MIN_DONOR_WEIGHT_KG; ?>" step="0.1" required>
                                            <small class="text-muted text-white">Minimum: <?php echo MIN_DONOR_WEIGHT_KG; ?> kg</small>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label text-white">Blood Type <span class="text-danger">*</span></label>
                                            <select class="form-select" name="blood_type_id" required>
                                                <option value="">Select Blood Type</option>
                                                <?php foreach ($bloodTypes as $type): ?>
                                                    <option value="<?php echo $type['blood_type_id']; ?>">
                                                        <?php echo $type['blood_type']; ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Medical Conditions (if any)</label>
                                        <textarea class="form-control" name="medical_conditions" rows="2" 
                                                  placeholder="List any medical conditions or medications"></textarea>
                                    </div>
                                    
                                    <hr class="my-4">
                                <?php else: ?>
                                    <input type="hidden" name="blood_type_id" value="<?php echo $user['blood_type_id']; ?>">
                                <?php endif; ?>
                                
                                <h6 class="fw-bold mb-3 text-white">Donation Details</h6>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label text-white">Donation Date <span class="text-danger">*</span></label>
                                        <input type="date" class="form-control" name="donation_date" 
                                               value="<?php echo date('Y-m-d'); ?>" required 
                                               max="<?php echo date('Y-m-d'); ?>">
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label text-white">Quantity (ml) <span class="text-danger">*</span></label>
                                        <select class="form-select" name="quantity_ml" required>
                                            <option value="450" selected>450 ml (Standard)</option>
                                            <option value="350">350 ml</option>
                                            <option value="500">500 ml</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label text-white">Donation Location <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="donation_location" 
                                           value="Koronadal Red Cross Center" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label text-white">Additional Notes</label>
                                    <textarea class="form-control" name="notes" rows="3" 
                                              placeholder="Any additional information"></textarea>
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="terms" required>
                                    <label class="form-check-label text-white" for="terms" >
                                        I confirm that all information provided is accurate and I understand the donation process.
                                    </label>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <?php if ($canDonate): ?>
                                        <button type="submit" name="submit_donation" class="btn btn-danger btn-lg">
                                            <i class="bi bi-droplet-fill me-2"></i>Submit Donation
                                        </button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-secondary btn-lg" disabled>
                                            <i class="bi bi-lock-fill me-2"></i>Donation Currently Unavailable
                                        </button>
                                        <div class="alert alert-info mb-0 mt-2">
                                            <i class="bi bi-info-circle me-2"></i>
                                            You can donate again on <strong><?php echo $nextDonationDate; ?></strong>
                                        </div>
                                    <?php endif; ?>
                                    <a href="dashboard.php" class="btn btn-outline-secondary">Back to Dashboard</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h6 class="fw-bold mb-3">Donation Requirements</h6>
                            <ul class="list-unstyled">
                                <li class="mb-2">
                                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                                    Age: <?php echo MIN_DONOR_AGE; ?>-<?php echo MAX_DONOR_AGE; ?> years
                                </li>
                                <li class="mb-2">
                                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                                    Weight: Minimum <?php echo MIN_DONOR_WEIGHT_KG; ?> kg
                                </li>
                                <li class="mb-2">
                                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                                    Wait <?php echo MIN_DONATION_INTERVAL_DAYS; ?> days between donations
                                </li>
                                <li class="mb-2">
                                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                                    Good health condition
                                </li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h6 class="fw-bold mb-3">Benefits of Donating</h6>
                            <ul class="list-unstyled">
                                <li class="mb-2">
                                    <i class="bi bi-heart-fill text-danger me-2"></i>
                                    Save up to 3 lives
                                </li>
                                <li class="mb-2">
                                    <i class="bi bi-heart-fill text-danger me-2"></i>
                                    Free health screening
                                </li>
                                <li class="mb-2">
                                    <i class="bi bi-heart-fill text-danger me-2"></i>
                                    Reduce heart disease risk
                                </li>
                                <li class="mb-2">
                                    <i class="bi bi-heart-fill text-danger me-2"></i>
                                    Feel good helping others
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
