# Koronadal Red Cross Blood Donation and Request System

A comprehensive web-based blood donation and request management system built with PHP, MySQL, HTML, CSS, and JavaScript.

## 🩸 Features

### User Features
- **User Registration & Authentication**: Secure registration with password hashing
- **Blood Donation**: Submit donation requests with eligibility checking
- **Blood Request**: Request blood with urgency levels
- **Dashboard**: View donation history, request status, and notifications
- **Notifications**: Real-time updates on donation and request status
- **Profile Management**: Update personal information and settings
- **Appointments**: Schedule donation appointments
- **Events**: View and register for blood donation events

### Admin Features
- **Complete Dashboard**: Overview of all system statistics
- **User Management**: Manage all registered users
- **Donation Management**: Approve/reject donation submissions
- **Request Management**: Process blood requests
- **Inventory Management**: Track blood stock levels by type
- **Event Management**: Create and manage donation events
- **Appointment Management**: View and manage all appointments
- **Notifications**: Send system-wide or targeted notifications
- **Audit Logs**: Track all system activities
- **Reports**: Generate various reports and analytics

### Security Features
- ✅ Password hashing with bcrypt
- ✅ CSRF token protection
- ✅ SQL injection prevention via PDO prepared statements
- ✅ XSS protection with input sanitization
- ✅ Session timeout management
- ✅ Role-based access control (Admin/User)

### Technical Features
- 📱 Responsive design (mobile, tablet, desktop)
- ⚡ AJAX for dynamic content updates
- 🎨 Modern UI with Bootstrap 5
- 📊 DataTables for advanced table features
- 🔔 Real-time notifications
- 📈 Inventory tracking with expiry alerts
- 🔍 Advanced filtering and search
- 📄 Export functionality

## 📋 Requirements

- **Web Server**: XAMPP (Apache)
- **PHP**: Version 7.4 or higher
- **MySQL**: Version 5.7 or higher
- **Browser**: Modern browser (Chrome, Firefox, Edge, Safari)

## 🚀 Installation Guide

### Step 1: Install XAMPP

1. Download XAMPP from [https://www.apachefriends.org](https://www.apachefriends.org)
2. Install XAMPP on your computer
3. Start Apache and MySQL from XAMPP Control Panel

### Step 2: Setup Project Files

1. Copy the `Koronadal Red Cross` folder to your XAMPP htdocs directory
   - Default path: `C:\xampp\htdocs\`
   - Final path should be: `C:\xampp\htdocs\Koronadal Red Cross\`

### Step 3: Create Database

1. Open phpMyAdmin in your browser: `http://localhost/phpmyadmin`
2. Click on "New" to create a new database
3. Name it: `koronadal_redcross`
4. Click "Create"

### Step 4: Import Database

1. Select the `koronadal_redcross` database
2. Click on "Import" tab
3. Click "Choose File" and select: `database/koronadal_redcross.sql`
4. Click "Go" at the bottom
5. Wait for successful import message

### Step 5: Configure Database Connection

The database configuration is already set for default XAMPP installation:
- **Host**: localhost
- **Database**: koronadal_redcross
- **Username**: root
- **Password**: (empty)

If you have custom settings, edit: `config/config.php`

### Step 6: Access the System

**Homepage**: `http://localhost/Koronadal Red Cross/`

**Admin Login**:
- URL: `http://localhost/Koronadal Red Cross/login.php`
- Username: `admin`
- Password: `admin123`

**User Login**:
- URL: `http://localhost/Koronadal Red Cross/login.php`
- Username: `jdoe`
- Password: `user123`

## 📁 Project Structure

```
Koronadal Red Cross/
│
├── admin/                      # Admin panel pages
│   ├── dashboard.php           # Admin dashboard
│   ├── manage_donations.php    # Donation management (CRUD)
│   ├── manage_requests.php     # Request management (CRUD)
│   ├── manage_inventory.php    # Inventory management (CRUD)
│   ├── manage_users.php        # User management (CRUD)
│   └── ...                     # Other admin pages
│
├── assets/                     # Static assets
│   ├── css/
│   │   ├── style.css           # Main stylesheet
│   │   └── admin.css           # Admin panel styles
│   ├── js/
│   │   └── main.js             # Main JavaScript
│   └── img/                    # Images
│
├── config/                     # Configuration files
│   ├── config.php              # Main configuration
│   ├── db.php                  # Database connection
│   └── functions.php           # Helper functions
│
├── database/                   # Database files
│   └── koronadal_redcross.sql  # Database schema with sample data
│
├── includes/                   # Reusable includes
│   ├── header.php              # User header
│   ├── footer.php              # Footer
│   ├── user_sidebar.php        # User sidebar
│   ├── admin_header.php        # Admin header
│   └── admin_sidebar.php       # Admin sidebar
│
├── api/                        # API endpoints for AJAX
│   ├── submit_donation.php     # Process donation submission
│   ├── submit_request.php      # Process blood request
│   └── ...                     # Other API endpoints
│
├── index.php                   # Landing page
├── login.php                   # Login page
├── register.php                # Registration page
├── logout.php                  # Logout script
├── dashboard.php               # User dashboard
├── donate.php                  # Blood donation form
├── request.php                 # Blood request form
├── donations.php               # User donations list
├── requests.php                # User requests list
├── profile.php                 # User profile
├── notifications.php           # Notifications page
└── README.md                   # This file
```

## 🗄️ Database Schema

The system uses 10 related tables:

1. **blood_types** - Blood type definitions (A+, B+, O-, etc.)
2. **users** - User accounts (admin and regular users)
3. **donors_info** - Donor-specific information
4. **donations** - Blood donation records
5. **requests** - Blood request records
6. **inventory** - Blood inventory/stock management
7. **events** - Blood donation events
8. **appointments** - Donation appointments
9. **notifications** - User notifications
10. **audit_logs** - System activity logs

## 🔐 Default Login Credentials

### Admin Account
- **Username**: admin
- **Email**: admin@koronadalredcross.org
- **Password**: admin123
- **Role**: Administrator

### Sample User Accounts
1. **User 1**:
   - Username: jdoe
   - Email: jdoe@email.com
   - Password: user123
   - Blood Type: A-

2. **User 2**:
   - Username: msmith
   - Email: msmith@email.com
   - Password: user123
   - Blood Type: B+

3. **User 3**:
   - Username: rgarcia
   - Email: rgarcia@email.com
   - Password: user123
   - Blood Type: O+

**⚠️ IMPORTANT**: Change all default passwords after first login!

## 🎯 Usage Guide

### For Regular Users

1. **Register an Account**
   - Navigate to registration page
   - Fill in required information
   - Verify email (if enabled)
   - Login with credentials

2. **Donate Blood**
   - Go to "Donate Blood" from dashboard
   - Fill in donation form
   - System checks eligibility
   - Submit and wait for admin approval
   - Get notification when processed

3. **Request Blood**
   - Go to "Request Blood"
   - Provide patient and requirement details
   - Select urgency level
   - Submit request
   - Track status in dashboard

4. **View History**
   - Check donation history
   - Monitor request status
   - View notifications
   - Access appointments

### For Administrators

1. **Manage Donations**
   - Review pending donations
   - Approve/reject submissions
   - Update donation status
   - Track completed donations

2. **Manage Requests**
   - Process blood requests
   - Check inventory availability
   - Approve urgent requests first
   - Update fulfillment status

3. **Manage Inventory**
   - Monitor blood stock levels
   - Add new inventory batches
   - Track expiry dates
   - Receive low-stock alerts

4. **Manage Users**
   - View all registered users
   - Activate/deactivate accounts
   - Assign roles
   - Monitor user activity

5. **Generate Reports**
   - Export donation records
   - View analytics
   - Print reports
   - Track trends

## 🔧 Configuration

### Email Settings (Optional)
Edit `config/config.php` to configure email notifications:
```php
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-password');
```

### Session Timeout
Adjust session timeout in `config/config.php`:
```php
define('SESSION_TIMEOUT', 3600); // 1 hour in seconds
```

### Donation Requirements
Modify donation requirements in `config/config.php`:
```php
define('MIN_DONATION_INTERVAL_DAYS', 56);
define('MIN_DONOR_WEIGHT_KG', 50);
define('MIN_DONOR_AGE', 18);
define('MAX_DONOR_AGE', 65);
```

## 🛠️ Troubleshooting

### Database Connection Error
- Verify MySQL is running in XAMPP
- Check database credentials in `config/config.php`
- Ensure database `koronadal_redcross` exists

### Page Not Found (404)
- Check project is in correct htdocs folder
- Verify Apache is running
- Use correct URL with spaces encoded or quoted

### CSRF Token Error
- Clear browser cookies
- Refresh the page
- Check session is enabled in PHP

### Cannot Upload Files
- Check PHP upload limits in `php.ini`
- Verify folder permissions
- Increase `upload_max_filesize` and `post_max_size`

## 📱 Browser Compatibility

- ✅ Google Chrome (Recommended)
- ✅ Mozilla Firefox
- ✅ Microsoft Edge
- ✅ Safari
- ⚠️ Internet Explorer (Not supported)

## 🔒 Security Recommendations

1. **Change Default Passwords** immediately
2. **Use Strong Passwords** (mix of letters, numbers, symbols)
3. **Enable HTTPS** in production
4. **Regular Backups** of database
5. **Update PHP** to latest stable version
6. **Limit Admin Access** to trusted users only
7. **Monitor Audit Logs** regularly
8. **Keep XAMPP Updated**

## 📊 System Requirements (Recommended)

- **RAM**: 4GB minimum, 8GB recommended
- **Storage**: 500MB free space
- **Processor**: Dual-core 2GHz or higher
- **Internet**: Broadband connection (for CDN assets)

## 🆘 Support

For issues or questions:
1. Check documentation
2. Review troubleshooting section
3. Check audit logs for errors
4. Contact system administrator

## 📝 License

This project is created for educational purposes for the Koronadal Red Cross chapter.

## 👥 Credits

- **Developed By**: Full-Stack Development Team
- **Framework**: Bootstrap 5
- **Icons**: Bootstrap Icons
- **Database**: MySQL
- **Server**: Apache (XAMPP)

## 🔄 Version History

- **v1.0.0** (2024-11-01)
  - Initial release
  - Complete user and admin functionality
  - Database with 10 tables
  - Responsive design
  - Security features implemented

## 📋 Future Enhancements

- SMS notifications
- Email notifications
- PDF report generation
- Advanced analytics dashboard
- Mobile app integration
- QR code for donors
- Automated inventory alerts
- Multi-language support

---

**Note**: This system is designed for local deployment using XAMPP. For production deployment, additional security measures and server configuration are required.

## 🎓 Quick Start Checklist

- [ ] XAMPP installed and running
- [ ] Database created and imported
- [ ] Project files in htdocs
- [ ] Admin login successful
- [ ] Sample user login tested
- [ ] Donation form tested
- [ ] Request form tested
- [ ] Default passwords changed
- [ ] System configured

**Ready to use!** 🚀

For detailed video tutorials, check the documentation folder or contact your system administrator.
