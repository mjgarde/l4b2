=====================================
UPLOADS FOLDER - User Documents
=====================================

This folder stores uploaded documents from user registration:
- Medical Certificates (PDF, JPG, PNG)
- Valid IDs / Photo IDs (JPG, PNG)

File Naming Convention:
-------------------------------------
medical_cert_{username}_{timestamp}.{ext}
valid_id_{username}_{timestamp}.{ext}

Example:
medical_cert_jdoe_1698567890.pdf
valid_id_jdoe_1698567890.jpg

Security:
-------------------------------------
- Files should not be directly accessible via browser
- Use PHP to serve files with proper authentication
- Validate file types before upload
- Scan for viruses (recommended)

Size Limits:
-------------------------------------
- Max file size: 5MB per file
- Allowed types: PDF, JPG, PNG, JPEG

Current Status:
-------------------------------------
This is a placeholder folder.
Sample data in database uses fake paths.
Real uploads from registration form will be stored here.

=====================================
