<?php
/**
 * Keep Alive Script
 * Prevents session timeout by updating last activity
 */

session_start();

if (isset($_SESSION['user_id'])) {
    $_SESSION['last_activity'] = time();
    echo json_encode(['success' => true, 'message' => 'Session renewed']);
} else {
    echo json_encode(['success' => false, 'message' => 'No active session']);
}
?>
