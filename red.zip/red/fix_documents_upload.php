<?php
/**
 * Fix Documents Upload - Diagnostic & Repair Tool
 * Para ma-check kung bakit hindi nag-save ang documents
 */

require_once 'config/config.php';
require_once 'config/db.php';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Fix Documents Upload</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
    <style>
        body { padding: 20px; font-family: monospace; }
        .success { color: green; }
        .error { color: red; }
        .warning { color: orange; }
        .info { color: blue; }
        .code-box { background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0; }
    </style>
</head>
<body>
<div class='container'>
<h2>🔧 Document Upload Diagnostic Tool</h2>
<hr>";

// Step 1: Check if user_documents table exists
echo "<h4>STEP 1: Checking user_documents table...</h4>";
try {
    $checkTable = $db->query("SHOW TABLES LIKE 'user_documents'");
    if ($checkTable->rowCount() > 0) {
        echo "<p class='success'>✅ Table 'user_documents' EXISTS</p>";
        
        // Show table structure
        $structure = $db->query("DESCRIBE user_documents");
        echo "<div class='code-box'><strong>Table Structure:</strong><br>";
        echo "<table class='table table-sm'><tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        while ($col = $structure->fetch()) {
            echo "<tr>";
            echo "<td>{$col['Field']}</td>";
            echo "<td>{$col['Type']}</td>";
            echo "<td>{$col['Null']}</td>";
            echo "<td>{$col['Key']}</td>";
            echo "<td>{$col['Default']}</td>";
            echo "</tr>";
        }
        echo "</table></div>";
    } else {
        echo "<p class='error'>❌ Table 'user_documents' DOES NOT EXIST!</p>";
        echo "<p class='warning'>⚠️ Creating table now...</p>";
        
        $createSql = "CREATE TABLE IF NOT EXISTS user_documents (
            document_id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL,
            document_type ENUM('medical_certificate', 'valid_id', 'id_card', 'photo_id') NOT NULL,
            file_name VARCHAR(255) NOT NULL,
            file_path VARCHAR(500) NOT NULL,
            file_size INT NOT NULL,
            uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
        )";
        
        $db->exec($createSql);
        echo "<p class='success'>✅ Table created successfully!</p>";
        
        // Add indexes
        $db->exec("CREATE INDEX idx_user_documents_user_id ON user_documents(user_id)");
        $db->exec("CREATE INDEX idx_user_documents_type ON user_documents(document_type)");
        echo "<p class='success'>✅ Indexes created!</p>";
    }
} catch (PDOException $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

// Step 2: Check existing documents
echo "<hr><h4>STEP 2: Checking existing documents in database...</h4>";
try {
    $docSql = "SELECT 
        ud.document_id,
        ud.user_id,
        u.username,
        u.full_name,
        ud.document_type,
        ud.file_name,
        ud.file_path,
        ROUND(ud.file_size/1024, 2) as size_kb,
        ud.uploaded_at
    FROM user_documents ud
    LEFT JOIN users u ON ud.user_id = u.user_id
    ORDER BY ud.uploaded_at DESC";
    
    $stmt = $db->query($docSql);
    $docs = $stmt->fetchAll();
    
    if (count($docs) > 0) {
        echo "<p class='success'>✅ Found " . count($docs) . " document(s) in database</p>";
        echo "<div class='code-box'>";
        echo "<table class='table table-sm'>";
        echo "<tr><th>ID</th><th>User</th><th>Type</th><th>File</th><th>Size</th><th>Exists?</th><th>Uploaded</th></tr>";
        foreach ($docs as $doc) {
            $fileExists = file_exists($doc['file_path']);
            echo "<tr>";
            echo "<td>{$doc['document_id']}</td>";
            echo "<td>{$doc['username']} ({$doc['full_name']})</td>";
            echo "<td>{$doc['document_type']}</td>";
            echo "<td>{$doc['file_name']}</td>";
            echo "<td>{$doc['size_kb']} KB</td>";
            echo "<td>" . ($fileExists ? "✅ YES" : "❌ NO") . "</td>";
            echo "<td>" . date('M j, Y H:i', strtotime($doc['uploaded_at'])) . "</td>";
            echo "</tr>";
        }
        echo "</table></div>";
    } else {
        echo "<p class='warning'>⚠️ NO documents found in database</p>";
        echo "<p class='info'>ℹ️ This means documents were not saved during registration</p>";
    }
} catch (PDOException $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

// Step 3: Check upload directories
echo "<hr><h4>STEP 3: Checking upload directories...</h4>";
$dirs = [
    'uploads/',
    'uploads/medical_certificates/',
    'uploads/profile_photos/'
];

foreach ($dirs as $dir) {
    if (is_dir($dir)) {
        $writable = is_writable($dir);
        $perms = substr(sprintf('%o', fileperms($dir)), -4);
        echo "<p class='success'>✅ Directory exists: <code>$dir</code> (Permissions: $perms, Writable: " . ($writable ? "YES" : "NO") . ")</p>";
        
        // List files
        $files = glob($dir . '*');
        if (count($files) > 0) {
            echo "<div class='code-box'><strong>Files in $dir:</strong><br>";
            foreach ($files as $file) {
                if (is_file($file)) {
                    $size = filesize($file);
                    echo "- " . basename($file) . " (" . round($size/1024, 2) . " KB)<br>";
                }
            }
            echo "</div>";
        } else {
            echo "<p class='info'>ℹ️ No files in $dir</p>";
        }
    } else {
        echo "<p class='error'>❌ Directory DOES NOT exist: <code>$dir</code></p>";
        echo "<p class='warning'>⚠️ Creating directory...</p>";
        if (mkdir($dir, 0755, true)) {
            echo "<p class='success'>✅ Directory created!</p>";
        } else {
            echo "<p class='error'>❌ Failed to create directory!</p>";
        }
    }
}

// Step 4: Check recent users without documents
echo "<hr><h4>STEP 4: Users without uploaded documents...</h4>";
try {
    $userSql = "SELECT u.user_id, u.username, u.full_name, u.email, u.status, u.created_at,
                (SELECT COUNT(*) FROM user_documents WHERE user_id = u.user_id) as doc_count
                FROM users u
                WHERE u.status = 'pending'
                ORDER BY u.created_at DESC
                LIMIT 10";
    
    $stmt = $db->query($userSql);
    $users = $stmt->fetchAll();
    
    if (count($users) > 0) {
        echo "<div class='code-box'>";
        echo "<table class='table table-sm'>";
        echo "<tr><th>ID</th><th>Username</th><th>Name</th><th>Email</th><th>Status</th><th>Documents</th><th>Registered</th></tr>";
        foreach ($users as $user) {
            $hasDoc = $user['doc_count'] > 0;
            echo "<tr style='background: " . ($hasDoc ? "#d4edda" : "#f8d7da") . "'>";
            echo "<td>{$user['user_id']}</td>";
            echo "<td>{$user['username']}</td>";
            echo "<td>{$user['full_name']}</td>";
            echo "<td>{$user['email']}</td>";
            echo "<td>{$user['status']}</td>";
            echo "<td>" . ($hasDoc ? "✅ {$user['doc_count']} docs" : "❌ NO DOCS") . "</td>";
            echo "<td>" . date('M j, Y H:i', strtotime($user['created_at'])) . "</td>";
            echo "</tr>";
        }
        echo "</table></div>";
    } else {
        echo "<p class='info'>ℹ️ No pending users found</p>";
    }
} catch (PDOException $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

// Step 5: Recommendations
echo "<hr><h4>STEP 5: Recommendations</h4>";
echo "<div class='alert alert-info'>";
echo "<h5>📝 What to do next:</h5>";
echo "<ol>";
echo "<li><strong>If table didn't exist:</strong> It has been created now. Try registering a new user.</li>";
echo "<li><strong>If directories didn't exist:</strong> They have been created. Try uploading again.</li>";
echo "<li><strong>If users have no documents:</strong> The files may not have uploaded properly during registration.</li>";
echo "<li><strong>To test upload:</strong> Go to <a href='register.php' target='_blank'>register.php</a> and create a new test account with documents.</li>";
echo "<li><strong>To view documents:</strong> Go to <a href='admin/manage_users.php' target='_blank'>admin panel</a> and click on a user to view their profile.</li>";
echo "</ol>";
echo "</div>";

echo "<div class='alert alert-success'>";
echo "<h5>✅ System Status:</h5>";
echo "<ul>";
echo "<li>Database table: " . (isset($checkTable) && $checkTable->rowCount() > 0 ? "✅ OK" : "❌ CREATED") . "</li>";
echo "<li>Upload directories: ✅ OK (checked and created if needed)</li>";
echo "<li>Document records: " . (count($docs) > 0 ? "✅ " . count($docs) . " found" : "⚠️ None yet") . "</li>";
echo "</ul>";
echo "</div>";

echo "</div></body></html>";
?>
