<?php
/**
 * Automated Reminder Cron Job
 * Run this script daily to send automated reminders
 * 
 * Schedule in Windows Task Scheduler or cron:
 * Daily at 8:00 AM: php "C:\xampp\htdocs\Koronadal Red Cross\cron\send_reminders.php"
 */

// Prevent direct browser access
if (php_sapi_name() !== 'cli') {
    // Check if accessed with proper key
    $cronKey = $_GET['key'] ?? '';
    if ($cronKey !== 'koronadal_redcross_cron_2024') {
        die('Access denied');
    }
}

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';

$logFile = __DIR__ . '/cron_log.txt';
$timestamp = date('Y-m-d H:i:s');

function logMessage($message, $logFile, $timestamp) {
    $logEntry = "[$timestamp] $message\n";
    file_put_contents($logFile, $logEntry, FILE_APPEND);
    echo $logEntry;
}

logMessage("=== Starting Automated Reminders ===", $logFile, $timestamp);

try {
    // 1. Send Donation Reminders to Eligible Donors
    logMessage("Sending donation reminders...", $logFile, $timestamp);
    $donationCount = sendDonationReminders($db, 1); // Admin user ID 1
    logMessage("Sent donation reminders to $donationCount eligible donors", $logFile, $timestamp);
    
    // 2. Send Appointment Reminders (24 hours before)
    logMessage("Sending appointment reminders...", $logFile, $timestamp);
    $appointmentCount = sendAppointmentReminders($db, 24, 1);
    logMessage("Sent appointment reminders to $appointmentCount users", $logFile, $timestamp);
    
    // 3. Send Event Reminders (3 days before)
    logMessage("Sending event reminders...", $logFile, $timestamp);
    $eventCount = sendEventReminders($db, 3, 1);
    logMessage("Sent event reminders to $eventCount participants", $logFile, $timestamp);
    
    // 4. Clean up old notifications (older than 30 days)
    logMessage("Cleaning up old notifications...", $logFile, $timestamp);
    $cleanupCount = cleanupOldNotifications($db, 30);
    logMessage("Deleted $cleanupCount old notifications", $logFile, $timestamp);
    
    logMessage("=== Automated Reminders Completed Successfully ===", $logFile, $timestamp);
    
} catch(Exception $e) {
    logMessage("ERROR: " . $e->getMessage(), $logFile, $timestamp);
    logMessage("=== Automated Reminders Failed ===", $logFile, $timestamp);
    exit(1);
}

exit(0);
?>
