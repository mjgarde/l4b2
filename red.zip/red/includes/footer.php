    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Custom JS -->
    <script src="<?php echo BASE_URL; ?>assets/js/main.js"></script>
    
    <!-- Session Timeout Warning -->
    <script>
        // Check session timeout
        let lastActivity = new Date().getTime();
        const sessionTimeout = <?php echo SESSION_TIMEOUT * 1000; ?>; // Convert to milliseconds
        
        setInterval(function() {
            let currentTime = new Date().getTime();
            let inactiveTime = currentTime - lastActivity;
            
            if (inactiveTime >= sessionTimeout - 60000) { // Warn 1 minute before timeout
                if (confirm('Your session is about to expire. Do you want to continue?')) {
                    lastActivity = new Date().getTime();
                    // Make a request to keep session alive
                    fetch('<?php echo BASE_URL; ?>keep_alive.php');
                }
            }
        }, 60000); // Check every minute
        
        // Update last activity on any user action
        document.addEventListener('click', function() {
            lastActivity = new Date().getTime();
        });
        document.addEventListener('keypress', function() {
            lastActivity = new Date().getTime();
        });
    </script>
</body>
</html>
