<nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-white sidebar collapse border-end">
    <div class="position-sticky pt-3">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>dashboard.php">
                    <i class="bi bi-speedometer2 me-2"></i>Dashboard
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'profile.php' ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>profile.php">
                    <i class="bi bi-person me-2"></i>My Profile
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'donate.php' ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>donate.php">
                    <i class="bi bi-droplet-fill me-2"></i>Donate Blood
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'donations.php' ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>donations.php">
                    <i class="bi bi-droplet-half me-2"></i>My Donations
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'request.php' ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>request.php">
                    <i class="bi bi-bandaid me-2"></i>Request Blood
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'requests.php' ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>requests.php">
                    <i class="bi bi-list-check me-2"></i>My Requests
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'appointments.php' ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>appointments.php">
                    <i class="bi bi-calendar-check me-2"></i>Appointments
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'events.php' ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>events.php">
                    <i class="bi bi-calendar-event me-2"></i>Events
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'notifications.php' ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>notifications.php">
                    <i class="bi bi-bell me-2"></i>Notifications
                    <?php 
                    $unreadCount = getUnreadNotificationCount($db, $_SESSION['user_id']);
                    if ($unreadCount > 0): 
                    ?>
                        <span class="badge bg-danger"><?php echo $unreadCount; ?></span>
                    <?php endif; ?>
                </a>
            </li>
        </ul>
        
        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>Account</span>
        </h6>
        <ul class="nav flex-column mb-2">
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'settings.php' ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>settings.php">
                    <i class="bi bi-gear me-2"></i>Settings
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-danger" href="<?php echo BASE_URL; ?>logout.php">
                    <i class="bi bi-box-arrow-right me-2"></i>Logout
                </a>
            </li>
        </ul>
    </div>
</nav>
