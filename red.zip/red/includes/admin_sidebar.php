<nav id="adminSidebar" class="col-md-3 col-lg-2 d-md-block bg-white sidebar collapse border-end">
    <div class="position-sticky pt-3">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link text-dark <?php echo basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active bg-danger' : ''; ?>" 
                   href="<?php echo BASE_URL; ?>admin/dashboard.php">
                    <i class="bi bi-speedometer2 me-2"></i>Dashboard
                </a>
            </li>
            
            <li class="nav-item">
                <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                    <span>BLOOD MANAGEMENT</span>
                </h6>
            </li>
            
            <li class="nav-item">
                <a class="nav-link text-dark <?php echo basename($_SERVER['PHP_SELF']) === 'manage_donations.php' ? 'active bg-danger' : ''; ?>" 
                   href="<?php echo BASE_URL; ?>admin/manage_donations.php">
                    <i class="bi bi-droplet-fill me-2"></i>Donations
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link text-dark <?php echo basename($_SERVER['PHP_SELF']) === 'manage_requests.php' ? 'active bg-danger' : ''; ?>" 
                   href="<?php echo BASE_URL; ?>admin/manage_requests.php">
                    <i class="bi bi-bandaid me-2"></i>Requests
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link text-dark <?php echo basename($_SERVER['PHP_SELF']) === 'manage_inventory.php' ? 'active bg-danger' : ''; ?>" 
                   href="<?php echo BASE_URL; ?>admin/manage_inventory.php">
                    <i class="bi bi-box-seam me-2"></i>Inventory
                </a>
            </li>
            
            <li class="nav-item">
                <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                    <span>USER MANAGEMENT</span>
                </h6>
            </li>
            
            <li class="nav-item">
                <a class="nav-link text-dark <?php echo basename($_SERVER['PHP_SELF']) === 'user_approvals.php' ? 'active bg-danger' : ''; ?>" 
                   href="<?php echo BASE_URL; ?>admin/user_approvals.php">
                    <i class="bi bi-person-check me-2"></i>User Approvals
                    <?php
                    // Show pending count badge
                    if (isset($db)) {
                        try {
                            $pendingCountSql = "SELECT COUNT(*) as count FROM users WHERE status = 'pending'";
                            $pendingCountStmt = $db->prepare($pendingCountSql);
                            $pendingCountStmt->execute();
                            $pendingCount = $pendingCountStmt->fetch()['count'];
                            if ($pendingCount > 0) {
                                echo '<span class="badge bg-warning text-dark ms-2">' . $pendingCount . '</span>';
                            }
                        } catch (Exception $e) {}
                    }
                    ?>
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link text-dark <?php echo basename($_SERVER['PHP_SELF']) === 'manage_users.php' ? 'active bg-danger' : ''; ?>" 
                   href="<?php echo BASE_URL; ?>admin/manage_users.php">
                    <i class="bi bi-people me-2"></i>Users
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link text-dark <?php echo basename($_SERVER['PHP_SELF']) === 'manage_donors.php' ? 'active bg-danger' : ''; ?>" 
                   href="<?php echo BASE_URL; ?>admin/manage_donors.php">
                    <i class="bi bi-person-hearts me-2"></i>Donors
                </a>
            </li>
            
            <li class="nav-item">
                <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                    <span>EVENTS & APPOINTMENTS</span>
                </h6>
            </li>
            
            <li class="nav-item">
                <a class="nav-link text-dark <?php echo basename($_SERVER['PHP_SELF']) === 'manage_events.php' ? 'active bg-danger' : ''; ?>" 
                   href="<?php echo BASE_URL; ?>admin/manage_events.php">
                    <i class="bi bi-calendar-event me-2"></i>Events
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link text-dark <?php echo basename($_SERVER['PHP_SELF']) === 'manage_appointments.php' ? 'active bg-danger' : ''; ?>" 
                   href="<?php echo BASE_URL; ?>admin/manage_appointments.php">
                    <i class="bi bi-calendar-check me-2"></i>Appointments
                </a>
            </li>
            
            <li class="nav-item">
                <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                    <span>SYSTEM</span>
                </h6>
            </li>
            
            <li class="nav-item">
                <a class="nav-link text-dark <?php echo basename($_SERVER['PHP_SELF']) === 'manage_notifications.php' ? 'active bg-danger' : ''; ?>" 
                   href="<?php echo BASE_URL; ?>admin/manage_notifications.php">
                    <i class="bi bi-bell me-2"></i>Manage Notifications
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link text-dark <?php echo basename($_SERVER['PHP_SELF']) === 'audit_logs.php' ? 'active bg-danger' : ''; ?>" 
                   href="<?php echo BASE_URL; ?>admin/audit_logs.php">
                    <i class="bi bi-shield-check me-2"></i>Audit Logs
                </a>
            </li>
        </ul>
        
        <hr class="my-3" style="border-color: #e9ecef;">
        
        <ul class="nav flex-column mb-2">
            <li class="nav-item">
                <a class="nav-link text-danger" href="<?php echo BASE_URL; ?>logout.php">
                    <i class="bi bi-box-arrow-right me-2"></i>Logout
                </a>
            </li>
        </ul>
    </div>
</nav>

<style>
#adminSidebar {
    box-shadow: 2px 0 10px rgba(0,0,0,0.05);
}

#adminSidebar .nav-link {
    padding: 0.75rem 1rem;
    border-radius: 8px;
    margin: 0.1rem 0.5rem;
    transition: all 0.2s ease;
    color: #495057;
    font-weight: 500;
}

#adminSidebar .nav-link:hover {
    background-color: #f8f9fa;
    color: #dc3545;
    transform: translateX(3px);
}

#adminSidebar .nav-link.active {
    background-color: #dc3545 !important;
    color: #fff !important;
    box-shadow: 0 2px 8px rgba(220, 53, 69, 0.3);
}

#adminSidebar .sidebar-heading {
    font-size: 0.75rem;
    font-weight: 600;
    letter-spacing: 0.5px;
}

#adminSidebar .nav-link i {
    width: 20px;
    text-align: center;
}
</style>
