
<?php
// DATABASE CONNECTION
$conn = new mysqli("localhost", "root", "", "koronadal_redcross");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $full_name = $_POST['full_name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $user_role = $_POST['user_role'];

    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // check existing user
    $check = $conn->prepare("SELECT user_id FROM users WHERE username=? OR email=?");
    $check->bind_param("ss", $username, $email);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        $message = "Username or Email already exists.";
    } else {

        $stmt = $conn->prepare("INSERT INTO users (username,email,password_hash,full_name,phone,address,user_role,status) VALUES (?,?,?,?,?,?,?,'active')");
        $stmt->bind_param("sssssss",$username,$email,$password_hash,$full_name,$phone,$address,$user_role);

        if ($stmt->execute()) {
            $message = "Signup successful!";
        } else {
            $message = "Error: " . $conn->error;
        }

    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Signup</title>
<style>
body{
font-family: Arial;
background:#f4f4f4;
}

.container{
width:350px;
margin:50px auto;
background:white;
padding:20px;
border-radius:10px;
box-shadow:0 0 10px rgba(0,0,0,0.1);
}

input,select,textarea{
width:100%;
padding:8px;
margin:5px 0 10px;
}

button{
width:100%;
padding:10px;
background:#28a745;
color:white;
border:none;
cursor:pointer;
}

.message{
color:red;
text-align:center;
margin-bottom:10px;
}
</style>
</head>

<body>

<div class="container">

<h2>Signup</h2>

<div class="message"><?php echo $message; ?></div>

<form method="POST">

<label>Full Name</label>
<input type="text" name="full_name" required>

<label>Username</label>
<input type="text" name="username" required>

<label>Email</label>
<input type="email" name="email" required>

<label>Password</label>
<input type="password" name="password" required>

<label>Phone</label>
<input type="text" name="phone">

<label>Address</label>
<textarea name="address"></textarea>

<label>User Role</label>
<select name="user_role">
<option value="user">User</option>
<option value="admin">Admin</option>
</select>

<button type="submit">Sign Up</button>

</form>

</div>

</body>
</html>