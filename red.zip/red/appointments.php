<?php
/**
 * My Appointments Page
 * View and manage user's appointments
 */

require_once 'config/config.php';
require_once 'config/db.php';

requireLogin();

$userId = $_SESSION['user_id'];
$success = $error = '';

// Handle appointment cancellation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_appointment'])) {
    if (validateCSRF($_POST['csrf_token'])) {
        $appointmentId = intval($_POST['appointment_id']);
        $cancelReason = sanitize($_POST['cancel_reason']);
        
        try {
            // Verify appointment belongs to user
            $stmt = $db->prepare("SELECT appointment_id FROM appointments WHERE appointment_id = ? AND user_id = ?");
            $stmt->execute([$appointmentId, $userId]);
            
            if ($stmt->fetch()) {
                $updateSql = "UPDATE appointments 
                             SET status = 'cancelled', 
                                 notes = CONCAT(COALESCE(notes,''), '\nCancelled by user: ', ?) 
                             WHERE appointment_id = ?";
                $stmt = $db->prepare($updateSql);
                $stmt->execute([$cancelReason, $appointmentId]);
                
                $success = 'Appointment cancelled successfully.';
            } else {
                $error = 'Appointment not found.';
            }
        } catch(PDOException $e) {
            $error = 'Error cancelling appointment: ' . $e->getMessage();
        }
    }
}

// Handle new appointment booking
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_appointment'])) {
    if (validateCSRF($_POST['csrf_token'])) {
        $eventId = !empty($_POST['event_id']) ? intval($_POST['event_id']) : null;
        $appointmentDate = sanitize($_POST['appointment_date']);
        $appointmentTime = sanitize($_POST['appointment_time']);
        $purpose = sanitize($_POST['purpose']);
        $notes = sanitize($_POST['notes']);
        
        try {
            $insertSql = "INSERT INTO appointments (user_id, event_id, appointment_date, appointment_time, purpose, status, notes) 
                         VALUES (?, ?, ?, ?, ?, 'scheduled', ?)";
            $stmt = $db->prepare($insertSql);
            $stmt->execute([$userId, $eventId, $appointmentDate, $appointmentTime, $purpose, $notes]);
            
            $success = 'Appointment booked successfully! We will confirm your appointment soon.';
        } catch(PDOException $e) {
            $error = 'Error booking appointment: ' . $e->getMessage();
        }
    }
}

// Get user's appointments
try {
    $appointmentsSql = "SELECT a.*, e.event_name, e.event_location 
                        FROM appointments a 
                        LEFT JOIN events e ON a.event_id = e.event_id 
                        WHERE a.user_id = :user_id 
                        ORDER BY a.appointment_date DESC, a.appointment_time DESC";
    $stmt = $db->prepare($appointmentsSql);
    $stmt->execute([':user_id' => $userId]);
    $appointments = $stmt->fetchAll();
} catch(PDOException $e) {
    $appointments = [];
}

// Get statistics
try {
    $statsSql = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'scheduled' THEN 1 ELSE 0 END) as scheduled,
                    SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed,
                    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                    SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
                    SUM(CASE WHEN appointment_date >= CURDATE() AND status IN ('scheduled', 'confirmed') THEN 1 ELSE 0 END) as upcoming
                 FROM appointments 
                 WHERE user_id = :user_id";
    $stmt = $db->prepare($statsSql);
    $stmt->execute([':user_id' => $userId]);
    $stats = $stmt->fetch();
} catch(PDOException $e) {
    $stats = ['total' => 0, 'scheduled' => 0, 'confirmed' => 0, 'completed' => 0, 'cancelled' => 0, 'upcoming' => 0];
}

// Get available events for booking
try {
    $eventsSql = "SELECT event_id, event_name, event_date, event_location 
                  FROM events 
                  WHERE status IN ('upcoming', 'ongoing') 
                  AND event_date >= CURDATE() 
                  ORDER BY event_date ASC";
    $stmt = $db->query($eventsSql);
    $availableEvents = $stmt->fetchAll();
} catch(PDOException $e) {
    $availableEvents = [];
}

$pageTitle = 'My Appointments';
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include 'includes/user_sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="bi bi-calendar-check text-primary me-2"></i>My Appointments</h1>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#bookAppointmentModal">
                    <i class="bi bi-plus-circle me-1"></i>Book Appointment
                </button>
            </div>

            <!-- Success/Error Messages -->
            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="bi bi-check-circle me-2"></i><?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="bi bi-exclamation-triangle me-2"></i><?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Statistics Cards -->
            <div class="row mb-4">
                <div class="col-md-2 mb-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body text-center">
                            <i class="bi bi-calendar-check text-primary" style="font-size: 2.5rem;"></i>
                            <h3 class="mt-2 fw-bold"><?php echo $stats['total']; ?></h3>
                            <small class="text-muted">Total</small>
                        </div>
                    </div>
                </div>

                <div class="col-md-2 mb-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body text-center">
                            <i class="bi bi-clock-history text-warning" style="font-size: 2.5rem;"></i>
                            <h3 class="mt-2 fw-bold"><?php echo $stats['scheduled']; ?></h3>
                            <small class="text-muted">Scheduled</small>
                        </div>
                    </div>
                </div>

                <div class="col-md-2 mb-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body text-center">
                            <i class="bi bi-check-circle text-success" style="font-size: 2.5rem;"></i>
                            <h3 class="mt-2 fw-bold"><?php echo $stats['confirmed']; ?></h3>
                            <small class="text-muted">Confirmed</small>
                        </div>
                    </div>
                </div>

                <div class="col-md-2 mb-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body text-center">
                            <i class="bi bi-check-all text-info" style="font-size: 2.5rem;"></i>
                            <h3 class="mt-2 fw-bold"><?php echo $stats['completed']; ?></h3>
                            <small class="text-muted">Completed</small>
                        </div>
                    </div>
                </div>

                <div class="col-md-2 mb-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body text-center">
                            <i class="bi bi-calendar-event text-success" style="font-size: 2.5rem;"></i>
                            <h3 class="mt-2 fw-bold"><?php echo $stats['upcoming']; ?></h3>
                            <small class="text-muted">Upcoming</small>
                        </div>
                    </div>
                </div>

                <div class="col-md-2 mb-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body text-center">
                            <i class="bi bi-x-circle text-danger" style="font-size: 2.5rem;"></i>
                            <h3 class="mt-2 fw-bold"><?php echo $stats['cancelled']; ?></h3>
                            <small class="text-muted">Cancelled</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Appointments Table -->
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <?php if (count($appointments) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover" id="appointmentsTable">
                                <thead class="table-light">
                                    <tr>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Purpose</th>
                                        <th>Event/Location</th>
                                        <th>Status</th>
                                        <th>Booked On</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($appointments as $appointment): ?>
                                        <tr>
                                            <td><?php echo formatDate($appointment['appointment_date']); ?></td>
                                            <td><?php echo date('g:i A', strtotime($appointment['appointment_time'])); ?></td>
                                            <td>
                                                <span class="badge bg-secondary">
                                                    <?php echo ucfirst($appointment['purpose']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($appointment['event_name']): ?>
                                                    <strong><?php echo htmlspecialchars($appointment['event_name']); ?></strong><br>
                                                    <small class="text-muted"><?php echo htmlspecialchars($appointment['event_location']); ?></small>
                                                <?php else: ?>
                                                    <span class="text-muted">Walk-in</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php
                                                $statusColors = [
                                                    'scheduled' => 'warning text-dark',
                                                    'confirmed' => 'info',
                                                    'completed' => 'success',
                                                    'cancelled' => 'danger'
                                                ];
                                                $statusColor = $statusColors[$appointment['status']] ?? 'secondary';
                                                ?>
                                                <span class="badge bg-<?php echo $statusColor; ?>">
                                                    <?php echo ucfirst($appointment['status']); ?>
                                                </span>
                                            </td>
                                            <td><small><?php echo formatDateTime($appointment['created_at']); ?></small></td>
                                            <td>
                                                <?php if (in_array($appointment['status'], ['scheduled', 'confirmed']) && 
                                                         strtotime($appointment['appointment_date']) >= strtotime(date('Y-m-d'))): ?>
                                                    <button type="button" class="btn btn-sm btn-outline-danger" 
                                                            data-bs-toggle="modal" 
                                                            data-bs-target="#cancelModal"
                                                            data-appointment-id="<?php echo $appointment['appointment_id']; ?>"
                                                            data-appointment-date="<?php echo formatDate($appointment['appointment_date']); ?>"
                                                            data-appointment-time="<?php echo date('g:i A', strtotime($appointment['appointment_time'])); ?>">
                                                        <i class="bi bi-x-circle"></i> Cancel
                                                    </button>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                                
                                                <?php if (!empty($appointment['notes'])): ?>
                                                    <button type="button" class="btn btn-sm btn-outline-secondary ms-1" 
                                                            data-bs-toggle="popover" 
                                                            data-bs-trigger="hover"
                                                            data-bs-content="<?php echo htmlspecialchars($appointment['notes']); ?>">
                                                        <i class="bi bi-info-circle"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-calendar-x" style="font-size: 5rem; color: #dee2e6;"></i>
                            <h4 class="mt-3 text-muted">No Appointments Yet</h4>
                            <p class="text-muted">Schedule your first appointment to donate blood or consult with us!</p>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#bookAppointmentModal">
                                <i class="bi bi-calendar-plus me-2"></i>Book Appointment
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Book Appointment Modal -->
<div class="modal fade" id="bookAppointmentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="bi bi-calendar-plus me-2"></i>Book Appointment</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRF(); ?>">
                    <input type="hidden" name="book_appointment" value="1">
                    
                    <div class="mb-3">
                        <label class="form-label">Event (Optional)</label>
                        <select name="event_id" class="form-select">
                            <option value="">Walk-in / No specific event</option>
                            <?php foreach ($availableEvents as $event): ?>
                                <option value="<?php echo $event['event_id']; ?>">
                                    <?php echo htmlspecialchars($event['event_name']); ?> 
                                    - <?php echo formatDate($event['event_date']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <small class="text-muted">Select an event or leave blank for a walk-in appointment</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Date <span class="text-danger">*</span></label>
                        <input type="date" name="appointment_date" class="form-control" 
                               min="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Time <span class="text-danger">*</span></label>
                        <input type="time" name="appointment_time" class="form-control" required>
                        <small class="text-muted">Operating hours: 8:00 AM - 5:00 PM</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Purpose <span class="text-danger">*</span></label>
                        <select name="purpose" class="form-select" required>
                            <option value="donation">Blood Donation</option>
                            <option value="consultation">Consultation</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Additional Notes</label>
                        <textarea name="notes" class="form-control" rows="3" 
                                  placeholder="Any special requirements or notes..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-circle me-1"></i>Book Appointment
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Cancel Appointment Modal -->
<div class="modal fade" id="cancelModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title"><i class="bi bi-x-circle me-2"></i>Cancel Appointment</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRF(); ?>">
                    <input type="hidden" name="cancel_appointment" value="1">
                    <input type="hidden" name="appointment_id" id="cancelAppointmentId">
                    
                    <p>Are you sure you want to cancel your appointment on <strong id="cancelAppointmentDate"></strong> at <strong id="cancelAppointmentTime"></strong>?</p>
                    
                    <div class="mb-3">
                        <label class="form-label">Reason for Cancellation <span class="text-danger">*</span></label>
                        <textarea name="cancel_reason" class="form-control" rows="3" 
                                  placeholder="Please provide a reason for cancellation..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keep Appointment</button>
                    <button type="submit" class="btn btn-danger">
                        <i class="bi bi-x-circle me-1"></i>Cancel Appointment
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
$(document).ready(function() {
    // Initialize DataTable
    $('#appointmentsTable').DataTable({
        "order": [[0, "desc"]],
        "pageLength": 25
    });
    
    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Handle cancel modal
    $('#cancelModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var appointmentId = button.data('appointment-id');
        var appointmentDate = button.data('appointment-date');
        var appointmentTime = button.data('appointment-time');
        
        var modal = $(this);
        modal.find('#cancelAppointmentId').val(appointmentId);
        modal.find('#cancelAppointmentDate').text(appointmentDate);
        modal.find('#cancelAppointmentTime').text(appointmentTime);
    });
});
</script>

<?php include 'includes/footer.php'; ?>
