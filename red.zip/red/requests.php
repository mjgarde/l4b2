<?php
/**
 * My Requests Page
 * View user's blood request history
 */

require_once 'config/config.php';
require_once 'config/db.php';

requireLogin();

$userId = $_SESSION['user_id'];

// Get user's requests
try {
    $requestsSql = "SELECT r.*, bt.blood_type 
                    FROM requests r 
                    JOIN blood_types bt ON r.blood_type_id = bt.blood_type_id 
                    WHERE r.user_id = :user_id 
                    ORDER BY r.created_at DESC";
    $stmt = $db->prepare($requestsSql);
    $stmt->execute([':user_id' => $userId]);
    $requests = $stmt->fetchAll();
} catch(PDOException $e) {
    $requests = [];
}

// Get statistics
try {
    $totalRequestsSql = "SELECT COUNT(*) as count FROM requests WHERE user_id = :user_id";
    $stmt = $db->prepare($totalRequestsSql);
    $stmt->execute([':user_id' => $userId]);
    $totalRequests = $stmt->fetch()['count'];
    
    $fulfilledSql = "SELECT COUNT(*) as count FROM requests WHERE user_id = :user_id AND status = 'fulfilled'";
    $stmt = $db->prepare($fulfilledSql);
    $stmt->execute([':user_id' => $userId]);
    $fulfilledRequests = $stmt->fetch()['count'];
    
    $pendingSql = "SELECT COUNT(*) as count FROM requests WHERE user_id = :user_id AND status = 'pending'";
    $stmt = $db->prepare($pendingSql);
    $stmt->execute([':user_id' => $userId]);
    $pendingRequests = $stmt->fetch()['count'];
} catch(PDOException $e) {
    $totalRequests = $fulfilledRequests = $pendingRequests = 0;
}

$pageTitle = 'My Requests';
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include 'includes/user_sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="bi bi-bandaid text-primary me-2"></i>My Blood Requests</h1>
                <a href="request.php" class="btn btn-primary">
                    <i class="bi bi-plus-circle me-1"></i>New Request
                </a>
            </div>

            <!-- Statistics Cards -->
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="card border-0 shadow-sm bg-primary text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="mb-1 opacity-75">Total Requests</p>
                                    <h3 class="mb-0 fw-bold"><?php echo $totalRequests; ?></h3>
                                </div>
                                <i class="bi bi-clipboard-data" style="font-size: 2.5rem; opacity: 0.5;"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 mb-3">
                    <div class="card border-0 shadow-sm bg-success text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="mb-1 opacity-75">Fulfilled</p>
                                    <h3 class="mb-0 fw-bold"><?php echo $fulfilledRequests; ?></h3>
                                </div>
                                <i class="bi bi-check-circle-fill" style="font-size: 2.5rem; opacity: 0.5;"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 mb-3">
                    <div class="card border-0 shadow-sm bg-warning text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="mb-1 opacity-75">Pending</p>
                                    <h3 class="mb-0 fw-bold"><?php echo $pendingRequests; ?></h3>
                                </div>
                                <i class="bi bi-clock-history" style="font-size: 2.5rem; opacity: 0.5;"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Requests Table -->
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <?php if (count($requests) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover" id="requestsTable">
                                <thead class="table-light">
                                    <tr>
                                        <th>Date</th>
                                        <th>Patient</th>
                                        <th>Hospital</th>
                                        <th>Blood Type</th>
                                        <th>Quantity</th>
                                        <th>Urgency</th>
                                        <th>Required By</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($requests as $request): ?>
                                        <tr>
                                            <td><?php echo formatDate($request['created_at']); ?></td>
                                            <td><?php echo htmlspecialchars($request['patient_name']); ?></td>
                                            <td><small><?php echo htmlspecialchars($request['hospital_name']); ?></small></td>
                                            <td><span class="badge bg-primary fs-6"><?php echo $request['blood_type']; ?></span></td>
                                            <td><?php echo $request['quantity_ml']; ?>ml</td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $request['urgency'] === 'Critical' ? 'danger' : 
                                                         ($request['urgency'] === 'High' ? 'warning text-dark' : 
                                                         ($request['urgency'] === 'Medium' ? 'info' : 'secondary')); 
                                                ?>">
                                                    <?php echo $request['urgency']; ?>
                                                </span>
                                            </td>
                                            <td><?php echo formatDate($request['required_date']); ?></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $request['status'] === 'fulfilled' ? 'success' : 
                                                         ($request['status'] === 'pending' ? 'warning text-dark' : 
                                                         ($request['status'] === 'approved' ? 'info' : 'danger')); 
                                                ?>">
                                                    <?php echo ucfirst($request['status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-bandaid" style="font-size: 5rem; color: #dee2e6;"></i>
                            <h4 class="mt-3 text-muted">No Requests Yet</h4>
                            <p class="text-muted">Submit your first blood request</p>
                            <a href="request.php" class="btn btn-primary">
                                <i class="bi bi-bandaid me-2"></i>Request Blood
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
$(document).ready(function() {
    $('#requestsTable').DataTable({
        "order": [[0, "desc"]],
        "pageLength": 25
    });
});
</script>

<?php include 'includes/footer.php'; ?>
