<?php
/**
 * Registration Page
 * New user registration
 */

require_once 'config/config.php';
require_once 'config/db.php';

// Redirect if already logged in
if (isLoggedIn()) {
    redirect('dashboard.php');
}

$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !validateCSRF($_POST['csrf_token'])) {
        $error = 'Invalid request. Please try again.';
    } else {
        $username = sanitize($_POST['username']);
        $email = sanitize($_POST['email']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];
        $full_name = sanitize($_POST['full_name']);
        $phone = sanitize($_POST['phone']);
        $address = sanitize($_POST['address']);
        $blood_type_id = intval($_POST['blood_type_id']);
        
        $medical_cert_path = null;
        $photo_id_path = null;
        
        if (empty($username) || empty($email) || empty($password) || empty($full_name)) {
            $error = 'Please fill in all required fields';
        } elseif (!isset($_FILES['medical_certificate']) || $_FILES['medical_certificate']['error'] === UPLOAD_ERR_NO_FILE) {
            $error = 'Medical certificate is required';
        } elseif (!isset($_FILES['photo_id']) || $_FILES['photo_id']['error'] === UPLOAD_ERR_NO_FILE) {
            $error = 'Photo ID is required';
        } elseif (strlen($username) < 4) {
            $error = 'Username must be at least 4 characters';
        } elseif (!validateEmail($email)) {
            $error = 'Invalid email format';
        } elseif (strlen($password) < PASSWORD_MIN_LENGTH) {
            $error = 'Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters';
        } elseif ($password !== $confirm_password) {
            $error = 'Passwords do not match';
        } elseif (!empty($phone) && !validatePhone($phone)) {
            $error = 'Invalid phone number format';
        } else {
            try {
                $checkUserSql = "SELECT user_id FROM users WHERE username = :username";
                $checkStmt = $db->prepare($checkUserSql);
                $checkStmt->execute([':username' => $username]);
                
                if ($checkStmt->rowCount() > 0) {
                    $error = 'Username already exists';
                } else {
                    $checkEmailSql = "SELECT user_id FROM users WHERE email = :email";
                    $checkStmt = $db->prepare($checkEmailSql);
                    $checkStmt->execute([':email' => $email]);
                    
                    if ($checkStmt->rowCount() > 0) {
                        $error = 'Email already registered';
                    } else {
                        $upload_errors = [];
                        
                        if (isset($_FILES['medical_certificate']) && $_FILES['medical_certificate']['error'] === UPLOAD_ERR_OK) {
                            $medical_cert = $_FILES['medical_certificate'];
                            $allowed_types = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
                            $max_size = 5 * 1024 * 1024;
                            
                            if (!in_array($medical_cert['type'], $allowed_types)) {
                                $upload_errors[] = 'Medical certificate must be PDF, JPG, or PNG';
                            } elseif ($medical_cert['size'] > $max_size) {
                                $upload_errors[] = 'Medical certificate must be less than 5MB';
                            } else {
                                $file_ext = pathinfo($medical_cert['name'], PATHINFO_EXTENSION);
                                $new_filename = 'medical_cert_' . uniqid() . '.' . $file_ext;
                                $upload_dir = 'uploads/medical_certificates/';
                                if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
                                $medical_cert_path = $upload_dir . $new_filename;
                                if (!move_uploaded_file($medical_cert['tmp_name'], $medical_cert_path)) {
                                    $upload_errors[] = 'Failed to upload medical certificate';
                                }
                            }
                        }
                        
                        if (isset($_FILES['photo_id']) && $_FILES['photo_id']['error'] === UPLOAD_ERR_OK) {
                            $photo_id = $_FILES['photo_id'];
                            $allowed_types = ['image/jpeg', 'image/jpg', 'image/png'];
                            $max_size = 3 * 1024 * 1024;
                            
                            if (!in_array($photo_id['type'], $allowed_types)) {
                                $upload_errors[] = 'Photo ID must be JPG or PNG';
                            } elseif ($photo_id['size'] > $max_size) {
                                $upload_errors[] = 'Photo ID must be less than 3MB';
                            } else {
                                $file_ext = pathinfo($photo_id['name'], PATHINFO_EXTENSION);
                                $new_filename = 'photo_id_' . uniqid() . '.' . $file_ext;
                                $upload_dir = 'uploads/profile_photos/';
                                if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
                                $photo_id_path = $upload_dir . $new_filename;
                                if (!move_uploaded_file($photo_id['tmp_name'], $photo_id_path)) {
                                    $upload_errors[] = 'Failed to upload photo ID';
                                }
                            }
                        }
                        
                        if (!empty($upload_errors)) {
                            $error = implode('. ', $upload_errors);
                        } else {
                            $hashedPassword = hashPassword($password);
                            $insertSql = "INSERT INTO users (username, email, password_hash, full_name, phone, address, blood_type_id, user_role, status) 
                                         VALUES (:username, :email, :password_hash, :full_name, :phone, :address, :blood_type_id, 'user', 'pending')";
                            $insertStmt = $db->prepare($insertSql);
                            $result = $insertStmt->execute([
                                ':username' => $username,
                                ':email' => $email,
                                ':password_hash' => $hashedPassword,
                                ':full_name' => $full_name,
                                ':phone' => $phone,
                                ':address' => $address,
                                ':blood_type_id' => $blood_type_id > 0 ? $blood_type_id : null
                            ]);
                            
                            if ($result) {
                                $userId = $db->lastInsertId();
                                
                                try {
                                    if ($medical_cert_path && file_exists($medical_cert_path)) {
                                        $docSql = "INSERT INTO user_documents (user_id, document_type, file_name, file_path, file_size) VALUES (:user_id, 'medical_certificate', :file_name, :file_path, :file_size)";
                                        $docStmt = $db->prepare($docSql);
                                        $docStmt->execute([':user_id' => $userId, ':file_name' => basename($medical_cert_path), ':file_path' => $medical_cert_path, ':file_size' => filesize($medical_cert_path)]);
                                    }
                                    if ($photo_id_path && file_exists($photo_id_path)) {
                                        $docSql = "INSERT INTO user_documents (user_id, document_type, file_name, file_path, file_size) VALUES (:user_id, 'valid_id', :file_name, :file_path, :file_size)";
                                        $docStmt = $db->prepare($docSql);
                                        $docStmt->execute([':user_id' => $userId, ':file_name' => basename($photo_id_path), ':file_path' => $photo_id_path, ':file_size' => filesize($photo_id_path)]);
                                    }
                                } catch (PDOException $e) {
                                    error_log("Error saving documents: " . $e->getMessage());
                                }
                                
                                createNotification($db, $userId, 'Account Pending Approval', 'Thank you for registering! Your account is pending admin approval.', 'info');
                                
                                $adminSql = "SELECT user_id FROM users WHERE user_role = 'admin' AND status = 'active'";
                                $adminStmt = $db->prepare($adminSql);
                                $adminStmt->execute();
                                foreach ($adminStmt->fetchAll() as $admin) {
                                    createNotification($db, $admin['user_id'], 'New User Registration', "New user '$full_name' ($username) has registered and is awaiting approval.", 'warning');
                                }
                                
                                logAudit($db, $userId, 'User Registration', 'users', $userId, 'New user registered - Pending approval');
                                $_SESSION['success'] = 'Registration successful! Your account is pending admin approval.';
                                redirect('login.php');
                            } else {
                                $error = 'Registration failed. Please try again.';
                            }
                        }
                    }
                }
            } catch(PDOException $e) {
                $error = 'An error occurred. Please try again.';
                error_log("Registration error: " . $e->getMessage());
            }
        }
    }
}

try {
    $bloodTypesSql = "SELECT * FROM blood_types ORDER BY blood_type";
    $bloodTypesStmt = $db->prepare($bloodTypesSql);
    $bloodTypesStmt->execute();
    $bloodTypes = $bloodTypesStmt->fetchAll();
} catch(PDOException $e) {
    $bloodTypes = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - <?php echo SITE_NAME; ?></title>
    <style>
        *, *::before, *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        :root {
            --red: #c0392b;
            --red-dark: #962d22;
            --red-light: #e74c3c;
            --red-pale: #fdf2f1;
            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-400: #9ca3af;
            --gray-600: #4b5563;
            --gray-800: #1f2937;
            --white: #ffffff;
            --info: #0369a1;
            --info-bg: #e0f2fe;
            --warn: #92400e;
            --warn-bg: #fef3c7;
            --success: #065f46;
            --success-bg: #d1fae5;
            --radius: 8px;
            --radius-lg: 14px;
            --shadow: 0 4px 24px rgba(0,0,0,0.10);
        }

        body {
            font-family: Georgia, 'Times New Roman', serif;
            background: var(--gray-50);
            color: var(--gray-800);
            min-height: 100vh;
            padding: 2rem 1rem;
        }

        .page-wrap {
            max-width: 640px;
            margin: 0 auto;
        }

        /* Back link */
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: var(--gray-600);
            text-decoration: none;
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            font-size: 0.85rem;
            margin-bottom: 1.5rem;
            padding: 6px 14px;
            border: 1px solid var(--gray-200);
            border-radius: 99px;
            background: var(--white);
            transition: border-color 0.2s, color 0.2s;
        }
        .back-link:hover {
            border-color: var(--gray-400);
            color: var(--gray-800);
        }
        .back-link svg { width: 14px; height: 14px; }

        /* Card */
        .card {
            background: var(--white);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow);
            padding: 2.5rem 2.5rem 2rem;
        }

        /* Header */
        .header {
            text-align: center;
            margin-bottom: 1.75rem;
        }
        .header-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 56px;
            height: 56px;
            background: var(--red-pale);
            border-radius: 50%;
            margin-bottom: 0.75rem;
        }
        .header-icon svg {
            width: 28px;
            height: 28px;
            fill: var(--red);
        }
        .header h1 {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--gray-800);
            letter-spacing: -0.3px;
        }
        .header p {
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            color: var(--gray-400);
            font-size: 0.9rem;
            margin-top: 4px;
        }

        /* Alerts */
        .alert {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            padding: 12px 16px;
            border-radius: var(--radius);
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            font-size: 0.875rem;
            margin-bottom: 1.25rem;
            line-height: 1.5;
        }
        .alert svg { flex-shrink: 0; margin-top: 1px; width: 16px; height: 16px; }
        .alert-danger { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
        .alert-info { background: var(--info-bg); color: var(--info); border: 1px solid #bae6fd; }
        .alert-info strong { display: block; margin-bottom: 2px; }
        .alert-warn { background: var(--warn-bg); color: var(--warn); border: 1px solid #fcd34d; }
        .alert-success-sm { background: var(--success-bg); color: var(--success); border: 1px solid #6ee7b7; padding: 8px 12px; border-radius: 6px; font-size: 0.8rem; }

        /* Form layout */
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        label {
            display: block;
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--gray-600);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 5px;
        }
        label .req { color: var(--red); }
        label .badge {
            display: inline-block;
            background: var(--info-bg);
            color: var(--info);
            font-size: 0.68rem;
            padding: 1px 7px;
            border-radius: 99px;
            margin-left: 4px;
            text-transform: none;
            letter-spacing: 0;
            font-weight: 500;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="tel"],
        input[type="file"],
        select,
        textarea {
            width: 100%;
            padding: 9px 12px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius);
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            font-size: 0.9rem;
            color: var(--gray-800);
            background: var(--white);
            transition: border-color 0.2s, box-shadow 0.2s;
            outline: none;
        }
        input:focus, select:focus, textarea:focus {
            border-color: var(--red);
            box-shadow: 0 0 0 3px rgba(192,57,43,0.1);
        }
        textarea { resize: vertical; min-height: 70px; }
        select { appearance: none; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%239ca3af' d='M6 8L1 3h10z'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 12px center; padding-right: 32px; }

        .hint {
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            font-size: 0.77rem;
            color: var(--gray-400);
            margin-top: 4px;
        }

        /* Password input group */
        .input-group {
            position: relative;
        }
        .input-group input { padding-right: 42px; }
        .toggle-pw {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            color: var(--gray-400);
            display: flex;
            align-items: center;
            padding: 4px;
        }
        .toggle-pw:hover { color: var(--gray-600); }
        .toggle-pw svg { width: 18px; height: 18px; }

        /* Documents section */
        .docs-section {
            border: 2px dashed #fca5a5;
            border-radius: var(--radius-lg);
            padding: 1.5rem;
            margin-bottom: 1.25rem;
            background: #fffafa;
        }
        .docs-section h2 {
            font-size: 1rem;
            font-weight: 700;
            color: var(--red);
            margin-bottom: 4px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .docs-section h2 svg { width: 18px; height: 18px; fill: var(--red); }
        .docs-section .sub {
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            font-size: 0.82rem;
            color: var(--gray-400);
            margin-bottom: 1.25rem;
        }

        input[type="file"] {
            padding: 7px 10px;
            cursor: pointer;
            background: var(--gray-50);
        }
        input[type="file"]::-webkit-file-upload-button {
            background: var(--gray-100);
            border: 1px solid var(--gray-200);
            border-radius: 5px;
            padding: 4px 10px;
            font-size: 0.8rem;
            cursor: pointer;
            margin-right: 8px;
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            color: var(--gray-600);
        }

        .divider {
            border: none;
            border-top: 1px solid var(--gray-100);
            margin: 1rem 0 1.25rem;
        }

        /* Checkbox */
        .check-group {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            margin-bottom: 1.25rem;
        }
        .check-group input[type="checkbox"] {
            width: 16px;
            height: 16px;
            min-width: 16px;
            margin-top: 2px;
            accent-color: var(--red);
            cursor: pointer;
        }
        .check-group label {
            text-transform: none;
            letter-spacing: 0;
            font-weight: 400;
            font-size: 0.85rem;
            color: var(--gray-600);
        }
        .check-group label a { color: var(--red); }

        /* Submit */
        .btn-submit {
            width: 100%;
            padding: 11px;
            background: var(--red);
            color: var(--white);
            border: none;
            border-radius: var(--radius);
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s, transform 0.1s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            letter-spacing: 0.2px;
        }
        .btn-submit svg { width: 18px; height: 18px; }
        .btn-submit:hover { background: var(--red-dark); }
        .btn-submit:active { transform: scale(0.99); }

        .login-link {
            text-align: center;
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            font-size: 0.875rem;
            color: var(--gray-600);
            margin-top: 1rem;
        }
        .login-link a { color: var(--red); font-weight: 700; text-decoration: none; }
        .login-link a:hover { text-decoration: underline; }

        @media (max-width: 540px) {
            .card { padding: 1.5rem 1.25rem; }
            .form-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<div class="page-wrap">

    <a href="index.php" class="back-link">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
        Back to Home
    </a>

    <div class="card">

        <!-- Header -->
        <div class="header">
            <div class="header-icon">
                <svg viewBox="0 0 24 24"><path d="M12 2C9.5 2 7.5 4.5 7.5 7.5c0 3.5 4.5 10.5 4.5 10.5s4.5-7 4.5-10.5C16.5 4.5 14.5 2 12 2z"/></svg>
            </div>
            <h1>Create Account</h1>
            <p>Join Koronadal Red Cross</p>
        </div>

        <!-- Error Alert -->
        <?php if ($error): ?>
        <div class="alert alert-danger">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 100 20A10 10 0 0012 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
            <span><?php echo $error; ?></span>
        </div>
        <?php endif; ?>

        <!-- Info Notice -->
        <div class="alert alert-info">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 100 20A10 10 0 0012 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
            <div>
                <strong>Admin Approval Required</strong>
                All new registrations must be approved before you can log in. You will be notified once verified.
            </div>
        </div>

        <!-- Form -->
        <form method="POST" action="" id="registerForm" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo getCSRFToken(); ?>">

            <div class="form-row">
                <div class="form-group">
                    <label for="username">Username <span class="req">*</span></label>
                    <input type="text" id="username" name="username" required minlength="4" placeholder="min. 4 characters">
                    <div class="hint">At least 4 characters</div>
                </div>
                <div class="form-group">
                    <label for="email">Email <span class="req">*</span></label>
                    <input type="email" id="email" name="email" required placeholder="you@email.com">
                </div>
            </div>

            <div class="form-group">
                <label for="full_name">Full Name <span class="req">*</span></label>
                <input type="text" id="full_name" name="full_name" required placeholder="As it appears on your ID">
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="password">Password <span class="req">*</span></label>
                    <div class="input-group">
                        <input type="password" id="password" name="password" required minlength="<?php echo PASSWORD_MIN_LENGTH; ?>" placeholder="Min <?php echo PASSWORD_MIN_LENGTH; ?> characters">
                        <button class="toggle-pw" type="button" id="togglePassword" aria-label="Toggle password">
                            <svg id="eyeIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                        </button>
                    </div>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm Password <span class="req">*</span></label>
                    <input type="password" id="confirm_password" name="confirm_password" required placeholder="Re-enter password">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone" placeholder="09XXXXXXXXX">
                </div>
                <div class="form-group">
                    <label for="blood_type_id">Blood Type</label>
                    <select id="blood_type_id" name="blood_type_id">
                        <option value="">Select Blood Type</option>
                        <?php foreach ($bloodTypes as $type): ?>
                        <option value="<?php echo $type['blood_type_id']; ?>"><?php echo $type['blood_type']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label for="address">Address</label>
                <textarea id="address" name="address" placeholder="Street, Barangay, City"></textarea>
            </div>

            <!-- Documents -->
            <div class="docs-section">
                <h2>
                    <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6zm-1 1.5L18.5 9H13V3.5zM8 13h8v1H8v-1zm0 3h8v1H8v-1zm0-6h5v1H8v-1z"/></svg>
                    Required Documents
                </h2>
                <p class="sub">Upload the following for admin verification:</p>

                <div class="form-group">
                    <label for="medical_certificate">
                        Medical Certificate <span class="req">*</span>
                        <span class="badge">Required</span>
                    </label>
                    <input type="file" id="medical_certificate" name="medical_certificate" accept=".pdf,.jpg,.jpeg,.png" required>
                    <div class="hint">From a licensed physician — PDF, JPG, PNG (max 5MB)</div>
                    <div id="medicalPreview"></div>
                </div>

                <div class="form-group" style="margin-bottom:0">
                    <label for="photo_id">
                        Photo ID / Valid ID <span class="req">*</span>
                        <span class="badge">Required</span>
                    </label>
                    <input type="file" id="photo_id" name="photo_id" accept=".jpg,.jpeg,.png" required>
                    <div class="hint">Driver's License, Passport, etc. — JPG, PNG (max 3MB)</div>
                    <div id="photoPreview"></div>
                </div>

                <hr class="divider">

                <div class="alert alert-warn" style="margin-bottom:0">
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 100 20A10 10 0 0012 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
                    <span><strong>Note:</strong> Documents are reviewed by our admin team and kept strictly confidential.</span>
                </div>
            </div>

            <div class="check-group">
                <input type="checkbox" id="terms" required>
                <label for="terms">I agree to the <a href="#">Terms and Conditions</a> and certify that all information provided is accurate.</label>
            </div>

            <button type="submit" class="btn-submit">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
                Create Account
            </button>

            <p class="login-link">Already have an account? <a href="login.php">Login</a></p>
        </form>
    </div>
</div>

<script>
    // Toggle password
    const toggleBtn = document.getElementById('togglePassword');
    const pwField = document.getElementById('password');
    const eyeIcon = document.getElementById('eyeIcon');

    toggleBtn.addEventListener('click', function () {
        const isPassword = pwField.type === 'password';
        pwField.type = isPassword ? 'text' : 'password';
        eyeIcon.innerHTML = isPassword
            ? '<path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>'
            : '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
    });

    // Password match check
    document.getElementById('registerForm').addEventListener('submit', function (e) {
        const pw = document.getElementById('password').value;
        const cpw = document.getElementById('confirm_password').value;
        if (pw !== cpw) {
            e.preventDefault();
            alert('Passwords do not match!');
        }
    });

    // Medical cert preview
    document.getElementById('medical_certificate').addEventListener('change', function () {
        const file = this.files[0];
        const preview = document.getElementById('medicalPreview');
        if (!file) { preview.innerHTML = ''; return; }
        if (file.size > 5 * 1024 * 1024) {
            alert('Medical certificate must be less than 5MB');
            this.value = '';
            preview.innerHTML = '';
            return;
        }
        const kb = (file.size / 1024).toFixed(1);
        preview.innerHTML = `<div class="alert-success-sm" style="margin-top:8px">&#10003; <strong>${file.name}</strong> &mdash; ${kb} KB</div>`;
    });

    // Photo ID preview
    document.getElementById('photo_id').addEventListener('change', function () {
        const file = this.files[0];
        const preview = document.getElementById('photoPreview');
        if (!file) { preview.innerHTML = ''; return; }
        if (file.size > 3 * 1024 * 1024) {
            alert('Photo ID must be less than 3MB');
            this.value = '';
            preview.innerHTML = '';
            return;
        }
        if (!file.type.startsWith('image/')) {
            alert('Photo ID must be an image file');
            this.value = '';
            preview.innerHTML = '';
            return;
        }
        const reader = new FileReader();
        reader.onload = function (e) {
            const kb = (file.size / 1024).toFixed(1);
            preview.innerHTML = `
                <div class="alert-success-sm" style="margin-top:8px">
                    &#10003; <strong>${file.name}</strong> &mdash; ${kb} KB<br>
                    <img src="${e.target.result}" style="max-width:180px;margin-top:8px;border-radius:6px;border:1px solid #e5e7eb;display:block;">
                </div>`;
        };
        reader.readAsDataURL(file);
    });
</script>
</body>
</html>