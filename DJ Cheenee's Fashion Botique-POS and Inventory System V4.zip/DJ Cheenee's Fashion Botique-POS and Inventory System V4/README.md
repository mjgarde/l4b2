# DJ Cheenee's Fashion Boutique - POS & Inventory System

A comprehensive Point of Sale and Inventory Management System designed specifically for fashion boutiques. Built with PHP, MySQL, Bootstrap 5, and vanilla JavaScript for XAMPP environments.

## 🌟 Features

### 🎨 **Modern Boutique-Inspired UI/UX**
- **Theme**: Deep mauve/purple primary with rose gold/beige accents
- **Typography**: Poppins font with clean hierarchy
- **Layout**: Card-based design with rounded corners and soft shadows
- **Responsive**: Mobile-friendly with collapsible sidebar navigation

### 👥 **Role-Based Access Control**
- **Admin**: Full system access (Dashboard, Inventory, Products, Reports, User Management)
- **Cashier**: POS operations and transaction history only
- **Secure Authentication**: Session-based login with password hashing

### 📊 **Admin Dashboard**
- **KPI Cards**: Today's sales, monthly revenue, inventory value, low-stock alerts
- **Interactive Charts**: Sales trends with Chart.js integration  
- **Quick Actions**: Add products, open POS, manage inventory, generate reports
- **Real-time Notifications**: Low-stock alerts with badge indicators

### 🛒 **Point of Sale (POS) System**
- **Barcode Scanning**: Direct barcode input or product search
- **Product Grid**: Visual product selection with images and stock status
- **Smart Cart**: Real-time calculations with tax (12%), quantity controls
- **Multiple Payment Methods**: Cash, Card, Digital Wallet
- **Receipt Generation**: Print/download receipts with store branding
- **Inventory Integration**: Automatic stock deduction on sales

### 📦 **Inventory Management**
- **Product Management**: Master-level products with categories and brands
- **Variant System**: Size/Color/Barcode level with individual pricing and stock
- **Stock Tracking**: Real-time stock levels with movement history
- **Low-Stock Alerts**: Automated notifications when items run low
- **Bulk Operations**: Easy stock adjustments with audit trail

### 📈 **Reports & Analytics**
- **Sales Reports**: Daily trends, payment method breakdown, top-selling products
- **Inventory Reports**: Category analysis, stock valuation, low-stock items
- **Date Range Filtering**: Flexible reporting periods
- **Export Options**: CSV download and print functionality
- **Visual Charts**: Interactive graphs for better insights

## 🛠️ **Installation Guide**

### Prerequisites
- **XAMPP** (Apache + MySQL + PHP 7.4+)
- **Web Browser** (Chrome, Firefox, Safari, Edge)
- **Text Editor** (Optional, for customization)

### Step 1: Download and Setup XAMPP
1. Download XAMPP from [https://www.apachefriends.org/](https://www.apachefriends.org/)
2. Install XAMPP and start **Apache** and **MySQL** services
3. Verify installation by visiting `http://localhost` in your browser

### Step 2: Database Setup
1. Open **phpMyAdmin** by visiting `http://localhost/phpmyadmin`
2. Create a new database named `dj_cheenee_boutique`
3. Import the database schema:
   - Click on the `dj_cheenee_boutique` database
   - Go to **Import** tab
   - Choose file: `database/schema.sql`
   - Click **Go** to execute

### Step 3: Sample Data (Optional but Recommended)
1. In phpMyAdmin, select the `dj_cheenee_boutique` database
2. Go to **Import** tab
3. Choose file: `database/sample_data.sql`
4. Click **Go** to load sample products and test data

### Step 4: Configuration
The system is pre-configured for XAMPP default settings:
- **Database Host**: `localhost`
- **Database Name**: `dj_cheenee_boutique`
- **Username**: `root`
- **Password**: *(empty)*

If you need to change these settings, edit `config/database.php`.

### Step 5: Access the System
1. Navigate to `http://localhost/DJ Cheenee's Fashion Botique-POS and Inventory System V4/`
2. You'll be redirected to the login page

## 🔐 **Default Login Credentials**

### Admin Account
- **Username**: `admin`
- **Password**: `password`
- **Access**: Full system administration

### Cashier Account  
- **Username**: `cashier`
- **Password**: `password`
- **Access**: POS operations only

> **⚠️ Security Note**: Change default passwords immediately after installation!

## 📱 **System Navigation**

### Admin Dashboard (`/admin/dashboard.php`)
- View KPIs and sales analytics
- Quick access to all system modules
- Real-time low-stock notifications

### Product Management (`/admin/products.php`)
- Add new products with categories and brands
- Create product variants (size, color, barcode)
- Manage product information and images

### Inventory Management (`/admin/inventory.php`)
- View all product variants with stock levels
- Update stock quantities with notes
- Filter by category and stock status
- Track stock movement history

### Point of Sale (`/cashier/pos.php`)
- Scan barcodes or search products
- Add items to cart with quantity controls
- Process payments and generate receipts
- View today's sales summary

### Reports & Analytics (`/admin/reports.php`)
- Generate sales and inventory reports
- View charts and analytics
- Export data to CSV format
- Print reports for record-keeping

## 🎯 **Key System Features**

### Barcode System
- **Auto-generation**: System generates unique barcodes for new variants
- **Manual Entry**: Support for existing barcode systems
- **Instant Search**: Fast barcode scanning in POS

### Stock Management
- **Real-time Updates**: Stock levels update immediately after sales
- **Movement Tracking**: Complete audit trail of all stock changes
- **Low-Stock Alerts**: Configurable thresholds per product variant
- **Batch Updates**: Efficient stock adjustments with reason codes

### Sales Tracking
- **Transaction History**: Complete record of all sales transactions
- **Customer Information**: Optional customer details for receipts
- **Payment Methods**: Support for multiple payment types
- **Receipt System**: Professional branded receipts

### Reporting System
- **Dashboard Analytics**: Key performance indicators at a glance
- **Detailed Reports**: Comprehensive sales and inventory analysis
- **Date Filtering**: Flexible date range selection
- **Export Options**: CSV export for external analysis

## 🔧 **Customization Options**

### Branding
- **Store Name**: Update in `database/system_settings` table
- **Logo**: Replace logo in login page and receipts
- **Colors**: Modify CSS variables in `assets/css/style.css`
- **Receipt Footer**: Customize receipt messages

### Business Rules
- **Tax Rate**: Adjust in system settings (default 12%)
- **Currency**: Change currency symbol (default ₱)
- **Stock Thresholds**: Set per-product low-stock alerts
- **User Roles**: Extend role-based permissions

### Categories & Brands
- Add new product categories in the database
- Create brand entries for better organization
- Customize product classification system

## 📋 **System Requirements**

### Server Requirements
- **PHP**: 7.4 or higher
- **MySQL**: 5.7 or higher  
- **Apache**: 2.4 or higher
- **Extensions**: PDO, MySQLi

### Browser Support
- **Chrome**: 80+
- **Firefox**: 75+
- **Safari**: 13+
- **Edge**: 80+

### Recommended Hardware
- **RAM**: 2GB minimum, 4GB recommended
- **Storage**: 500MB for system files
- **Network**: Local network or internet for multi-user access

## 🐛 **Troubleshooting**

### Common Issues

**1. "Database Connection Failed"**
- Verify MySQL service is running in XAMPP
- Check database credentials in `config/database.php`
- Ensure database `dj_cheenee_boutique` exists

**2. "Page Not Found" Errors**
- Verify Apache service is running
- Check the correct URL path
- Ensure all files are in the correct directory

**3. "Session Expired" Messages**
- Clear browser cookies and cache
- Restart XAMPP services
- Check session configuration

**4. Charts Not Loading**
- Verify internet connection (Chart.js CDN)
- Check browser console for JavaScript errors
- Ensure data is available for the selected date range

### Support & Maintenance

**Regular Maintenance**
- Backup database regularly via phpMyAdmin export
- Monitor disk space for transaction logs
- Update default passwords after installation
- Review and clean up old transaction data periodically

**Performance Optimization**
- Index database tables for faster queries
- Optimize images for faster loading
- Enable compression in Apache configuration
- Consider caching for high-traffic scenarios

## 📝 **License & Credits**

### Built With
- **PHP** - Server-side scripting
- **MySQL** - Database management
- **Bootstrap 5** - UI framework
- **Chart.js** - Data visualization
- **Font Awesome** - Icons
- **Google Fonts** - Typography (Poppins)

### Sample Images
- Product images from Unsplash (for demonstration only)
- Replace with actual product photos in production

---

**© 2024 DJ Cheenee's Fashion Boutique POS System**

*Built with ❤️ for fashion boutique management*

For technical support or customization requests, please refer to the documentation or contact your system administrator.
