<?php
/**
 * DJ Cheenee's Fashion Boutique - Session Management
 */

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

class SessionManager {
    
    public static function startSession() {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
    }

    public static function login($user) {
        self::startSession();
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['login_time'] = time();
    }

    public static function logout() {
        self::startSession();
        session_unset();
        session_destroy();
    }

    public static function isLoggedIn() {
        self::startSession();
        return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
    }

    public static function getUser() {
        self::startSession();
        if (self::isLoggedIn()) {
            return [
                'id' => $_SESSION['user_id'] ?? null,
                'username' => $_SESSION['username'] ?? null,
                'full_name' => $_SESSION['full_name'] ?? null,
                'role' => $_SESSION['role'] ?? null,
                'email' => $_SESSION['email'] ?? null
            ];
        }
        return null;
    }

    public static function getUserRole() {
        self::startSession();
        return $_SESSION['role'] ?? null;
    }

    public static function isAdmin() {
        return self::getUserRole() === 'admin';
    }

    public static function isCashier() {
        return self::getUserRole() === 'cashier';
    }

    public static function requireAuth() {
        if (!self::isLoggedIn()) {
            header("Location: ../login.php");
            exit();
        }
    }

    public static function requireAdmin() {
        self::requireAuth();
        if (!self::isAdmin()) {
            header("Location: /DJ Cheenee's Fashion Botique-POS and Inventory System V4/unauthorized.php");
            exit();
        }
    }

    public static function redirectByRole() {
        if (self::isLoggedIn()) {
            if (self::isAdmin()) {
                header("Location: /DJ Cheenee's Fashion Botique-POS and Inventory System V4/admin/dashboard.php");
            } else {
                header("Location: /DJ Cheenee's Fashion Botique-POS and Inventory System V4/cashier/pos.php");
            }
            exit();
        }
    }
}
?>
