        </div> <!-- End container-fluid -->
    </div> <!-- End main-content -->

    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JavaScript -->
    <script>
        // Sidebar Toggle with state persistence
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('main-content');
            
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
            
            // Save the collapse state to localStorage
            const isCollapsed = sidebar.classList.contains('collapsed');
            localStorage.setItem('sidebarCollapsed', isCollapsed);
        });

        // Auto-hide alerts after 5 seconds (exclude dashboard stock alerts)
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                // Don't auto-hide stock alerts in dashboard or alerts marked as permanent
                if (!alert.classList.contains('alert-permanent') && 
                    !alert.closest('[class*="out-of-stock"]') &&
                    !alert.closest('[class*="stock-alert"]') &&
                    !alert.closest('.card-body')) {
                    alert.style.transition = 'opacity 0.5s ease';
                    alert.style.opacity = '0';
                    setTimeout(function() {
                        alert.remove();
                    }, 500);
                }
            });
        }, 5000);

        // Load notifications with enhanced UI
        function loadNotifications() {
            fetch('../api/notifications.php')
                .then(response => response.json())
                .then(data => {
                    const badge = document.getElementById('notificationBadge');
                    const list = document.getElementById('notificationList');
                    
                    if (data.count > 0) {
                        badge.textContent = data.count;
                        badge.style.display = 'block';
                        
                        let html = `
                            <li>
                                <h6 class="dropdown-header">
                                    <i class="fas fa-bell me-2"></i>Notifications
                                    <span class="badge bg-white text-primary ms-auto">${data.count}</span>
                                </h6>
                            </li>
                        `;
                        
                        data.notifications.forEach(notification => {
                            // Enhanced notification styling
                            let iconClass, iconCircleClass, timeAgo;
                            
                            if (notification.type === 'out_of_stock') {
                                iconClass = 'fas fa-times-circle';
                                iconCircleClass = 'notification-icon-circle notification-out-stock';
                            } else if (notification.type === 'low_stock') {
                                iconClass = 'fas fa-exclamation-triangle';
                                iconCircleClass = 'notification-icon-circle notification-low-stock';
                            }
                            
                            // Calculate time ago (simplified)
                            const now = new Date();
                            const notificationDate = new Date(notification.created_at);
                            const diffInMinutes = Math.floor((now - notificationDate) / (1000 * 60));
                            
                            if (diffInMinutes < 1) {
                                timeAgo = 'Just now';
                            } else if (diffInMinutes < 60) {
                                timeAgo = `${diffInMinutes}m ago`;
                            } else if (diffInMinutes < 1440) {
                                timeAgo = `${Math.floor(diffInMinutes / 60)}h ago`;
                            } else {
                                timeAgo = `${Math.floor(diffInMinutes / 1440)}d ago`;
                            }
                            
                            html += `
                                <li class="notification-item">
                                    <a class="dropdown-item" href="#" onclick="handleNotificationClick('${notification.type}', ${notification.id})">
                                        <div class="d-flex align-items-start">
                                            <div class="${iconCircleClass}">
                                                <i class="${iconClass}"></i>
                                            </div>
                                            <div class="flex-grow-1">
                                                <div class="notification-title">${notification.title}</div>
                                                <div class="notification-message">${notification.message}</div>
                                                <div class="notification-time">
                                                    <i class="fas fa-clock me-1"></i>${timeAgo}
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            `;
                        });
                        list.innerHTML = html;
                    } else {
                        badge.style.display = 'none';
                        list.innerHTML = `
                            <li>
                                <h6 class="dropdown-header">
                                    <i class="fas fa-bell me-2"></i>Notifications
                                </h6>
                            </li>
                            <li class="notification-empty">
                                <i class="fas fa-bell-slash"></i>
                                <div>No new notifications</div>
                                <small>You're all caught up!</small>
                            </li>
                        `;
                    }
                })
                .catch(error => {
                    console.log('Error loading notifications:', error);
                });
        }
        
        // Handle notification clicks
        function handleNotificationClick(type, id) {
            if (type === 'low_stock' || type === 'out_of_stock') {
                // Redirect to inventory page
                window.location.href = '../admin/inventory.php';
            }
        }

        // Load notifications on page load and every 30 seconds
        loadNotifications();
        setInterval(loadNotifications, 30000);

        // Mobile responsive sidebar
        function handleResponsive() {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('main-content');
            
            if (window.innerWidth <= 768) {
                sidebar.classList.add('collapsed');
                mainContent.classList.add('expanded');
            }
        }

        window.addEventListener('resize', handleResponsive);
        window.addEventListener('load', handleResponsive);
    </script>
    
    <?php if (isset($additional_js)): ?>
        <?php echo $additional_js; ?>
    <?php endif; ?>
</body>
</html>
