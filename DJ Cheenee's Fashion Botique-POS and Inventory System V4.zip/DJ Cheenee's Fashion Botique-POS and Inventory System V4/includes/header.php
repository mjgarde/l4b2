<?php
/**
 * DJ Cheenee's Fashion Boutique - Header Include
 */

require_once __DIR__ . '/../config/session.php';
SessionManager::requireAuth();
$current_user = SessionManager::getUser();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'DJ Cheenee\'s Fashion Boutique'; ?></title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Custom CSS with cache busting -->
    <link href="../assets/css/style.css?v=<?php echo time(); ?>" rel="stylesheet">
</head>
<body>
    <!-- Sidebar Navigation -->
    <nav class="sidebar" id="sidebar">
        <script>
            // Apply collapsed state immediately to prevent flickering
            (function() {
                const isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
                if (isCollapsed) {
                    document.getElementById('sidebar').classList.add('collapsed');
                }
            })();
        </script>
        <div class="sidebar-header">
            <div class="logo-container">
                <div class="logo-main">
                    <div class="logo-icon">
                        <i class="fas fa-tshirt"></i>
                        <div class="logo-shine"></div>
                    </div>
                    <div class="logo-accent-dot"></div>
                </div>
                <div class="logo-pulse-ring"></div>
            </div>
            <div class="sidebar-brand">
                <h5 class="brand-title mb-0">DJ Cheenee's</h5>
                <small class="brand-subtitle">Fashion Boutique</small>
                <div class="brand-divider">
                    <div class="divider-line"></div>
                    <div class="divider-dot"></div>
                    <div class="divider-line"></div>
                </div>
            </div>
        </div>

        <ul class="sidebar-menu">
            <?php if (SessionManager::isAdmin()): ?>
                <li>
                    <a href="../admin/dashboard.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'dashboard.php') ? 'active' : ''; ?>" data-title="Dashboard">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="../admin/inventory.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'inventory.php') ? 'active' : ''; ?>" data-title="Inventory">
                        <i class="fas fa-boxes"></i>
                        <span>Inventory</span>
                    </a>
                </li>
                <li>
                    <a href="../admin/products.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'products.php') ? 'active' : ''; ?>" data-title="Products">
                        <i class="fas fa-tag"></i>
                        <span>Products</span>
                    </a>
                </li>
                <li>
                    <a href="../admin/sales.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'sales.php') ? 'active' : ''; ?>" data-title="Sales">
                        <i class="fas fa-chart-line"></i>
                        <span>Sales</span>
                    </a>
                </li>
                <li>
                    <a href="../admin/reports.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'reports.php') ? 'active' : ''; ?>" data-title="Reports">
                        <i class="fas fa-file-alt"></i>
                        <span>Reports</span>
                    </a>
                </li>
                <li>
                    <a href="../admin/users.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'users.php') ? 'active' : ''; ?>" data-title="Users">
                        <i class="fas fa-users"></i>
                        <span>Users</span>
                    </a>
                </li>
            <?php endif; ?>
            
            <li>
                <a href="../cashier/pos.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'pos.php') ? 'active' : ''; ?>" data-title="POS">
                    <i class="fas fa-cash-register"></i>
                    <span>POS</span>
                </a>
            </li>
            
            <li>
                <a href="../logout.php" data-title="Logout">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="main-content" id="main-content">
        <script>
            // Apply expanded state to main content immediately if sidebar is collapsed
            (function() {
                const isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
                if (isCollapsed) {
                    document.getElementById('main-content').classList.add('expanded');
                }
            })();
        </script>
        <!-- Top Navbar -->
        <nav class="navbar">
            <div class="navbar-left">
                <button class="btn btn-outline-primary btn-sm" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <nav aria-label="breadcrumb" class="ms-3">
                    <ol class="breadcrumb mb-0">
                        <?php if (isset($breadcrumbs) && is_array($breadcrumbs)): ?>
                            <?php foreach ($breadcrumbs as $index => $crumb): ?>
                                <?php if ($index === count($breadcrumbs) - 1): ?>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo $crumb['name']; ?></li>
                                <?php else: ?>
                                    <li class="breadcrumb-item">
                                        <a href="<?php echo $crumb['url']; ?>"><?php echo $crumb['name']; ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ol>
                </nav>
            </div>
            
            <div class="navbar-right d-flex align-items-center">
                <!-- Notifications -->
                <div class="dropdown me-3">
                    <button class="btn btn-outline-primary btn-sm position-relative" type="button" 
                            id="notificationDropdown" data-bs-toggle="dropdown">
                        <i class="fas fa-bell"></i>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" 
                              id="notificationBadge" style="display: none;">
                            0
                        </span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" id="notificationList">
                        <li><h6 class="dropdown-header">Notifications</h6></li>
                        <li><span class="dropdown-item-text text-muted">No new notifications</span></li>
                    </ul>
                </div>

                <!-- User Profile -->
                <div class="dropdown">
                    <button class="btn btn-outline-primary btn-sm dropdown-toggle" type="button" 
                            data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-2"></i>
                        <?php echo htmlspecialchars($current_user['full_name']); ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><h6 class="dropdown-header"><?php echo ucfirst($current_user['role']); ?></h6></li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item" href="../logout.php">
                                <i class="fas fa-sign-out-alt me-2"></i>Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Page Content -->
        <div class="container-fluid p-4">
