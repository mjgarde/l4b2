-- DJ Cheenee's Fashion Boutique - Sample Data
-- Insert sample data for testing the POS system

USE dj_cheenee_boutique;

-- Sample Products
INSERT INTO products (name, description, category_id, brand_id, image_url) VALUES 
('Classic Denim Jacket', 'Timeless denim jacket perfect for any season', 4, 2, 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400'),
('Floral Summer Dress', 'Light and breezy floral dress for summer', 1, 3, 'https://images.unsplash.com/photo-1595777457583-95e59e62e2a1?w=400'),
('Business Blouse', 'Professional white blouse for office wear', 2, 3, 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400'),
('High-Waist Jeans', 'Comfortable high-waist denim jeans', 3, 2, 'https://images.unsplash.com/photo-1582418702059-97ebafb35d09?w=400'),
('Designer Handbag', 'Luxury leather handbag with gold accents', 5, 1, 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400'),
('Knit Cardigan', 'Cozy knit cardigan for layering', 4, 3, 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=400'),
('Midi Skirt', 'Elegant pleated midi skirt', 3, 3, 'https://images.unsplash.com/photo-1583496661160-fb5886a13d4e?w=400'),
('Statement Necklace', 'Bold statement necklace with pearls', 5, 1, 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400');

-- Sample Product Variants
-- Denim Jacket variants
INSERT INTO product_variants (product_id, barcode, size, color, price, cost_price, stock_quantity, low_stock_threshold) VALUES 
(1, '1234567890123', 'S', 'Blue', 89.99, 45.00, 15, 5),
(1, '1234567890124', 'M', 'Blue', 89.99, 45.00, 20, 5),
(1, '1234567890125', 'L', 'Blue', 89.99, 45.00, 12, 5),
(1, '1234567890126', 'XL', 'Blue', 89.99, 45.00, 8, 5),
(1, '1234567890127', 'S', 'Black', 94.99, 47.50, 10, 5),
(1, '1234567890128', 'M', 'Black', 94.99, 47.50, 18, 5),
(1, '1234567890129', 'L', 'Black', 94.99, 47.50, 14, 5),
(1, '1234567890130', 'XL', 'Black', 94.99, 47.50, 6, 5),
(1, '123456789156', 'M', 'Black', 94.99, 47.50, 89, 5);

-- Summer Dress variants
INSERT INTO product_variants (product_id, barcode, size, color, price, cost_price, stock_quantity, low_stock_threshold) VALUES 
(2, '2234567890123', 'XS', 'Pink', 65.99, 30.00, 8, 3),
(2, '2234567890124', 'S', 'Pink', 65.99, 30.00, 12, 3),
(2, '2234567890125', 'M', 'Pink', 65.99, 30.00, 15, 3),
(2, '2234567890126', 'L', 'Pink', 65.99, 30.00, 9, 3),
(2, '2234567890127', 'XS', 'Blue', 65.99, 30.00, 6, 3),
(2, '2234567890128', 'S', 'Blue', 65.99, 30.00, 11, 3),
(2, '2234567890129', 'M', 'Blue', 65.99, 30.00, 13, 3),
(2, '2234567890130', 'L', 'Blue', 65.99, 30.00, 7, 3);

-- Business Blouse variants
INSERT INTO product_variants (product_id, barcode, size, color, price, cost_price, stock_quantity, low_stock_threshold) VALUES 
(3, '3234567890123', 'XS', 'White', 45.99, 22.00, 5, 5),
(3, '3234567890124', 'S', 'White', 45.99, 22.00, 3, 5),
(3, '3234567890125', 'M', 'White', 45.99, 22.00, 8, 5),
(3, '3234567890126', 'L', 'White', 45.99, 22.00, 6, 5),
(3, '3234567890127', 'XL', 'White', 45.99, 22.00, 4, 5),
(3, '3234567890128', 'S', 'Cream', 49.99, 24.00, 7, 5),
(3, '3234567890129', 'M', 'Cream', 49.99, 24.00, 9, 5),
(3, '3234567890130', 'L', 'Cream', 49.99, 24.00, 5, 5);

-- High-Waist Jeans variants
INSERT INTO product_variants (product_id, barcode, size, color, price, cost_price, stock_quantity, low_stock_threshold) VALUES 
(4, '4234567890123', '26', 'Dark Blue', 79.99, 40.00, 12, 4),
(4, '4234567890124', '28', 'Dark Blue', 79.99, 40.00, 15, 4),
(4, '4234567890125', '30', 'Dark Blue', 79.99, 40.00, 18, 4),
(4, '4234567890126', '32', 'Dark Blue', 79.99, 40.00, 11, 4),
(4, '4234567890127', '34', 'Dark Blue', 79.99, 40.00, 8, 4),
(4, '4234567890128', '26', 'Black', 84.99, 42.50, 9, 4),
(4, '4234567890129', '28', 'Black', 84.99, 42.50, 13, 4),
(4, '4234567890130', '30', 'Black', 84.99, 42.50, 16, 4);

-- Designer Handbag variants
INSERT INTO product_variants (product_id, barcode, size, color, price, cost_price, stock_quantity, low_stock_threshold) VALUES 
(5, '5234567890123', 'One Size', 'Brown', 299.99, 150.00, 4, 2),
(5, '5234567890124', 'One Size', 'Black', 299.99, 150.00, 6, 2),
(5, '5234567890125', 'One Size', 'Tan', 319.99, 160.00, 3, 2),
(5, '5234567890126', 'One Size', 'Red', 329.99, 165.00, 2, 2);

-- Knit Cardigan variants
INSERT INTO product_variants (product_id, barcode, size, color, price, cost_price, stock_quantity, low_stock_threshold) VALUES 
(6, '6234567890123', 'S', 'Beige', 55.99, 28.00, 10, 4),
(6, '6234567890124', 'M', 'Beige', 55.99, 28.00, 14, 4),
(6, '6234567890125', 'L', 'Beige', 55.99, 28.00, 11, 4),
(6, '6234567890126', 'S', 'Gray', 55.99, 28.00, 8, 4),
(6, '6234567890127', 'M', 'Gray', 55.99, 28.00, 12, 4),
(6, '6234567890128', 'L', 'Gray', 55.99, 28.00, 9, 4);

-- Midi Skirt variants
INSERT INTO product_variants (product_id, barcode, size, color, price, cost_price, stock_quantity, low_stock_threshold) VALUES 
(7, '7234567890123', 'XS', 'Navy', 39.99, 20.00, 7, 3),
(7, '7234567890124', 'S', 'Navy', 39.99, 20.00, 9, 3),
(7, '7234567890125', 'M', 'Navy', 39.99, 20.00, 11, 3),
(7, '7234567890126', 'L', 'Navy', 39.99, 20.00, 6, 3),
(7, '7234567890127', 'XS', 'Black', 39.99, 20.00, 5, 3),
(7, '7234567890128', 'S', 'Black', 39.99, 20.00, 8, 3);

-- Statement Necklace variants
INSERT INTO product_variants (product_id, barcode, size, color, price, cost_price, stock_quantity, low_stock_threshold) VALUES 
(8, '8234567890123', 'One Size', 'Gold', 129.99, 65.00, 6, 2),
(8, '8234567890124', 'One Size', 'Silver', 119.99, 60.00, 8, 2),
(8, '8234567890125', 'One Size', 'Rose Gold', 139.99, 70.00, 4, 2);

-- Sample Sales Transactions (for dashboard data)
INSERT INTO sales_transactions (transaction_number, user_id, customer_name, customer_phone, subtotal, tax_amount, discount_amount, total_amount, payment_method, payment_status, created_at) VALUES 
('TXN-20240906-0001', 2, 'Maria Santos', '09123456789', 155.98, 18.72, 0.00, 174.70, 'cash', 'completed', '2024-09-06 09:30:00'),
('TXN-20240906-0002', 2, 'John Dela Cruz', '09234567890', 89.99, 10.80, 0.00, 100.79, 'card', 'completed', '2024-09-06 11:15:00'),
('TXN-20240906-0003', 2, 'Ana Garcia', '09345678901', 79.99, 9.60, 5.00, 84.59, 'cash', 'completed', '2024-09-06 14:22:00'),
('TXN-20240906-0004', 2, 'Robert Tan', '09456789012', 299.99, 36.00, 0.00, 335.99, 'card', 'completed', '2024-09-06 16:45:00'),
('TXN-20240905-0001', 2, 'Linda Chen', '09567890123', 105.98, 12.72, 0.00, 118.70, 'digital_wallet', 'completed', '2024-09-05 10:20:00'),
('TXN-20240905-0002', 2, 'Mark Wilson', '09678901234', 65.99, 7.92, 0.00, 73.91, 'cash', 'completed', '2024-09-05 13:30:00'),
('TXN-20240905-0003', 2, 'Sarah Kim', '09789012345', 219.98, 26.40, 10.00, 236.38, 'card', 'completed', '2024-09-05 15:45:00');

-- Sample Sales Transaction Items
INSERT INTO sales_transaction_items (transaction_id, product_variant_id, quantity, unit_price, total_price) VALUES 
-- Transaction 1: Maria Santos
(1, 2, 1, 89.99, 89.99),
(1, 10, 1, 65.99, 65.99),
-- Transaction 2: John Dela Cruz
(2, 1, 1, 89.99, 89.99),
-- Transaction 3: Ana Garcia
(3, 16, 1, 79.99, 79.99),
-- Transaction 4: Robert Tan
(4, 21, 1, 299.99, 299.99),
-- Transaction 5: Linda Chen
(5, 3, 1, 89.99, 89.99),
(5, 37, 1, 15.99, 15.99),
-- Transaction 6: Mark Wilson
(6, 11, 1, 65.99, 65.99),
-- Transaction 7: Sarah Kim
(7, 2, 1, 89.99, 89.99),
(7, 22, 1, 129.99, 129.99);

-- Update stock quantities based on sales
UPDATE product_variants SET stock_quantity = stock_quantity - 1 WHERE id IN (1, 2, 3, 10, 11, 16, 21, 22, 37);

-- Create some low stock notifications
INSERT INTO notifications (type, title, message, product_variant_id) VALUES 
('low_stock', 'Low Stock Alert', 'Business Blouse (S - White) is running low: 3 left', 14),
('low_stock', 'Low Stock Alert', 'Designer Handbag (One Size - Red) is running low: 2 left', 24);
