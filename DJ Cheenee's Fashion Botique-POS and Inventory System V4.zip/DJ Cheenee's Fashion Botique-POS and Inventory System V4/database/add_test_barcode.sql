-- Add test barcode 123456789156 to the database
-- This will make the barcode from your printed label work with the scanner

INSERT INTO product_variants (product_id, barcode, size, color, price, cost_price, stock_quantity, low_stock_threshold) 
VALUES (1, '123456789156', 'M', 'Black', 94.99, 47.50, 89, 5);

-- This adds the barcode "123456789156" as:
-- Product: Classic Denim Jacket (product_id = 1)
-- Size: Medium (M)
-- Color: Black
-- Price: ₱94.99
-- Stock: 89 pieces
-- Low stock threshold: 5 pieces
