-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 15, 2025 at 05:29 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dj_cheenee_boutique`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `description`, `created_at`) VALUES
(1, 'DJ Cheenee Signature', 'Exclusive boutique collection', '2025-09-06 11:48:23'),
(2, 'Fashion Forward', 'Contemporary women\'s fashion', '2025-09-06 11:48:23'),
(3, 'Elegant Essentials', 'Classic and timeless pieces', '2025-09-06 11:48:23');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `created_at`) VALUES
(1, 'Dresses', 'Various dress styles and designs', '2025-09-06 11:48:22'),
(2, 'Tops', 'Blouses, shirts, and casual tops', '2025-09-06 11:48:22'),
(3, 'Bottoms', 'Pants, skirts, and shorts', '2025-09-06 11:48:22'),
(4, 'Outerwear', 'Jackets, coats, and cardigans', '2025-09-06 11:48:22'),
(5, 'Accessories', 'Bags, jewelry, and fashion accessories', '2025-09-06 11:48:22');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `type` enum('low_stock','system','alert') NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `user_id` int(11) DEFAULT NULL,
  `product_variant_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `type`, `title`, `message`, `is_read`, `user_id`, `product_variant_id`, `created_at`) VALUES
(1, 'low_stock', 'Low Stock Alert', 'Business Blouse (S - White) is running low: 3 left', 0, NULL, 14, '2025-09-06 11:55:18'),
(2, 'low_stock', 'Low Stock Alert', 'Designer Handbag (One Size - Red) is running low: 2 left', 0, NULL, 24, '2025-09-06 11:55:18'),
(3, 'low_stock', 'Low Stock Alert', 'Business Blouse (S - White) is running low: 3 left', 0, NULL, 18, '2025-09-06 11:58:07'),
(4, 'low_stock', 'Low Stock Alert', 'Business Blouse (XL - White) is running low: 3 left', 0, NULL, 21, '2025-09-06 11:58:07'),
(5, 'low_stock', 'Low Stock Alert', 'Business Blouse (XS - White) is running low: 5 left', 0, NULL, 17, '2025-09-06 11:58:07'),
(6, 'low_stock', 'Low Stock Alert', 'Designer Handbag (One Size - Red) is running low: 2 left', 0, NULL, 36, '2025-09-06 11:58:07'),
(7, 'low_stock', 'Low Stock Alert', 'Elegant Evening Dress (M - Black) is running low: 0 left', 0, NULL, 52, '2025-09-06 13:33:08'),
(8, 'low_stock', 'Low Stock Alert', 'Business Blouse (L - White) is running low: 5 left', 0, NULL, 20, '2025-09-07 02:50:44'),
(9, 'low_stock', 'Low Stock Alert', 'Classic Denim Jacket (L - Blue) is running low: 5 left', 0, NULL, 3, '2025-09-07 11:58:44');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `category_id`, `brand_id`, `image_url`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Classic Denim Jacket', 'Timeless denim jacket perfect for any season', 4, 2, 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400', 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(2, 'Floral Summer Dress', 'Light and breezy floral dress for summer', 1, 3, 'https://images.unsplash.com/photo-1595777457583-95e59e62e2a1?w=400', 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(3, 'Business Blouse', 'Professional white blouse for office wear', 2, 3, 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400', 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(4, 'High-Waist Jeans', 'Comfortable high-waist denim jeans', 3, 2, 'https://images.unsplash.com/photo-1582418702059-97ebafb35d09?w=400', 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(5, 'Designer Handbag', 'Luxury leather handbag with gold accents', 5, 1, 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400', 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(6, 'Knit Cardigan', 'Cozy knit cardigan for layering', 4, 3, 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=400', 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(7, 'Midi Skirt', 'Elegant pleated midi skirt', 3, 3, 'https://images.unsplash.com/photo-1583496661160-fb5886a13d4e?w=400', 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(8, 'Statement Necklace', 'Bold statement necklace with pearls', 5, 1, 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400', 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(9, 'Elegant Evening Dress', 'wew', 1, 3, 'https://th.bing.com/th?id=OIF.%2bN0dgP06WkZQQ%2fzGIv5FPQ&w=195&h=319&c=7&r=0&o=7&pid=1.7&rm=3', 1, '2025-09-06 13:08:37', '2025-09-06 13:08:37'),
(10, 'Elegant Evening Dress', 'wew', 1, 3, 'https://th.bing.com/th?id=OIF.%2bN0dgP06WkZQQ%2fzGIv5FPQ&w=195&h=319&c=7&r=0&o=7&pid=1.7&rm=3', 1, '2025-09-06 13:08:41', '2025-09-06 13:08:41');

-- --------------------------------------------------------

--
-- Table structure for table `product_variants`
--

CREATE TABLE `product_variants` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `barcode` varchar(100) NOT NULL,
  `size` varchar(20) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `cost_price` decimal(10,2) DEFAULT 0.00,
  `stock_quantity` int(11) NOT NULL DEFAULT 0,
  `low_stock_threshold` int(11) DEFAULT 5,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_variants`
--

INSERT INTO `product_variants` (`id`, `product_id`, `barcode`, `size`, `color`, `price`, `cost_price`, `stock_quantity`, `low_stock_threshold`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, '1234567890123', 'S', 'Blue', 89.99, 45.00, 14, 5, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:18'),
(2, 1, '1234567890124', 'M', 'Blue', 89.99, 45.00, 18, 5, 1, '2025-09-06 11:55:17', '2025-09-06 11:59:07'),
(3, 1, '1234567890125', 'L', 'Blue', 89.99, 45.00, 5, 5, 1, '2025-09-06 11:55:17', '2025-09-07 11:58:22'),
(4, 1, '1234567890126', 'XL', 'Blue', 89.99, 45.00, 8, 5, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(5, 1, '1234567890127', 'S', 'Black', 94.99, 47.50, 10, 5, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(6, 1, '1234567890128', 'M', 'Black', 94.99, 47.50, 17, 5, 1, '2025-09-06 11:55:17', '2025-09-06 22:20:00'),
(7, 1, '1234567890129', 'L', 'Black', 94.99, 47.50, 10, 5, 1, '2025-09-06 11:55:17', '2025-09-07 11:58:22'),
(8, 1, '1234567890130', 'XL', 'Black', 94.99, 47.50, 6, 5, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(9, 2, '2234567890123', 'XS', 'Pink', 65.99, 30.00, 8, 3, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(10, 2, '2234567890124', 'S', 'Pink', 65.99, 30.00, 11, 3, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:18'),
(11, 2, '2234567890125', 'M', 'Pink', 65.99, 30.00, 14, 3, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:18'),
(12, 2, '2234567890126', 'L', 'Pink', 65.99, 30.00, 9, 3, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(13, 2, '2234567890127', 'XS', 'Blue', 65.99, 30.00, 6, 3, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(14, 2, '2234567890128', 'S', 'Blue', 65.99, 30.00, 11, 3, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(15, 2, '2234567890129', 'M', 'Blue', 65.99, 30.00, 13, 3, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(16, 2, '2234567890130', 'L', 'Blue', 65.99, 30.00, 6, 3, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:18'),
(17, 3, '3234567890123', 'XS', 'White', 45.99, 22.00, 5, 5, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(18, 3, '3234567890124', 'S', 'White', 45.99, 22.00, 3, 5, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(19, 3, '3234567890125', 'M', 'White', 45.99, 22.00, 8, 5, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(20, 3, '3234567890126', 'L', 'White', 45.99, 22.00, 5, 5, 1, '2025-09-06 11:55:17', '2025-09-07 02:50:11'),
(21, 3, '3234567890127', 'XL', 'White', 45.99, 22.00, 3, 5, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:18'),
(22, 3, '3234567890128', 'S', 'Cream', 49.99, 24.00, 6, 5, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:18'),
(23, 3, '3234567890129', 'M', 'Cream', 49.99, 24.00, 7, 5, 1, '2025-09-06 11:55:17', '2025-09-07 02:50:11'),
(24, 3, '3234567890130', 'L', 'Cream', 49.99, 24.00, 4, 5, 1, '2025-09-06 11:55:17', '2025-09-07 10:47:58'),
(25, 4, '4234567890123', '26', 'Dark Blue', 79.99, 40.00, 9, 4, 1, '2025-09-06 11:55:17', '2025-09-06 13:30:28'),
(26, 4, '4234567890124', '28', 'Dark Blue', 79.99, 40.00, 15, 4, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(27, 4, '4234567890125', '30', 'Dark Blue', 79.99, 40.00, 18, 4, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(28, 4, '4234567890126', '32', 'Dark Blue', 79.99, 40.00, 11, 4, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(29, 4, '4234567890127', '34', 'Dark Blue', 79.99, 40.00, 8, 4, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(30, 4, '4234567890128', '26', 'Black', 84.99, 42.50, 9, 4, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(31, 4, '4234567890129', '28', 'Black', 84.99, 42.50, 13, 4, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(32, 4, '4234567890130', '30', 'Black', 84.99, 42.50, 16, 4, 1, '2025-09-06 11:55:17', '2025-09-06 11:55:17'),
(33, 5, '5234567890123', 'One Size', 'Brown', 299.99, 150.00, 4, 2, 1, '2025-09-06 11:55:18', '2025-09-06 11:55:18'),
(34, 5, '5234567890124', 'One Size', 'Black', 299.99, 150.00, 6, 2, 1, '2025-09-06 11:55:18', '2025-09-06 11:55:18'),
(35, 5, '5234567890125', 'One Size', 'Tan', 319.99, 160.00, 3, 2, 1, '2025-09-06 11:55:18', '2025-09-06 11:55:18'),
(36, 5, '5234567890126', 'One Size', 'Red', 329.99, 165.00, 3, 2, 1, '2025-09-06 11:55:18', '2025-09-06 13:10:21'),
(37, 6, '6234567890123', 'S', 'Beige', 55.99, 28.00, 9, 4, 1, '2025-09-06 11:55:18', '2025-09-06 11:55:18'),
(38, 6, '6234567890124', 'M', 'Beige', 55.99, 28.00, 13, 4, 1, '2025-09-06 11:55:18', '2025-09-06 22:20:00'),
(39, 6, '6234567890125', 'L', 'Beige', 55.99, 28.00, 11, 4, 1, '2025-09-06 11:55:18', '2025-09-06 11:55:18'),
(40, 6, '6234567890126', 'S', 'Gray', 55.99, 28.00, 8, 4, 1, '2025-09-06 11:55:18', '2025-09-06 11:55:18'),
(41, 6, '6234567890127', 'M', 'Gray', 55.99, 28.00, 11, 4, 1, '2025-09-06 11:55:18', '2025-09-06 22:20:00'),
(42, 6, '6234567890128', 'L', 'Gray', 55.99, 28.00, 9, 4, 1, '2025-09-06 11:55:18', '2025-09-06 11:55:18'),
(43, 7, '7234567890123', 'XS', 'Navy', 39.99, 20.00, 7, 3, 1, '2025-09-06 11:55:18', '2025-09-06 11:55:18'),
(44, 7, '7234567890124', 'S', 'Navy', 39.99, 20.00, 9, 3, 1, '2025-09-06 11:55:18', '2025-09-06 11:55:18'),
(45, 7, '7234567890125', 'M', 'Navy', 39.99, 20.00, 11, 3, 1, '2025-09-06 11:55:18', '2025-09-06 11:55:18'),
(46, 7, '7234567890126', 'L', 'Navy', 39.99, 20.00, 6, 3, 1, '2025-09-06 11:55:18', '2025-09-06 11:55:18'),
(47, 7, '7234567890127', 'XS', 'Black', 39.99, 20.00, 5, 3, 1, '2025-09-06 11:55:18', '2025-09-06 11:55:18'),
(48, 7, '7234567890128', 'S', 'Black', 39.99, 20.00, 8, 3, 1, '2025-09-06 11:55:18', '2025-09-06 11:55:18'),
(49, 8, '8234567890123', 'One Size', 'Gold', 129.99, 65.00, 6, 2, 1, '2025-09-06 11:55:18', '2025-09-06 11:55:18'),
(50, 8, '8234567890124', 'One Size', 'Silver', 119.99, 60.00, 8, 2, 1, '2025-09-06 11:55:18', '2025-09-06 11:55:18'),
(51, 8, '8234567890125', 'One Size', 'Rose Gold', 139.99, 70.00, 4, 2, 1, '2025-09-06 11:55:18', '2025-09-06 11:55:18'),
(52, 9, '1757164176619138', 'M', 'Black', 40.00, 30.00, 0, 5, 1, '2025-09-06 13:09:45', '2025-09-06 13:33:05');

-- --------------------------------------------------------

--
-- Table structure for table `sales_transactions`
--

CREATE TABLE `sales_transactions` (
  `id` int(11) NOT NULL,
  `transaction_number` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `tax_amount` decimal(10,2) DEFAULT 0.00,
  `discount_amount` decimal(10,2) DEFAULT 0.00,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_method` enum('cash','card','digital_wallet') NOT NULL,
  `payment_amount` decimal(10,2) DEFAULT NULL,
  `change_amount` decimal(10,2) DEFAULT NULL,
  `payment_status` enum('completed','pending','cancelled') DEFAULT 'completed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_transactions`
--

INSERT INTO `sales_transactions` (`id`, `transaction_number`, `user_id`, `customer_name`, `customer_phone`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `payment_method`, `payment_amount`, `change_amount`, `payment_status`, `created_at`) VALUES
(1, 'TXN-20240906-0001', 2, 'Maria Santos', '09123456789', 155.98, 18.72, 0.00, 174.70, 'cash', 174.70, 0.00, 'completed', '2024-09-06 01:30:00'),
(2, 'TXN-20240906-0002', 2, 'John Dela Cruz', '09234567890', 89.99, 10.80, 0.00, 100.79, 'card', 100.79, 0.00, 'completed', '2024-09-06 03:15:00'),
(3, 'TXN-20240906-0003', 2, 'Ana Garcia', '09345678901', 79.99, 9.60, 5.00, 84.59, 'cash', 84.59, 0.00, 'completed', '2024-09-06 06:22:00'),
(4, 'TXN-20240906-0004', 2, 'Robert Tan', '09456789012', 299.99, 36.00, 0.00, 335.99, 'card', 335.99, 0.00, 'completed', '2024-09-06 08:45:00'),
(5, 'TXN-20240905-0001', 2, 'Linda Chen', '09567890123', 105.98, 12.72, 0.00, 118.70, 'digital_wallet', 118.70, 0.00, 'completed', '2024-09-05 02:20:00'),
(6, 'TXN-20240905-0002', 2, 'Mark Wilson', '09678901234', 65.99, 7.92, 0.00, 73.91, 'cash', 73.91, 0.00, 'completed', '2024-09-05 05:30:00'),
(7, 'TXN-20240905-0003', 2, 'Sarah Kim', '09789012345', 219.98, 26.40, 10.00, 236.38, 'card', 236.38, 0.00, 'completed', '2024-09-05 07:45:00'),
(8, 'TXN-20250906-5436', 1, NULL, NULL, 89.99, 10.80, 0.00, 100.79, 'card', 100.79, 0.00, 'completed', '2025-09-06 11:59:07'),
(9, 'TXN-20250906-3410', 1, NULL, NULL, 239.97, 28.80, 0.00, 268.77, 'cash', 268.77, 0.00, 'completed', '2025-09-06 13:30:28'),
(10, 'TXN-20250906-3847', 1, NULL, NULL, 400.00, 48.00, 0.00, 448.00, 'cash', 448.00, 0.00, 'completed', '2025-09-06 13:33:05'),
(11, 'TXN-20250906-3484', 1, NULL, NULL, 284.97, 34.20, 0.00, 319.17, 'cash', 319.17, 0.00, 'completed', '2025-09-06 13:33:29'),
(12, 'TXN-20250906-6991', 1, NULL, NULL, 89.99, 10.80, 0.00, 100.79, 'cash', 300.00, 199.21, 'completed', '2025-09-06 13:41:11'),
(13, 'TXN-20250907-5553', 1, NULL, NULL, 269.97, 32.40, 0.00, 302.37, 'cash', 350.00, 47.63, 'completed', '2025-09-06 22:07:27'),
(14, 'TXN-20250907-4628', 1, NULL, NULL, 206.97, 24.84, 0.00, 231.81, 'cash', 300.00, 68.19, 'completed', '2025-09-06 22:20:00'),
(15, 'TXN-20250907-3661', 1, NULL, NULL, 89.99, 10.80, 0.00, 100.79, 'cash', 150.00, 49.21, 'completed', '2025-09-07 02:30:19'),
(16, 'TXN-20250907-7519', 1, NULL, NULL, 145.97, 17.52, 0.00, 163.49, 'cash', 300.00, 136.51, 'completed', '2025-09-07 02:50:11'),
(17, 'TXN-20250907-0429', 1, NULL, NULL, 49.99, 6.00, 0.00, 55.99, 'cash', 60.00, 4.01, 'completed', '2025-09-07 10:47:58'),
(18, 'TXN-20250907-1221', 1, NULL, NULL, 184.98, 22.20, 0.00, 207.18, 'cash', 210.00, 2.82, 'completed', '2025-09-07 11:58:22');

-- --------------------------------------------------------

--
-- Table structure for table `sales_transaction_items`
--

CREATE TABLE `sales_transaction_items` (
  `id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `product_variant_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_transaction_items`
--

INSERT INTO `sales_transaction_items` (`id`, `transaction_id`, `product_variant_id`, `quantity`, `unit_price`, `total_price`, `created_at`) VALUES
(1, 1, 2, 1, 89.99, 89.99, '2025-09-06 11:55:18'),
(2, 1, 10, 1, 65.99, 65.99, '2025-09-06 11:55:18'),
(3, 2, 1, 1, 89.99, 89.99, '2025-09-06 11:55:18'),
(4, 3, 16, 1, 79.99, 79.99, '2025-09-06 11:55:18'),
(5, 4, 21, 1, 299.99, 299.99, '2025-09-06 11:55:18'),
(6, 5, 3, 1, 89.99, 89.99, '2025-09-06 11:55:18'),
(7, 5, 37, 1, 15.99, 15.99, '2025-09-06 11:55:18'),
(8, 6, 11, 1, 65.99, 65.99, '2025-09-06 11:55:18'),
(9, 7, 2, 1, 89.99, 89.99, '2025-09-06 11:55:18'),
(10, 7, 22, 1, 129.99, 129.99, '2025-09-06 11:55:18'),
(11, 8, 2, 1, 89.99, 89.99, '2025-09-06 11:59:07'),
(12, 9, 25, 3, 79.99, 239.97, '2025-09-06 13:30:28'),
(13, 10, 52, 10, 40.00, 400.00, '2025-09-06 13:33:05'),
(14, 11, 7, 3, 94.99, 284.97, '2025-09-06 13:33:29'),
(15, 12, 3, 1, 89.99, 89.99, '2025-09-06 13:41:11'),
(16, 13, 3, 3, 89.99, 269.97, '2025-09-06 22:07:27'),
(17, 14, 6, 1, 94.99, 94.99, '2025-09-06 22:20:00'),
(18, 14, 41, 1, 55.99, 55.99, '2025-09-06 22:20:00'),
(19, 14, 38, 1, 55.99, 55.99, '2025-09-06 22:20:00'),
(20, 15, 3, 1, 89.99, 89.99, '2025-09-07 02:30:19'),
(21, 16, 20, 1, 45.99, 45.99, '2025-09-07 02:50:11'),
(22, 16, 23, 2, 49.99, 99.98, '2025-09-07 02:50:11'),
(23, 17, 24, 1, 49.99, 49.99, '2025-09-07 10:47:58'),
(24, 18, 7, 1, 94.99, 94.99, '2025-09-07 11:58:22'),
(25, 18, 3, 1, 89.99, 89.99, '2025-09-07 11:58:22');

-- --------------------------------------------------------

--
-- Table structure for table `stock_movements`
--

CREATE TABLE `stock_movements` (
  `id` int(11) NOT NULL,
  `product_variant_id` int(11) NOT NULL,
  `movement_type` enum('in','out','adjustment') NOT NULL,
  `quantity` int(11) NOT NULL,
  `reference_type` enum('purchase','sale','adjustment','return') NOT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock_movements`
--

INSERT INTO `stock_movements` (`id`, `product_variant_id`, `movement_type`, `quantity`, `reference_type`, `reference_id`, `notes`, `user_id`, `created_at`) VALUES
(1, 2, 'out', 1, 'sale', 8, NULL, 1, '2025-09-06 11:59:07'),
(2, 36, 'in', 1, 'adjustment', NULL, '', 1, '2025-09-06 13:10:21'),
(3, 25, 'out', 3, 'sale', 9, NULL, 1, '2025-09-06 13:30:28'),
(4, 52, 'out', 10, 'sale', 10, NULL, 1, '2025-09-06 13:33:05'),
(5, 7, 'out', 3, 'sale', 11, NULL, 1, '2025-09-06 13:33:29'),
(6, 3, 'out', 1, 'sale', 12, NULL, 1, '2025-09-06 13:41:11'),
(7, 3, 'out', 3, 'sale', 13, NULL, 1, '2025-09-06 22:07:27'),
(8, 6, 'out', 1, 'sale', 14, NULL, 1, '2025-09-06 22:20:00'),
(9, 41, 'out', 1, 'sale', 14, NULL, 1, '2025-09-06 22:20:00'),
(10, 38, 'out', 1, 'sale', 14, NULL, 1, '2025-09-06 22:20:00'),
(11, 3, 'out', 1, 'sale', 15, NULL, 1, '2025-09-07 02:30:19'),
(12, 20, 'out', 1, 'sale', 16, NULL, 1, '2025-09-07 02:50:11'),
(13, 23, 'out', 2, 'sale', 16, NULL, 1, '2025-09-07 02:50:11'),
(14, 24, 'out', 1, 'sale', 17, NULL, 1, '2025-09-07 10:47:58'),
(15, 7, 'out', 1, 'sale', 18, NULL, 1, '2025-09-07 11:58:22'),
(16, 3, 'out', 1, 'sale', 18, NULL, 1, '2025-09-07 11:58:22');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `description`, `updated_at`) VALUES
(1, 'store_name', 'DJ Cheenee\'s Fashion Boutique', 'Store name displayed on receipts and system', '2025-09-06 11:48:23'),
(2, 'tax_rate', '0.12', 'Default tax rate (12%)', '2025-09-06 11:48:23'),
(3, 'currency_symbol', '₱', 'Currency symbol', '2025-09-06 11:48:23'),
(4, 'receipt_footer', 'Thank you for shopping with us!', 'Footer message on receipts', '2025-09-06 11:48:23'),
(5, 'low_stock_threshold', '5', 'Default low stock threshold for notifications', '2025-09-06 11:48:23');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `role` enum('admin','cashier') NOT NULL DEFAULT 'cashier',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `email`, `role`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'DJ Cheenee Admin', 'admin@djcheenee.com', 'admin', 1, '2025-09-06 11:48:22', '2025-09-06 11:48:22'),
(2, 'cashier', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Store Cashier', 'cashier@djcheenee.com', 'cashier', 1, '2025-09-06 11:48:22', '2025-09-06 11:48:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_variant_id` (`product_variant_id`),
  ADD KEY `idx_notifications` (`user_id`,`is_read`,`created_at`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `brand_id` (`brand_id`);

--
-- Indexes for table `product_variants`
--
ALTER TABLE `product_variants`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `barcode` (`barcode`),
  ADD KEY `idx_barcode` (`barcode`),
  ADD KEY `idx_product_variant` (`product_id`,`size`,`color`);

--
-- Indexes for table `sales_transactions`
--
ALTER TABLE `sales_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_number` (`transaction_number`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_transaction_date` (`created_at`),
  ADD KEY `idx_transaction_number` (`transaction_number`);

--
-- Indexes for table `sales_transaction_items`
--
ALTER TABLE `sales_transaction_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_variant_id` (`product_variant_id`),
  ADD KEY `idx_transaction_items` (`transaction_id`);

--
-- Indexes for table `stock_movements`
--
ALTER TABLE `stock_movements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_stock_movements` (`product_variant_id`,`created_at`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `product_variants`
--
ALTER TABLE `product_variants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `sales_transactions`
--
ALTER TABLE `sales_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `sales_transaction_items`
--
ALTER TABLE `sales_transaction_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `stock_movements`
--
ALTER TABLE `stock_movements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`product_variant_id`) REFERENCES `product_variants` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `product_variants`
--
ALTER TABLE `product_variants`
  ADD CONSTRAINT `product_variants_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sales_transactions`
--
ALTER TABLE `sales_transactions`
  ADD CONSTRAINT `sales_transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `sales_transaction_items`
--
ALTER TABLE `sales_transaction_items`
  ADD CONSTRAINT `sales_transaction_items_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `sales_transactions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sales_transaction_items_ibfk_2` FOREIGN KEY (`product_variant_id`) REFERENCES `product_variants` (`id`);

--
-- Constraints for table `stock_movements`
--
ALTER TABLE `stock_movements`
  ADD CONSTRAINT `stock_movements_ibfk_1` FOREIGN KEY (`product_variant_id`) REFERENCES `product_variants` (`id`),
  ADD CONSTRAINT `stock_movements_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
