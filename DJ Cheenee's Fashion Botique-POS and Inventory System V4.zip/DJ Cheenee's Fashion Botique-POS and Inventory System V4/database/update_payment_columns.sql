-- Add payment_amount and change_amount columns to sales_transactions table
-- This update is required for the payment calculation feature

USE dj_cheenee_boutique;

-- Add payment_amount column (amount paid by customer)
ALTER TABLE sales_transactions 
ADD COLUMN payment_amount DECIMAL(10,2) NULL AFTER payment_method;

-- Add change_amount column (change given to customer)
ALTER TABLE sales_transactions 
ADD COLUMN change_amount DECIMAL(10,2) NULL AFTER payment_amount;

-- Update existing records to set payment_amount equal to total_amount where payment_amount is null
UPDATE sales_transactions 
SET payment_amount = total_amount, change_amount = 0.00 
WHERE payment_amount IS NULL;
