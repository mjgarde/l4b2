-- DJ Cheenee's Fashion Boutique - DELETE SPECIFIC Sample Data
-- Remove only the specific sample data items, keep other real data

USE dj_cheenee_boutique;

-- Disable foreign key checks temporarily
SET FOREIGN_KEY_CHECKS = 0;

-- Delete specific sample sales transaction items first (by transaction IDs that match sample transaction numbers)
DELETE FROM sales_transaction_items 
WHERE transaction_id IN (
    SELECT id FROM sales_transactions 
    WHERE transaction_number IN (
        'TXN-20240906-0001', 'TXN-20240906-0002', 'TXN-20240906-0003', 'TXN-20240906-0004',
        'TXN-20240905-0001', 'TXN-20240905-0002', 'TXN-20240905-0003'
    )
);

-- Delete specific sample sales transactions
DELETE FROM sales_transactions 
WHERE transaction_number IN (
    'TXN-20240906-0001', 'TXN-20240906-0002', 'TXN-20240906-0003', 'TXN-20240906-0004',
    'TXN-20240905-0001', 'TXN-20240905-0002', 'TXN-20240905-0003'
);

-- Delete specific sample notifications
DELETE FROM notifications 
WHERE message IN (
    'Business Blouse (S - White) is running low: 3 left',
    'Designer Handbag (One Size - Red) is running low: 2 left'
);

-- Delete specific sample product variants by barcode
DELETE FROM product_variants 
WHERE barcode IN (
    -- Denim Jacket barcodes
    '1234567890123', '1234567890124', '1234567890125', '1234567890126', 
    '1234567890127', '1234567890128', '1234567890129', '1234567890130', '123456789156',
    -- Summer Dress barcodes
    '2234567890123', '2234567890124', '2234567890125', '2234567890126',
    '2234567890127', '2234567890128', '2234567890129', '2234567890130',
    -- Business Blouse barcodes
    '3234567890123', '3234567890124', '3234567890125', '3234567890126',
    '3234567890127', '3234567890128', '3234567890129', '3234567890130',
    -- High-Waist Jeans barcodes
    '4234567890123', '4234567890124', '4234567890125', '4234567890126',
    '4234567890127', '4234567890128', '4234567890129', '4234567890130',
    -- Designer Handbag barcodes
    '5234567890123', '5234567890124', '5234567890125', '5234567890126',
    -- Knit Cardigan barcodes
    '6234567890123', '6234567890124', '6234567890125', '6234567890126',
    '6234567890127', '6234567890128',
    -- Midi Skirt barcodes
    '7234567890123', '7234567890124', '7234567890125', '7234567890126',
    '7234567890127', '7234567890128',
    -- Statement Necklace barcodes
    '8234567890123', '8234567890124', '8234567890125'
);

-- Delete specific sample products by name
DELETE FROM products 
WHERE name IN (
    'Classic Denim Jacket',
    'Floral Summer Dress', 
    'Business Blouse',
    'High-Waist Jeans',
    'Designer Handbag',
    'Knit Cardigan',
    'Midi Skirt',
    'Statement Necklace'
);

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- Show confirmation
SELECT 'Specific sample data has been deleted from the database!' as Status;
SELECT 'Other real data (if any) has been preserved.' as Note;
