<?php
require_once 'config/session.php';
require_once 'config/database.php';
require_once 'classes/User.php';

if (SessionManager::isLoggedIn()) {
    SessionManager::redirectByRole();
}

$error_message      = '';
$login_success      = false;
$authenticated_user = null;

$MAX_ATTEMPTS = 5;
$BAN_SECONDS  = 25;
$type         = 'boutique';

function is_safe_input($val) {
    $blocked = ["'", '"', ';', '--', '#', '/*', '*/', 'SELECT', 'INSERT', 'UPDATE',
                'DELETE', 'DROP', 'UNION', 'OR ', 'AND ', '<script', '</script',
                '<', '>', '\\', '/', '=', '%', '&', '|', '`', 'EXEC', 'CAST',
                'CHAR(', 'alert(', 'onerror', 'onload'];
    $upper = strtoupper($val);
    foreach ($blocked as $b) {
        if (str_contains($upper, strtoupper($b))) return false;
    }
    return true;
}

$ip          = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$ua          = $_SERVER['HTTP_USER_AGENT']      ?? '';
$lang        = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '';
$encoding    = $_SERVER['HTTP_ACCEPT_ENCODING'] ?? '';
$device_hash = hash('sha256', $ua . $lang . $encoding);

$pdo = getDbConnection();

$stmt = $pdo->prepare("SELECT attempts, ban_until FROM login_attempts WHERE ip_address = ? AND device_hash = ? AND type = ?");
$stmt->execute([$ip, $device_hash, $type]);
$row = $stmt->fetch();

$attempts  = $row ? (int)$row['attempts']  : 0;
$ban_until = $row ? (int)$row['ban_until'] : 0;

$isBanned       = $ban_until > time();
$banSecondsLeft = max(0, $ban_until - time());

if ($row && !$isBanned && $ban_until > 0) {
    $pdo->prepare("DELETE FROM login_attempts WHERE ip_address = ? AND device_hash = ? AND type = ?")
        ->execute([$ip, $device_hash, $type]);
    $attempts = 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($isBanned) {
        $error_message = "Too many failed attempts. Please wait {$banSecondsLeft} second(s) before trying again.";
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($username) || empty($password)) {
            $error_message = 'Please enter both username and password.';
        } elseif (!is_safe_input($username) || !is_safe_input($password)) {
            $error_message = 'Invalid characters detected in input.';
        } else {
            $user = new User();
            $authenticated_user = $user->authenticate($username, $password);

            if ($authenticated_user) {
                $pdo->prepare("DELETE FROM login_attempts WHERE ip_address = ? AND device_hash = ? AND type = ?")
                    ->execute([$ip, $device_hash, $type]);

                $existing = $pdo->prepare("SELECT session_id FROM user_sessions WHERE user_id = ?");
                $existing->execute([$authenticated_user['id']]);
                $active = $existing->fetch();

                if ($active) {
                    $error_message = 'This account is already logged in on another device. Please log out from that device first.';
                    $authenticated_user = null;
                } else {
                    SessionManager::login($authenticated_user);

                    $pdo->prepare("INSERT INTO user_sessions (user_id, session_id) VALUES (?, ?) ON DUPLICATE KEY UPDATE session_id = ?")
                        ->execute([$authenticated_user['id'], session_id(), session_id()]);

                    $login_success = true;
                }
            } else {
                $attempts++;

                if ($attempts >= $MAX_ATTEMPTS) {
                    $ban_until      = time() + $BAN_SECONDS;
                    $isBanned       = true;
                    $banSecondsLeft = $BAN_SECONDS;
                    $error_message  = "Too many failed attempts. Please wait {$BAN_SECONDS} second(s) before trying again.";

                    $pdo->prepare("
                        INSERT INTO login_attempts (ip_address, device_hash, type, attempts, ban_until)
                        VALUES (?, ?, ?, ?, ?)
                        ON DUPLICATE KEY UPDATE attempts = ?, ban_until = ?
                    ")->execute([$ip, $device_hash, $type, $attempts, $ban_until, $attempts, $ban_until]);
                } else {
                    $remaining     = $MAX_ATTEMPTS - $attempts;
                    $error_message = "Invalid username or password. {$remaining} attempt(s) remaining before temporary lockout.";

                    $pdo->prepare("
                        INSERT INTO login_attempts (ip_address, device_hash, type, attempts, ban_until)
                        VALUES (?, ?, ?, ?, 0)
                        ON DUPLICATE KEY UPDATE attempts = ?
                    ")->execute([$ip, $device_hash, $type, $attempts, $attempts]);
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - DJ Cheenee's Fashion Boutique</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="assets/css/style.css?v=<?= time() ?>" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body class="login-body">
    <div class="particles-container" id="particles"></div>

    <div class="login-container">
        <div class="login-card glass-effect">
            <div class="login-header">
                <div class="logo animated-logo"><i class="fas fa-tshirt"></i></div>
                <h1 class="brand-title gradient-text">DJ Cheenee's</h1>
                <div class="brand-divider">
                    <div class="divider-line"></div>
                    <div class="divider-dot"></div>
                    <div class="divider-line"></div>
                </div>
                <p class="brand-subtitle">Fashion Boutique POS System</p>
            </div>

            <?php if ($isBanned): ?>
            <div class="alert-banned">
                <strong>Device Temporarily Locked</strong>
                <span class="countdown-num" id="countdown"><?= $banSecondsLeft ?></span>
                <small>seconds remaining. Please wait before trying again.</small>
            </div>
            <?php elseif (!empty($error_message)): ?>
            <div style="background:rgba(248,215,218,0.95);backdrop-filter:blur(20px);border:1px solid rgba(220,53,69,0.2);border-radius:16px;margin-bottom:1.5rem;padding:1rem 1.25rem;display:flex;align-items:flex-start;gap:0.75rem;color:#721c24;font-size:0.9rem;">
                <i class="fas fa-exclamation-triangle" style="color:#dc3545;font-size:1.1rem;margin-top:2px"></i>
                <div>
                    <div style="font-weight:600;margin-bottom:0.25rem">Authentication Failed</div>
                    <div style="opacity:0.9;font-size:0.85rem"><?= htmlspecialchars($error_message) ?></div>
                </div>
            </div>
            <?php endif; ?>

            <form method="POST" action="" class="login-form" id="loginForm">
                <div class="input-group-floating">
                    <div class="input-wrapper">
                        <input type="text" class="form-control-modern" id="username" name="username"
                               value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                               required autocomplete="username"
                               <?= $isBanned ? 'disabled' : '' ?>>
                        <label for="username" class="floating-label">
                            <i class="fas fa-user me-2"></i>Username
                        </label>
                    </div>
                </div>

                <div class="input-group-floating">
                    <div class="input-wrapper">
                        <input type="password" class="form-control-modern" id="password" name="password"
                               required autocomplete="current-password"
                               <?= $isBanned ? 'disabled' : '' ?>>
                        <label for="password" class="floating-label">
                            <i class="fas fa-lock me-2"></i>Password
                        </label>
                        <button type="button" class="password-toggle" id="passwordToggle"
                                <?= $isBanned ? 'disabled' : '' ?>>
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>

                <button type="submit" class="btn-modern btn-primary-modern w-100" id="loginBtn"
                        <?= $isBanned ? 'disabled' : '' ?>>
                    <span class="btn-text"><i class="fas fa-sign-in-alt me-2"></i>Sign In</span>
                    <div class="btn-ripple"></div>
                </button>
            </form>
        </div>

        <div class="floating-shapes">
            <div class="shape shape-1"></div>
            <div class="shape shape-2"></div>
            <div class="shape shape-3"></div>
        </div>
    </div>

    <div id="loadingScreen" class="loading-screen" style="display:none">
        <div class="loading-background">
            <div class="bg-wave wave-1"></div>
            <div class="bg-wave wave-2"></div>
            <div class="bg-wave wave-3"></div>
        </div>
        <div class="loading-content">
            <div class="loading-logo-container">
                <div class="loading-logo">
                    <i class="fas fa-tshirt"></i>
                    <div class="logo-pulse"></div>
                </div>
                <div class="orbit-ring">
                    <div class="orbit-dot dot-1"></div>
                    <div class="orbit-dot dot-2"></div>
                    <div class="orbit-dot dot-3"></div>
                </div>
            </div>
            <div class="loading-spinner-enhanced">
                <div class="spinner-outer">
                    <div class="spinner-segment segment-1"></div>
                    <div class="spinner-segment segment-2"></div>
                    <div class="spinner-segment segment-3"></div>
                    <div class="spinner-segment segment-4"></div>
                </div>
                <div class="spinner-inner"><div class="inner-ring"></div></div>
            </div>
            <div class="loading-text-container">
                <h3 class="loading-title" id="loadingTitle">Welcome Back!</h3>
                <p class="loading-subtitle" id="loadingSubtitle">Initializing your session...</p>
                <div class="loading-dots">
                    <span class="dot"></span><span class="dot"></span><span class="dot"></span>
                </div>
            </div>
            <div class="loading-progress-container">
                <div class="progress-steps">
                    <div class="step active" data-step="1">Authentication</div>
                    <div class="step" data-step="2">Loading Profile</div>
                    <div class="step" data-step="3">Preparing Dashboard</div>
                </div>
            </div>
        </div>
        <div class="loading-particles-enhanced">
            <div class="particle-system">
                <div class="particle large"></div><div class="particle medium"></div>
                <div class="particle small"></div><div class="particle large"></div>
                <div class="particle medium"></div><div class="particle small"></div>
                <div class="particle large"></div><div class="particle medium"></div>
            </div>
        </div>
        <div class="geometric-shapes">
            <div class="geo-shape triangle"></div>
            <div class="geo-shape square"></div>
            <div class="geo-shape circle"></div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            initializeFloatingLabels();
            initializeParticles();
            initializePasswordToggle();
            initializeFormValidation();
            initializeRippleEffects();
            setTimeout(() => {
                const u = document.getElementById('username');
                if (u && !u.value.trim()) u.focus();
            }, 100);
            <?php if ($login_success): ?>
            showLoadingScreen();
            <?php endif; ?>
        });

        function initializeFloatingLabels() {
            document.querySelectorAll('.form-control-modern').forEach(input => {
                const wrapper = input.closest('.input-wrapper');
                function checkValue() {
                    wrapper.classList.toggle('has-value', input.value.trim() !== '');
                }
                checkValue();
                setTimeout(checkValue, 50);
                input.addEventListener('focus', () => { wrapper.classList.add('focused'); setTimeout(checkValue, 10); });
                input.addEventListener('blur',  () => { wrapper.classList.remove('focused'); checkValue(); });
                input.addEventListener('input', checkValue);
            });
        }

        function initializePasswordToggle() {
            const toggle = document.getElementById('passwordToggle');
            const pw     = document.getElementById('password');
            if (!toggle) return;
            toggle.addEventListener('click', function() {
                const isPassword = pw.getAttribute('type') === 'password';
                pw.setAttribute('type', isPassword ? 'text' : 'password');
                this.querySelector('i').classList.toggle('fa-eye');
                this.querySelector('i').classList.toggle('fa-eye-slash');
            });
        }

        function initializeFormValidation() {
            const form = document.getElementById('loginForm');
            const btn  = document.getElementById('loginBtn');
            form.addEventListener('submit', function(e) {
                const u = document.getElementById('username').value.trim();
                const p = document.getElementById('password').value.trim();
                if (!u || !p) { e.preventDefault(); return; }
                btn.disabled = true;
                btn.querySelector('.btn-text').innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Signing in...';
            });
        }

        function initializeRippleEffects() {
            document.querySelectorAll('.btn-modern').forEach(button => {
                button.addEventListener('click', function(e) {
                    const ripple = this.querySelector('.btn-ripple');
                    if (!ripple) return;
                    const rect = this.getBoundingClientRect();
                    const size = Math.max(rect.width, rect.height);
                    ripple.style.width = ripple.style.height = size + 'px';
                    ripple.style.left = (e.clientX - rect.left - size / 2) + 'px';
                    ripple.style.top  = (e.clientY - rect.top  - size / 2) + 'px';
                    ripple.classList.add('active');
                    setTimeout(() => ripple.classList.remove('active'), 600);
                });
            });
        }

        function initializeParticles() {
            const container = document.getElementById('particles');
            const count     = window.innerWidth < 768 ? 30 : 50;
            for (let i = 0; i < count; i++) {
                const p = document.createElement('div');
                p.className = 'particle';
                const size = Math.random() * 4 + 2;
                p.style.cssText = `position:absolute;border-radius:50%;background:radial-gradient(circle,rgba(255,255,255,0.4),transparent);width:${size}px;height:${size}px;left:${Math.random()*100}%;top:${Math.random()*100}%;animation:particleFloat ${Math.random()*20+10}s ease-in-out infinite;animation-delay:${Math.random()*5}s;`;
                container.appendChild(p);
            }
        }

        <?php if ($isBanned): ?>
        (function() {
            let seconds       = <?= $banSecondsLeft ?>;
            const countdownEl = document.getElementById('countdown');
            const timer = setInterval(function() {
                seconds--;
                if (countdownEl) countdownEl.textContent = seconds;
                if (seconds <= 0) { clearInterval(timer); location.reload(); }
            }, 1000);
        })();
        <?php endif; ?>

        function showLoadingScreen() {
            const screen    = document.getElementById('loadingScreen');
            const container = document.querySelector('.login-container');
            screen.style.display = 'flex';
            setTimeout(() => screen.classList.add('show'), 100);
            container.style.transition = 'opacity 0.8s ease-out';
            container.style.opacity    = '0';
            startLoadingSequence();
            setTimeout(() => {
                <?php if ($authenticated_user): ?>
                <?php if ($authenticated_user['role'] === 'admin'): ?>
                window.location.href = 'admin/dashboard.php';
                <?php elseif ($authenticated_user['role'] === 'cashier'): ?>
                window.location.href = 'cashier/pos.php';
                <?php else: ?>
                window.location.href = 'admin/dashboard.php';
                <?php endif; ?>
                <?php endif; ?>
            }, 3000);
        }

        function startLoadingSequence() {
            const title    = document.getElementById('loadingTitle');
            const subtitle = document.getElementById('loadingSubtitle');
            const steps    = document.querySelectorAll('.step');
            const phases   = [
                { duration: 1000, title: 'Welcome Back!',   subtitle: 'Authenticating credentials...', step: 1 },
                { duration: 1000, title: 'Access Granted!', subtitle: 'Loading your profile...',        step: 2 },
                { duration: 1000, title: 'Almost Ready!',   subtitle: 'Preparing your dashboard...',    step: 3 }
            ];
            let i = 0;
            function next() {
                if (i >= phases.length) return;
                const phase = phases[i];
                title.style.opacity = subtitle.style.opacity = '0';
                setTimeout(() => {
                    title.textContent    = phase.title;
                    subtitle.textContent = phase.subtitle;
                    steps.forEach((s, idx) => s.classList.toggle('active', idx < phase.step));
                    title.style.opacity = subtitle.style.opacity = '1';
                }, 300);
                i++;
                if (i < phases.length) setTimeout(next, phase.duration);
            }
            next();
        }

        const blocked = ["'", '"', ';', '--', '<', '>', '\\', '=', '`', '|', '&', '%', '#', '/'];
        document.querySelectorAll('input[type=text], input[type=password]').forEach(input => {
            input.addEventListener('input', function () {
                blocked.forEach(c => { this.value = this.value.split(c).join(''); });
            });
            input.addEventListener('paste', function (e) {
                e.preventDefault();
                let text = (e.clipboardData || window.clipboardData).getData('text');
                blocked.forEach(c => { text = text.split(c).join(''); });
                this.value += text;
            });
        });
    </script>
</body>
</html>