<?php
require_once 'config/session.php';
require_once 'config/database.php';

$pdo = getDbConnection();

if (!empty($_SESSION['user_id'])) {
    $pdo->prepare("DELETE FROM user_sessions WHERE user_id = ?")
        ->execute([$_SESSION['user_id']]);
}

SessionManager::logout();
header('Location: login.php');
exit();