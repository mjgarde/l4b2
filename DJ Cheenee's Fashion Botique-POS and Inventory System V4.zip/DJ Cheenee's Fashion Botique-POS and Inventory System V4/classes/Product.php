<?php
/**
 * DJ Cheenee's Fashion Boutique - Product Class
 */

require_once __DIR__ . '/../config/database.php';

class Product {
    private $conn;
    private $table_name = "products";

    public function __construct() {
        $this->conn = getDbConnection();
    }

    public function getAllProducts($limit = null, $offset = null) {
        $query = "SELECT p.*, p.name as product_name, c.name as category_name, b.name as brand_name,
                         COUNT(pv.id) as variant_count,
                         SUM(pv.stock_quantity) as total_stock,
                         MIN(pv.price) as price
                  FROM " . $this->table_name . " p 
                  LEFT JOIN categories c ON p.category_id = c.id
                  LEFT JOIN brands b ON p.brand_id = b.id
                  LEFT JOIN product_variants pv ON p.id = pv.product_id AND pv.is_active = 1
                  WHERE p.is_active = 1
                  GROUP BY p.id
                  ORDER BY p.created_at DESC";
        
        if ($limit) {
            $query .= " LIMIT " . (int)$limit;
            if ($offset) {
                $query .= " OFFSET " . (int)$offset;
            }
        }
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function searchProducts($search, $category_id = null) {
        $query = "SELECT p.*, p.name as product_name, c.name as category_name, b.name as brand_name,
                         COUNT(pv.id) as variant_count,
                         SUM(pv.stock_quantity) as total_stock,
                         MIN(pv.price) as price
                  FROM " . $this->table_name . " p 
                  LEFT JOIN categories c ON p.category_id = c.id
                  LEFT JOIN brands b ON p.brand_id = b.id
                  LEFT JOIN product_variants pv ON p.id = pv.product_id AND pv.is_active = 1
                  WHERE p.is_active = 1 
                  AND (p.name LIKE :search OR p.description LIKE :search OR pv.barcode LIKE :search)";
        
        if ($category_id) {
            $query .= " AND p.category_id = :category_id";
        }
        
        $query .= " GROUP BY p.id ORDER BY p.name ASC";
        
        $stmt = $this->conn->prepare($query);
        $searchParam = '%' . $search . '%';
        $stmt->bindParam(':search', $searchParam);
        
        if ($category_id) {
            $stmt->bindParam(':category_id', $category_id);
        }
        
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getProductById($id) {
        $query = "SELECT p.*, c.name as category_name, b.name as brand_name
                  FROM " . $this->table_name . " p 
                  LEFT JOIN categories c ON p.category_id = c.id
                  LEFT JOIN brands b ON p.brand_id = b.id
                  WHERE p.id = :id AND p.is_active = 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function getProductVariants($product_id) {
        $query = "SELECT pv.*, p.name as product_name
                  FROM product_variants pv
                  JOIN products p ON pv.product_id = p.id
                  WHERE pv.product_id = :product_id AND pv.is_active = 1
                  ORDER BY pv.size, pv.color";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':product_id', $product_id);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getVariantByBarcode($barcode) {
        $query = "SELECT pv.*, p.name as product_name, p.image_url,
                         c.name as category_name, b.name as brand_name
                  FROM product_variants pv
                  JOIN products p ON pv.product_id = p.id
                  LEFT JOIN categories c ON p.category_id = c.id
                  LEFT JOIN brands b ON p.brand_id = b.id
                  WHERE pv.barcode = :barcode AND pv.is_active = 1 AND p.is_active = 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':barcode', $barcode);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function createProduct($name, $description, $category_id, $brand_name, $image_url = null) {
        // Handle brand as text instead of foreign key
        $brand_id = null;
        if (!empty($brand_name)) {
            // Check if brand already exists
            $brand_query = "SELECT id FROM brands WHERE name = :brand_name";
            $brand_stmt = $this->conn->prepare($brand_query);
            $brand_stmt->bindParam(':brand_name', $brand_name);
            $brand_stmt->execute();
            $existing_brand = $brand_stmt->fetch();
            
            if ($existing_brand) {
                $brand_id = $existing_brand['id'];
            } else {
                // Create new brand
                $insert_brand_query = "INSERT INTO brands (name) VALUES (:brand_name)";
                $insert_brand_stmt = $this->conn->prepare($insert_brand_query);
                $insert_brand_stmt->bindParam(':brand_name', $brand_name);
                if ($insert_brand_stmt->execute()) {
                    $brand_id = $this->conn->lastInsertId();
                }
            }
        }
        
        $query = "INSERT INTO " . $this->table_name . " 
                  (name, description, category_id, brand_id, image_url) 
                  VALUES (:name, :description, :category_id, :brand_id, :image_url)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':category_id', $category_id);
        $stmt->bindParam(':brand_id', $brand_id);
        $stmt->bindParam(':image_url', $image_url);
        
        if ($stmt->execute()) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    public function updateProduct($id, $name, $description, $category_id, $brand_name, $image_url = null) {
        // Handle brand as text instead of foreign key
        $brand_id = null;
        if (!empty($brand_name)) {
            // Check if brand already exists
            $brand_query = "SELECT id FROM brands WHERE name = :brand_name";
            $brand_stmt = $this->conn->prepare($brand_query);
            $brand_stmt->bindParam(':brand_name', $brand_name);
            $brand_stmt->execute();
            $existing_brand = $brand_stmt->fetch();
            
            if ($existing_brand) {
                $brand_id = $existing_brand['id'];
            } else {
                // Create new brand
                $insert_brand_query = "INSERT INTO brands (name) VALUES (:brand_name)";
                $insert_brand_stmt = $this->conn->prepare($insert_brand_query);
                $insert_brand_stmt->bindParam(':brand_name', $brand_name);
                if ($insert_brand_stmt->execute()) {
                    $brand_id = $this->conn->lastInsertId();
                }
            }
        }
        
        $query = "UPDATE " . $this->table_name . " 
                  SET name = :name, description = :description, 
                      category_id = :category_id, brand_id = :brand_id, image_url = :image_url
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':category_id', $category_id);
        $stmt->bindParam(':brand_id', $brand_id);
        $stmt->bindParam(':image_url', $image_url);
        
        return $stmt->execute();
    }

    public function deleteProduct($id) {
        // Soft delete - mark as inactive
        $query = "UPDATE " . $this->table_name . " SET is_active = 0 WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    public function getAllCategories() {
        $query = "SELECT * FROM categories ORDER BY name ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getAllBrands() {
        $query = "SELECT * FROM brands ORDER BY name ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
?>
