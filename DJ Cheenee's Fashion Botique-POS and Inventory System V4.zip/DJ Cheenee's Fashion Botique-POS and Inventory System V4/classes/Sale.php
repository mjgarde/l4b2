<?php
/**
 * DJ Cheenee's Fashion Boutique - Sale Transaction Class
 */

require_once __DIR__ . '/../config/database.php';

class Sale {
    private $conn;
    private $sales_table = "sales_transactions";
    private $items_table = "sales_transaction_items";

    public function __construct() {
        $this->conn = getDbConnection();
    }

    public function createTransaction($user_id, $cart_items, $customer_name = null, $customer_phone = null, $payment_method = 'cash', $payment_amount = null, $change_amount = null, $discount_amount = 0) {
        try {
            $this->conn->beginTransaction();

            // Generate transaction number
            $transaction_number = 'TXN-' . date('Ymd') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);

            // Calculate totals
            $subtotal = 0;
            foreach ($cart_items as $item) {
                $subtotal += $item['price'] * $item['quantity'];
            }

            // No tax calculation - cash only system
            $tax_rate = 0;
            $tax_amount = 0;
            $total_amount = $subtotal - $discount_amount;

            // Check if payment columns exist (backward compatibility)
            $has_payment_columns = $this->checkPaymentColumnsExist();
            
            if ($has_payment_columns) {
                // Insert main transaction with payment columns
                $query = "INSERT INTO " . $this->sales_table . " 
                          (transaction_number, user_id, customer_name, customer_phone, 
                           subtotal, tax_amount, discount_amount, total_amount, payment_method, 
                           payment_amount, change_amount, payment_status) 
                          VALUES (:transaction_number, :user_id, :customer_name, :customer_phone, 
                                  :subtotal, :tax_amount, :discount_amount, :total_amount, :payment_method, 
                                  :payment_amount, :change_amount, 'completed')";
            } else {
                // Insert main transaction without payment columns (backward compatibility)
                $query = "INSERT INTO " . $this->sales_table . " 
                          (transaction_number, user_id, customer_name, customer_phone, 
                           subtotal, tax_amount, discount_amount, total_amount, payment_method, payment_status) 
                          VALUES (:transaction_number, :user_id, :customer_name, :customer_phone, 
                                  :subtotal, :tax_amount, :discount_amount, :total_amount, :payment_method, 'completed')";
            }

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':transaction_number', $transaction_number);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':customer_name', $customer_name);
            $stmt->bindParam(':customer_phone', $customer_phone);
            $stmt->bindParam(':subtotal', $subtotal);
            $stmt->bindParam(':tax_amount', $tax_amount);
            $stmt->bindParam(':discount_amount', $discount_amount);
            $stmt->bindParam(':total_amount', $total_amount);
            $stmt->bindParam(':payment_method', $payment_method);
            
            if ($has_payment_columns) {
                $stmt->bindParam(':payment_amount', $payment_amount);
                $stmt->bindParam(':change_amount', $change_amount);
            }
            
            $stmt->execute();

            $transaction_id = $this->conn->lastInsertId();

            // Insert transaction items and update stock
            foreach ($cart_items as $item) {
                // Insert item
                $item_query = "INSERT INTO " . $this->items_table . " 
                               (transaction_id, product_variant_id, quantity, unit_price, total_price) 
                               VALUES (:transaction_id, :product_variant_id, :quantity, :unit_price, :total_price)";
                
                $item_stmt = $this->conn->prepare($item_query);
                $total_price = $item['price'] * $item['quantity'];
                $item_stmt->bindParam(':transaction_id', $transaction_id);
                $item_stmt->bindParam(':product_variant_id', $item['variant_id']);
                $item_stmt->bindParam(':quantity', $item['quantity']);
                $item_stmt->bindParam(':unit_price', $item['price']);
                $item_stmt->bindParam(':total_price', $total_price);
                $item_stmt->execute();

                // Update stock
                $stock_query = "UPDATE product_variants 
                                SET stock_quantity = stock_quantity - :quantity 
                                WHERE id = :variant_id";
                $stock_stmt = $this->conn->prepare($stock_query);
                $stock_stmt->bindParam(':quantity', $item['quantity']);
                $stock_stmt->bindParam(':variant_id', $item['variant_id']);
                $stock_stmt->execute();

                // Record stock movement
                $movement_query = "INSERT INTO stock_movements 
                                   (product_variant_id, movement_type, quantity, reference_type, reference_id, user_id) 
                                   VALUES (:variant_id, 'out', :quantity, 'sale', :transaction_id, :user_id)";
                $movement_stmt = $this->conn->prepare($movement_query);
                $movement_stmt->bindParam(':variant_id', $item['variant_id']);
                $movement_stmt->bindParam(':quantity', $item['quantity']);
                $movement_stmt->bindParam(':transaction_id', $transaction_id);
                $movement_stmt->bindParam(':user_id', $user_id);
                $movement_stmt->execute();
            }

            $this->conn->commit();
            return [
                'success' => true,
                'transaction_id' => $transaction_id,
                'transaction_number' => $transaction_number,
                'total_amount' => $total_amount
            ];

        } catch (Exception $e) {
            $this->conn->rollback();
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    public function getTransactionById($id) {
        $query = "SELECT st.*, u.full_name as cashier_name
                  FROM " . $this->sales_table . " st
                  JOIN users u ON st.user_id = u.id
                  WHERE st.id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function getTransactionItems($transaction_id) {
        $query = "SELECT sti.*, pv.barcode, pv.size, pv.color, p.name as product_name
                  FROM " . $this->items_table . " sti
                  JOIN product_variants pv ON sti.product_variant_id = pv.id
                  JOIN products p ON pv.product_id = p.id
                  WHERE sti.transaction_id = :transaction_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':transaction_id', $transaction_id);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getRecentTransactions($limit = 10, $user_id = null) {
        $query = "SELECT st.*, u.full_name as cashier_name, COUNT(sti.id) as item_count
                  FROM " . $this->sales_table . " st
                  JOIN users u ON st.user_id = u.id
                  LEFT JOIN " . $this->items_table . " sti ON st.id = sti.transaction_id
                  WHERE 1=1";
        
        if ($user_id) {
            $query .= " AND st.user_id = :user_id";
        }
        
        $query .= " GROUP BY st.id ORDER BY st.created_at DESC LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        if ($user_id) {
            $stmt->bindParam(':user_id', $user_id);
        }
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getTodaysSales($user_id = null) {
        $today = date('Y-m-d');
        $query = "SELECT COUNT(*) as count, COALESCE(SUM(total_amount), 0) as total
                  FROM " . $this->sales_table . " 
                  WHERE DATE(created_at) = :today AND payment_status = 'completed'";
        
        if ($user_id) {
            $query .= " AND user_id = :user_id";
        }
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':today', $today);
        if ($user_id) {
            $stmt->bindParam(':user_id', $user_id);
        }
        $stmt->execute();
        return $stmt->fetch();
    }

    private function getTaxRate() {
        // Cash-only system with no tax
        return 0;
    }

    private function checkPaymentColumnsExist() {
        try {
            $query = "SHOW COLUMNS FROM " . $this->sales_table . " LIKE 'payment_amount'";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->rowCount() > 0;
        } catch (Exception $e) {
            return false;
        }
    }
}
?>
