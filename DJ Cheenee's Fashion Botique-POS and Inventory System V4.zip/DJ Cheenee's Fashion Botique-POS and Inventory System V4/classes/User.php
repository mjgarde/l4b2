<?php
/**
 * DJ Cheenee's Fashion Boutique - User Class
 */

require_once __DIR__ . '/../config/database.php';

class User {
    private $conn;
    private $table_name = "users";

    public $id;
    public $username;
    public $password;
    public $full_name;
    public $email;
    public $role;
    public $is_active;

    public function __construct() {
        $this->conn = getDbConnection();
    }

    public function authenticate($username, $password) {
        $query = "SELECT id, username, password, full_name, email, role, is_active 
                  FROM " . $this->table_name . " 
                  WHERE username = :username AND is_active = 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch();
            
            // Verify password (assuming passwords are hashed with password_hash)
            if (password_verify($password, $row['password'])) {
                return [
                    'id' => $row['id'],
                    'username' => $row['username'],
                    'full_name' => $row['full_name'],
                    'email' => $row['email'],
                    'role' => $row['role']
                ];
            }
        }
        return false;
    }

    public function getUserById($id) {
        $query = "SELECT id, username, full_name, email, role, is_active, created_at 
                  FROM " . $this->table_name . " 
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        return $stmt->fetch();
    }

    public function getAllUsers() {
        $query = "SELECT id, username, full_name, email, role, is_active, created_at 
                  FROM " . $this->table_name . " 
                  ORDER BY created_at DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function createUser($username, $password, $full_name, $email, $role) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (username, password, full_name, email, role) 
                  VALUES (:username, :password, :full_name, :email, :role)";
        
        $stmt = $this->conn->prepare($query);
        
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $hashed_password);
        $stmt->bindParam(':full_name', $full_name);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':role', $role);

        return $stmt->execute();
    }

    public function updateUser($id, $username, $full_name, $email, $role, $is_active) {
        $query = "UPDATE " . $this->table_name . " 
                  SET username = :username, full_name = :full_name, email = :email, 
                      role = :role, is_active = :is_active
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':full_name', $full_name);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':role', $role);
        $stmt->bindParam(':is_active', $is_active);

        return $stmt->execute();
    }

    public function changePassword($id, $new_password) {
        $query = "UPDATE " . $this->table_name . " 
                  SET password = :password 
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt->bindParam(':password', $hashed_password);
        $stmt->bindParam(':id', $id);

        return $stmt->execute();
    }

    public function deleteUser($id) {
        $query = "UPDATE " . $this->table_name . " 
                  SET is_active = 0 
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);

        return $stmt->execute();
    }
}
?>
