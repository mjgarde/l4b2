<?php
/**
 * DJ Cheenee's Fashion Boutique - User Management
 */

$page_title = 'User Management - DJ Cheenee\'s Fashion Boutique';
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Users', 'url' => '#']
];

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../classes/User.php';

SessionManager::requireAdmin();

$user = new User();
$db = getDbConnection();

// Handle form submissions
if ($_POST) {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add_user') {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $full_name = $_POST['full_name'];
        $email = $_POST['email'];
        $role = $_POST['role'];
        
        if ($user->createUser($username, $password, $full_name, $email, $role)) {
            $success_message = "User '$username' created successfully!";
        } else {
            $error_message = "Failed to create user. Username or email may already exist.";
        }
    } elseif ($action === 'edit_user') {
        $user_id = $_POST['user_id'];
        $username = $_POST['username'];
        $full_name = $_POST['full_name'];
        $email = $_POST['email'];
        $role = $_POST['role'];
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        $stmt = $db->prepare("UPDATE users SET username = :username, full_name = :full_name, email = :email, role = :role, is_active = :is_active WHERE id = :id");
        if ($stmt->execute([
            ':username' => $username,
            ':full_name' => $full_name,
            ':email' => $email,
            ':role' => $role,
            ':is_active' => $is_active,
            ':id' => $user_id
        ])) {
            $success_message = "User updated successfully!";
        } else {
            $error_message = "Failed to update user.";
        }
    } elseif ($action === 'reset_password') {
        $user_id = $_POST['user_id'];
        $new_password = $_POST['new_password'];
        
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $db->prepare("UPDATE users SET password = :password WHERE id = :id");
        if ($stmt->execute([':password' => $hashed_password, ':id' => $user_id])) {
            $success_message = "Password reset successfully!";
        } else {
            $error_message = "Failed to reset password.";
        }
    } elseif ($action === 'toggle_status') {
        $user_id = $_POST['user_id'];
        $stmt = $db->prepare("UPDATE users SET is_active = NOT is_active WHERE id = :id");
        if ($stmt->execute([':id' => $user_id])) {
            $success_message = "User status updated successfully!";
        } else {
            $error_message = "Failed to update user status.";
        }
    }
}

// Get all users
$stmt = $db->prepare("SELECT * FROM users ORDER BY created_at DESC");
$stmt->execute();
$users = $stmt->fetchAll();

// Get user statistics
$stmt = $db->prepare("
    SELECT 
        COUNT(*) as total_users,
        SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) as admin_count,
        SUM(CASE WHEN role = 'cashier' THEN 1 ELSE 0 END) as cashier_count,
        SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active_count
    FROM users
");
$stmt->execute();
$stats = $stmt->fetch();
?>

<?php if (isset($success_message)): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fas fa-check-circle me-2"></i><?php echo $success_message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if (isset($error_message)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fas fa-exclamation-circle me-2"></i><?php echo $error_message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="row mb-4">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h2 mb-2 gradient-text">
                    <i class="fas fa-users me-3"></i>User Management
                </h1>
                <p class="text-muted mb-0">Manage system users and their roles across your boutique</p>
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-outline-primary btn-modern" onclick="location.reload()">
                    <i class="fas fa-sync-alt me-2"></i>Refresh
                </button>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
                    <i class="fas fa-user-plus me-2"></i>Add New User
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Enhanced Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="kpi-card kpi-card-floating" style="animation-delay: 0.1s;">
            <div class="kpi-icon">
                <i class="fas fa-users"></i>
            </div>
            <div class="kpi-value"><?php echo $stats['total_users']; ?></div>
            <div class="kpi-label">Total Users</div>
            <div class="kpi-meta">
                <i class="fas fa-user-friends me-1"></i>
                System users
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-3">
        <div class="kpi-card kpi-card-secondary kpi-card-floating" style="animation-delay: 0.2s;">
            <div class="kpi-icon">
                <i class="fas fa-user-shield"></i>
            </div>
            <div class="kpi-value"><?php echo $stats['admin_count']; ?></div>
            <div class="kpi-label">Administrators</div>
            <div class="kpi-meta">
                <i class="fas fa-crown me-1"></i>
                Admin access
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-3">
        <div class="kpi-card kpi-card-success kpi-card-floating" style="animation-delay: 0.3s;">
            <div class="kpi-icon">
                <i class="fas fa-cash-register"></i>
            </div>
            <div class="kpi-value"><?php echo $stats['cashier_count']; ?></div>
            <div class="kpi-label">Cashiers</div>
            <div class="kpi-meta">
                <i class="fas fa-shopping-cart me-1"></i>
                POS operators
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-3">
        <div class="kpi-card kpi-card-info kpi-card-floating" style="animation-delay: 0.4s;">
            <div class="kpi-icon">
                <i class="fas fa-user-check"></i>
            </div>
            <div class="kpi-value"><?php echo $stats['active_count']; ?></div>
            <div class="kpi-label">Active Users</div>
            <div class="kpi-meta">
                <i class="fas fa-toggle-on me-1"></i>
                Currently active
            </div>
        </div>
    </div>
</div>

<!-- Enhanced Users Table -->
<div class="card glass-effect">
    <div class="card-header">
        <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center">
                <div class="icon-circle me-3">
                    <i class="fas fa-list"></i>
                </div>
                <h5 class="mb-0 gradient-text">System Users</h5>
            </div>
            <span class="badge badge-modern badge-primary">
                <i class="fas fa-users me-1"></i><?php echo count($users); ?> users
            </span>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th class="text-center">Status</th>
                        <th>Created</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $u): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="avatar me-3">
                                        <div class="avatar-circle">
                                            <?php echo strtoupper(substr($u['full_name'], 0, 2)); ?>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="fw-bold"><?php echo htmlspecialchars($u['full_name']); ?></div>
                                        <small class="text-muted">ID: <?php echo $u['id']; ?></small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <code><?php echo htmlspecialchars($u['username']); ?></code>
                            </td>
                            <td>
                                <?php if ($u['email']): ?>
                                    <a href="mailto:<?php echo htmlspecialchars($u['email']); ?>">
                                        <?php echo htmlspecialchars($u['email']); ?>
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">No email</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo $u['role'] === 'admin' ? 'bg-danger' : 'bg-info'; ?>">
                                    <?php echo ucfirst($u['role']); ?>
                                </span>
                            </td>
                            <td class="text-center">
                                <span class="badge <?php echo $u['is_active'] ? 'badge-success' : 'badge-secondary'; ?>">
                                    <?php echo $u['is_active'] ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td>
                                <div><?php echo date('M d, Y', strtotime($u['created_at'])); ?></div>
                                <small class="text-muted"><?php echo date('h:i A', strtotime($u['created_at'])); ?></small>
                            </td>
                            <td class="text-center">
                                <div class="btn-group" role="group">
                                    <button class="btn btn-sm btn-outline-primary" 
                                            onclick="editUser(<?php echo htmlspecialchars(json_encode($u)); ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-warning" 
                                            onclick="resetPassword(<?php echo $u['id']; ?>, '<?php echo htmlspecialchars($u['full_name']); ?>')">
                                        <i class="fas fa-key"></i>
                                    </button>
                                    <?php if ($u['id'] != $current_user['id']): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="toggle_status">
                                        <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                        <button type="submit" class="btn btn-sm <?php echo $u['is_active'] ? 'btn-outline-secondary' : 'btn-outline-success'; ?>" 
                                                onclick="return confirm('Are you sure you want to <?php echo $u['is_active'] ? 'deactivate' : 'activate'; ?> this user?')">
                                            <i class="fas <?php echo $u['is_active'] ? 'fa-user-slash' : 'fa-user-check'; ?>"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="add_user">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="username" class="form-label">Username *</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="password" class="form-label">Password *</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Full Name *</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email">
                    </div>
                    <div class="mb-3">
                        <label for="role" class="form-label">Role *</label>
                        <select class="form-control" id="role" name="role" required>
                            <option value="cashier">Cashier</option>
                            <option value="admin">Administrator</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit User Modal -->
<div class="modal fade" id="editUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="edit_user">
                <input type="hidden" name="user_id" id="edit_user_id">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="edit_username" class="form-label">Username *</label>
                            <input type="text" class="form-control" id="edit_username" name="username" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="edit_role" class="form-label">Role *</label>
                            <select class="form-control" id="edit_role" name="role" required>
                                <option value="cashier">Cashier</option>
                                <option value="admin">Administrator</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="edit_full_name" class="form-label">Full Name *</label>
                        <input type="text" class="form-control" id="edit_full_name" name="full_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="edit_email" name="email">
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="edit_is_active" name="is_active">
                            <label class="form-check-label" for="edit_is_active">
                                Active User
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Reset Password Modal -->
<div class="modal fade" id="resetPasswordModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Reset Password</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="reset_password">
                <input type="hidden" name="user_id" id="reset_user_id">
                <div class="modal-body">
                    <p>Reset password for: <strong id="reset_user_name"></strong></p>
                    <div class="mb-3">
                        <label for="new_password" class="form-label">New Password *</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required minlength="6">
                        <div class="form-text">Minimum 6 characters</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">Reset Password</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$additional_css = "
<style>
.avatar-circle {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 14px;
}
</style>
";

$additional_js = "
<script>
function editUser(user) {
    document.getElementById('edit_user_id').value = user.id;
    document.getElementById('edit_username').value = user.username;
    document.getElementById('edit_full_name').value = user.full_name;
    document.getElementById('edit_email').value = user.email || '';
    document.getElementById('edit_role').value = user.role;
    document.getElementById('edit_is_active').checked = user.is_active == 1;
    
    new bootstrap.Modal(document.getElementById('editUserModal')).show();
}

function resetPassword(userId, userName) {
    document.getElementById('reset_user_id').value = userId;
    document.getElementById('reset_user_name').textContent = userName;
    document.getElementById('new_password').value = '';
    
    new bootstrap.Modal(document.getElementById('resetPasswordModal')).show();
}
</script>
";

require_once __DIR__ . '/../includes/footer.php';
?>



<style>
.kpi-meta {
    color: rgba(255, 255, 255, 0.8);
    font-size: 0.85rem;
    font-weight: 500;
    margin-top: 0.5rem;
    display: flex;
    align-items: center;
}

.icon-circle {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, var(--primary-color), var(--primary-light));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.2rem;
    box-shadow: 0 4px 15px rgba(139, 79, 122, 0.3);
}

.btn-modern {
    text-align: left;
    padding: 1.5rem;
    height: auto;
    display: flex;
    align-items: center;
}

.btn-modern i {
    font-size: 1.5rem;
    min-width: 24px;
}

.btn-modern div {
    text-align: left;
}
</style>