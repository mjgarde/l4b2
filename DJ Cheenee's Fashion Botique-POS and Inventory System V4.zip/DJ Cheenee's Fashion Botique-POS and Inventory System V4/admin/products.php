<?php
/**
 * DJ Cheenee's Fashion Boutique - Product Management
 */

$page_title = 'Product Management - DJ Cheenee\'s Fashion Boutique';
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Products', 'url' => '#']
];

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../classes/Product.php';

SessionManager::requireAdmin();

$product = new Product();
$db = getDbConnection();

// Handle form submissions
if ($_POST) {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create_product') {
        $name = trim($_POST['name']);
        $description = trim($_POST['description']);
        $category_id = $_POST['category_id'] ?: null;
        $brand_name = trim($_POST['brand_name']) ?: null;
        $image_url = trim($_POST['image_url']) ?: null;
        
        if (!empty($name)) {
            $product_id = $product->createProduct($name, $description, $category_id, $brand_name, $image_url);
            if ($product_id) {
                $success_message = 'Product created successfully!';
            } else {
                $error_message = 'Failed to create product.';
            }
        } else {
            $error_message = 'Product name is required.';
        }
    }
    
    if ($action === 'edit_product') {
        $product_id = $_POST['product_id'];
        $name = trim($_POST['name']);
        $description = trim($_POST['description']);
        $category_id = $_POST['category_id'] ?: null;
        $brand_name = trim($_POST['brand_name']) ?: null;
        $image_url = trim($_POST['image_url']) ?: null;
        
        if (!empty($name)) {
            $result = $product->updateProduct($product_id, $name, $description, $category_id, $brand_name, $image_url);
            if ($result) {
                $success_message = 'Product updated successfully!';
            } else {
                $error_message = 'Failed to update product.';
            }
        } else {
            $error_message = 'Product name is required.';
        }
    }
    
    if ($action === 'delete_product') {
        $product_id = $_POST['product_id'];
        
        $result = $product->deleteProduct($product_id);
        if ($result) {
            $success_message = 'Product deleted successfully!';
        } else {
            $error_message = 'Failed to delete product.';
        }
    }
    
    if ($action === 'add_variant') {
        $product_id = $_POST['product_id'];
        $barcode = trim($_POST['barcode']);
        $size = trim($_POST['size']) ?: null;
        $color = trim($_POST['color']) ?: null;
        $price = $_POST['price'];
        $cost_price = $_POST['cost_price'] ?: 0;
        $stock_quantity = $_POST['stock_quantity'] ?: 0;
        $low_stock_threshold = $_POST['low_stock_threshold'] ?: 5;
        
        if (!empty($barcode) && !empty($price)) {
            try {
                $query = "INSERT INTO product_variants 
                          (product_id, barcode, size, color, price, cost_price, stock_quantity, low_stock_threshold) 
                          VALUES (:product_id, :barcode, :size, :color, :price, :cost_price, :stock_quantity, :low_stock_threshold)";
                
                $stmt = $db->prepare($query);
                $stmt->bindParam(':product_id', $product_id);
                $stmt->bindParam(':barcode', $barcode);
                $stmt->bindParam(':size', $size);
                $stmt->bindParam(':color', $color);
                $stmt->bindParam(':price', $price);
                $stmt->bindParam(':cost_price', $cost_price);
                $stmt->bindParam(':stock_quantity', $stock_quantity);
                $stmt->bindParam(':low_stock_threshold', $low_stock_threshold);
                $stmt->execute();
                
                $success_message = 'Product variant added successfully!';
            } catch (Exception $e) {
                if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
                    $error_message = 'Barcode already exists. Please use a unique barcode.';
                } else {
                    $error_message = 'Failed to add variant: ' . $e->getMessage();
                }
            }
        } else {
            $error_message = 'Barcode and price are required.';
        }
    }
}

// Get all products with variant counts
$products = $product->getAllProducts();
$categories = $product->getAllCategories();
$brands = $product->getAllBrands();
?>

<div class="row mb-4">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h2 mb-2 gradient-text">
                    <i class="fas fa-tag me-2"></i>Product Management
                </h1>
                <p class="text-muted mb-0">Manage products and their variants</p>
            </div>
            <div>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addProductModal">
                    <i class="fas fa-plus me-2"></i>Add Product
                </button>
            </div>
        </div>
    </div>
</div>

<?php if (isset($success_message)): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i><?php echo $success_message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if (isset($error_message)): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error_message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Enhanced Products List -->
<div class="row">
    <?php foreach ($products as $prod): ?>
        <div class="col-xl-4 col-lg-6 mb-4">
            <div class="card h-100 card-floating glass-effect product-card" style="animation-delay: <?php echo rand(1,5) * 0.1; ?>s;">
                <div class="card-img-top product-image-container position-relative" style="height: 200px;">
                    <div class="product-image-wrapper">
                        <?php if ($prod['image_url']): ?>
                            <img src="<?php echo htmlspecialchars($prod['image_url']); ?>" 
                                 class="product-image" alt="<?php echo htmlspecialchars($prod['name']); ?>">
                        <?php else: ?>
                            <div class="product-image-placeholder">
                                <div class="icon-circle-large">
                                    <i class="fas fa-tshirt fa-2x"></i>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Modern Hover Overlay -->
                        <div class="product-image-overlay">
                            <div class="overlay-content">
                                <button class="btn btn-glass btn-lg view-details-btn" 
                                        onclick="viewProductDetails(<?php echo $prod['id']; ?>)"
                                        title="View product details">
                                    <i class="fas fa-eye me-2"></i>View Details
                                </button>
                            </div>
                        </div>
                        
                        <!-- Stock Status Badge -->
                        <?php if ($prod['total_stock'] <= 0): ?>
                            <div class="position-absolute top-0 end-0 m-2">
                                <span class="badge badge-danger badge-pulse">Out of Stock</span>
                            </div>
                        <?php elseif ($prod['total_stock'] <= 10): ?>
                            <div class="position-absolute top-0 end-0 m-2">
                                <span class="badge badge-warning badge-pulse">Low Stock</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="card-body">
                    <h5 class="card-title gradient-text"><?php echo htmlspecialchars($prod['name']); ?></h5>
                    
                    <div class="mb-3">
                        <?php if ($prod['category_name']): ?>
                            <span class="badge badge-secondary badge-modern me-1">
                                <i class="fas fa-tag me-1"></i><?php echo htmlspecialchars($prod['category_name']); ?>
                            </span>
                        <?php endif; ?>
                        <?php if ($prod['brand_name']): ?>
                            <span class="badge badge-primary badge-modern">
                                <i class="fas fa-crown me-1"></i><?php echo htmlspecialchars($prod['brand_name']); ?>
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <p class="card-text text-muted small mb-3">
                        <?php echo htmlspecialchars($prod['description'] ?: 'No description available'); ?>
                    </p>
                    
                    <div class="row text-center mb-3">
                        <div class="col-6">
                            <div class="stat-card">
                                <div class="stat-icon">
                                    <i class="fas fa-layer-group"></i>
                                </div>
                                <div class="stat-value"><?php echo $prod['variant_count']; ?></div>
                                <div class="stat-label">Variants</div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="stat-card">
                                <div class="stat-icon">
                                    <i class="fas fa-boxes"></i>
                                </div>
                                <div class="stat-value text-success"><?php echo $prod['total_stock'] ?: 0; ?></div>
                                <div class="stat-label">Stock</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card-footer bg-transparent border-0">
                    <div class="d-grid gap-2">
                        <button class="btn btn-outline-primary btn-modern" 
                                onclick="viewVariants(<?php echo $prod['id']; ?>, '<?php echo addslashes($prod['name']); ?>')">
                            <i class="fas fa-list me-2"></i>View Variants
                        </button>
                        <button class="btn btn-primary btn-modern" 
                                onclick="addVariant(<?php echo $prod['id']; ?>, '<?php echo addslashes($prod['name']); ?>')">
                            <i class="fas fa-plus me-2"></i>Add Variant
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
    
    <?php if (empty($products)): ?>
        <div class="col-12">
            <div class="card glass-effect text-center py-5">
                <div class="card-body">
                    <div class="icon-circle-large mx-auto mb-4">
                        <i class="fas fa-tag fa-3x"></i>
                    </div>
                    <h4 class="gradient-text mb-3">No products found</h4>
                    <p class="text-muted mb-4">Start building your fashion collection by adding your first product to the inventory.</p>
                    <button class="btn btn-primary btn-lg btn-modern" data-bs-toggle="modal" data-bs-target="#addProductModal">
                        <i class="fas fa-plus me-2"></i>Add First Product
                    </button>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Add Product Modal -->
<div class="modal fade" id="addProductModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="action" value="create_product">
                
                <div class="modal-header">
                    <h5 class="modal-title">Add New Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="mb-3">
                                <label for="name" class="form-label">Product Name *</label>
                                <input type="text" class="form-control" name="name" required 
                                       placeholder="e.g., Denim Jacket, Summer Dress">
                            </div>
                            
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea class="form-control" name="description" rows="3" 
                                          placeholder="Product description..."></textarea>
                            </div>
                            
                            <div class="row">
                                <div class="col-6">
                                    <div class="mb-3">
                                        <label for="category_id" class="form-label">Category</label>
                                        <select class="form-control" name="category_id">
                                            <option value="">Select Category</option>
                                            <?php foreach ($categories as $category): ?>
                                                <option value="<?php echo $category['id']; ?>">
                                                    <?php echo htmlspecialchars($category['name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="mb-3">
                                        <label for="brand_name" class="form-label">Brand</label>
                                        <input type="text" class="form-control" name="brand_name" 
                                               placeholder="Enter brand name">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="image_url" class="form-label">Image URL</label>
                                <input type="url" class="form-control" name="image_url" 
                                       placeholder="https://example.com/image.jpg">
                                <small class="text-muted">Optional: Add a product image URL</small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Create Product
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add Variant Modal -->
<div class="modal fade" id="addVariantModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="action" value="add_variant">
                <input type="hidden" name="product_id" id="variant_product_id">
                
                <div class="modal-header">
                    <h5 class="modal-title">Add Product Variant</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold" id="variant_product_name"></label>
                    </div>
                    
                    <div class="row">
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="size" class="form-label">Size</label>
                                <input type="text" class="form-control" name="size" 
                                       placeholder="e.g., S, M, L, XL">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="color" class="form-label">Color</label>
                                <input type="text" class="form-control" name="color" 
                                       placeholder="e.g., Red, Blue, Black">
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="barcode" class="form-label">Barcode *</label>
                        <div class="input-group">
                            <input type="text" class="form-control" name="barcode" required 
                                   placeholder="Enter or generate barcode">
                            <button type="button" class="btn btn-outline-secondary" onclick="generateBarcode()">
                                <i class="fas fa-random"></i> Generate
                            </button>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="cost_price" class="form-label">Cost Price</label>
                                <input type="number" class="form-control" name="cost_price" 
                                       step="0.01" min="0" placeholder="0.00">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="price" class="form-label">Selling Price *</label>
                                <input type="number" class="form-control" name="price" 
                                       step="0.01" min="0" required placeholder="0.00">
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="stock_quantity" class="form-label">Initial Stock</label>
                                <input type="number" class="form-control" name="stock_quantity" 
                                       min="0" value="0">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label for="low_stock_threshold" class="form-label">Low Stock Alert</label>
                                <input type="number" class="form-control" name="low_stock_threshold" 
                                       min="0" value="5">
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Add Variant
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Variants Modal -->
<div class="modal fade" id="viewVariantsModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Product Variants</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="variantsContent">
                    <!-- Variants will be loaded here -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Product Details Modal -->
<div class="modal fade" id="productDetailsModal" tabindex="-1" aria-labelledby="productDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="productDetailsModalLabel">
                    <i class="fas fa-eye me-2"></i>Product Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="productDetailsContent">
                    <!-- Product details will be loaded here -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-warning" id="editProductBtn" onclick="openEditMode()">
                    <i class="fas fa-edit me-2"></i>Edit Product
                </button>
                <button type="button" class="btn btn-danger" id="deleteProductBtn" onclick="confirmDeleteProduct()">
                    <i class="fas fa-trash me-2"></i>Delete Product
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Product Modal -->
<div class="modal fade" id="editProductModal" tabindex="-1" aria-labelledby="editProductModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editProductModalLabel">
                    <i class="fas fa-edit me-2"></i>Edit Product
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="edit_product">
                <input type="hidden" name="product_id" id="edit_product_id">
                
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="mb-3">
                                <label for="edit_name" class="form-label">Product Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="name" id="edit_name" required 
                                       placeholder="e.g. Denim Jacket, Summer Dress">
                            </div>
                            
                            <div class="mb-3">
                                <label for="edit_description" class="form-label">Description</label>
                                <textarea class="form-control" name="description" id="edit_description" rows="3" 
                                          placeholder="Product description..."></textarea>
                            </div>
                            
                            <div class="row">
                                <div class="col-6">
                                    <div class="mb-3">
                                        <label for="edit_category_id" class="form-label">Category</label>
                                        <select class="form-control" name="category_id" id="edit_category_id">
                                            <option value="">Select Category</option>
                                            <?php foreach ($categories as $category): ?>
                                                <option value="<?php echo $category['id']; ?>">
                                                    <?php echo htmlspecialchars($category['name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="mb-3">
                                        <label for="edit_brand_name" class="form-label">Brand</label>
                                        <input type="text" class="form-control" name="brand_name" id="edit_brand_name" 
                                               placeholder="Enter brand name">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_image_url" class="form-label">Image URL</label>
                                <input type="url" class="form-control" name="image_url" id="edit_image_url" 
                                       placeholder="https://example.com/image.jpg">
                                <small class="text-muted">Optional: Add a product image URL</small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">
                        <i class="fas fa-save me-2"></i>Update Product
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$additional_js = "
<style>
/* Product Image Hover Overlay Styles */
.product-image-container {
    position: relative;
    overflow: hidden;
    border-radius: 0.5rem 0.5rem 0 0;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
}

.product-image-wrapper {
    position: relative;
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: transform 0.3s ease;
}

.product-image {
    max-height: 180px;
    max-width: 100%;
    object-fit: cover;
    border-radius: 0.25rem;
    transition: transform 0.3s ease, filter 0.3s ease;
}

.product-image-placeholder {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 0.25rem;
}

.product-image-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    backdrop-filter: blur(2px);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
    border-radius: 0.5rem 0.5rem 0 0;
}

.overlay-content {
    text-align: center;
    transform: translateY(20px);
    transition: transform 0.3s ease;
}

.view-details-btn {
    background: linear-gradient(135deg, var(--bs-primary) 0%, #6f42c1 100%);
    border: none;
    border-radius: 50px;
    padding: 12px 24px;
    font-weight: 600;
    letter-spacing: 0.5px;
    box-shadow: 0 8px 25px rgba(0, 123, 255, 0.3);
    transform: translateY(0);
    transition: all 0.3s ease;
}

.view-details-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 35px rgba(0, 123, 255, 0.4);
    background: linear-gradient(135deg, #0056b3 0%, #5a32a3 100%);
}

.view-details-btn:active {
    transform: translateY(0);
}

/* Hover Effects */
.product-image-container:hover .product-image-overlay {
    opacity: 1;
    visibility: visible;
}

.product-image-container:hover .overlay-content {
    transform: translateY(0);
}

.product-image-container:hover .product-image {
    transform: scale(1.05);
    filter: brightness(0.8);
}

.product-image-container:hover .product-image-wrapper {
    transform: scale(1.02);
}

/* Enhanced Card Styles */
.card-elevated {
    transition: all 0.3s ease;
    border: none;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.card-elevated:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
}

/* Responsive Adjustments */
@media (max-width: 768px) {
    .product-image-overlay {
        background: rgba(0, 0, 0, 0.8);
    }
    
    .view-details-btn {
        padding: 10px 20px;
        font-size: 0.9rem;
    }
}

/* Animation for smooth loading */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.card-elevated {
    animation: fadeInUp 0.6s ease forwards;
}

.card-elevated:nth-child(2) { animation-delay: 0.1s; }
.card-elevated:nth-child(3) { animation-delay: 0.2s; }
.card-elevated:nth-child(4) { animation-delay: 0.3s; }
</style>

<script>
function addVariant(productId, productName) {
    document.getElementById('variant_product_id').value = productId;
    document.getElementById('variant_product_name').textContent = 'Product: ' + productName;
    
    // Clear form
    const form = document.querySelector('#addVariantModal form');
    form.querySelectorAll('input[type=\"text\"], input[type=\"number\"]').forEach(input => {
        if (input.name !== 'low_stock_threshold') {
            input.value = '';
        }
    });
    
    new bootstrap.Modal(document.getElementById('addVariantModal')).show();
}

async function viewVariants(productId, productName) {
    try {
        const response = await fetch('../api/product_variants.php?product_id=' + productId);
        const data = await response.json();
        
        if (data.success) {
            const content = document.getElementById('variantsContent');
            
            if (data.variants.length === 0) {
                content.innerHTML = `
                    <div class='text-center py-4'>
                        <i class='fas fa-box-open fa-3x text-muted mb-3'></i>
                        <h5 class='text-muted'>No variants found</h5>
                        <p class='text-muted'>Add variants to this product to start selling.</p>
                        <button class='btn btn-primary' onclick='addVariant(\${productId}, \"\${productName}\")'>
                            <i class='fas fa-plus me-2'></i>Add First Variant
                        </button>
                    </div>
                `;
            } else {
                content.innerHTML = `
                    <div class='d-flex justify-content-between align-items-center mb-3'>
                        <h6 class='mb-0'>\${productName} - Variants</h6>
                        <button class='btn btn-sm btn-primary' onclick='addVariant(\${productId}, \"\${productName}\")'>
                            <i class='fas fa-plus me-1'></i>Add Variant
                        </button>
                    </div>
                    <div class='table-responsive'>
                        <table class='table table-striped'>
                            <thead>
                                <tr>
                                    <th>Size</th>
                                    <th>Color</th>
                                    <th>Barcode</th>
                                    <th class='text-end'>Price</th>
                                    <th class='text-center'>Stock</th>
                                    <th class='text-center'>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                \${data.variants.map(variant => `
                                    <tr>
                                        <td><span class='badge bg-secondary'>\${variant.size || 'N/A'}</span></td>
                                        <td><span class='badge bg-info'>\${variant.color || 'N/A'}</span></td>
                                        <td><code>\${variant.barcode}</code></td>
                                        <td class='text-end'>₱\${parseFloat(variant.price).toFixed(2)}</td>
                                        <td class='text-center'>\${variant.stock_quantity}</td>
                                        <td class='text-center'>
                                            \${variant.stock_quantity == 0 ? 
                                                '<span class=\"badge badge-danger\">Out of Stock</span>' :
                                                variant.stock_quantity <= variant.low_stock_threshold ?
                                                '<span class=\"badge badge-warning\">Low Stock</span>' :
                                                '<span class=\"badge badge-success\">In Stock</span>'
                                            }
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            }
            
            new bootstrap.Modal(document.getElementById('viewVariantsModal')).show();
        }
    } catch (error) {
        alert('Error loading variants: ' + error.message);
    }
}

function generateBarcode() {
    // Generate a simple barcode (timestamp + random)
    const timestamp = Date.now().toString();
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    const barcode = timestamp.slice(-8) + random;
    
    document.querySelector('input[name=\"barcode\"]').value = barcode;
}

let currentProductData = null;

// View product details function
function viewProductDetails(productId) {
    console.log('Fetching product details for ID:', productId);
    fetch('../api/get_product.php?id=' + productId)
        .then(response => {
            console.log('Response status:', response.status);
            if (!response.ok) {
                throw new Error('HTTP error! status: ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            console.log('Response data:', data);
            if (data.success) {
                currentProductData = data.product;
                displayProductDetails(data.product);
                new bootstrap.Modal(document.getElementById('productDetailsModal')).show();
            } else {
                alert('Failed to load product data: ' + (data.message || 'Unknown error'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to load product data: ' + error.message);
        });
}

// Display product details in modal
function displayProductDetails(product) {
    const content = document.getElementById('productDetailsContent');
    content.innerHTML = 
        '<div class=\"row\">' +
            '<div class=\"col-md-4\">' +
                '<div class=\"text-center mb-3\">' +
                    (product.image_url ? 
                        '<img src=\"' + product.image_url + '\" class=\"img-fluid rounded\" style=\"max-height: 300px;\">' : 
                        '<div class=\"bg-light rounded d-flex align-items-center justify-content-center\" style=\"height: 200px;\">' +
                            '<i class=\"fas fa-tshirt fa-4x text-muted\"></i>' +
                         '</div>'
                    ) +
                '</div>' +
            '</div>' +
            '<div class=\"col-md-8\">' +
                '<h4>' + product.name + '</h4>' +
                '<p class=\"text-muted\">' + (product.description || 'No description available') + '</p>' +
                
                '<div class=\"row mb-3\">' +
                    '<div class=\"col-6\">' +
                        '<strong>Category:</strong><br>' +
                        '<span class=\"badge bg-secondary\">' + (product.category_name || 'No category') + '</span>' +
                    '</div>' +
                    '<div class=\"col-6\">' +
                        '<strong>Brand:</strong><br>' +
                        '<span class=\"badge bg-info\">' + (product.brand_name || 'No brand') + '</span>' +
                    '</div>' +
                '</div>' +
                
                '<div class=\"row mb-3\">' +
                    '<div class=\"col-6\">' +
                        '<strong>Total Variants:</strong><br>' +
                        '<span class=\"fs-4 text-primary\">' + (product.variant_count || 0) + '</span>' +
                    '</div>' +
                    '<div class=\"col-6\">' +
                        '<strong>Total Stock:</strong><br>' +
                        '<span class=\"fs-4 text-success\">' + (product.total_stock || 0) + '</span>' +
                    '</div>' +
                '</div>' +
                
                '<div class=\"row\">' +
                    '<div class=\"col-12\">' +
                        '<strong>Price Range:</strong><br>' +
                        '<span class=\"fs-5 text-primary\">₱' + parseFloat(product.min_price || 0).toFixed(2) + ' - ₱' + parseFloat(product.max_price || product.min_price || 0).toFixed(2) + '</span>' +
                    '</div>' +
                '</div>' +
            '</div>' +
        '</div>';
}

// Open edit mode from product details
function openEditMode() {
    if (currentProductData) {
        document.getElementById('edit_product_id').value = currentProductData.id;
        document.getElementById('edit_name').value = currentProductData.name;
        document.getElementById('edit_description').value = currentProductData.description || '';
        document.getElementById('edit_category_id').value = currentProductData.category_id || '';
        document.getElementById('edit_brand_name').value = currentProductData.brand_name || '';
        document.getElementById('edit_image_url').value = currentProductData.image_url || '';
        
        // Hide product details modal and show edit modal
        bootstrap.Modal.getInstance(document.getElementById('productDetailsModal')).hide();
        new bootstrap.Modal(document.getElementById('editProductModal')).show();
    }
}

// Confirm delete product from details modal
function confirmDeleteProduct() {
    if (currentProductData) {
        if (confirm('Are you sure you want to delete \"' + currentProductData.name + '\"? This action cannot be undone.')) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = 
                '<input type=\"hidden\" name=\"action\" value=\"delete_product\">' +
                '<input type=\"hidden\" name=\"product_id\" value=\"' + currentProductData.id + '\">';
            document.body.appendChild(form);
            form.submit();
        }
    }
}

// Auto-generate barcode when modal opens
document.getElementById('addVariantModal').addEventListener('shown.bs.modal', function() {
    const barcodeInput = document.querySelector('input[name=\"barcode\"]');
    if (!barcodeInput.value) {
        generateBarcode();
    }
    barcodeInput.focus();
    barcodeInput.select();
});
</script>
";

require_once __DIR__ . '/../includes/footer.php';
?>
