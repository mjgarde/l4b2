<?php
/**
 * DJ Cheenee's Fashion Boutique - Reports & Analytics
 */

$page_title = 'Reports & Analytics - DJ Cheenee\'s Fashion Boutique';
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Reports', 'url' => '#']
];

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../classes/Product.php';
require_once __DIR__ . '/../classes/Sale.php';

SessionManager::requireAdmin();

$db = getDbConnection();

// Get filter parameters
$period = $_GET['period'] ?? '';
$start_date = $_GET['start_date'] ?? date('Y-m-01'); // First day of current month
$end_date = $_GET['end_date'] ?? date('Y-m-d'); // Today
$report_type = $_GET['report_type'] ?? 'sales';

// Handle period-based filtering
if ($period) {
    switch ($period) {
        case 'today':
            $start_date = $end_date = date('Y-m-d');
            break;
        case 'yesterday':
            $start_date = $end_date = date('Y-m-d', strtotime('-1 day'));
            break;
        case 'this_week':
            $start_date = date('Y-m-d', strtotime('monday this week'));
            $end_date = date('Y-m-d', strtotime('sunday this week'));
            break;
        case 'last_week':
            $start_date = date('Y-m-d', strtotime('monday last week'));
            $end_date = date('Y-m-d', strtotime('sunday last week'));
            break;
        case 'this_month':
            $start_date = date('Y-m-01');
            $end_date = date('Y-m-t');
            break;
        case 'last_month':
            $start_date = date('Y-m-01', strtotime('first day of last month'));
            $end_date = date('Y-m-t', strtotime('last day of last month'));
            break;
        case 'this_year':
            $start_date = date('Y-01-01');
            $end_date = date('Y-12-31');
            break;
        case 'last_30_days':
            $start_date = date('Y-m-d', strtotime('-30 days'));
            $end_date = date('Y-m-d');
            break;
    }
}

// Sales Reports
if ($report_type === 'sales') {
    // Sales Summary
    $sales_query = "SELECT 
                        COUNT(*) as total_transactions,
                        SUM(total_amount) as total_revenue,
                        AVG(total_amount) as avg_transaction
                    FROM sales_transactions 
                    WHERE DATE(created_at) BETWEEN :start_date AND :end_date 
                    AND payment_status = 'completed'";
    
    // Get total items sold
    $items_query = "SELECT 
                        COALESCE(SUM(sti.quantity), 0) as total_items_sold
                    FROM sales_transaction_items sti
                    JOIN sales_transactions st ON sti.transaction_id = st.id
                    WHERE DATE(st.created_at) BETWEEN :start_date AND :end_date 
                    AND st.payment_status = 'completed'";
    
    $stmt = $db->prepare($sales_query);
    $stmt->bindParam(':start_date', $start_date);
    $stmt->bindParam(':end_date', $end_date);
    $stmt->execute();
    $sales_summary = $stmt->fetch();

    // Execute items query
    $stmt = $db->prepare($items_query);
    $stmt->bindParam(':start_date', $start_date);
    $stmt->bindParam(':end_date', $end_date);
    $stmt->execute();
    $items_summary = $stmt->fetch();
    
    // Merge the results
    $sales_summary['total_items_sold'] = $items_summary['total_items_sold'];

    // Daily Sales Breakdown
    $daily_query = "SELECT 
                        DATE(created_at) as sale_date,
                        COUNT(*) as transactions,
                        SUM(total_amount) as revenue
                    FROM sales_transactions 
                    WHERE DATE(created_at) BETWEEN :start_date AND :end_date 
                    AND payment_status = 'completed'
                    GROUP BY DATE(created_at)
                    ORDER BY sale_date ASC";
    
    $stmt = $db->prepare($daily_query);
    $stmt->bindParam(':start_date', $start_date);
    $stmt->bindParam(':end_date', $end_date);
    $stmt->execute();
    $daily_sales = $stmt->fetchAll();

    // Payment Method Breakdown
    $payment_query = "SELECT 
                          payment_method,
                          COUNT(*) as transactions,
                          SUM(total_amount) as revenue
                      FROM sales_transactions 
                      WHERE DATE(created_at) BETWEEN :start_date AND :end_date 
                      AND payment_status = 'completed'
                      GROUP BY payment_method";
    
    $stmt = $db->prepare($payment_query);
    $stmt->bindParam(':start_date', $start_date);
    $stmt->bindParam(':end_date', $end_date);
    $stmt->execute();
    $payment_methods = $stmt->fetchAll();

    // Top Selling Products
    $top_products_query = "SELECT 
                               p.name as product_name,
                               pv.size, pv.color,
                               SUM(sti.quantity) as total_sold,
                               SUM(sti.total_price) as total_revenue
                           FROM sales_transaction_items sti
                           JOIN product_variants pv ON sti.product_variant_id = pv.id
                           JOIN products p ON pv.product_id = p.id
                           JOIN sales_transactions st ON sti.transaction_id = st.id
                           WHERE DATE(st.created_at) BETWEEN :start_date AND :end_date 
                           AND st.payment_status = 'completed'
                           GROUP BY sti.product_variant_id
                           ORDER BY total_sold DESC
                           LIMIT 10";
    
    $stmt = $db->prepare($top_products_query);
    $stmt->bindParam(':start_date', $start_date);
    $stmt->bindParam(':end_date', $end_date);
    $stmt->execute();
    $top_products = $stmt->fetchAll();
}

// Inventory Reports
if ($report_type === 'inventory') {
    // Inventory Summary
    $inventory_query = "SELECT 
                            COUNT(DISTINCT p.id) as total_products,
                            COUNT(pv.id) as total_variants,
                            SUM(pv.stock_quantity) as total_stock,
                            SUM(pv.price * pv.stock_quantity) as inventory_value,
                            SUM(CASE WHEN pv.stock_quantity <= pv.low_stock_threshold THEN 1 ELSE 0 END) as low_stock_items,
                            SUM(CASE WHEN pv.stock_quantity = 0 THEN 1 ELSE 0 END) as out_of_stock_items
                        FROM products p
                        JOIN product_variants pv ON p.id = pv.product_id
                        WHERE p.is_active = 1 AND pv.is_active = 1";
    
    $stmt = $db->prepare($inventory_query);
    $stmt->execute();
    $inventory_summary = $stmt->fetch();

    // Category Breakdown
    $category_query = "SELECT 
                           c.name as category_name,
                           COUNT(DISTINCT p.id) as product_count,
                           COUNT(pv.id) as variant_count,
                           SUM(pv.stock_quantity) as total_stock,
                           SUM(pv.price * pv.stock_quantity) as category_value
                       FROM categories c
                       LEFT JOIN products p ON c.id = p.category_id AND p.is_active = 1
                       LEFT JOIN product_variants pv ON p.id = pv.product_id AND pv.is_active = 1
                       GROUP BY c.id, c.name
                       ORDER BY category_value DESC";
    
    $stmt = $db->prepare($category_query);
    $stmt->execute();
    $category_breakdown = $stmt->fetchAll();

    // Low Stock Items
    $low_stock_query = "SELECT 
                            p.name as product_name,
                            pv.size, pv.color, pv.barcode,
                            pv.stock_quantity,
                            pv.low_stock_threshold,
                            pv.price
                        FROM products p
                        JOIN product_variants pv ON p.id = pv.product_id
                        WHERE p.is_active = 1 AND pv.is_active = 1
                        AND pv.stock_quantity <= pv.low_stock_threshold
                        ORDER BY pv.stock_quantity ASC";
    
    $stmt = $db->prepare($low_stock_query);
    $stmt->execute();
    $low_stock_items = $stmt->fetchAll();
}
?>

<div class="row mb-4">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h2 mb-2 gradient-text">
                    <i class="fas fa-chart-bar me-3"></i>Reports & Analytics
                </h1>
                <p class="text-muted mb-0">Comprehensive business insights and analytics dashboard</p>
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-outline-primary btn-modern" onclick="location.reload()">
                    <i class="fas fa-sync-alt me-2"></i>Refresh
                </button>
                <button class="btn btn-outline-secondary btn-modern" onclick="window.print()">
                    <i class="fas fa-print me-2"></i>Print Report
                </button>
                <button class="btn btn-primary" onclick="exportToCSV()">
                    <i class="fas fa-download me-2"></i>Export CSV
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Enhanced Filters -->
<div class="card card-floating glass-effect mb-4">
    <div class="card-header">
        <div class="d-flex align-items-center">
            <div class="icon-circle me-3">
                <i class="fas fa-sliders-h"></i>
            </div>
            <h5 class="mb-0 gradient-text">Report Configuration</h5>
        </div>
    </div>
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-2">
                <div class="form-floating">
                    <select class="form-select" id="report_type" name="report_type">
                        <option value="sales" <?php echo $report_type === 'sales' ? 'selected' : ''; ?>>Sales Report</option>
                        <option value="inventory" <?php echo $report_type === 'inventory' ? 'selected' : ''; ?>>Inventory Report</option>
                    </select>
                    <label for="report_type">
                        <i class="fas fa-chart-pie me-2"></i>Report Type
                    </label>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-floating">
                    <select class="form-select" id="period" name="period" onchange="handlePeriodChange(this.value)">
                        <option value="">Custom Range</option>
                        <option value="this_week" <?php echo $period === 'this_week' ? 'selected' : ''; ?>>This Week</option>
                        <option value="last_week" <?php echo $period === 'last_week' ? 'selected' : ''; ?>>Last Week</option>
                        <option value="this_month" <?php echo $period === 'this_month' ? 'selected' : ''; ?>>This Month</option>
                        <option value="last_month" <?php echo $period === 'last_month' ? 'selected' : ''; ?>>Last Month</option>
                        <option value="last_30_days" <?php echo $period === 'last_30_days' ? 'selected' : ''; ?>>Last 30 Days</option>
                        <option value="this_year" <?php echo $period === 'this_year' ? 'selected' : ''; ?>>This Year</option>
                    </select>
                    <label for="period">
                        <i class="fas fa-clock me-2"></i>Quick Period
                    </label>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-floating">
                    <input type="date" class="form-control" id="start_date" name="start_date" 
                           value="<?php echo $start_date; ?>" placeholder="Start Date">
                    <label for="start_date">
                        <i class="fas fa-calendar-alt me-2"></i>Start Date
                    </label>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-floating">
                    <input type="date" class="form-control" id="end_date" name="end_date" 
                           value="<?php echo $end_date; ?>" placeholder="End Date">
                    <label for="end_date">
                        <i class="fas fa-calendar-check me-2"></i>End Date
                    </label>
                </div>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-primary btn-lg w-100">
                    <i class="fas fa-chart-line me-2"></i>Generate
                </button>
            </div>
        </form>
    </div>
</div>

<?php if ($report_type === 'sales'): ?>
    <!-- Sales Report -->
    <div class="row mb-4">
        <!-- Sales Summary Cards -->
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="kpi-card kpi-card-primary kpi-card-floating" style="animation-delay: 0.1s;">
                <div class="kpi-icon">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div class="kpi-value">₱<?php echo number_format($sales_summary['total_revenue'] ?: 0, 2); ?></div>
                <div class="kpi-label">TOTAL REVENUE</div>
                <div class="kpi-meta">
                    <i class="fas fa-chart-line me-1"></i>
                    Revenue earned
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-3">
            <div class="kpi-card kpi-card-secondary kpi-card-floating" style="animation-delay: 0.2s;">
                <div class="kpi-icon">
                    <i class="fas fa-receipt"></i>
                </div>
                <div class="kpi-value"><?php echo number_format($sales_summary['total_transactions'] ?: 0); ?></div>
                <div class="kpi-label">TRANSACTIONS</div>
                <div class="kpi-meta">
                    <i class="fas fa-shopping-bag me-1"></i>
                    Completed sales
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-3">
            <div class="kpi-card kpi-card-success kpi-card-floating" style="animation-delay: 0.3s;">
                <div class="kpi-icon">
                    <i class="fas fa-calculator"></i>
                </div>
                <div class="kpi-value">₱<?php echo number_format($sales_summary['avg_transaction'] ?: 0, 2); ?></div>
                <div class="kpi-label">AVG. TRANSACTION</div>
                <div class="kpi-meta">
                    <i class="fas fa-chart-bar me-1"></i>
                    Per transaction
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-3">
            <div class="kpi-card kpi-card-warning kpi-card-floating" style="animation-delay: 0.4s;">
                <div class="kpi-icon">
                    <i class="fas fa-boxes"></i>
                </div>
                <div class="kpi-value"><?php echo number_format($sales_summary['total_items_sold'] ?: 0); ?></div>
                <div class="kpi-label">ITEMS SOLD</div>
                <div class="kpi-meta">
                    <i class="fas fa-shopping-cart me-1"></i>
                    Total quantity
                </div>
            </div>
        </div>

    </div>

    <div class="row">
        <!-- Daily Sales Chart -->
        <div class="col-xl-8 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-chart-line me-2"></i>Daily Sales Trend
                    </h5>
                </div>
                <div class="card-body">
                    <canvas id="dailySalesChart" width="400" height="200"></canvas>
                </div>
            </div>
        </div>

        <!-- Payment Methods -->
        <div class="col-xl-4 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-credit-card me-2"></i>Payment Methods
                    </h5>
                </div>
                <div class="card-body">
                    <canvas id="paymentMethodChart" width="400" height="200"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Top Selling Products -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">
                <i class="fas fa-trophy me-2"></i>Top Selling Products
            </h5>
        </div>
        <div class="card-body">
            <?php if (!empty($top_products)): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Rank</th>
                                <th>Product</th>
                                <th>Variant</th>
                                <th class="text-center">Quantity Sold</th>
                                <th class="text-end">Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_products as $index => $product): ?>
                                <tr>
                                    <td>
                                        <span class="badge <?php echo $index < 3 ? 'bg-warning' : 'bg-secondary'; ?>">
                                            #<?php echo $index + 1; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="fw-bold"><?php echo htmlspecialchars($product['product_name']); ?></div>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary me-1"><?php echo htmlspecialchars($product['size'] ?: 'N/A'); ?></span>
                                        <span class="badge bg-info"><?php echo htmlspecialchars($product['color'] ?: 'N/A'); ?></span>
                                    </td>
                                    <td class="text-center">
                                        <span class="fw-bold text-primary"><?php echo $product['total_sold']; ?></span>
                                    </td>
                                    <td class="text-end">
                                        <span class="fw-bold">₱<?php echo number_format($product['total_revenue'], 2); ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-4">
                    <i class="fas fa-chart-bar fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">No sales data available</h5>
                    <p class="text-muted">No sales found for the selected date range.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php else: ?>
    <!-- Inventory Report -->
    <div class="row mb-4">
        <!-- Inventory Summary Cards -->
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="kpi-card kpi-card-primary kpi-card-floating" style="animation-delay: 0.1s;">
                <div class="kpi-icon">
                    <i class="fas fa-tag"></i>
                </div>
                <div class="kpi-value"><?php echo number_format($inventory_summary['total_products'] ?: 0); ?></div>
                <div class="kpi-label">TOTAL PRODUCTS</div>
                <div class="kpi-meta">
                    <i class="fas fa-boxes me-1"></i>
                    Product catalog
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-3">
            <div class="kpi-card kpi-card-secondary kpi-card-floating" style="animation-delay: 0.2s;">
                <div class="kpi-icon">
                    <i class="fas fa-list"></i>
                </div>
                <div class="kpi-value"><?php echo number_format($inventory_summary['total_variants'] ?: 0); ?></div>
                <div class="kpi-label">TOTAL VARIANTS</div>
                <div class="kpi-meta">
                    <i class="fas fa-layer-group me-1"></i>
                    Size & color options
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-3">
            <div class="kpi-card kpi-card-success kpi-card-floating" style="animation-delay: 0.3s;">
                <div class="kpi-icon">
                    <i class="fas fa-peso-sign"></i>
                </div>
                <div class="kpi-value">₱<?php echo number_format($inventory_summary['inventory_value'] ?: 0, 2); ?></div>
                <div class="kpi-label">INVENTORY VALUE</div>
                <div class="kpi-meta">
                    <i class="fas fa-warehouse me-1"></i>
                    Stock worth
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-3">
            <div class="kpi-card kpi-card-warning kpi-card-floating" style="animation-delay: 0.4s;">
                <div class="kpi-icon">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="kpi-value"><?php echo number_format($inventory_summary['low_stock_items'] ?: 0); ?></div>
                <div class="kpi-label">LOW STOCK ITEMS</div>
                <div class="kpi-meta">
                    <i class="fas fa-bell me-1"></i>
                    Need attention
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Category Breakdown -->
        <div class="col-xl-8 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-chart-pie me-2"></i>Category Breakdown
                    </h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Category</th>
                                    <th class="text-center">Products</th>
                                    <th class="text-center">Variants</th>
                                    <th class="text-center">Stock</th>
                                    <th class="text-end">Value</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($category_breakdown as $category): ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold"><?php echo htmlspecialchars($category['category_name']); ?></div>
                                        </td>
                                        <td class="text-center"><?php echo $category['product_count'] ?: 0; ?></td>
                                        <td class="text-center"><?php echo $category['variant_count'] ?: 0; ?></td>
                                        <td class="text-center"><?php echo $category['total_stock'] ?: 0; ?></td>
                                        <td class="text-end">₱<?php echo number_format($category['category_value'] ?: 0, 2); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Low Stock Alert -->
        <div class="col-xl-4 mb-4">
            <div class="card">
                <div class="card-header bg-warning text-dark">
                    <h5 class="mb-0">
                        <i class="fas fa-exclamation-triangle me-2"></i>Low Stock Alerts
                    </h5>
                </div>
                <div class="card-body" style="max-height: 400px; overflow-y: auto;">
                    <?php if (!empty($low_stock_items)): ?>
                        <?php foreach ($low_stock_items as $item): ?>
                            <div class="d-flex justify-content-between align-items-center mb-2 pb-2 border-bottom">
                                <div>
                                    <div class="fw-bold small"><?php echo htmlspecialchars($item['product_name']); ?></div>
                                    <small class="text-muted"><?php echo htmlspecialchars($item['size'] . ' - ' . $item['color']); ?></small>
                                </div>
                                <div class="text-end">
                                    <span class="badge badge-danger"><?php echo $item['stock_quantity']; ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="text-center py-3">
                            <i class="fas fa-check-circle fa-2x text-success mb-2"></i>
                            <p class="text-muted mb-0">All items are well stocked!</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php
$additional_js = "
<script>
";

if ($report_type === 'sales') {
    $additional_js .= "
// Daily Sales Chart
const dailySalesData = " . json_encode($daily_sales) . ";
const ctx1 = document.getElementById('dailySalesChart').getContext('2d');

new Chart(ctx1, {
    type: 'line',
    data: {
        labels: dailySalesData.map(item => new Date(item.sale_date).toLocaleDateString()),
        datasets: [{
            label: 'Daily Revenue (₱)',
            data: dailySalesData.map(item => parseFloat(item.revenue)),
            borderColor: 'rgb(139, 79, 122)',
            backgroundColor: 'rgba(139, 79, 122, 0.1)',
            tension: 0.1,
            fill: true
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return '₱' + value.toLocaleString();
                    }
                }
            }
        }
    }
});

// Payment Methods Chart
const paymentData = " . json_encode($payment_methods) . ";
const ctx2 = document.getElementById('paymentMethodChart').getContext('2d');

new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: paymentData.map(item => item.payment_method.toUpperCase()),
        datasets: [{
            data: paymentData.map(item => parseFloat(item.revenue)),
            backgroundColor: [
                'rgb(139, 79, 122)',
                'rgb(212, 165, 116)',
                'rgb(76, 175, 80)'
            ]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});
";
}

$additional_js .= "

function exportToCSV() {
    const reportType = '" . $report_type . "';
    const startDate = '" . $start_date . "';
    const endDate = '" . $end_date . "';
    
    // Create CSV content based on report type
    let csvContent = '';
    
    if (reportType === 'sales') {
        csvContent = 'DJ Cheenee\\'s Fashion Boutique - Sales Report\\n';
        csvContent += 'Date Range: ' + startDate + ' to ' + endDate + '\\n\\n';
        csvContent += 'Product,Size,Color,Quantity Sold,Revenue\\n';
        
        " . (isset($top_products) ? "const topProducts = " . json_encode($top_products) . ";
        topProducts.forEach(product => {
            csvContent += `\"\${product.product_name}\",\"\${product.size || 'N/A'}\",\"\${product.color || 'N/A'}\",\${product.total_sold},\${product.total_revenue}\\n`;
        });" : "") . "
    } else {
        csvContent = 'DJ Cheenee\\'s Fashion Boutique - Inventory Report\\n';
        csvContent += 'Generated: ' + new Date().toLocaleDateString() + '\\n\\n';
        csvContent += 'Category,Products,Variants,Stock,Value\\n';
        
        " . (isset($category_breakdown) ? "const categories = " . json_encode($category_breakdown) . ";
        categories.forEach(category => {
            csvContent += `\"\${category.category_name}\",\${category.product_count},\${category.variant_count},\${category.total_stock},\${category.category_value}\\n`;
        });" : "") . "
    }
    
    // Download CSV
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dj-cheenee-\${reportType}-report-\${startDate}-to-\${endDate}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
}

function handlePeriodChange(period) {
    const startDateInput = document.getElementById('start_date');
    const endDateInput = document.getElementById('end_date');
    
    if (!period) return; // Custom range selected
    
    const today = new Date();
    let startDate, endDate;
    
    switch (period) {
        case 'today':
            startDate = endDate = today.toISOString().split('T')[0];
            break;
        case 'yesterday':
            const yesterday = new Date(today);
            yesterday.setDate(today.getDate() - 1);
            startDate = endDate = yesterday.toISOString().split('T')[0];
            break;
        case 'this_week':
            const thisWeekStart = new Date(today);
            thisWeekStart.setDate(today.getDate() - today.getDay() + 1); // Monday
            const thisWeekEnd = new Date(thisWeekStart);
            thisWeekEnd.setDate(thisWeekStart.getDate() + 6); // Sunday
            startDate = thisWeekStart.toISOString().split('T')[0];
            endDate = thisWeekEnd.toISOString().split('T')[0];
            break;
        case 'last_week':
            const lastWeekStart = new Date(today);
            lastWeekStart.setDate(today.getDate() - today.getDay() - 6); // Last Monday
            const lastWeekEnd = new Date(lastWeekStart);
            lastWeekEnd.setDate(lastWeekStart.getDate() + 6); // Last Sunday
            startDate = lastWeekStart.toISOString().split('T')[0];
            endDate = lastWeekEnd.toISOString().split('T')[0];
            break;
        case 'this_month':
            startDate = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0];
            endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0).toISOString().split('T')[0];
            break;
        case 'last_month':
            startDate = new Date(today.getFullYear(), today.getMonth() - 1, 1).toISOString().split('T')[0];
            endDate = new Date(today.getFullYear(), today.getMonth(), 0).toISOString().split('T')[0];
            break;
        case 'this_year':
            startDate = new Date(today.getFullYear(), 0, 1).toISOString().split('T')[0];
            endDate = new Date(today.getFullYear(), 11, 31).toISOString().split('T')[0];
            break;
        case 'last_30_days':
            const thirtyDaysAgo = new Date(today);
            thirtyDaysAgo.setDate(today.getDate() - 30);
            startDate = thirtyDaysAgo.toISOString().split('T')[0];
            endDate = today.toISOString().split('T')[0];
            break;
    }
    
    if (startDate && endDate) {
        startDateInput.value = startDate;
        endDateInput.value = endDate;
        
        // Auto-submit the form
        startDateInput.form.submit();
    }
}
</script>
";

require_once __DIR__ . '/../includes/footer.php';
?>



<style>
.kpi-meta {
    color: rgba(255, 255, 255, 0.8);
    font-size: 0.85rem;
    font-weight: 500;
    margin-top: 0.5rem;
    display: flex;
    align-items: center;
}

.icon-circle {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, var(--primary-color), var(--primary-light));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.2rem;
    box-shadow: 0 4px 15px rgba(139, 79, 122, 0.3);
}

.btn-modern {
    text-align: left;
    padding: 1.5rem;
    height: auto;
    display: flex;
    align-items: center;
}

.btn-modern i {
    font-size: 1.5rem;
    min-width: 24px;
}

.btn-modern div {
    text-align: left;
}
</style>