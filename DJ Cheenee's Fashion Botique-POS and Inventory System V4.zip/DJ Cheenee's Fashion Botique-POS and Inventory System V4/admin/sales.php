<?php
/**
 * DJ Cheenee's Fashion Boutique - Sales Management
 */

$page_title = 'Sales Management - DJ Cheenee\'s Fashion Boutique';
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Sales', 'url' => '#']
];

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../classes/Sale.php';
require_once __DIR__ . '/../classes/Product.php';

SessionManager::requireAdmin();

$sale = new Sale();
$db = getDbConnection();

// Get filter parameters
$period = $_GET['period'] ?? '';
$start_date = $_GET['start_date'] ?? date('Y-m-d');
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$payment_method = $_GET['payment_method'] ?? '';
$cashier_id = $_GET['cashier_id'] ?? '';

// Handle period-based filtering
if ($period) {
    switch ($period) {
        case 'today':
            $start_date = $end_date = date('Y-m-d');
            break;
        case 'yesterday':
            $start_date = $end_date = date('Y-m-d', strtotime('-1 day'));
            break;
        case 'this_week':
            $start_date = date('Y-m-d', strtotime('monday this week'));
            $end_date = date('Y-m-d', strtotime('sunday this week'));
            break;
        case 'last_week':
            $start_date = date('Y-m-d', strtotime('monday last week'));
            $end_date = date('Y-m-d', strtotime('sunday last week'));
            break;
        case 'this_month':
            $start_date = date('Y-m-01');
            $end_date = date('Y-m-t');
            break;
        case 'last_month':
            $start_date = date('Y-m-01', strtotime('first day of last month'));
            $end_date = date('Y-m-t', strtotime('last day of last month'));
            break;
        case 'this_year':
            $start_date = date('Y-01-01');
            $end_date = date('Y-12-31');
            break;
        case 'last_30_days':
            $start_date = date('Y-m-d', strtotime('-30 days'));
            $end_date = date('Y-m-d');
            break;
    }
}

// Build query with filters
$query = "SELECT st.*, u.full_name as cashier_name, COUNT(sti.id) as item_count
          FROM sales_transactions st
          JOIN users u ON st.user_id = u.id
          LEFT JOIN sales_transaction_items sti ON st.id = sti.transaction_id
          WHERE DATE(st.created_at) BETWEEN :start_date AND :end_date";

$params = [
    ':start_date' => $start_date,
    ':end_date' => $end_date
];

if ($payment_method) {
    $query .= " AND st.payment_method = :payment_method";
    $params[':payment_method'] = $payment_method;
}

if ($cashier_id) {
    $query .= " AND st.user_id = :cashier_id";
    $params[':cashier_id'] = $cashier_id;
}

$query .= " GROUP BY st.id ORDER BY st.created_at DESC";

$stmt = $db->prepare($query);
foreach ($params as $param => $value) {
    $stmt->bindValue($param, $value);
}
$stmt->execute();
$sales_transactions = $stmt->fetchAll();

// Get summary statistics
$summary_query = "SELECT 
                    COUNT(*) as total_transactions,
                    SUM(total_amount) as total_revenue,
                    AVG(total_amount) as avg_transaction
                  FROM sales_transactions 
                  WHERE DATE(created_at) BETWEEN :start_date AND :end_date 
                  AND payment_status = 'completed'";

if ($payment_method) {
    $summary_query .= " AND payment_method = :payment_method";
}
if ($cashier_id) {
    $summary_query .= " AND user_id = :cashier_id";
}

$stmt = $db->prepare($summary_query);
foreach ($params as $param => $value) {
    $stmt->bindValue($param, $value);
}
$stmt->execute();
$summary = $stmt->fetch();

// Get total items sold
$items_query = "SELECT 
                    COALESCE(SUM(sti.quantity), 0) as total_items_sold
                FROM sales_transaction_items sti
                JOIN sales_transactions st ON sti.transaction_id = st.id
                WHERE DATE(st.created_at) BETWEEN :start_date AND :end_date 
                AND st.payment_status = 'completed'";

if ($payment_method) {
    $items_query .= " AND st.payment_method = :payment_method";
}
if ($cashier_id) {
    $items_query .= " AND st.user_id = :cashier_id";
}

$stmt = $db->prepare($items_query);
foreach ($params as $param => $value) {
    $stmt->bindValue($param, $value);
}
$stmt->execute();
$items_result = $stmt->fetch();

// Merge the results
$summary['total_items_sold'] = $items_result['total_items_sold'];

// Get all cashiers for filter
$cashiers_query = "SELECT id, full_name FROM users WHERE role = 'cashier' OR role = 'admin' ORDER BY full_name";
$stmt = $db->prepare($cashiers_query);
$stmt->execute();
$cashiers = $stmt->fetchAll();
?>

<div class="row mb-4">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h2 mb-2 gradient-text">
                    <i class="fas fa-cash-register me-3"></i>Sales Management
                </h1>
                <p class="text-muted mb-0">View and manage all sales transactions across your boutique</p>
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-outline-primary btn-modern" onclick="location.reload()">
                    <i class="fas fa-sync-alt me-2"></i>Refresh
                </button>
                <button class="btn btn-primary" onclick="exportSalesToCSV()">
                    <i class="fas fa-download me-2"></i>Export CSV
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Enhanced Summary Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="kpi-card kpi-card-floating" style="animation-delay: 0.1s;">
            <div class="kpi-icon">
                <i class="fas fa-money-bill-wave"></i>
            </div>
            <div class="kpi-value">₱<?php echo number_format($summary['total_revenue'] ?: 0, 2); ?></div>
            <div class="kpi-label">Total Revenue</div>
            <div class="kpi-meta">
                <i class="fas fa-chart-line me-1"></i>
                Revenue earned
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-3">
        <div class="kpi-card kpi-card-secondary kpi-card-floating" style="animation-delay: 0.2s;">
            <div class="kpi-icon">
                <i class="fas fa-receipt"></i>
            </div>
            <div class="kpi-value"><?php echo number_format($summary['total_transactions'] ?: 0); ?></div>
            <div class="kpi-label">Transactions</div>
            <div class="kpi-meta">
                <i class="fas fa-shopping-bag me-1"></i>
                Completed sales
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-3">
        <div class="kpi-card kpi-card-success kpi-card-floating" style="animation-delay: 0.3s;">
            <div class="kpi-icon">
                <i class="fas fa-calculator"></i>
            </div>
            <div class="kpi-value">₱<?php echo number_format($summary['avg_transaction'] ?: 0, 2); ?></div>
            <div class="kpi-label">Avg. Transaction</div>
            <div class="kpi-meta">
                <i class="fas fa-chart-bar me-1"></i>
                Per transaction
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-3">
        <div class="kpi-card kpi-card-warning kpi-card-floating" style="animation-delay: 0.4s;">
            <div class="kpi-icon">
                <i class="fas fa-boxes"></i>
            </div>
            <div class="kpi-value"><?php echo number_format($summary['total_items_sold'] ?: 0); ?></div>
            <div class="kpi-label">Items Sold</div>
            <div class="kpi-meta">
                <i class="fas fa-shopping-cart me-1"></i>
                Total quantity
            </div>
        </div>
    </div>

</div>

<!-- Enhanced Filters -->
<div class="card card-floating glass-effect mb-4">
    <div class="card-header">
        <div class="d-flex align-items-center">
            <div class="icon-circle me-3">
                <i class="fas fa-filter"></i>
            </div>
            <h5 class="mb-0 gradient-text">Filter Sales Data</h5>
        </div>
    </div>
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-2">
                <div class="form-floating">
                    <select class="form-select" id="period" name="period" onchange="handlePeriodChange(this.value)">
                        <option value="">Custom Range</option>
                        <option value="today" <?php echo $period === 'today' ? 'selected' : ''; ?>>Today</option>
                        <option value="yesterday" <?php echo $period === 'yesterday' ? 'selected' : ''; ?>>Yesterday</option>
                        <option value="this_week" <?php echo $period === 'this_week' ? 'selected' : ''; ?>>This Week</option>
                        <option value="last_week" <?php echo $period === 'last_week' ? 'selected' : ''; ?>>Last Week</option>
                        <option value="this_month" <?php echo $period === 'this_month' ? 'selected' : ''; ?>>This Month</option>
                        <option value="last_month" <?php echo $period === 'last_month' ? 'selected' : ''; ?>>Last Month</option>
                        <option value="last_30_days" <?php echo $period === 'last_30_days' ? 'selected' : ''; ?>>Last 30 Days</option>
                        <option value="this_year" <?php echo $period === 'this_year' ? 'selected' : ''; ?>>This Year</option>
                    </select>
                    <label for="period">
                        <i class="fas fa-clock me-2"></i>Quick Period
                    </label>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-floating">
                    <input type="date" class="form-control" id="start_date" name="start_date" 
                           value="<?php echo $start_date; ?>" placeholder="Start Date">
                    <label for="start_date">
                        <i class="fas fa-calendar-alt me-2"></i>Start Date
                    </label>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-floating">
                    <input type="date" class="form-control" id="end_date" name="end_date" 
                           value="<?php echo $end_date; ?>" placeholder="End Date">
                    <label for="end_date">
                        <i class="fas fa-calendar-check me-2"></i>End Date
                    </label>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-floating">
                    <select class="form-select" id="payment_method" name="payment_method">
                        <option value="">All Methods</option>
                        <option value="cash" <?php echo $payment_method === 'cash' ? 'selected' : ''; ?>>Cash</option>
                    </select>
                    <label for="payment_method">
                        <i class="fas fa-credit-card me-2"></i>Payment Method
                    </label>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-floating">
                    <select class="form-select" id="cashier_id" name="cashier_id">
                        <option value="">All Cashiers</option>
                        <?php foreach ($cashiers as $cashier): ?>
                            <option value="<?php echo $cashier['id']; ?>" 
                                    <?php echo $cashier_id == $cashier['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cashier['full_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <label for="cashier_id">
                        <i class="fas fa-user me-2"></i>Cashier
                    </label>
                </div>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-primary btn-lg w-100">
                    <i class="fas fa-filter me-2"></i>Filter
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Enhanced Sales Transactions Table -->
<div class="card glass-effect">
    <div class="card-header">
        <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center">
                <div class="icon-circle me-3">
                    <i class="fas fa-list"></i>
                </div>
                <h5 class="mb-0 gradient-text">Sales Transactions</h5>
            </div>
            <span class="badge badge-modern badge-primary">
                <i class="fas fa-receipt me-1"></i><?php echo count($sales_transactions); ?> transactions
            </span>
        </div>
    </div>
    <div class="card-body p-0">
        <?php if (empty($sales_transactions)): ?>
            <div class="text-center py-5">
                <div class="icon-circle-large mx-auto mb-4">
                    <i class="fas fa-receipt fa-3x"></i>
                </div>
                <h4 class="gradient-text mb-3">No transactions found</h4>
                <p class="text-muted mb-4">No sales transactions found for the selected criteria. Try adjusting your filters.</p>
                <a href="../cashier/pos.php" class="btn btn-primary btn-lg btn-modern">
                    <i class="fas fa-cash-register me-2"></i>Start New Sale
                </a>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Transaction #</th>
                            <th>Date & Time</th>
                            <th>Cashier</th>
                            <th>Customer</th>
                            <th class="text-center">Items</th>
                            <th>Payment</th>
                            <th class="text-end">Amount</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sales_transactions as $transaction): ?>
                            <tr>
                                <td>
                                    <div class="fw-bold"><?php echo htmlspecialchars($transaction['transaction_number']); ?></div>
                                    <small class="text-muted">#<?php echo $transaction['id']; ?></small>
                                </td>
                                <td>
                                    <div><?php echo date('M d, Y', strtotime($transaction['created_at'])); ?></div>
                                    <small class="text-muted"><?php echo date('h:i A', strtotime($transaction['created_at'])); ?></small>
                                </td>
                                <td>
                                    <div class="fw-bold"><?php echo htmlspecialchars($transaction['cashier_name']); ?></div>
                                </td>
                                <td>
                                    <?php if ($transaction['customer_name']): ?>
                                        <div class="fw-bold"><?php echo htmlspecialchars($transaction['customer_name']); ?></div>
                                    <?php else: ?>
                                        <span class="text-muted">Walk-in</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-primary"><?php echo $transaction['item_count']; ?> items</span>
                                </td>
                                <td>
                                    <span class="badge <?php 
                                        echo $transaction['payment_method'] === 'cash' ? 'bg-success' : 
                                             ($transaction['payment_method'] === 'card' ? 'bg-info' : 'bg-warning'); 
                                    ?>">
                                        <?php echo strtoupper($transaction['payment_method']); ?>
                                    </span>
                                </td>
                                <td class="text-end">
                                    <div class="fw-bold">₱<?php echo number_format($transaction['total_amount'], 2); ?></div>
                                    <?php if ($transaction['discount_amount'] > 0): ?>
                                        <small class="text-success">-₱<?php echo number_format($transaction['discount_amount'], 2); ?> discount</small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <span class="badge <?php 
                                        echo $transaction['payment_status'] === 'completed' ? 'badge-success' : 
                                             ($transaction['payment_status'] === 'pending' ? 'badge-warning' : 'badge-danger'); 
                                    ?>">
                                        <?php echo ucfirst($transaction['payment_status']); ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-outline-primary" 
                                            onclick="viewTransactionDetails(<?php echo $transaction['id']; ?>)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-secondary" 
                                            onclick="printReceipt(<?php echo $transaction['id']; ?>)">
                                        <i class="fas fa-print"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Transaction Details Modal -->
<div class="modal fade" id="transactionModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Transaction Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="transactionDetails">
                    <!-- Transaction details will be loaded here -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="printTransactionBtn">
                    <i class="fas fa-print me-2"></i>Print Receipt
                </button>
            </div>
        </div>
    </div>
</div>

<?php
$additional_js = "
<script>
let currentTransactionId = null;

async function viewTransactionDetails(transactionId) {
    currentTransactionId = transactionId;
    
    try {
        const response = await fetch('../api/get_transaction_details.php?id=' + transactionId);
        const data = await response.json();
        
        if (data.success) {
            const transaction = data.transaction;
            const items = data.items;
            
            const content = `
                <div class='row mb-4'>
                    <div class='col-md-6'>
                        <h6 class='fw-bold'>Transaction Information</h6>
                        <p><strong>Transaction #:</strong> \${transaction.transaction_number}</p>
                        <p><strong>Date:</strong> \${new Date(transaction.created_at).toLocaleString()}</p>
                        <p><strong>Cashier:</strong> \${transaction.cashier_name}</p>
                        <p><strong>Payment Method:</strong> \${transaction.payment_method.toUpperCase()}</p>
                        <p><strong>Status:</strong> <span class='badge badge-success'>\${transaction.payment_status.toUpperCase()}</span></p>
                    </div>
                    <div class='col-md-6'>
                        <h6 class='fw-bold'>Customer Information</h6>
                        <p><strong>Name:</strong> \${transaction.customer_name || 'Walk-in Customer'}</p>
                    </div>
                </div>
                
                <h6 class='fw-bold mb-3'>Items Purchased</h6>
                <div class='table-responsive mb-4'>
                    <table class='table table-sm'>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Variant</th>
                                <th>Barcode</th>
                                <th class='text-center'>Qty</th>
                                <th class='text-end'>Unit Price</th>
                                <th class='text-end'>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            \${items.map(item => `
                                <tr>
                                    <td>\${item.product_name}</td>
                                    <td>
                                        <span class='badge bg-secondary me-1'>\${item.size || 'N/A'}</span>
                                        <span class='badge bg-info'>\${item.color || 'N/A'}</span>
                                    </td>
                                    <td><code>\${item.barcode}</code></td>
                                    <td class='text-center'>\${item.quantity}</td>
                                    <td class='text-end'>₱\${parseFloat(item.unit_price).toFixed(2)}</td>
                                    <td class='text-end'>₱\${parseFloat(item.total_price).toFixed(2)}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
                
                <div class='row'>
                    <div class='col-md-6 offset-md-6'>
                        <table class='table table-sm'>
                            \${transaction.discount_amount > 0 ? `
                                <tr>
                                    <td><strong>Discount:</strong></td>
                                    <td class='text-end text-success'>-₱\${parseFloat(transaction.discount_amount).toFixed(2)}</td>
                                </tr>
                            ` : ''}
                            <tr class='table-primary'>
                                <td><strong>Total Amount:</strong></td>
                                <td class='text-end'><strong>₱\${parseFloat(transaction.total_amount).toFixed(2)}</strong></td>
                            </tr>
                        </table>
                    </div>
                </div>
            `;
            
            document.getElementById('transactionDetails').innerHTML = content;
            new bootstrap.Modal(document.getElementById('transactionModal')).show();
        } else {
            alert('Error loading transaction details: ' + data.error);
        }
    } catch (error) {
        alert('Error loading transaction details: ' + error.message);
    }
}

function printReceipt(transactionId) {
    const printWindow = window.open('../api/print_receipt.php?id=' + transactionId, '_blank');
    if (printWindow) {
        printWindow.focus();
    }
}

document.getElementById('printTransactionBtn').addEventListener('click', function() {
    if (currentTransactionId) {
        printReceipt(currentTransactionId);
    }
});

function exportSalesToCSV() {
    const urlParams = new URLSearchParams(window.location.search);
    const exportUrl = '../api/export_sales.php?' + urlParams.toString();
    window.location.href = exportUrl;
}

function handlePeriodChange(period) {
    const startDateInput = document.getElementById('start_date');
    const endDateInput = document.getElementById('end_date');
    
    if (!period) return; // Custom range selected
    
    const today = new Date();
    let startDate, endDate;
    
    switch (period) {
        case 'today':
            startDate = endDate = today.toISOString().split('T')[0];
            break;
        case 'yesterday':
            const yesterday = new Date(today);
            yesterday.setDate(today.getDate() - 1);
            startDate = endDate = yesterday.toISOString().split('T')[0];
            break;
        case 'this_week':
            const thisWeekStart = new Date(today);
            thisWeekStart.setDate(today.getDate() - today.getDay() + 1); // Monday
            const thisWeekEnd = new Date(thisWeekStart);
            thisWeekEnd.setDate(thisWeekStart.getDate() + 6); // Sunday
            startDate = thisWeekStart.toISOString().split('T')[0];
            endDate = thisWeekEnd.toISOString().split('T')[0];
            break;
        case 'last_week':
            const lastWeekStart = new Date(today);
            lastWeekStart.setDate(today.getDate() - today.getDay() - 6); // Last Monday
            const lastWeekEnd = new Date(lastWeekStart);
            lastWeekEnd.setDate(lastWeekStart.getDate() + 6); // Last Sunday
            startDate = lastWeekStart.toISOString().split('T')[0];
            endDate = lastWeekEnd.toISOString().split('T')[0];
            break;
        case 'this_month':
            startDate = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0];
            endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0).toISOString().split('T')[0];
            break;
        case 'last_month':
            startDate = new Date(today.getFullYear(), today.getMonth() - 1, 1).toISOString().split('T')[0];
            endDate = new Date(today.getFullYear(), today.getMonth(), 0).toISOString().split('T')[0];
            break;
        case 'this_year':
            startDate = new Date(today.getFullYear(), 0, 1).toISOString().split('T')[0];
            endDate = new Date(today.getFullYear(), 11, 31).toISOString().split('T')[0];
            break;
        case 'last_30_days':
            const thirtyDaysAgo = new Date(today);
            thirtyDaysAgo.setDate(today.getDate() - 30);
            startDate = thirtyDaysAgo.toISOString().split('T')[0];
            endDate = today.toISOString().split('T')[0];
            break;
    }
    
    if (startDate && endDate) {
        startDateInput.value = startDate;
        endDateInput.value = endDate;
        
        // Auto-submit the form
        startDateInput.form.submit();
    }
}

// Set default dates to today if not set
document.addEventListener('DOMContentLoaded', function() {
    const startDate = document.getElementById('start_date');
    const endDate = document.getElementById('end_date');
    
    if (!startDate.value) {
        startDate.value = new Date().toISOString().split('T')[0];
    }
    if (!endDate.value) {
        endDate.value = new Date().toISOString().split('T')[0];
    }
});
</script>
";

require_once __DIR__ . '/../includes/footer.php';
?>


<style>
.kpi-meta {
    color: rgba(255, 255, 255, 0.8);
    font-size: 0.85rem;
    font-weight: 500;
    margin-top: 0.5rem;
    display: flex;
    align-items: center;
}

.icon-circle {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, var(--primary-color), var(--primary-light));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.2rem;
    box-shadow: 0 4px 15px rgba(139, 79, 122, 0.3);
}

.btn-modern {
    text-align: left;
    padding: 1.5rem;
    height: auto;
    display: flex;
    align-items: center;
}

.btn-modern i {
    font-size: 1.5rem;
    min-width: 24px;
}

.btn-modern div {
    text-align: left;
}
</style>