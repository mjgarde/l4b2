<?php
/**
 * DJ Cheenee's Fashion Boutique - Admin Dashboard
 */

$page_title = 'Admin Dashboard - DJ Cheenee\'s Fashion Boutique';
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => '#']
];

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/database.php';

// Ensure admin access
SessionManager::requireAdmin();

// Get database connection
$db = getDbConnection();

// Fetch dashboard KPIs
$today = date('Y-m-d');
$thisMonth = date('Y-m');

// Today's Sales
$todaySalesQuery = "SELECT COUNT(*) as transactions, COALESCE(SUM(total_amount), 0) as total 
                    FROM sales_transactions 
                    WHERE DATE(created_at) = :today AND payment_status = 'completed'";
$stmt = $db->prepare($todaySalesQuery);
$stmt->bindParam(':today', $today);
$stmt->execute();
$todaysSales = $stmt->fetch();

// Total Revenue (This Month)
$monthRevenueQuery = "SELECT COALESCE(SUM(total_amount), 0) as revenue 
                      FROM sales_transactions 
                      WHERE DATE(created_at) LIKE :month AND payment_status = 'completed'";
$stmt = $db->prepare($monthRevenueQuery);
$monthPattern = $thisMonth . '%';
$stmt->bindParam(':month', $monthPattern);
$stmt->execute();
$monthRevenue = $stmt->fetch();

// Inventory Value
$inventoryQuery = "SELECT COALESCE(SUM(pv.price * pv.stock_quantity), 0) as value, 
                          COUNT(pv.id) as total_variants
                   FROM product_variants pv 
                   JOIN products p ON pv.product_id = p.id 
                   WHERE pv.is_active = 1 AND p.is_active = 1";
$stmt = $db->prepare($inventoryQuery);
$stmt->execute();
$inventory = $stmt->fetch();

// Low Stock Items
$lowStockQuery = "SELECT COUNT(*) as count 
                  FROM product_variants pv 
                  JOIN products p ON pv.product_id = p.id 
                  WHERE pv.stock_quantity <= pv.low_stock_threshold 
                  AND pv.is_active = 1 AND p.is_active = 1";
$stmt = $db->prepare($lowStockQuery);
$stmt->execute();
$lowStock = $stmt->fetch();

// Recent Sales for chart (last 7 days)
$salesChartQuery = "SELECT DATE(created_at) as date, 
                           COUNT(*) as transactions, 
                           COALESCE(SUM(total_amount), 0) as revenue
                    FROM sales_transactions 
                    WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                    AND payment_status = 'completed'
                    GROUP BY DATE(created_at)
                    ORDER BY date ASC";
$stmt = $db->prepare($salesChartQuery);
$stmt->execute();
$salesData = $stmt->fetchAll();

// Top Selling Products (This Month)
$topProductsQuery = "SELECT p.name, pv.size, pv.color, 
                            SUM(sti.quantity) as total_sold,
                            SUM(sti.total_price) as total_revenue
                     FROM sales_transaction_items sti
                     JOIN product_variants pv ON sti.product_variant_id = pv.id
                     JOIN products p ON pv.product_id = p.id
                     JOIN sales_transactions st ON sti.transaction_id = st.id
                     WHERE DATE(st.created_at) LIKE :month AND st.payment_status = 'completed'
                     GROUP BY pv.id
                     ORDER BY total_sold DESC
                     LIMIT 5";
$stmt = $db->prepare($topProductsQuery);
$stmt->bindParam(':month', $monthPattern);
$stmt->execute();
$topProducts = $stmt->fetchAll();

// Recent Low Stock Items
$recentLowStockQuery = "SELECT p.name, pv.size, pv.color, pv.stock_quantity, pv.low_stock_threshold
                        FROM product_variants pv 
                        JOIN products p ON pv.product_id = p.id 
                        WHERE pv.stock_quantity <= pv.low_stock_threshold 
                        AND pv.is_active = 1 AND p.is_active = 1
                        ORDER BY pv.stock_quantity ASC
                        LIMIT 10";
$stmt = $db->prepare($recentLowStockQuery);
$stmt->execute();
$lowStockItems = $stmt->fetchAll();

// Out of Stock Items - Fixed query for consistent results
$outOfStockQuery = "SELECT p.name, pv.size, pv.color, pv.stock_quantity, pv.id as variant_id
                    FROM product_variants pv 
                    JOIN products p ON pv.product_id = p.id 
                    WHERE pv.stock_quantity <= 0 
                    AND pv.is_active = 1 AND p.is_active = 1
                    ORDER BY p.name ASC, pv.size ASC, pv.color ASC
                    LIMIT 10";
$stmt = $db->prepare($outOfStockQuery);
$stmt->execute();
$outOfStockItems = $stmt->fetchAll();

// Debug: Log out of stock items count for troubleshooting
error_log("Dashboard - Out of stock items found: " . count($outOfStockItems));

// Recent Transactions
$recentTransactionsQuery = "SELECT st.id, st.transaction_number, st.total_amount, 
                                  st.created_at, st.payment_method, st.customer_name,
                                  u.full_name as cashier_name,
                                  COUNT(sti.id) as item_count
                           FROM sales_transactions st
                           JOIN users u ON st.user_id = u.id
                           LEFT JOIN sales_transaction_items sti ON st.id = sti.transaction_id
                           WHERE st.payment_status = 'completed'
                           GROUP BY st.id
                           ORDER BY st.created_at DESC
                           LIMIT 8";
$stmt = $db->prepare($recentTransactionsQuery);
$stmt->execute();
$recentTransactions = $stmt->fetchAll();

// Payment Method Breakdown (Today)
$paymentMethodQuery = "SELECT payment_method, 
                             COUNT(*) as transaction_count,
                             SUM(total_amount) as total_amount
                      FROM sales_transactions 
                      WHERE DATE(created_at) = :today 
                      AND payment_status = 'completed'
                      GROUP BY payment_method
                      ORDER BY total_amount DESC";
$stmt = $db->prepare($paymentMethodQuery);
$stmt->bindParam(':today', $today);
$stmt->execute();
$paymentMethods = $stmt->fetchAll();

// Customer Analytics
$customerStatsQuery = "SELECT 
                         COUNT(CASE WHEN customer_name IS NULL OR customer_name = '' THEN 1 END) as walkin_customers,
                         AVG(total_amount) as avg_order_value
                       FROM sales_transactions 
                       WHERE DATE(created_at) = :today 
                       AND payment_status = 'completed'";
$stmt = $db->prepare($customerStatsQuery);
$stmt->bindParam(':today', $today);
$stmt->execute();
$customerStats = $stmt->fetch();

// Staff Performance (Today)
$staffPerformanceQuery = "SELECT u.full_name, u.role,
                                COUNT(st.id) as transactions_today,
                                SUM(st.total_amount) as revenue_today
                         FROM users u
                         LEFT JOIN sales_transactions st ON u.id = st.user_id 
                                  AND DATE(st.created_at) = :today 
                                  AND st.payment_status = 'completed'
                         WHERE u.role IN ('cashier', 'admin')
                         GROUP BY u.id
                         ORDER BY revenue_today DESC";
$stmt = $db->prepare($staffPerformanceQuery);
$stmt->bindParam(':today', $today);
$stmt->execute();
$staffPerformance = $stmt->fetchAll();

// System Activities (Recent Actions)
$recentActivitiesQuery = "SELECT 'Transaction' as activity_type, 
                                CONCAT('New sale: ', transaction_number) as description,
                                created_at,
                                'success' as status
                         FROM sales_transactions 
                         WHERE created_at >= DATE_SUB(NOW(), INTERVAL 2 HOUR)
                         ORDER BY created_at DESC
                         LIMIT 5";
$stmt = $db->prepare($recentActivitiesQuery);
$stmt->execute();
$recentActivities = $stmt->fetchAll();
?>

<div class="row mb-4">
    <div class="col-12">
        <div class="d-flex align-items-center justify-content-between">
            <div>
                <h1 class="h2 mb-2 gradient-text">
                    <i class="fas fa-tachometer-alt me-3"></i>
                    Dashboard Overview
                </h1>
                <p class="text-muted mb-0">Welcome back, <strong><?php echo htmlspecialchars($current_user['full_name']); ?></strong>! Here's what's happening with your boutique today.</p>
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-outline-primary btn-modern" onclick="location.reload()">
                    <i class="fas fa-sync-alt me-2"></i>Refresh
                </button>
                <button class="btn btn-primary" onclick="window.location.href='../cashier/pos.php'">
                    <i class="fas fa-cash-register me-2"></i>Open POS
                </button>
            </div>
        </div>
    </div>
</div>

<style>
.gradient-text {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    font-weight: 700;
    font-family: 'Playfair Display', serif;
}
</style>

<!-- Enhanced KPI Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="kpi-card kpi-card-floating" style="animation-delay: 0.1s;">
            <div class="kpi-icon">
                <i class="fas fa-cash-register"></i>
            </div>
            <div class="kpi-value">₱<?php echo number_format($todaysSales['total'], 2); ?></div>
            <div class="kpi-label">Today's Sales</div>
            <div class="kpi-meta">
                <i class="fas fa-receipt me-1"></i>
                <?php echo $todaysSales['transactions']; ?> transactions
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="kpi-card kpi-card-secondary kpi-card-floating" style="animation-delay: 0.2s;">
            <div class="kpi-icon">
                <i class="fas fa-chart-line"></i>
            </div>
            <div class="kpi-value">₱<?php echo number_format($monthRevenue['revenue'], 2); ?></div>
            <div class="kpi-label">Monthly Revenue</div>
            <div class="kpi-meta">
                <i class="fas fa-calendar-alt me-1"></i>
                <?php echo date('F Y'); ?>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="kpi-card kpi-card-success kpi-card-floating" style="animation-delay: 0.3s;">
            <div class="kpi-icon">
                <i class="fas fa-boxes"></i>
            </div>
            <div class="kpi-value">₱<?php echo number_format($inventory['value'], 2); ?></div>
            <div class="kpi-label">Inventory Value</div>
            <div class="kpi-meta">
                <i class="fas fa-cubes me-1"></i>
                <?php echo number_format($inventory['total_variants']); ?> variants
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="kpi-card kpi-card-warning kpi-card-floating" style="animation-delay: 0.4s;">
            <div class="kpi-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <div class="kpi-value"><?php echo $lowStock['count']; ?></div>
            <div class="kpi-label">Low Stock Items</div>
            <div class="kpi-meta">
                <i class="fas fa-bell me-1"></i>
                Need attention
            </div>
        </div>
    </div>
</div>



<!-- Enhanced Quick Actions -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card card-elevated glass-effect">
            <div class="card-header">
                <div class="d-flex align-items-center">
                    <div class="icon-circle me-3">
                        <i class="fas fa-bolt"></i>
                    </div>
                    <h5 class="mb-0 gradient-text">Quick Actions</h5>
                </div>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-lg-3 col-md-6">
                        <a href="products.php?action=add" class="btn btn-lg btn-primary w-100 btn-modern">
                            <i class="fas fa-plus me-2"></i>
                            <div>
                                <div class="fw-bold">Add Product</div>
                                <small class="opacity-75">Create new items</small>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <a href="../cashier/pos.php" class="btn btn-lg btn-secondary w-100 btn-modern">
                            <i class="fas fa-cash-register me-2"></i>
                            <div>
                                <div class="fw-bold">Open POS</div>
                                <small class="opacity-75">Start selling</small>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <a href="inventory.php" class="btn btn-lg btn-outline-primary w-100 btn-modern">
                            <i class="fas fa-warehouse me-2"></i>
                            <div>
                                <div class="fw-bold">Inventory</div>
                                <small class="opacity-75">Manage stock</small>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <a href="reports.php" class="btn btn-lg btn-outline-secondary w-100 btn-modern">
                            <i class="fas fa-chart-bar me-2"></i>
                            <div>
                                <div class="fw-bold">Reports</div>
                                <small class="opacity-75">View analytics</small>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Charts & Analytics -->
<div class="row mb-4">
    <!-- Sales Trend Chart -->
    <div class="col-xl-8 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-area me-2"></i>Sales Trend (Last 7 Days)
                </h5>
            </div>
            <div class="card-body">
                <canvas id="salesTrendChart" width="400" height="200"></canvas>
            </div>
        </div>
    </div>

    <!-- Top Products -->
    <div class="col-xl-4 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-star me-2"></i>Top Selling Products
                </h5>
            </div>
            <div class="card-body">
                <?php if (!empty($topProducts)): ?>
                    <?php foreach ($topProducts as $index => $product): ?>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <div class="fw-bold"><?php echo htmlspecialchars($product['name']); ?></div>
                                <small class="text-muted">
                                    <?php echo htmlspecialchars($product['size'] . ' - ' . $product['color']); ?>
                                </small>
                            </div>
                            <div class="text-end">
                                <div class="fw-bold text-primary"><?php echo $product['total_sold']; ?> sold</div>
                                <small class="text-muted">₱<?php echo number_format($product['total_revenue'], 2); ?></small>
                            </div>
                        </div>
                        <?php if ($index < count($topProducts) - 1): ?>
                            <hr class="my-2">
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-muted text-center">No sales data available for this month.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Low Stock Alerts -->
<?php if (!empty($lowStockItems)): ?>
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0">
                    <i class="fas fa-exclamation-triangle me-2"></i>Low Stock Alerts
                </h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Variant</th>
                                <th>Current Stock</th>
                                <th>Threshold</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($lowStockItems as $item): ?>
                                <tr>
                                    <td>
                                        <div class="fw-bold"><?php echo htmlspecialchars($item['name']); ?></div>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary">
                                            <?php echo htmlspecialchars($item['size'] . ' - ' . $item['color']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge badge-danger"><?php echo $item['stock_quantity']; ?></span>
                                    </td>
                                    <td><?php echo $item['low_stock_threshold']; ?></td>
                                    <td>
                                        <a href="inventory.php?search=<?php echo urlencode($item['name']); ?>" 
                                           class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-edit me-1"></i>Update Stock
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Out of Stock Alert -->
<?php if (!empty($outOfStockItems) && count($outOfStockItems) > 0): ?>
<div class="row mb-4">
    <div class="col-12">
        <div class="card card-elevated">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0">
                    <i class="fas fa-times-circle me-2"></i>Out of Stock Alert
                    <span class="badge bg-white text-danger ms-2"><?php echo count($outOfStockItems); ?> items</span>
                </h5>
            </div>
            <div class="card-body">
                <?php if (count($outOfStockItems) > 0): ?>
                    <div class="row">
                        <?php foreach ($outOfStockItems as $index => $item): ?>
                            <?php if (isset($item['name']) && !empty($item['name'])): ?>
                                <div class="col-md-6 col-lg-4 mb-3">
                                    <div class="alert alert-danger alert-permanent mb-0">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <div class="fw-bold"><?php echo htmlspecialchars($item['name']); ?></div>
                                                <small><?php echo htmlspecialchars(($item['size'] ?? 'N/A') . ' - ' . ($item['color'] ?? 'N/A')); ?></small>
                                                <br><small class="text-muted">Stock: <?php echo intval($item['stock_quantity']); ?></small>
                                            </div>
                                            <div>
                                                <a href="inventory.php?search=<?php echo urlencode($item['name']); ?>" 
                                                   class="btn btn-sm btn-outline-danger">
                                                    <i class="fas fa-plus me-1"></i>Restock
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-3">
                        <i class="fas fa-check-circle fa-2x text-success mb-2"></i>
                        <p class="text-muted mb-0">All items are currently in stock!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Additional Dashboard Widgets -->
<div class="row mb-4">
    <!-- Recent Transactions -->
    <div class="col-xl-4 mb-4">
        <div class="card card-elevated">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-receipt me-2"></i>Recent Transactions
                </h5>
            </div>
            <div class="card-body p-0">
                <?php if (!empty($recentTransactions)): ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($recentTransactions as $transaction): ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div class="flex-grow-1">
                                        <div class="d-flex justify-content-between">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($transaction['transaction_number']); ?></h6>
                                            <small class="text-muted"><?php echo date('H:i', strtotime($transaction['created_at'])); ?></small>
                                        </div>
                                        <p class="mb-1 text-muted small">
                                            <?php echo htmlspecialchars($transaction['customer_name'] ?: 'Walk-in'); ?> • 
                                            <?php echo $transaction['item_count']; ?> items
                                        </p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="badge <?php 
                                                echo $transaction['payment_method'] === 'cash' ? 'bg-success' : 
                                                     ($transaction['payment_method'] === 'card' ? 'bg-info' : 'bg-warning'); 
                                            ?> text-uppercase">
                                                <?php echo $transaction['payment_method']; ?>
                                            </span>
                                            <strong class="text-primary">₱<?php echo number_format($transaction['total_amount'], 2); ?></strong>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-receipt fa-2x text-muted mb-2"></i>
                        <p class="text-muted mb-0">No recent transactions</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Payment Methods Breakdown -->
    <div class="col-xl-4 mb-4">
        <div class="card card-elevated">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-credit-card me-2"></i>Payment Methods Today
                </h5>
            </div>
            <div class="card-body">
                <?php if (!empty($paymentMethods)): ?>
                    <?php foreach ($paymentMethods as $method): ?>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div class="d-flex align-items-center">
                                <div class="icon-circle me-3" style="background: <?php 
                                    echo $method['payment_method'] === 'cash' ? 'linear-gradient(135deg, #4CAF50, #66BB6A)' : 
                                         ($method['payment_method'] === 'card' ? 'linear-gradient(135deg, #2196F3, #42A5F5)' : 
                                          'linear-gradient(135deg, #FF9800, #FFB74D)'); 
                                ?>;">
                                    <i class="fas <?php 
                                        echo $method['payment_method'] === 'cash' ? 'fa-money-bill-wave' : 
                                             ($method['payment_method'] === 'card' ? 'fa-credit-card' : 'fa-mobile-alt'); 
                                    ?> text-white"></i>
                                </div>
                                <div>
                                    <div class="fw-bold text-capitalize"><?php echo str_replace('_', ' ', $method['payment_method']); ?></div>
                                    <small class="text-muted"><?php echo $method['transaction_count']; ?> transactions</small>
                                </div>
                            </div>
                            <div class="text-end">
                                <div class="fw-bold text-primary">₱<?php echo number_format($method['total_amount'], 2); ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-credit-card fa-2x text-muted mb-2"></i>
                        <p class="text-muted mb-0">No transactions today</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Customer Analytics -->
    <div class="col-xl-4 mb-4">
        <div class="card card-elevated">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-users me-2"></i>Customer Analytics
                </h5>
            </div>
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-12 mb-3">
                        <div class="icon-circle mx-auto mb-2" style="background: linear-gradient(135deg, var(--secondary-color), var(--secondary-light));">
                            <i class="fas fa-user text-white"></i>
                        </div>
                        <div class="fw-bold fs-4"><?php echo $customerStats['walkin_customers'] ?: 0; ?></div>
                        <small class="text-muted">Walk-in</small>
                    </div>
                </div>
                <div class="text-center border-top pt-3">
                    <div class="fw-bold text-primary fs-5">₱<?php echo number_format($customerStats['avg_order_value'] ?: 0, 2); ?></div>
                    <small class="text-muted">Average Order Value</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Staff Performance & System Activity -->
<div class="row mb-4">
    <!-- Staff Performance -->
    <div class="col-xl-6 mb-4">
        <div class="card card-elevated">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-user-tie me-2"></i>Staff Performance Today
                </h5>
            </div>
            <div class="card-body">
                <?php if (!empty($staffPerformance)): ?>
                    <div class="table-responsive">
                        <table class="table table-sm mb-0">
                            <thead>
                                <tr>
                                    <th>Staff Member</th>
                                    <th class="text-center">Transactions</th>
                                    <th class="text-end">Revenue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($staffPerformance as $staff): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="icon-circle me-2" style="background: linear-gradient(135deg, var(--accent-color), var(--accent-light));">
                                                    <i class="fas fa-user text-white"></i>
                                                </div>
                                                <div>
                                                    <div class="fw-bold"><?php echo htmlspecialchars($staff['full_name']); ?></div>
                                                    <small class="text-muted text-capitalize"><?php echo $staff['role']; ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-primary"><?php echo $staff['transactions_today'] ?: 0; ?></span>
                                        </td>
                                        <td class="text-end">
                                            <div class="fw-bold text-success">₱<?php echo number_format($staff['revenue_today'] ?: 0, 2); ?></div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-user-tie fa-2x text-muted mb-2"></i>
                        <p class="text-muted mb-0">No staff activity today</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Recent System Activity -->
    <div class="col-xl-6 mb-4">
        <div class="card card-elevated">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-clock me-2"></i>Recent Activity
                </h5>
            </div>
            <div class="card-body">
                <?php if (!empty($recentActivities)): ?>
                    <div class="timeline">
                        <?php foreach ($recentActivities as $activity): ?>
                            <div class="timeline-item">
                                <div class="timeline-marker bg-success"></div>
                                <div class="timeline-content">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <div class="fw-bold"><?php echo htmlspecialchars($activity['description']); ?></div>
                                            <small class="text-muted">
                                                <?php echo date('g:i A', strtotime($activity['created_at'])); ?>
                                            </small>
                                        </div>
                                        <span class="badge badge-success badge-modern">Success</span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-clock fa-2x text-muted mb-2"></i>
                        <p class="text-muted mb-0">No recent activity</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<?php
$additional_js = "
<script>
// Sales Trend Chart
const salesData = " . json_encode($salesData) . ";
const ctx = document.getElementById('salesTrendChart').getContext('2d');

// Prepare chart data
const dates = [];
const revenues = [];
const transactions = [];

// Fill in missing days with 0 values
const today = new Date();
for (let i = 6; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    const dateStr = date.toISOString().split('T')[0];
    
    const found = salesData.find(item => item.date === dateStr);
    dates.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
    revenues.push(found ? parseFloat(found.revenue) : 0);
    transactions.push(found ? parseInt(found.transactions) : 0);
}

new Chart(ctx, {
    type: 'line',
    data: {
        labels: dates,
        datasets: [{
            label: 'Revenue (₱)',
            data: revenues,
            borderColor: 'rgb(139, 79, 122)',
            backgroundColor: 'rgba(139, 79, 122, 0.1)',
            tension: 0.1,
            fill: true
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: true,
                position: 'top'
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return '₱' + value.toLocaleString();
                    }
                }
            }
        }
    }
});
</script>
";

require_once __DIR__ . '/../includes/footer.php';
?>


<style>
.kpi-meta {
    color: rgba(255, 255, 255, 0.8);
    font-size: 0.85rem;
    font-weight: 500;
    margin-top: 0.5rem;
    display: flex;
    align-items: center;
}

.icon-circle {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, var(--primary-color), var(--primary-light));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.2rem;
    box-shadow: 0 4px 15px rgba(139, 79, 122, 0.3);
}

.btn-modern {
    text-align: left;
    padding: 1.5rem;
    height: auto;
    display: flex;
    align-items: center;
}

.btn-modern i {
    font-size: 1.5rem;
    min-width: 24px;
}

.btn-modern div {
    text-align: left;
}
</style>