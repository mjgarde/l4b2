<?php
/**
 * DJ Cheenee's Fashion Boutique - Inventory Management
 */

$page_title = 'Inventory Management - DJ Cheenee\'s Fashion Boutique';
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Inventory', 'url' => '#']
];

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../classes/Product.php';

SessionManager::requireAdmin();

$product = new Product();
$db = getDbConnection();

// Handle minimum stock threshold update
if ($_POST && isset($_POST['action']) && $_POST['action'] === 'update_min_stock') {
    $variant_id = $_POST['variant_id'];
    $min_stock = $_POST['min_stock'];
    
    try {
        $update_query = "UPDATE product_variants SET low_stock_threshold = :min_stock WHERE id = :id";
        $stmt = $db->prepare($update_query);
        $stmt->bindParam(':min_stock', $min_stock);
        $stmt->bindParam(':id', $variant_id);
        $stmt->execute();
        
        $success_message = 'Minimum stock threshold updated successfully!';
    } catch (Exception $e) {
        $error_message = 'Error updating minimum stock: ' . $e->getMessage();
    }
}

// Handle stock update
if ($_POST && isset($_POST['action']) && $_POST['action'] === 'update_stock') {
    $variant_id = $_POST['variant_id'];
    $new_stock = $_POST['new_stock'];
    $notes = $_POST['notes'] ?? '';
    
    try {
        $db->beginTransaction();
        
        // Get current stock
        $current_query = "SELECT stock_quantity FROM product_variants WHERE id = :id";
        $stmt = $db->prepare($current_query);
        $stmt->bindParam(':id', $variant_id);
        $stmt->execute();
        $current_stock = $stmt->fetchColumn();
        
        // Update stock
        $update_query = "UPDATE product_variants SET stock_quantity = :stock WHERE id = :id";
        $stmt = $db->prepare($update_query);
        $stmt->bindParam(':stock', $new_stock);
        $stmt->bindParam(':id', $variant_id);
        $stmt->execute();
        
        // Record stock movement
        $movement_type = $new_stock > $current_stock ? 'in' : 'out';
        $quantity = abs($new_stock - $current_stock);
        
        if ($quantity > 0) {
            $movement_query = "INSERT INTO stock_movements 
                               (product_variant_id, movement_type, quantity, reference_type, notes, user_id) 
                               VALUES (:variant_id, :movement_type, :quantity, 'adjustment', :notes, :user_id)";
            $stmt = $db->prepare($movement_query);
            $stmt->bindParam(':variant_id', $variant_id);
            $stmt->bindParam(':movement_type', $movement_type);
            $stmt->bindParam(':quantity', $quantity);
            $stmt->bindParam(':notes', $notes);
            $stmt->bindParam(':user_id', $current_user['id']);
            $stmt->execute();
        }
        
        $db->commit();
        $success_message = 'Stock updated successfully!';
    } catch (Exception $e) {
        $db->rollback();
        $error_message = 'Error updating stock: ' . $e->getMessage();
    }
}

// Get search parameters
$search = $_GET['search'] ?? '';
$category_filter = $_GET['category'] ?? '';
$stock_filter = $_GET['stock_status'] ?? '';

// Build inventory query
$query = "SELECT p.id, p.name as product_name, p.image_url, c.name as category_name, b.name as brand_name,
                 pv.id as variant_id, pv.barcode, pv.size, pv.color, pv.price, pv.cost_price,
                 pv.stock_quantity, pv.low_stock_threshold, pv.updated_at
          FROM products p
          JOIN product_variants pv ON p.id = pv.product_id
          LEFT JOIN categories c ON p.category_id = c.id
          LEFT JOIN brands b ON p.brand_id = b.id
          WHERE p.is_active = 1 AND pv.is_active = 1";

$params = [];

if ($search) {
    $query .= " AND (p.name LIKE :search OR pv.barcode LIKE :search)";
    $params[':search'] = '%' . $search . '%';
}

if ($category_filter) {
    $query .= " AND p.category_id = :category";
    $params[':category'] = $category_filter;
}

if ($stock_filter === 'low') {
    $query .= " AND pv.stock_quantity <= pv.low_stock_threshold";
} elseif ($stock_filter === 'out') {
    $query .= " AND pv.stock_quantity = 0";
} elseif ($stock_filter === 'in') {
    $query .= " AND pv.stock_quantity > pv.low_stock_threshold";
}

$query .= " ORDER BY p.name, pv.size, pv.color";

$stmt = $db->prepare($query);
foreach ($params as $param => $value) {
    $stmt->bindValue($param, $value);
}
$stmt->execute();
$inventory_items = $stmt->fetchAll();

// Get categories for filter
$categories = $product->getAllCategories();
?>

<div class="row mb-4">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h2 mb-2 gradient-text">
                    <i class="fas fa-warehouse me-3"></i>Inventory Management
                </h1>
                <p class="text-muted mb-0">Manage stock levels and track inventory movements across your boutique</p>
            </div>
            <div class="d-flex gap-2">
                <button id="printSelectedBtn" class="btn btn-outline-secondary btn-modern" onclick="printSelectedBarcodes()" style="display: none;">
                    <i class="fas fa-print me-2"></i>Print Barcodes
                </button>
                <button class="btn btn-outline-primary btn-modern" onclick="location.reload()">
                    <i class="fas fa-sync-alt me-2"></i>Refresh
                </button>
                <a href="products.php" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Add Product
                </a>
            </div>
        </div>
    </div>
</div>

<?php if (isset($success_message)): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i><?php echo $success_message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if (isset($error_message)): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error_message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Enhanced Filters -->
<div class="card card-floating glass-effect mb-4">
    <div class="card-header">
        <div class="d-flex align-items-center">
            <div class="icon-circle me-3">
                <i class="fas fa-filter"></i>
            </div>
            <h5 class="mb-0 gradient-text">Filter Inventory</h5>
        </div>
    </div>
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-4">
                <div class="form-floating">
                    <input type="text" class="form-control" id="search" name="search" 
                           placeholder="Product name or barcode..." value="<?php echo htmlspecialchars($search); ?>">
                    <label for="search">
                        <i class="fas fa-search me-2"></i>Search Products
                    </label>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-floating">
                    <select class="form-select" id="category" name="category">
                        <option value="">All Categories</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo $category['id']; ?>" 
                                    <?php echo $category_filter == $category['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($category['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <label for="category">
                        <i class="fas fa-tag me-2"></i>Category
                    </label>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-floating">
                    <select class="form-select" id="stock_status" name="stock_status">
                        <option value="">All Items</option>
                        <option value="in" <?php echo $stock_filter === 'in' ? 'selected' : ''; ?>>In Stock</option>
                        <option value="low" <?php echo $stock_filter === 'low' ? 'selected' : ''; ?>>Low Stock</option>
                        <option value="out" <?php echo $stock_filter === 'out' ? 'selected' : ''; ?>>Out of Stock</option>
                    </select>
                    <label for="stock_status">
                        <i class="fas fa-boxes me-2"></i>Stock Status
                    </label>
                </div>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-primary btn-lg w-100">
                    <i class="fas fa-search me-2"></i>Filter
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Enhanced Inventory Table -->
<div class="card glass-effect">
    <div class="card-header">
        <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center">
                <div class="icon-circle me-3">
                    <i class="fas fa-list"></i>
                </div>
                <h5 class="mb-0 gradient-text">Inventory Items</h5>
            </div>
            <span class="badge badge-modern badge-primary">
                <i class="fas fa-cubes me-1"></i><?php echo count($inventory_items); ?> items
            </span>
        </div>
    </div>
    <div class="card-body p-0">
        <?php if (empty($inventory_items)): ?>
            <div class="text-center py-5">
                <div class="icon-circle-large mx-auto mb-4">
                    <i class="fas fa-box-open fa-3x"></i>
                </div>
                <h4 class="gradient-text mb-3">No inventory items found</h4>
                <p class="text-muted mb-4">Try adjusting your search filters or add some products to get started.</p>
                <a href="products.php" class="btn btn-primary btn-lg btn-modern">
                    <i class="fas fa-plus me-2"></i>Add First Product
                </a>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Variant</th>
                            <th>Barcode</th>
                            <th class="text-end">Price</th>
                            <th class="text-center">Stock</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">
                                Actions
                                <div class="form-check form-check-inline ms-2">
                                    <input class="form-check-input" type="checkbox" id="selectAll" onchange="toggleSelectAll()">
                                    <label class="form-check-label small" for="selectAll">All</label>
                                </div>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($inventory_items as $item): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="form-check me-2">
                                            <input class="form-check-input item-checkbox" type="checkbox" 
                                                   value="<?php echo $item['variant_id']; ?>"
                                                   data-barcode="<?php echo htmlspecialchars($item['barcode']); ?>">
                                        </div>
                                        <div class="flex-shrink-0 me-3">
                                            <?php if ($item['image_url']): ?>
                                                <img src="<?php echo htmlspecialchars($item['image_url']); ?>" 
                                                     class="rounded" width="50" height="50" 
                                                     style="object-fit: cover;">
                                            <?php else: ?>
                                                <div class="bg-light rounded d-flex align-items-center justify-content-center" 
                                                     style="width: 50px; height: 50px;">
                                                    <i class="fas fa-tshirt text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div>
                                            <div class="fw-bold"><?php echo htmlspecialchars($item['product_name']); ?></div>
                                            <small class="text-muted"><?php echo htmlspecialchars($item['category_name']); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <span class="badge bg-secondary me-1"><?php echo htmlspecialchars($item['size'] ?: 'N/A'); ?></span>
                                        <span class="badge bg-info"><?php echo htmlspecialchars($item['color'] ?: 'N/A'); ?></span>
                                    </div>
                                </td>
                                <td>
                                    <code><?php echo htmlspecialchars($item['barcode']); ?></code>
                                </td>
                                <td class="text-end">
                                    <div class="fw-bold">₱<?php echo number_format($item['price'], 2); ?></div>
                                    <?php if ($item['cost_price'] > 0): ?>
                                        <small class="text-muted">Cost: ₱<?php echo number_format($item['cost_price'], 2); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <div class="fw-bold"><?php echo $item['stock_quantity']; ?></div>
                                    <small class="text-muted">Min: <?php echo $item['low_stock_threshold']; ?></small>
                                </td>
                                <td class="text-center">
                                    <?php
                                    if ($item['stock_quantity'] == 0) {
                                        echo '<span class="badge badge-danger">Out of Stock</span>';
                                    } elseif ($item['stock_quantity'] <= $item['low_stock_threshold']) {
                                        echo '<span class="badge badge-warning">Low Stock</span>';
                                    } else {
                                        echo '<span class="badge badge-success">In Stock</span>';
                                    }
                                    ?>
                                </td>
                                <td class="text-center">
                                    <div class="btn-group" role="group">
                                        <button class="btn btn-sm btn-outline-primary" 
                                                onclick="showStockModal(<?php echo $item['variant_id']; ?>, '<?php echo addslashes($item['product_name'] . ' - ' . $item['size'] . ' - ' . $item['color']); ?>', <?php echo $item['stock_quantity']; ?>)"
                                                title="Edit Stock">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-warning" 
                                                onclick="showMinStockModal(<?php echo $item['variant_id']; ?>, '<?php echo addslashes($item['product_name'] . ' - ' . $item['size'] . ' - ' . $item['color']); ?>', <?php echo $item['low_stock_threshold']; ?>)"
                                                title="Set Minimum Stock">
                                            <i class="fas fa-exclamation-triangle"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-secondary" 
                                                onclick="printBarcode(<?php echo $item['variant_id']; ?>, '<?php echo addslashes($item['barcode']); ?>')"
                                                title="Print Barcode">
                                            <i class="fas fa-print"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Stock Update Modal -->
<div class="modal fade" id="stockModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="action" value="update_stock">
                <input type="hidden" name="variant_id" id="modal_variant_id">
                
                <div class="modal-header">
                    <h5 class="modal-title">Update Stock</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold" id="modal_product_name"></label>
                    </div>
                    
                    <div class="mb-3">
                        <label for="current_stock" class="form-label">Current Stock</label>
                        <input type="number" class="form-control" id="current_stock" readonly>
                    </div>
                    
                    <div class="mb-3">
                        <label for="new_stock" class="form-label">New Stock Quantity</label>
                        <input type="number" class="form-control" name="new_stock" id="new_stock" min="0" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="notes" class="form-label">Notes (Optional)</label>
                        <textarea class="form-control" name="notes" id="notes" rows="3" 
                                  placeholder="Reason for stock adjustment..."></textarea>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Update Stock
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Minimum Stock Modal -->
<div class="modal fade" id="minStockModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="action" value="update_min_stock">
                <input type="hidden" name="variant_id" id="min_modal_variant_id">
                
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-exclamation-triangle me-2 text-warning"></i>Set Minimum Stock Alert
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold" id="min_modal_product_name"></label>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Low Stock Alert:</strong> You will receive notifications when stock falls below this threshold.
                    </div>
                    
                    <div class="mb-3">
                        <label for="current_min_stock" class="form-label">Current Minimum Stock</label>
                        <input type="number" class="form-control" id="current_min_stock" readonly>
                    </div>
                    
                    <div class="mb-3">
                        <label for="min_stock" class="form-label">New Minimum Stock Threshold</label>
                        <input type="number" class="form-control" name="min_stock" id="min_stock" min="0" required>
                        <div class="form-text">Set the minimum stock level that triggers low stock alerts.</div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">
                        <i class="fas fa-save me-2"></i>Update Minimum Stock
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$additional_js = "
<script>
function showStockModal(variantId, productName, currentStock) {
    document.getElementById('modal_variant_id').value = variantId;
    document.getElementById('modal_product_name').textContent = productName;
    document.getElementById('current_stock').value = currentStock;
    document.getElementById('new_stock').value = currentStock;
    document.getElementById('notes').value = '';
    
    new bootstrap.Modal(document.getElementById('stockModal')).show();
    
    // Focus on new stock input
    setTimeout(() => {
        document.getElementById('new_stock').focus();
        document.getElementById('new_stock').select();
    }, 300);
}

function showMinStockModal(variantId, productName, currentMinStock) {
    document.getElementById('min_modal_variant_id').value = variantId;
    document.getElementById('min_modal_product_name').textContent = productName;
    document.getElementById('current_min_stock').value = currentMinStock;
    document.getElementById('min_stock').value = currentMinStock;
    
    new bootstrap.Modal(document.getElementById('minStockModal')).show();
    
    // Focus on minimum stock input
    setTimeout(() => {
        document.getElementById('min_stock').focus();
        document.getElementById('min_stock').select();
    }, 300);
}

function printBarcode(variantId, barcode) {
    // Open barcode printing window
    const printWindow = window.open(
        '../api/print_barcode.php?variant_id=' + variantId + '&autoprint=1',
        'barcode_print',
        'width=800,height=600,scrollbars=yes,resizable=yes'
    );
    
    if (printWindow) {
        printWindow.focus();
    } else {
        alert('Please allow pop-ups to print barcodes.');
    }
}

function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.item-checkbox');
    const printBtn = document.getElementById('printSelectedBtn');
    
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAll.checked;
    });
    
    updatePrintButtonVisibility();
}

function updatePrintButtonVisibility() {
    const checkedBoxes = document.querySelectorAll('.item-checkbox:checked');
    const printBtn = document.getElementById('printSelectedBtn');
    
    if (checkedBoxes.length > 0) {
        printBtn.style.display = 'inline-block';
        printBtn.innerHTML = '<i class=\"fas fa-print me-2\"></i>Print Selected Barcodes (' + checkedBoxes.length + ')';
    } else {
        printBtn.style.display = 'none';
    }
}

function printSelectedBarcodes() {
    const checkedBoxes = document.querySelectorAll('.item-checkbox:checked');
    
    if (checkedBoxes.length === 0) {
        alert('Please select at least one item to print barcodes.');
        return;
    }
    
    // Collect variant IDs
    const variantIds = Array.from(checkedBoxes).map(cb => cb.value);
    
    // Open print window with multiple barcodes
    const printWindow = window.open(
        '../api/print_multiple_barcodes.php?variant_ids=' + variantIds.join(',') + '&autoprint=1',
        'barcode_print_multiple',
        'width=800,height=600,scrollbars=yes,resizable=yes'
    );
    
    if (printWindow) {
        printWindow.focus();
    } else {
        alert('Please allow pop-ups to print barcodes.');
    }
}

// Add event listeners for checkboxes and floating labels
document.addEventListener('DOMContentLoaded', function() {
    const checkboxes = document.querySelectorAll('.item-checkbox');
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updatePrintButtonVisibility);
    });
    
    // Handle floating labels for select elements
    const selectElements = document.querySelectorAll('.form-floating .form-select');
    selectElements.forEach(select => {
        // Set initial state
        updateSelectLabel(select);
        
        // Update on change
        select.addEventListener('change', function() {
            updateSelectLabel(this);
        });
    });
});

function updateSelectLabel(selectElement) {
    const label = selectElement.nextElementSibling;
    if (label && label.tagName === 'LABEL') {
        if (selectElement.value && selectElement.value !== '') {
            label.classList.add('active');
        } else {
            label.classList.remove('active');
        }
    }
}
</script>
";

require_once __DIR__ . '/../includes/footer.php';
?>
