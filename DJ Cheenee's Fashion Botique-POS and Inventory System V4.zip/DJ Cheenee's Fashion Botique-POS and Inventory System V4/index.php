<?php
/**
 * DJ Cheenee's Fashion Boutique - Main Index Page
 * Redirects to appropriate page based on login status
 */

require_once 'config/session.php';

// Check if user is logged in
if (SessionManager::isLoggedIn()) {
    // Redirect based on role
    SessionManager::redirectByRole();
} else {
    // Redirect to login page
    header('Location: login.php');
    exit();
}
?>
