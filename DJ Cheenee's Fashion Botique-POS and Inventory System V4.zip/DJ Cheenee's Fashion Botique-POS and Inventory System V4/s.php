<?php

$host = "localhost";
$user = "root";
$pass = "";
$db   = "pos";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username  = $_POST['username'];
    $password  = $_POST['password'];
    $full_name = $_POST['full_name'];
    $email     = $_POST['email'];
    $role      = $_POST['role'];

    // hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (username, password, full_name, email, role)
            VALUES ('$username', '$hashed_password', '$full_name', '$email', '$role')";

    if ($conn->query($sql) === TRUE) {
        $message = "User created successfully!";
    } else {
        $message = "Error: " . $conn->error;
    }
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Create Account</title>
</head>
<body>

<h2>Create User</h2>

<?php echo $message; ?>

<form method="POST">

Username:<br>
<input type="text" name="username" required>
<br><br>

Password:<br>
<input type="password" name="password" required>
<br><br>

Full Name:<br>
<input type="text" name="full_name" required>
<br><br>

Email:<br>
<input type="email" name="email">
<br><br>

Role:<br>
<select name="role">
<option value="cashier">Cashier</option>
<option value="admin">Admin</option>
</select>

<br><br>

<button type="submit">Create Account</button>

</form>

</body>
</html>
