<?php
/**
 * DJ Cheenee's Fashion Boutique - Point of Sale (POS) System
 */

$page_title = 'Point of Sale - DJ Cheenee\'s Fashion Boutique';
$breadcrumbs = [
    ['name' => 'POS', 'url' => '#']
];

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../classes/Product.php';
require_once __DIR__ . '/../classes/Sale.php';

$product = new Product();
$sale = new Sale();

// Get categories for filter
$categories = $product->getAllCategories();

// Get today's sales for current user
$todaysSales = $sale->getTodaysSales($current_user['id']);
?>

<div class="row">
    <!-- Left Panel - Product Search & Grid -->
    <div class="col-xl-8 col-lg-7">
        <!-- Enhanced Search & Scanner -->
        <div class="card glass-effect mb-4">
            <div class="card-header">
                <div class="d-flex align-items-center">
                    <div class="icon-circle me-3">
                        <i class="fas fa-search"></i>
                    </div>
                    <h5 class="mb-0 gradient-text">Product Search</h5>
                </div>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-8">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="barcodeInput" 
                                   placeholder="Scan barcode or type product name..." autofocus>
                            <label for="barcodeInput">
                                <i class="fas fa-barcode me-2"></i>Scan Barcode or Search Product
                            </label>
                        </div>
                        <div class="mt-2 d-flex gap-2">
                            <button class="btn btn-outline-secondary btn-modern" type="button" id="cameraScanBtn" title="Camera Barcode Scanner">
                                <i class="fas fa-camera me-2"></i>Camera Scan
                            </button>
                            <button class="btn btn-primary" type="button" id="searchBtn">
                                <i class="fas fa-search me-2"></i>Search
                            </button>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-floating">
                            <select class="form-select" id="categoryFilter">
                                <option value="">All Categories</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?php echo $category['id']; ?>">
                                        <?php echo htmlspecialchars($category['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <label for="categoryFilter">
                                <i class="fas fa-tag me-2"></i>Category Filter
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Enhanced Product Grid -->
        <div class="card glass-effect">
            <div class="card-header">
                <div class="d-flex align-items-center">
                    <div class="icon-circle me-3">
                        <i class="fas fa-th-large"></i>
                    </div>
                    <h5 class="mb-0 gradient-text">Products</h5>
                </div>
            </div>
            <div class="card-body">
                <div class="row" id="productGrid">
                    <!-- Products will be loaded here via AJAX -->
                    <div class="col-12 text-center py-5">
                        <div class="icon-circle-large mx-auto mb-3">
                            <i class="fas fa-spinner fa-spin fa-2x"></i>
                        </div>
                        <p class="text-muted">Loading products...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Right Panel - Cart & Checkout -->
    <div class="col-xl-4 col-lg-5">
        <!-- Enhanced Today's Summary -->
        <div class="kpi-card kpi-card-secondary kpi-card-floating mb-4">
            <div class="kpi-icon">
                <i class="fas fa-chart-line"></i>
            </div>
            <div class="kpi-value">₱<?php echo number_format($todaysSales['total'], 2); ?></div>
            <div class="kpi-label">Today's Sales</div>
            <div class="kpi-meta">
                <i class="fas fa-receipt me-1"></i>
                <?php echo $todaysSales['count']; ?> transactions
            </div>
        </div>

        <!-- Enhanced Shopping Cart -->
        <div class="card glass-effect">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <div class="icon-circle me-3">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <h5 class="mb-0 gradient-text">Cart</h5>
                    </div>
                    <span class="badge badge-modern badge-primary" id="cartItemCount">0</span>
                </div>
            </div>
            <div class="card-body">
                <!-- Cart Items -->
                <div id="cartItems" style="min-height: 300px; max-height: 400px; overflow-y: auto;">
                    <div class="text-center py-5 text-muted" id="emptyCartMessage">
                        <i class="fas fa-shopping-cart fa-3x mb-3 opacity-50"></i>
                        <p>Cart is empty<br><small>Scan or select products to add</small></p>
                    </div>
                </div>

                <!-- Cart Summary -->
                <div class="border-top pt-3 mt-3" id="cartSummary" style="display: none;">
                    <div class="d-flex justify-content-between mb-3">
                        <strong>Total:</strong>
                        <strong class="text-primary" id="cartTotal">₱0.00</strong>
                    </div>


                    <!-- Payment Method - Cash Only -->
                    <div class="mb-3">
                        <div class="alert alert-info mb-0 py-2">
                            <i class="fas fa-money-bill me-2"></i><strong>Payment Method:</strong> Cash Only
                        </div>
                        <input type="hidden" id="paymentMethod" value="cash">
                    </div>

                    <!-- Action Buttons -->
                    <div class="d-grid gap-2">
                        <button class="btn btn-primary" id="checkoutBtn">
                            <i class="fas fa-credit-card me-2"></i>Checkout
                        </button>
                        <button class="btn btn-outline-secondary" id="clearCartBtn">
                            <i class="fas fa-trash me-2"></i>Clear Cart
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Product Selection Modal -->
<div class="modal fade" id="productModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Select Product Variant</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="productVariants">
                    <!-- Variants will be loaded here -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div class="modal fade" id="paymentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Payment Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="text-center mb-4">
                    <h4 class="text-primary">Total Amount: <span id="paymentTotal">₱0.00</span></h4>
                </div>
                
                <div class="mb-3">
                    <label for="paymentAmount" class="form-label">
                        <i class="fas fa-money-bill me-2"></i>Amount Received
                    </label>
                    <div class="input-group input-group-lg">
                        <span class="input-group-text">₱</span>
                        <input type="number" class="form-control" id="paymentAmount" 
                               placeholder="0.00" step="0.01" min="0" autofocus>
                    </div>
                </div>
                
                <div class="mb-3" id="changeSection" style="display: none;">
                    <label class="form-label">Change</label>
                    <div class="input-group input-group-lg">
                        <span class="input-group-text">₱</span>
                        <input type="text" class="form-control bg-light" id="changeAmount" readonly>
                    </div>
                </div>

                <div class="alert alert-warning" id="insufficientPaymentAlert" style="display: none;">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Insufficient payment amount. Please enter at least the total amount.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="confirmPaymentBtn">
                    <i class="fas fa-check me-2"></i>Complete Transaction
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Receipt Modal -->
<div class="modal fade" id="receiptModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Transaction Receipt</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="receiptContent">
                    <!-- Receipt will be generated here -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="printReceipt()">
                    <i class="fas fa-print me-2"></i>Print Receipt
                </button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Camera Barcode Scanner Modal -->
<div class="modal fade" id="cameraScannerModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-camera me-2"></i>Camera Barcode Scanner
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="text-center mb-3">
                    <p class="text-muted">Position the barcode within the viewfinder below</p>
                </div>
                
                <!-- Scanner Container -->
                <div id="scannerContainer" class="position-relative bg-dark rounded" style="height: 400px;">
                    <video id="cameraVideo" class="w-100 h-100" style="object-fit: cover;" autoplay muted playsinline></video>
                    
                    <!-- Scanning Overlay -->
                    <div class="position-absolute top-50 start-50 translate-middle" style="width: 250px; height: 100px; border: 2px solid #00ff00; background: rgba(0,255,0,0.1);">
                        <div class="position-absolute" style="top: -2px; left: -2px; width: 20px; height: 20px; border-top: 3px solid #00ff00; border-left: 3px solid #00ff00;"></div>
                        <div class="position-absolute" style="top: -2px; right: -2px; width: 20px; height: 20px; border-top: 3px solid #00ff00; border-right: 3px solid #00ff00;"></div>
                        <div class="position-absolute" style="bottom: -2px; left: -2px; width: 20px; height: 20px; border-bottom: 3px solid #00ff00; border-left: 3px solid #00ff00;"></div>
                        <div class="position-absolute" style="bottom: -2px; right: -2px; width: 20px; height: 20px; border-bottom: 3px solid #00ff00; border-right: 3px solid #00ff00;"></div>
                    </div>
                    
                    <!-- Scanning Line Animation -->
                    <div id="scanLine" class="position-absolute start-50 translate-middle-x bg-danger" 
                         style="width: 250px; height: 2px; top: 50%; animation: scanAnimation 2s linear infinite;"></div>
                </div>
                
                <!-- Scanner Status -->
                <div class="mt-3">
                    <div id="scannerStatus" class="text-center">
                        <span class="badge bg-secondary">
                            <i class="fas fa-camera"></i> Initializing camera...
                        </span>
                    </div>
                    
                    <!-- Detected Barcode Display -->
                    <div id="detectedBarcode" class="mt-3" style="display: none;">
                        <div class="alert alert-success">
                            <h6><i class="fas fa-check-circle me-2"></i>Barcode Detected!</h6>
                            <p class="mb-0">Code: <strong id="detectedBarcodeValue"></strong></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-success" id="useBarcodeBtn" style="display: none;">
                    <i class="fas fa-plus me-2"></i>Add to Cart
                </button>
            </div>
        </div>
    </div>
</div>

<style>
@keyframes scanAnimation {
    0% { top: 25%; }
    50% { top: 75%; }
    100% { top: 25%; }
}

.scanner-viewfinder {
    box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.3);
}
</style>

<!-- QuaggaJS Library for Barcode Scanning -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/quagga/0.12.1/quagga.min.js"></script>

<script>
class POSSystem {
    constructor() {
        this.cart = [];
        this.taxRate = 0;
        this.initializeEventListeners();
        this.loadProducts();
    }

    initializeEventListeners() {
        // Barcode input
        document.getElementById('barcodeInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.handleBarcodeInput();
            }
        });

        // Search button
        document.getElementById('searchBtn').addEventListener('click', () => {
            this.handleBarcodeInput();
        });

        // Camera scanner button
        document.getElementById('cameraScanBtn').addEventListener('click', () => {
            this.openCameraScanner();
        });

        // Category filter
        document.getElementById('categoryFilter').addEventListener('change', () => {
            this.loadProducts();
        });

        // Checkout button
        document.getElementById('checkoutBtn').addEventListener('click', () => {
            console.log('Checkout button clicked');
            console.log('Cart contents:', this.cart);
            this.showPaymentModal();
        });

        // Clear cart button
        document.getElementById('clearCartBtn').addEventListener('click', () => {
            this.clearCart();
        });

        // Event delegation for cart items (quantity and remove buttons)
        document.getElementById('cartItems').addEventListener('click', (e) => {
            if (e.target.classList.contains('remove-item-btn') || e.target.closest('.remove-item-btn')) {
                const button = e.target.closest('.remove-item-btn');
                const index = parseInt(button.dataset.index);
                this.removeFromCart(index);
            }
        });

        document.getElementById('cartItems').addEventListener('change', (e) => {
            if (e.target.classList.contains('quantity-input')) {
                const index = parseInt(e.target.dataset.index);
                const quantity = parseInt(e.target.value);
                this.updateCartQuantity(index, quantity);
            }
        });

        document.getElementById('cartItems').addEventListener('input', (e) => {
            if (e.target.classList.contains('quantity-input')) {
                const index = parseInt(e.target.dataset.index);
                const quantity = parseInt(e.target.value);
                if (quantity > 0) {
                    this.updateCartQuantity(index, quantity);
                }
            }
        });

        // Payment modal event listeners
        document.getElementById('paymentAmount').addEventListener('input', () => {
            this.calculateChange();
        });

        document.getElementById('confirmPaymentBtn').addEventListener('click', () => {
            this.processCheckout();
        });

        // Camera scanner modal events
        document.getElementById('cameraScannerModal').addEventListener('hidden.bs.modal', () => {
            this.stopCameraScanner();
        });

        document.getElementById('useBarcodeBtn').addEventListener('click', () => {
            this.useDetectedBarcode();
        });
    }

    async handleBarcodeInput() {
        const input = document.getElementById('barcodeInput').value.trim();
        if (!input) return;

        try {
            const response = await fetch('../api/search_product.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ query: input })
            });

            const data = await response.json();
            
            if (data.success) {
                if (data.type === 'barcode') {
                    // Direct barcode match - add to cart
                    this.addToCart(data.product);
                } else {
                    // Search results - show product grid
                    this.displayProducts(data.products);
                }
            } else {
                this.showAlert('Product not found', 'warning');
            }
        } catch (error) {
            this.showAlert('Error searching product', 'danger');
        }

        document.getElementById('barcodeInput').value = '';
        document.getElementById('barcodeInput').focus();
    }

    async loadProducts() {
        const categoryId = document.getElementById('categoryFilter').value;
        
        try {
            const response = await fetch('../api/load_products.php?category_id=' + categoryId);
            const data = await response.json();
            
            if (data.success) {
                this.displayProducts(data.products);
            }
        } catch (error) {
            console.error('Error loading products:', error);
        }
    }

    displayProducts(products) {
        const grid = document.getElementById('productGrid');
        
        if (products.length === 0) {
            grid.innerHTML = `
                <div class="col-12 text-center py-5">
                    <i class="fas fa-search fa-2x text-muted"></i>
                    <p class="text-muted mt-3">No products found</p>
                </div>
            `;
            return;
        }

        grid.innerHTML = products.map(product => {
            const isOutOfStock = !product.total_stock || product.total_stock <= 0;
            return `
            <div class="col-lg-4 col-md-6 mb-3">
                <div class="card h-100 product-card ${isOutOfStock ? 'opacity-50' : ''}" 
                     style="${isOutOfStock ? 'cursor: not-allowed;' : 'cursor: pointer;'}" 
                     ${isOutOfStock ? '' : `onclick="pos.selectProduct(${product.id})"`}>
                    <div class="card-img-top d-flex align-items-center justify-content-center" 
                         style="height: 150px; background: #f8f9fa; position: relative;">
                        ${product.image_url ? 
                            `<img src="${product.image_url}" class="img-fluid" style="max-height: 130px;">` :
                            `<i class="fas fa-tshirt fa-3x text-muted"></i>`
                        }
                        ${isOutOfStock ? 
                            `<div class="position-absolute top-50 start-50 translate-middle">
                                <span class="badge bg-danger fs-6">OUT OF STOCK</span>
                             </div>` : ''
                        }
                    </div>
                    <div class="card-body p-3">
                        <h6 class="card-title mb-2">${product.product_name}</h6>
                        <p class="text-muted small mb-2">${product.category_name}</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="fw-bold text-primary">₱${parseFloat(product.price).toFixed(2)}</span>
                            <small class="${isOutOfStock ? 'text-danger fw-bold' : 'text-muted'}">
                                ${isOutOfStock ? 'OUT OF STOCK' : `Stock: ${product.total_stock || 0}`}
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        `;}).join('');
    }

    async selectProduct(productId) {
        try {
            const response = await fetch('../api/product_variants.php?product_id=' + productId);
            const data = await response.json();
            
            if (data.success && data.variants.length > 0) {
                // Filter out variants with 0 stock
                const availableVariants = data.variants.filter(variant => variant.stock_quantity > 0);
                
                if (availableVariants.length === 0) {
                    this.showAlert('This product is out of stock', 'warning');
                    return;
                }
                
                if (availableVariants.length === 1) {
                    // Only one variant with stock - add directly to cart
                    this.addToCart(availableVariants[0]);
                } else {
                    // Multiple variants with stock - show selection modal
                    this.showVariantSelection(data.variants); // Show all variants but disable out-of-stock ones
                }
            } else {
                this.showAlert('No variants available', 'warning');
            }
        } catch (error) {
            this.showAlert('Error loading product variants', 'danger');
        }
    }

    showVariantSelection(variants) {
        const modal = document.getElementById('productModal');
        const variantsContainer = document.getElementById('productVariants');
        
        // Store variants in a temporary array for click handling
        this.tempVariants = variants;
        
        variantsContainer.innerHTML = '';
        variants.forEach((variant, index) => {
            const variantDiv = document.createElement('div');
            variantDiv.className = 'card mb-2';
            
            const cardBody = document.createElement('div');
            cardBody.className = 'card-body py-2';
            
            const flexContainer = document.createElement('div');
            flexContainer.className = 'd-flex justify-content-between align-items-center';
            
            const leftDiv = document.createElement('div');
            const productName = document.createElement('strong');
            productName.textContent = variant.product_name;
            leftDiv.appendChild(productName);
            leftDiv.appendChild(document.createElement('br'));
            
            const sizeColor = document.createElement('small');
            sizeColor.className = 'text-muted';
            sizeColor.textContent = 'Size: ' + (variant.size || 'N/A') + ' | Color: ' + (variant.color || 'N/A');
            leftDiv.appendChild(sizeColor);
            
            const rightDiv = document.createElement('div');
            rightDiv.className = 'text-end';
            
            const price = document.createElement('div');
            price.className = 'fw-bold text-primary';
            price.textContent = '₱' + parseFloat(variant.price).toFixed(2);
            rightDiv.appendChild(price);
            
            const stock = document.createElement('small');
            if (variant.stock_quantity <= 0) {
                stock.className = 'text-danger fw-bold';
                stock.textContent = 'OUT OF STOCK';
            } else {
                stock.className = 'text-muted';
                stock.textContent = 'Stock: ' + variant.stock_quantity;
            }
            rightDiv.appendChild(stock);
            
            flexContainer.appendChild(leftDiv);
            flexContainer.appendChild(rightDiv);
            
            // Add quantity controls
            const quantityControls = document.createElement('div');
            quantityControls.className = 'd-flex align-items-center gap-2 mt-2';
            
            const quantityLabel = document.createElement('small');
            quantityLabel.textContent = 'Qty:';
            quantityLabel.className = 'text-muted';
            
            const decreaseBtn = document.createElement('button');
            decreaseBtn.className = 'btn btn-outline-secondary btn-sm';
            decreaseBtn.textContent = '-';
            decreaseBtn.onclick = (e) => {
                e.stopPropagation();
                const qtyInput = quantityControls.querySelector('.quantity-input-modal');
                if (parseInt(qtyInput.value) > 1) {
                    qtyInput.value = parseInt(qtyInput.value) - 1;
                }
            };
            
            const quantityInput = document.createElement('input');
            quantityInput.type = 'number';
            quantityInput.className = 'form-control form-control-sm quantity-input-modal';
            quantityInput.style.width = '60px';
            quantityInput.value = '1';
            quantityInput.min = '1';
            quantityInput.max = variant.stock_quantity;
            quantityInput.onclick = (e) => e.stopPropagation();
            
            const increaseBtn = document.createElement('button');
            increaseBtn.className = 'btn btn-outline-secondary btn-sm';
            increaseBtn.textContent = '+';
            increaseBtn.onclick = (e) => {
                e.stopPropagation();
                const qtyInput = quantityControls.querySelector('.quantity-input-modal');
                if (parseInt(qtyInput.value) < variant.stock_quantity) {
                    qtyInput.value = parseInt(qtyInput.value) + 1;
                }
            };
            
            const addToCartBtn = document.createElement('button');
            if (variant.stock_quantity <= 0) {
                addToCartBtn.className = 'btn btn-secondary btn-sm';
                addToCartBtn.innerHTML = '<i class="fas fa-ban"></i> Out of Stock';
                addToCartBtn.disabled = true;
                // Disable quantity controls for out of stock items
                decreaseBtn.disabled = true;
                increaseBtn.disabled = true;
                quantityInput.disabled = true;
            } else {
                addToCartBtn.className = 'btn btn-primary btn-sm';
                addToCartBtn.innerHTML = '<i class="fas fa-plus"></i> Add to Cart';
                addToCartBtn.onclick = (e) => {
                    e.stopPropagation();
                    const quantity = parseInt(quantityInput.value);
                    this.addToCartFromModal(index, quantity);
                };
            }
            
            quantityControls.appendChild(quantityLabel);
            quantityControls.appendChild(decreaseBtn);
            quantityControls.appendChild(quantityInput);
            quantityControls.appendChild(increaseBtn);
            quantityControls.appendChild(addToCartBtn);
            
            cardBody.appendChild(flexContainer);
            cardBody.appendChild(quantityControls);
            variantDiv.appendChild(cardBody);
            variantsContainer.appendChild(variantDiv);
        });
        
        new bootstrap.Modal(modal).show();
    }

    addToCartFromModal(variantIndex, quantity = 1) {
        const variant = this.tempVariants[variantIndex];
        this.addToCart(variant, quantity);
    }

    addToCart(variant, quantity = 1) {
        // Check if variant has sufficient stock
        if (!variant.stock_quantity || variant.stock_quantity <= 0) {
            this.showAlert('This item is out of stock', 'warning');
            return;
        }
        
        const existingItem = this.cart.find(item => item.variant_id === variant.id);
        
        if (existingItem) {
            const newQuantity = existingItem.quantity + quantity;
            if (newQuantity > variant.stock_quantity) {
                this.showAlert(`Only ${variant.stock_quantity} items available in stock`, 'warning');
                return;
            }
            existingItem.quantity = newQuantity;
        } else {
            if (quantity > variant.stock_quantity) {
                this.showAlert(`Only ${variant.stock_quantity} items available in stock`, 'warning');
                return;
            }
            this.cart.push({
                variant_id: variant.id,
                product_name: variant.product_name,
                size: variant.size || 'N/A',
                color: variant.color || 'N/A',
                price: parseFloat(variant.price),
                quantity: quantity,
                stock_quantity: variant.stock_quantity
            });
        }

        this.updateCartDisplay();
        this.showAlert((quantity > 1 ? quantity + ' items' : 'Item') + ' added to cart', 'success');

        // Don't close modal automatically - let user continue adding items
        // const modal = bootstrap.Modal.getInstance(document.getElementById('productModal'));
        // if (modal) modal.hide();
    }

    removeFromCart(index) {
        this.cart.splice(index, 1);
        this.updateCartDisplay();
    }

    updateCartQuantity(index, quantity) {
        if (quantity <= 0) {
            this.removeFromCart(index);
            return;
        }

        const item = this.cart[index];
        const newQuantity = parseInt(quantity);
        
        // Check if new quantity exceeds available stock
        if (newQuantity > item.stock_quantity) {
            this.showAlert(`Only ${item.stock_quantity} items available in stock`, 'warning');
            // Reset to maximum available stock
            item.quantity = item.stock_quantity;
        } else {
            item.quantity = newQuantity;
        }
        
        this.updateCartDisplay();
    }

    updateCartDisplay() {
        const cartItems = document.getElementById('cartItems');
        const cartSummary = document.getElementById('cartSummary');
        const emptyMessage = document.getElementById('emptyCartMessage');
        const itemCount = document.getElementById('cartItemCount');

        itemCount.textContent = this.cart.reduce((sum, item) => sum + item.quantity, 0);

        if (this.cart.length === 0) {
            cartItems.innerHTML = `
                <div class="text-center py-5 text-muted" id="emptyCartMessage">
                    <i class="fas fa-shopping-cart fa-3x mb-3 opacity-50"></i>
                    <p>Cart is empty<br><small>Scan or select products to add</small></p>
                </div>
            `;
            cartSummary.style.display = 'none';
            return;
        }

        cartSummary.style.display = 'block';

        // Display cart items
        cartItems.innerHTML = '';
        this.cart.forEach((item, index) => {
            const itemDiv = document.createElement('div');
            itemDiv.className = 'd-flex justify-content-between align-items-center mb-3 pb-2 border-bottom';
            
            const leftDiv = document.createElement('div');
            leftDiv.className = 'flex-grow-1';
            
            const productName = document.createElement('div');
            productName.className = 'fw-bold small';
            productName.textContent = item.product_name;
            leftDiv.appendChild(productName);
            
            const sizeColor = document.createElement('small');
            sizeColor.className = 'text-muted';
            sizeColor.textContent = item.size + ' - ' + item.color;
            leftDiv.appendChild(sizeColor);
            
            leftDiv.appendChild(document.createElement('br'));
            
            const price = document.createElement('span');
            price.className = 'text-primary';
            price.textContent = '₱' + item.price.toFixed(2);
            leftDiv.appendChild(price);
            
            const rightDiv = document.createElement('div');
            rightDiv.className = 'd-flex align-items-center gap-2';
            
            const quantityInput = document.createElement('input');
            quantityInput.type = 'number';
            quantityInput.className = 'form-control form-control-sm quantity-input';
            quantityInput.style.width = '60px';
            quantityInput.value = item.quantity;
            quantityInput.min = '1';
            quantityInput.max = item.stock_quantity;
            quantityInput.dataset.index = index;
            rightDiv.appendChild(quantityInput);
            
            const removeBtn = document.createElement('button');
            removeBtn.className = 'btn btn-outline-danger btn-sm remove-item-btn';
            removeBtn.dataset.index = index;
            
            const trashIcon = document.createElement('i');
            trashIcon.className = 'fas fa-trash';
            removeBtn.appendChild(trashIcon);
            
            rightDiv.appendChild(removeBtn);
            
            itemDiv.appendChild(leftDiv);
            itemDiv.appendChild(rightDiv);
            cartItems.appendChild(itemDiv);
        });

        // Update summary
        const total = this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

        document.getElementById('cartTotal').textContent = '₱' + total.toFixed(2);

        // Event listeners are handled by event delegation in initializeEventListeners()
    }

    showPaymentModal() {
        console.log('showPaymentModal called');
        console.log('Cart length:', this.cart.length);
        
        if (this.cart.length === 0) {
            console.log('Cart is empty, showing alert');
            this.showAlert('Cart is empty', 'warning');
            return;
        }

        const total = this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

        console.log('Calculated total:', total);

        const paymentTotalElement = document.getElementById('paymentTotal');
        console.log('paymentTotal element:', paymentTotalElement);
        
        if (paymentTotalElement) {
            paymentTotalElement.textContent = '₱' + total.toFixed(2);
        }
        
        const paymentAmountElement = document.getElementById('paymentAmount');
        const changeAmountElement = document.getElementById('changeAmount');
        const changeSectionElement = document.getElementById('changeSection');
        const insufficientAlertElement = document.getElementById('insufficientPaymentAlert');
        
        if (paymentAmountElement) paymentAmountElement.value = '';
        if (changeAmountElement) changeAmountElement.value = '';
        if (changeSectionElement) changeSectionElement.style.display = 'none';
        if (insufficientAlertElement) insufficientAlertElement.style.display = 'none';

        const paymentModalElement = document.getElementById('paymentModal');
        console.log('paymentModal element:', paymentModalElement);
        
        if (paymentModalElement) {
            const modal = new bootstrap.Modal(paymentModalElement);
            console.log('Modal created, attempting to show');
            modal.show();

            // Focus on payment amount input after modal is shown
            paymentModalElement.addEventListener('shown.bs.modal', () => {
                if (paymentAmountElement) paymentAmountElement.focus();
            }, { once: true });
        } else {
            console.error('Payment modal element not found');
        }
    }

    calculateChange() {
        const paymentAmount = parseFloat(document.getElementById('paymentAmount').value) || 0;
        const totalText = document.getElementById('paymentTotal').textContent;
        const total = parseFloat(totalText.replace('₱', ''));

        const changeSection = document.getElementById('changeSection');
        const changeAmount = document.getElementById('changeAmount');
        const insufficientAlert = document.getElementById('insufficientPaymentAlert');
        const confirmBtn = document.getElementById('confirmPaymentBtn');

        if (paymentAmount > 0) {
            if (paymentAmount >= total) {
                const change = paymentAmount - total;
                changeAmount.value = change.toFixed(2);
                changeSection.style.display = 'block';
                insufficientAlert.style.display = 'none';
                confirmBtn.disabled = false;
            } else {
                changeSection.style.display = 'none';
                insufficientAlert.style.display = 'block';
                confirmBtn.disabled = true;
            }
        } else {
            changeSection.style.display = 'none';
            insufficientAlert.style.display = 'none';
            confirmBtn.disabled = false;
        }
    }

    async processCheckout() {
        const paymentAmount = parseFloat(document.getElementById('paymentAmount').value) || 0;
        const totalText = document.getElementById('paymentTotal').textContent;
        const total = parseFloat(totalText.replace('₱', ''));

        if (paymentAmount < total) {
            this.showAlert('Insufficient payment amount', 'warning');
            return;
        }

        const paymentMethod = document.getElementById('paymentMethod').value;
        const change = paymentAmount - total;

        try {
            const response = await fetch('../api/process_checkout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    cart_items: this.cart,
                    payment_method: paymentMethod,
                    payment_amount: paymentAmount,
                    change_amount: change
                })
            });

            const data = await response.json();
            
            if (data.success) {
                // Hide payment modal
                const paymentModal = bootstrap.Modal.getInstance(document.getElementById('paymentModal'));
                if (paymentModal) paymentModal.hide();

                // Show receipt with payment details
                this.showReceipt({
                    ...data.transaction,
                    payment_amount: paymentAmount,
                    change_amount: change
                });
                this.clearCart();
                this.showAlert('Transaction completed successfully!', 'success');
            } else {
                this.showAlert(data.error || 'Checkout failed', 'danger');
            }
        } catch (error) {
            this.showAlert('Error processing checkout', 'danger');
        }
    }

    showReceipt(transaction) {
        // Generate receipt content
        const receiptContent = document.getElementById('receiptContent');
        const now = new Date().toLocaleString();
        
        receiptContent.innerHTML = 
            '<div class="text-center mb-4">' +
                '<h4>DJ Cheenee\'s Fashion Boutique</h4>' +
                '<p class="mb-1">Fashion Boutique POS System</p>' +
                '<p class="mb-0"><small>' + now + '</small></p>' +
            '</div>' +
            
            '<div class="receipt-info mb-3">' +
                '<div class="row small">' +
                    '<div class="col-6"><strong>Transaction #:</strong> TXN-' + Date.now() + '</div>' +
                    '<div class="col-6"><strong>Cashier:</strong> <?php echo $current_user['full_name']; ?></div>' +
                    '<div class="col-6"><strong>Payment:</strong> ' + transaction.payment_method.toUpperCase() + '</div>' +
                '</div>' +
                (transaction.customer_name ? '<div class="mt-2"><strong>Customer:</strong> ' + transaction.customer_name + '</div>' : '') +
            '</div>' +
            
            '<table class="table table-sm">' +
                '<thead>' +
                    '<tr>' +
                        '<th>Item</th>' +
                        '<th class="text-end">Qty</th>' +
                        '<th class="text-end">Price</th>' +
                        '<th class="text-end">Total</th>' +
                    '</tr>' +
                '</thead>' +
                '<tbody>' +
                    this.cart.map(item => 
                        '<tr>' +
                            '<td>' +
                                '<div class="small fw-bold">' + item.product_name + '</div>' +
                                '<div class="small text-muted">' + item.size + ' - ' + item.color + '</div>' +
                            '</td>' +
                            '<td class="text-end">' + item.quantity + '</td>' +
                            '<td class="text-end">₱' + item.price.toFixed(2) + '</td>' +
                            '<td class="text-end">₱' + (item.price * item.quantity).toFixed(2) + '</td>' +
                        '</tr>'
                    ).join('') +
                '</tbody>' +
            '</table>' +
            
            '<div class="text-end mt-3">' +
                '<div class="fw-bold fs-5">Total: ₱' + transaction.total_amount + '</div>' +
                '<hr class="my-2">' +
                '<div class="fw-bold">Payment: ₱' + (transaction.payment_amount ? transaction.payment_amount.toFixed(2) : transaction.total_amount) + '</div>' +
                (transaction.change_amount !== undefined ? '<div class="fw-bold text-success">Change: ₱' + transaction.change_amount.toFixed(2) + '</div>' : '') +
            '</div>' +
            
            '<div class="text-center mt-4 pt-3 border-top">' +
                '<p class="mb-1">Thank you for shopping with us!</p>' +
                '<small class="text-muted">Please keep this receipt for your records</small>' +
            '</div>';
        
        new bootstrap.Modal(document.getElementById('receiptModal')).show();
    }

    clearCart() {
        this.cart = [];
        this.updateCartDisplay();
        
    }

    showAlert(message, type = 'info') {
        const alertDiv = document.createElement('div');
        alertDiv.className = 'alert alert-' + type + ' alert-dismissible fade show position-fixed';
        alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        alertDiv.innerHTML = 
            message +
            '<button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\"></button>';
        
        document.body.appendChild(alertDiv);
        
        setTimeout(() => {
            alertDiv.remove();
        }, 3000);
    }

    // Camera Barcode Scanner Methods
    openCameraScanner() {
        const modal = new bootstrap.Modal(document.getElementById('cameraScannerModal'));
        modal.show();
        
        // Initialize scanner when modal is shown
        document.getElementById('cameraScannerModal').addEventListener('shown.bs.modal', () => {
            this.initializeCameraScanner();
        }, { once: true });
    }

    async initializeCameraScanner() {
        try {
            // Check HTTPS requirement
            if (location.protocol !== 'https:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
                this.showCameraError('Camera requires HTTPS connection', 
                    'Please use HTTPS or localhost to access camera features.');
                return;
            }

            // Check if getUserMedia is supported
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                this.showCameraError('Camera not supported', 
                    'Your browser does not support camera access.');
                return;
            }

            this.updateScannerStatus('Requesting camera permission...', 'warning');

            // First, check available devices
            try {
                const devices = await navigator.mediaDevices.enumerateDevices();
                const videoDevices = devices.filter(device => device.kind === 'videoinput');
                console.log('Available video devices:', videoDevices);
                
                if (videoDevices.length === 0) {
                    this.showCameraError('No camera detected', 
                        'Please connect a camera to your device and refresh the page.');
                    return;
                }
            } catch (enumError) {
                console.log('Could not enumerate devices:', enumError);
            }

            // Check current permissions state
            try {
                const permission = await navigator.permissions.query({ name: 'camera' });
                console.log('Camera permission state:', permission.state);
                
                if (permission.state === 'denied') {
                    this.showCameraError('Camera permission denied', 
                        'Please reset camera permissions in your browser settings and try again.');
                    return;
                }
            } catch (permError) {
                console.log('Could not check permissions:', permError);
            }

            // Try different camera configurations
            const configurations = [
                { video: { width: { ideal: 640 }, height: { ideal: 480 } } },
                { video: { facingMode: 'environment', width: { ideal: 640 }, height: { ideal: 480 } } },
                { video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } } },
                { video: true }
            ];

            let stream = null;
            let lastError = null;

            for (let i = 0; i < configurations.length; i++) {
                const config = configurations[i];
                try {
                    console.log(`Trying camera configuration ${i + 1}:`, config);
                    this.updateScannerStatus(`Trying camera configuration ${i + 1}...`, 'warning');
                    
                    stream = await navigator.mediaDevices.getUserMedia(config);
                    console.log('Camera access successful with config:', config);
                    break;
                } catch (error) {
                    lastError = error;
                    console.log(`Camera config ${i + 1} failed:`, error.name, error.message);
                    continue;
                }
            }

            if (!stream) {
                throw lastError || new Error('No camera configuration worked');
            }

            const video = document.getElementById('cameraVideo');
            video.srcObject = stream;
            this.cameraStream = stream;

            // Wait for video to be ready
            video.addEventListener('loadedmetadata', () => {
                console.log('Video loaded, starting barcode scanning');
                this.startBarcodeScanning();
            }, { once: true });

        } catch (error) {
            console.error('Error accessing camera:', error);
            this.handleCameraError(error);
        }
    }

    handleCameraError(error) {
        let message = 'Camera access failed';
        let guidance = '';

        switch (error.name) {
            case 'NotAllowedError':
                message = 'Camera permission denied';
                guidance = 'Please allow camera access and try again. Check your browser settings.';
                break;
            case 'NotFoundError':
                message = 'No camera found';
                guidance = 'Please connect a camera and refresh the page.';
                break;
            case 'NotSupportedError':
                message = 'Camera not supported';
                guidance = 'Your browser or device does not support camera access.';
                break;
            case 'NotReadableError':
                message = 'Camera is busy';
                guidance = 'Camera may be in use by another application. Please close other camera apps.';
                break;
            default:
                guidance = 'Please check your camera permissions and try again.';
        }

        this.showCameraError(message, guidance);
    }

    showCameraError(message, guidance) {
        this.updateScannerStatus(message, 'danger');
        
        const statusElement = document.getElementById('scannerStatus');
        statusElement.innerHTML += `
            <div class="mt-2 p-3 bg-light rounded">
                <h6><i class="fas fa-exclamation-triangle text-warning"></i> Troubleshooting Tips:</h6>
                <p class="mb-2 small">${guidance}</p>
                <div class="small mb-3">
                    <strong>Reset Camera Permissions:</strong>
                    <ul class="mb-2">
                        <li><strong>Chrome:</strong> Click the camera icon in address bar → Reset permissions</li>
                        <li><strong>Firefox:</strong> Click shield icon → Reset permissions for this site</li>
                        <li><strong>Edge:</strong> Click lock icon → Reset permissions</li>
                        <li><strong>Safari:</strong> Settings → Websites → Camera → Reset for this site</li>
                    </ul>
                    <strong>Other Solutions:</strong>
                    <ul>
                        <li>Close and reopen your browser completely</li>
                        <li>Try using a different browser (Chrome works best)</li>
                        <li>Make sure no other tabs/windows are using camera</li>
                        <li>Check Windows camera privacy settings</li>
                        <li>Try pressing F5 to refresh the page</li>
                    </ul>
                </div>
                <div class="d-flex gap-2 flex-wrap">
                    <button class="btn btn-sm btn-primary" onclick="pos.retryCamera()">
                        <i class="fas fa-redo"></i> Try Again
                    </button>
                    <button class="btn btn-sm btn-info" onclick="pos.openCameraSettings()">
                        <i class="fas fa-cog"></i> Camera Settings
                    </button>
                    <button class="btn btn-sm btn-secondary" onclick="pos.showManualEntry()">
                        <i class="fas fa-keyboard"></i> Manual Entry
                    </button>
                </div>
            </div>
        `;
    }

    retryCamera() {
        // Reset UI
        document.getElementById('detectedBarcode').style.display = 'none';
        document.getElementById('useBarcodeBtn').style.display = 'none';
        this.detectedBarcode = null;
        
        // Retry camera initialization
        this.initializeCameraScanner();
    }

    showManualEntry() {
        // Close scanner modal and focus on barcode input
        const modal = bootstrap.Modal.getInstance(document.getElementById('cameraScannerModal'));
        modal.hide();
        
        setTimeout(() => {
            document.getElementById('barcodeInput').focus();
            this.showAlert('Enter barcode manually in the search field', 'info');
        }, 300);
    }

    openCameraSettings() {
        // Show browser-specific instructions to reset camera permissions
        const userAgent = navigator.userAgent.toLowerCase();
        let instructions = '';
        
        if (userAgent.includes('chrome') && !userAgent.includes('edge')) {
            instructions = `
                <strong>Google Chrome:</strong><br>
                1. Look for the camera icon in the address bar (next to the URL)<br>
                2. Click it and select "Allow"<br>
                3. If no icon, click the lock/info icon → Site settings → Camera → Allow<br>
                4. Refresh the page after changing settings
            `;
        } else if (userAgent.includes('firefox')) {
            instructions = `
                <strong>Mozilla Firefox:</strong><br>
                1. Look for the shield or camera icon in the address bar<br>
                2. Click it and select "Allow"<br>
                3. Or go to: Settings → Privacy & Security → Permissions → Camera<br>
                4. Remove this site from blocked list if present
            `;
        } else if (userAgent.includes('edge')) {
            instructions = `
                <strong>Microsoft Edge:</strong><br>
                1. Click the lock icon in the address bar<br>
                2. Set Camera permission to "Allow"<br>
                3. Or go to: Settings → Site permissions → Camera<br>
                4. Refresh the page after changing settings
            `;
        } else {
            instructions = `
                <strong>General Instructions:</strong><br>
                1. Look for camera/lock icon in your browser's address bar<br>
                2. Click it and allow camera permissions<br>
                3. Check your browser's privacy/security settings<br>
                4. Make sure camera is not blocked for this site
            `;
        }
        
        const statusElement = document.getElementById('scannerStatus');
        statusElement.innerHTML = `
            <div class="alert alert-info">
                <h6><i class="fas fa-info-circle"></i> Camera Permission Instructions</h6>
                <div class="small">${instructions}</div>
                <hr>
                <div class="small">
                    <strong>Windows Camera Privacy:</strong><br>
                    Go to Settings → Privacy → Camera → Allow apps to access camera
                </div>
                <div class="mt-3">
                    <button class="btn btn-sm btn-primary" onclick="pos.retryCamera()">
                        <i class="fas fa-redo"></i> I've Updated Settings - Try Again
                    </button>
                </div>
            </div>
        `;
    }

    startBarcodeScanning() {
        this.updateScannerStatus('Scanning for barcodes...', 'success');
        this.detectedBarcode = null;
        this.lastDetectionTime = 0;

        // Detect mobile device for optimized settings
        const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
        console.log('Device type:', isMobile ? 'Mobile' : 'Desktop');

        // Initialize QuaggaJS with optimized settings for better detection
        Quagga.init({
            inputStream: {
                name: "Live",
                type: "LiveStream",
                target: document.querySelector('#cameraVideo'),
                constraints: isMobile ? {
                    // Mobile-optimized constraints
                    facingMode: "environment", // Prefer rear camera on mobile
                    width: { ideal: 640 },
                    height: { ideal: 480 }
                } : {
                    // Desktop constraints with higher resolution
                    width: { min: 640, ideal: 1280, max: 1920 },
                    height: { min: 480, ideal: 720, max: 1080 },
                    facingMode: "environment"
                },
                area: { // Focus on center area matching the green overlay
                    top: "25%",    // Match the green rectangle position
                    right: "12.5%", 
                    left: "12.5%",
                    bottom: "25%"
                }
            },
            decoder: {
                readers: [
                    "code_128_reader",  // Most common for retail
                    "ean_reader",       // EAN-13
                    "ean_8_reader",     // EAN-8
                    "code_39_reader",   // Code 39
                    "upc_reader",       // UPC-A
                    "upc_e_reader",     // UPC-E
                    "codabar_reader"    // Codabar
                ],
                multiple: false // Only decode one barcode at a time
            },
            locate: true,
            locator: {
                halfSample: isMobile,  // Enable on mobile for better performance
                patchSize: isMobile ? "medium" : "large", // Adjust patch size based on device
                debug: {
                    showCanvas: !isMobile,     // Disable debug canvas on mobile for better performance
                    showPatches: false,
                    showFoundPatches: !isMobile, // Show found patches only on desktop
                    showSkeleton: false,
                    showLabels: false,
                    showPatchLabels: false,
                    showRemainingPatchLabels: false,
                    boxFromPatches: {
                        showTransformed: !isMobile,    // Show transformed box only on desktop
                        showTransformedBox: !isMobile, // Show bounding box only on desktop
                        showBB: !isMobile             // Show bounding box only on desktop
                    }
                }
            },
            frequency: isMobile ? 5 : 10 // Lower frequency on mobile to improve performance
        }, (err) => {
            if (err) {
                console.error('Quagga initialization failed:', err);
                this.updateScannerStatus('Scanner initialization failed', 'danger');
                return;
            }

            console.log("Quagga initialization finished. Ready to start");
            Quagga.start();

            // Listen for barcode processing attempts (even failed ones)
            Quagga.onProcessed((result) => {
                const drawingCtx = Quagga.canvas.ctx.overlay;
                const drawingCanvas = Quagga.canvas.dom.overlay;

                if (result) {
                    // Clear previous drawings
                    drawingCtx.clearRect(0, 0, parseInt(drawingCanvas.getAttribute("width")), parseInt(drawingCanvas.getAttribute("height")));
                    
                    if (result.boxes) {
                        drawingCtx.strokeStyle = "green";
                        drawingCtx.lineWidth = 2;
                        result.boxes.filter(box => box !== result.box).forEach(box => {
                            Quagga.ImageDebug.drawPath(box, {x: 0, y: 1}, drawingCtx, {color: "green", lineWidth: 2});
                        });
                    }

                    if (result.box) {
                        drawingCtx.strokeStyle = "blue";
                        drawingCtx.lineWidth = 2;
                        Quagga.ImageDebug.drawPath(result.box, {x: 0, y: 1}, drawingCtx, {color: "blue", lineWidth: 2});
                    }

                    if (result.codeResult && result.codeResult.code) {
                        drawingCtx.strokeStyle = "red";
                        drawingCtx.lineWidth = 3;
                        Quagga.ImageDebug.drawPath(result.line, {x: 'x', y: 'y'}, drawingCtx, {color: 'red', lineWidth: 3});
                    }
                }
            });

            // Listen for detected barcodes
            Quagga.onDetected((result) => {
                const code = result.codeResult.code;
                const confidence = result.codeResult.confidence || 0;
                const currentTime = Date.now();
                
                console.log('Barcode detected:', code, 'Confidence:', confidence);
                
                // Only process if confidence is high enough and not detected recently
                if (confidence > 75 && currentTime - this.lastDetectionTime > 2000) {
                    this.lastDetectionTime = currentTime;
                    this.handleDetectedBarcode(code);
                }
            });
        });
    }

    async handleDetectedBarcode(barcode) {
        this.detectedBarcode = barcode;
        
        // Update UI to show detected barcode
        document.getElementById('detectedBarcodeValue').textContent = barcode;
        document.getElementById('detectedBarcode').style.display = 'block';
        
        this.updateScannerStatus('Processing barcode: ' + barcode, 'warning');
        
        // Play success sound
        this.playBeep();
        
        // Automatically process the barcode
        try {
            const response = await fetch('../api/search_product.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ query: barcode })
            });

            const data = await response.json();
            
            if (data.success && data.type === 'barcode') {
                // Valid barcode found - add to cart automatically
                this.addToCart(data.product);
                this.updateScannerStatus('Product added to cart!', 'success');
                
                // Close scanner modal after successful add
                setTimeout(() => {
                    const modal = bootstrap.Modal.getInstance(document.getElementById('cameraScannerModal'));
                    if (modal) modal.hide();
                }, 1500);
                
            } else if (data.success && data.type === 'search' && data.products.length > 0) {
                // Multiple products found - this shouldn't happen with exact barcode, but handle gracefully
                this.updateScannerStatus('Multiple products found - check barcode', 'warning');
                document.getElementById('useBarcodeBtn').style.display = 'inline-block';
                
            } else {
                // Invalid barcode
                this.updateScannerStatus('Invalid barcode: ' + barcode, 'danger');
                this.showInvalidBarcodeMessage(barcode);
                
                // Allow scanning to continue for next barcode
                setTimeout(() => {
                    this.resetScannerForNextScan();
                }, 2000);
            }
        } catch (error) {
            console.error('Error processing barcode:', error);
            this.updateScannerStatus('Error processing barcode', 'danger');
            
            // Show fallback option
            document.getElementById('useBarcodeBtn').style.display = 'inline-block';
        }
    }

    async useDetectedBarcode() {
        if (!this.detectedBarcode) return;

        // Close scanner modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('cameraScannerModal'));
        modal.hide();

        // Set barcode in input field and process
        document.getElementById('barcodeInput').value = this.detectedBarcode;
        await this.handleBarcodeInput();
    }

    stopCameraScanner() {
        // Stop Quagga
        if (typeof Quagga !== 'undefined') {
            Quagga.stop();
        }

        // Stop camera stream
        if (this.cameraStream) {
            this.cameraStream.getTracks().forEach(track => {
                track.stop();
            });
            this.cameraStream = null;
        }

        // Reset UI
        document.getElementById('detectedBarcode').style.display = 'none';
        document.getElementById('useBarcodeBtn').style.display = 'none';
        this.detectedBarcode = null;
        
        this.updateScannerStatus('Scanner stopped', 'secondary');
    }

    updateScannerStatus(message, type) {
        const statusElement = document.getElementById('scannerStatus');
        const badgeClass = `bg-${type}`;
        
        statusElement.innerHTML = `<span class="badge ${badgeClass}">
            <i class="fas fa-${this.getStatusIcon(type)}"></i> ${message}
        </span>`;
    }

    getStatusIcon(type) {
        const icons = {
            'success': 'check-circle',
            'warning': 'exclamation-triangle',
            'danger': 'times-circle',
            'secondary': 'camera'
        };
        return icons[type] || 'camera';
    }

    showInvalidBarcodeMessage(barcode) {
        const statusElement = document.getElementById('scannerStatus');
        statusElement.innerHTML = `
            <div class="alert alert-danger">
                <h6><i class="fas fa-exclamation-triangle"></i> Invalid Barcode</h6>
                <p class="mb-2">Barcode <strong>${barcode}</strong> was not found in the system.</p>
                <div class="small">
                    <strong>Possible reasons:</strong>
                    <ul class="mb-2">
                        <li>Product not registered in inventory</li>
                        <li>Barcode damaged or unclear</li>
                        <li>Wrong barcode format</li>
                    </ul>
                    <strong>What to do:</strong>
                    <ul>
                        <li>Try scanning again with better positioning</li>
                        <li>Check if barcode is clear and undamaged</li>
                        <li>Use manual search instead</li>
                    </ul>
                </div>
                <div class="mt-2">
                    <button class="btn btn-sm btn-primary" onclick="pos.resetScannerForNextScan()">
                        <i class="fas fa-redo"></i> Scan Another
                    </button>
                    <button class="btn btn-sm btn-secondary" onclick="pos.showManualEntry()">
                        <i class="fas fa-keyboard"></i> Manual Search
                    </button>
                </div>
            </div>
        `;
    }

    resetScannerForNextScan() {
        // Reset detected barcode display
        document.getElementById('detectedBarcode').style.display = 'none';
        document.getElementById('useBarcodeBtn').style.display = 'none';
        this.detectedBarcode = null;
        
        // Reset last detection time to allow immediate new scans
        this.lastDetectionTime = 0;
        
        // Update status to scanning
        this.updateScannerStatus('Scanning for barcodes...', 'success');
    }

    playBeep() {
        // Create audio context for beep sound
        try {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.frequency.value = 800; // Frequency in Hz
            oscillator.type = 'square';
            
            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.2);
        } catch (error) {
            console.log('Could not play beep sound:', error);
        }
    }
}

// Initialize POS System
const pos = new POSSystem();

// Print receipt function
function printReceipt() {
    const receiptContent = document.getElementById('receiptContent').innerHTML;
    const printWindow = window.open('', '', 'height=600,width=800');
    
    printWindow.document.write(
        '<html>' +
            '<head>' +
                '<title>Receipt</title>' +
                '<style>' +
                    'body { font-family: Arial, sans-serif; margin: 20px; }' +
                    '.table { width: 100%; border-collapse: collapse; }' +
                    '.table th, .table td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }' +
                    '.text-center { text-align: center; }' +
                    '.text-end { text-align: right; }' +
                    '.fw-bold { font-weight: bold; }' +
                    '.border-top { border-top: 1px solid #ddd; }' +
                    '.border-bottom { border-bottom: 1px solid #ddd; }' +
                '</style>' +
            '</head>' +
            '<body>' +
                receiptContent +
            '</body>' +
        '</html>'
    );
    
    printWindow.document.close();
    printWindow.print();
}

// Auto-focus on barcode input
document.getElementById('barcodeInput').focus();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
