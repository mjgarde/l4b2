<?php
/**
 * DJ Cheenee's Fashion Boutique - Notifications API
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';

SessionManager::requireAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$db = getDbConnection();
$current_user = SessionManager::getUser();

// Get both low stock and out of stock notifications
$query = "SELECT n.*, p.name as product_name, pv.size, pv.color, pv.stock_quantity, pv.low_stock_threshold
          FROM notifications n
          LEFT JOIN product_variants pv ON n.product_variant_id = pv.id
          LEFT JOIN products p ON pv.product_id = p.id
          WHERE (n.type = 'low_stock' OR n.type = 'out_of_stock') AND n.is_read = 0
          ORDER BY n.created_at DESC
          LIMIT 15";

$stmt = $db->prepare($query);
$stmt->execute();
$notifications = $stmt->fetchAll();

// Format notifications
$formatted_notifications = [];
foreach ($notifications as $notification) {
    if ($notification['product_name']) {
        $title = ($notification['type'] == 'out_of_stock') ? 'Out of Stock Alert' : 'Low Stock Alert';
        $message = '';
        
        if ($notification['type'] == 'out_of_stock') {
            $message = $notification['product_name'] . ' (' . $notification['size'] . ' - ' . $notification['color'] . ') is out of stock!';
        } else {
            $message = $notification['product_name'] . ' (' . $notification['size'] . ' - ' . $notification['color'] . ') is running low: ' . $notification['stock_quantity'] . ' left';
        }
        
        $formatted_notifications[] = [
            'id' => $notification['id'],
            'title' => $title,
            'message' => $message,
            'type' => $notification['type'],
            'created_at' => $notification['created_at']
        ];
    }
}

// Check for new out of stock items and create notifications
$out_of_stock_query = "SELECT pv.id, p.name, pv.size, pv.color, pv.stock_quantity
                       FROM product_variants pv
                       JOIN products p ON pv.product_id = p.id
                       WHERE pv.stock_quantity <= 0
                       AND pv.is_active = 1 AND p.is_active = 1
                       AND NOT EXISTS (
                           SELECT 1 FROM notifications 
                           WHERE product_variant_id = pv.id 
                           AND type = 'out_of_stock' 
                           AND is_read = 0
                       )";

$stmt = $db->prepare($out_of_stock_query);
$stmt->execute();
$out_of_stock_items = $stmt->fetchAll();

// Create notifications for new out of stock items
foreach ($out_of_stock_items as $item) {
    $insert_query = "INSERT INTO notifications (type, title, message, product_variant_id) 
                     VALUES ('out_of_stock', 'Out of Stock Alert', :message, :variant_id)";
    
    $message = $item['name'] . ' (' . $item['size'] . ' - ' . $item['color'] . ') is out of stock!';
    
    $insert_stmt = $db->prepare($insert_query);
    $insert_stmt->bindParam(':message', $message);
    $insert_stmt->bindParam(':variant_id', $item['id']);
    $insert_stmt->execute();
    
    // Add to current notifications
    $formatted_notifications[] = [
        'id' => $db->lastInsertId(),
        'title' => 'Out of Stock Alert',
        'message' => $message,
        'type' => 'out_of_stock',
        'created_at' => date('Y-m-d H:i:s')
    ];
}

// Check for new low stock items and create notifications (but not for out of stock items)
$low_stock_query = "SELECT pv.id, p.name, pv.size, pv.color, pv.stock_quantity, pv.low_stock_threshold
                    FROM product_variants pv
                    JOIN products p ON pv.product_id = p.id
                    WHERE pv.stock_quantity <= pv.low_stock_threshold 
                    AND pv.stock_quantity > 0
                    AND pv.is_active = 1 AND p.is_active = 1
                    AND NOT EXISTS (
                        SELECT 1 FROM notifications 
                        WHERE product_variant_id = pv.id 
                        AND type = 'low_stock' 
                        AND is_read = 0
                    )";

$stmt = $db->prepare($low_stock_query);
$stmt->execute();
$low_stock_items = $stmt->fetchAll();

// Create notifications for new low stock items
foreach ($low_stock_items as $item) {
    $insert_query = "INSERT INTO notifications (type, title, message, product_variant_id) 
                     VALUES ('low_stock', 'Low Stock Alert', :message, :variant_id)";
    
    $message = $item['name'] . ' (' . $item['size'] . ' - ' . $item['color'] . ') is running low: ' . $item['stock_quantity'] . ' left';
    
    $insert_stmt = $db->prepare($insert_query);
    $insert_stmt->bindParam(':message', $message);
    $insert_stmt->bindParam(':variant_id', $item['id']);
    $insert_stmt->execute();
    
    // Add to current notifications
    $formatted_notifications[] = [
        'id' => $db->lastInsertId(),
        'title' => 'Low Stock Alert',
        'message' => $message,
        'type' => 'low_stock',
        'created_at' => date('Y-m-d H:i:s')
    ];
}

// Clean up out-of-stock notifications for items that are back in stock
$cleanup_query = "UPDATE notifications n
                  JOIN product_variants pv ON n.product_variant_id = pv.id
                  SET n.is_read = 1
                  WHERE n.type = 'out_of_stock' 
                  AND n.is_read = 0 
                  AND pv.stock_quantity > 0";
$db->prepare($cleanup_query)->execute();

echo json_encode([
    'success' => true,
    'count' => count($formatted_notifications),
    'notifications' => $formatted_notifications
]);
?>
