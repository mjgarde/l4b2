<?php
/**
 * DJ Cheenee's Fashion Boutique - Search Product API
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../classes/Product.php';

SessionManager::requireAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$query = trim($input['query'] ?? '');

if (empty($query)) {
    echo json_encode(['success' => false, 'error' => 'Search query is required']);
    exit;
}

$product = new Product();

// First, try to find by barcode
$variant = $product->getVariantByBarcode($query);

if ($variant) {
    echo json_encode([
        'success' => true,
        'type' => 'barcode',
        'product' => $variant
    ]);
} else {
    // Search by product name/description
    $products = $product->searchProducts($query);
    
    echo json_encode([
        'success' => true,
        'type' => 'search',
        'products' => $products
    ]);
}
?>
