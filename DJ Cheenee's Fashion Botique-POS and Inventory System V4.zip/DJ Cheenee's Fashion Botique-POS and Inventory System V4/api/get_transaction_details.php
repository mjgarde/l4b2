<?php
/**
 * DJ Cheenee's Fashion Boutique - Get Transaction Details API
 */

header('Content-Type: application/json');

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';

SessionManager::requireAuth();

if (!isset($_GET['id'])) {
    echo json_encode(['success' => false, 'error' => 'Transaction ID is required']);
    exit;
}

$transaction_id = $_GET['id'];
$db = getDbConnection();

try {
    // Get transaction details
    $stmt = $db->prepare("
        SELECT st.*, u.full_name as cashier_name 
        FROM sales_transactions st
        JOIN users u ON st.user_id = u.id
        WHERE st.id = :id
    ");
    $stmt->bindParam(':id', $transaction_id);
    $stmt->execute();
    $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$transaction) {
        echo json_encode(['success' => false, 'error' => 'Transaction not found']);
        exit;
    }

    // Get transaction items
    $stmt = $db->prepare("
        SELECT sti.*, p.name as product_name, pv.size, pv.color, pv.barcode
        FROM sales_transaction_items sti
        JOIN product_variants pv ON sti.product_variant_id = pv.id
        JOIN products p ON pv.product_id = p.id
        WHERE sti.transaction_id = :transaction_id
        ORDER BY sti.id
    ");
    $stmt->bindParam(':transaction_id', $transaction_id);
    $stmt->execute();
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'transaction' => $transaction,
        'items' => $items
    ]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
