<?php
/**
 * DJ Cheenee's Fashion Boutique - Process Checkout API
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../classes/Sale.php';

SessionManager::requireAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$cart_items = $input['cart_items'] ?? [];
$payment_method = $input['payment_method'] ?? 'cash';
$payment_amount = $input['payment_amount'] ?? null;
$change_amount = $input['change_amount'] ?? null;

if (empty($cart_items)) {
    echo json_encode(['success' => false, 'error' => 'Cart is empty']);
    exit;
}

$current_user = SessionManager::getUser();
$sale = new Sale();

$result = $sale->createTransaction(
    $current_user['id'],
    $cart_items,
    null, // customer_name
    null, // customer_phone
    $payment_method,
    $payment_amount,
    $change_amount
);

if ($result['success']) {
    // Get transaction details for receipt
    $transaction = $sale->getTransactionById($result['transaction_id']);
    
    echo json_encode([
        'success' => true,
        'transaction' => [
            'transaction_id' => $result['transaction_id'],
            'transaction_number' => $result['transaction_number'],
            'total_amount' => number_format($result['total_amount'], 2),
            'payment_method' => $transaction['payment_method'],
            'payment_amount' => $payment_amount,
            'change_amount' => $change_amount
        ]
    ]);
} else {
    echo json_encode([
        'success' => false,
        'error' => $result['error']
    ]);
}
?>
