<?php
/**
 * DJ Cheenee's Fashion Boutique - Export Sales Data to CSV
 */

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';

SessionManager::requireAdmin();

$db = getDbConnection();

// Get filter parameters
$start_date = $_GET['start_date'] ?? date('Y-m-d');
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$payment_method = $_GET['payment_method'] ?? '';
$cashier_id = $_GET['cashier_id'] ?? '';

// Build query with filters
$query = "SELECT 
    st.transaction_number,
    st.created_at,
    u.full_name as cashier_name,
    st.customer_name,
    st.customer_phone,
    st.payment_method,
    st.subtotal,
    st.discount_amount,
    st.total_amount,
    st.amount_received,
    st.change_amount,
    st.payment_status,
    COUNT(sti.id) as item_count
FROM sales_transactions st
JOIN users u ON st.user_id = u.id
LEFT JOIN sales_transaction_items sti ON st.id = sti.transaction_id
WHERE DATE(st.created_at) BETWEEN :start_date AND :end_date";

$params = [
    ':start_date' => $start_date,
    ':end_date' => $end_date
];

if ($payment_method) {
    $query .= " AND st.payment_method = :payment_method";
    $params[':payment_method'] = $payment_method;
}

if ($cashier_id) {
    $query .= " AND st.user_id = :cashier_id";
    $params[':cashier_id'] = $cashier_id;
}

$query .= " GROUP BY st.id ORDER BY st.created_at DESC";

$stmt = $db->prepare($query);
foreach ($params as $param => $value) {
    $stmt->bindValue($param, $value);
}
$stmt->execute();
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Set headers for CSV download
$filename = 'DJ-Cheenee-Sales-Report-' . $start_date . '-to-' . $end_date . '.csv';
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');

// Open output stream
$output = fopen('php://output', 'w');

// Write CSV header
fputcsv($output, [
    'Transaction Number',
    'Date & Time',
    'Cashier',
    'Customer Name',
    'Customer Phone',
    'Payment Method',
    'Items Count',
    'Subtotal',
    'Discount Amount',
    'Total Amount',
    'Amount Received',
    'Change Given',
    'Payment Status'
]);

// Write data rows
foreach ($transactions as $transaction) {
    fputcsv($output, [
        $transaction['transaction_number'],
        $transaction['created_at'],
        $transaction['cashier_name'],
        $transaction['customer_name'] ?: 'Walk-in Customer',
        $transaction['customer_phone'] ?: 'N/A',
        strtoupper($transaction['payment_method']),
        $transaction['item_count'],
        number_format($transaction['subtotal'], 2),
        number_format($transaction['discount_amount'], 2),
        number_format($transaction['total_amount'], 2),
        number_format($transaction['amount_received'], 2),
        number_format($transaction['change_amount'], 2),
        strtoupper($transaction['payment_status'])
    ]);
}

// Add summary row
fputcsv($output, []); // Empty row
fputcsv($output, ['SUMMARY']);
fputcsv($output, [
    'Total Transactions',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    count($transactions)
]);

$total_revenue = array_sum(array_column($transactions, 'total_amount'));
$total_discount = array_sum(array_column($transactions, 'discount_amount'));

fputcsv($output, [
    'Total Revenue',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    number_format($total_revenue, 2)
]);

fputcsv($output, [
    'Total Discounts Given',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    number_format($total_discount, 2)
]);

fclose($output);
exit;
?>
