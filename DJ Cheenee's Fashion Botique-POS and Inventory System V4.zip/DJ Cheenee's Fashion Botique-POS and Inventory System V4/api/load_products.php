<?php
/**
 * DJ Cheenee's Fashion Boutique - Load Products API
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../classes/Product.php';

SessionManager::requireAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$category_id = $_GET['category_id'] ?? null;
$limit = $_GET['limit'] ?? 50;

$product = new Product();

if ($category_id) {
    $products = $product->searchProducts('', $category_id);
} else {
    $products = $product->getAllProducts($limit);
}

echo json_encode([
    'success' => true,
    'products' => $products
]);
?>
