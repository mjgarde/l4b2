<?php
/**
 * DJ Cheenee's Fashion Boutique - Product Variants API
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../classes/Product.php';

SessionManager::requireAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$product_id = $_GET['product_id'] ?? null;

if (!$product_id) {
    echo json_encode(['success' => false, 'error' => 'Product ID is required']);
    exit;
}

$product = new Product();
$variants = $product->getProductVariants($product_id);

echo json_encode([
    'success' => true,
    'variants' => $variants
]);
?>
