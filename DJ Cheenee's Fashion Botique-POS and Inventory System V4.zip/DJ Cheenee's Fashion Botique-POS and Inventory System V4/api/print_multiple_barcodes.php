<?php
/**
 * DJ Cheenee's Fashion Boutique - Multiple Barcode Printing API
 * Generates printable barcode labels for multiple product variants
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';

SessionManager::requireAuth();

header('Content-Type: text/html; charset=UTF-8');

if (!isset($_GET['variant_ids']) || empty($_GET['variant_ids'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Variant IDs are required']);
    exit;
}

$variant_ids = explode(',', $_GET['variant_ids']);
$variant_ids = array_map('intval', $variant_ids);
$variant_ids = array_filter($variant_ids, function($id) { return $id > 0; });

if (empty($variant_ids) || count($variant_ids) > 50) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid variant IDs or too many items (max 50)']);
    exit;
}

try {
    $db = getDbConnection();
    
    // Create placeholders for IN clause
    $placeholders = str_repeat('?,', count($variant_ids) - 1) . '?';
    
    // Get product variants
    $query = "SELECT p.name as product_name, pv.id, pv.barcode, pv.size, pv.color, pv.price, b.name as brand_name
              FROM product_variants pv
              JOIN products p ON pv.product_id = p.id
              LEFT JOIN brands b ON p.brand_id = b.id
              WHERE pv.id IN ($placeholders) AND pv.is_active = 1
              ORDER BY p.name, pv.size, pv.color";
    
    $stmt = $db->prepare($query);
    $stmt->execute($variant_ids);
    $variants = $stmt->fetchAll();
    
    if (empty($variants)) {
        http_response_code(404);
        echo json_encode(['error' => 'No product variants found']);
        exit;
    }
    
    // Get store name from system settings
    $store_query = "SELECT setting_value FROM system_settings WHERE setting_key = 'store_name'";
    $store_stmt = $db->prepare($store_query);
    $store_stmt->execute();
    $store_name = $store_stmt->fetchColumn() ?: "DJ Cheenee's Fashion Boutique";
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    exit;
}

// No longer using custom pattern - will use JsBarcode library for proper Code 128 encoding

// Get quantity per barcode
$quantity_per = isset($_GET['quantity_per']) ? max(1, min(10, intval($_GET['quantity_per']))) : 1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multiple Barcode Labels - DJ Cheenee's Fashion Boutique</title>
    <!-- JsBarcode Library for proper Code 128 encoding -->
    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
    <style>
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
            .page-break { page-break-after: always; }
            
            /* Force backgrounds and colors to print */
            * {
                -webkit-print-color-adjust: exact !important;
                color-adjust: exact !important;
                print-color-adjust: exact !important;
            }
            
            .bar.black { 
                background: #000000 !important; 
                background-color: #000000 !important;
                border: 1px solid #000000 !important;
            }
        }
        
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #f5f5f5;
        }
        
        .barcode-label {
            width: 4in;
            height: 2in;
            border: 2px solid #000;
            margin: 10px;
            padding: 8px;
            background: white;
            display: inline-block;
            text-align: center;
            box-sizing: border-box;
        }
        
        .store-name {
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 4px;
            text-transform: uppercase;
        }
        
        .product-name {
            font-size: 11px;
            margin-bottom: 4px;
            font-weight: bold;
            line-height: 1.2;
            height: 26px;
            overflow: hidden;
        }
        
        .variant-info {
            font-size: 9px;
            margin-bottom: 6px;
            color: #666;
        }
        
        .barcode {
            margin: 6px 0;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .barcode svg {
            max-width: 100%;
            height: 45px;
        }
        
        .price {
            font-size: 14px;
            font-weight: bold;
            margin-top: 4px;
        }
        
        .controls {
            margin-bottom: 20px;
            padding: 15px;
            background: white;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .btn {
            padding: 8px 16px;
            margin: 5px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        
        .btn-primary {
            background: #007bff;
            color: white;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn:hover {
            opacity: 0.8;
        }
        
        input[type="number"] {
            width: 60px;
            padding: 4px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        
        .summary {
            background: #e9f7ef;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="no-print controls">
        <h3>Multiple Barcode Labels</h3>
        <div class="summary">
            <strong><?php echo count($variants); ?></strong> different products, 
            <strong><?php echo $quantity_per; ?></strong> label(s) each = 
            <strong><?php echo count($variants) * $quantity_per; ?></strong> total labels
        </div>
        <div>
            <label>Quantity per product: </label>
            <input type="number" id="quantityInput" value="<?php echo $quantity_per; ?>" min="1" max="10">
            <button class="btn btn-secondary" onclick="updateQuantity()">Update</button>
            <button class="btn btn-primary" onclick="window.print()">
                <i class="fas fa-print"></i> Print All Labels
            </button>
            <button class="btn btn-secondary" onclick="window.close()">Close</button>
        </div>
    </div>

    <div class="labels-container">
        <?php 
        $label_count = 0;
        foreach ($variants as $variant):
            for ($i = 0; $i < $quantity_per; $i++): 
                if ($label_count > 0 && $label_count % 8 == 0) echo '<div class="page-break"></div>';
                $label_count++;
        ?>
        <div class="barcode-label">
            <div class="store-name"><?php echo htmlspecialchars($store_name); ?></div>
            
            <div class="product-name">
                <?php echo htmlspecialchars($variant['product_name']); ?>
                <?php if ($variant['brand_name']): ?>
                    <br><small><?php echo htmlspecialchars($variant['brand_name']); ?></small>
                <?php endif; ?>
            </div>
            
            <div class="variant-info">
                <?php if ($variant['size']): ?>
                    Size: <?php echo htmlspecialchars($variant['size']); ?> | 
                <?php endif; ?>
                <?php if ($variant['color']): ?>
                    Color: <?php echo htmlspecialchars($variant['color']); ?>
                <?php endif; ?>
            </div>
            
            <div class="barcode">
                <svg class="barcode-svg" data-barcode="<?php echo htmlspecialchars($variant['barcode']); ?>"></svg>
            </div>
            
            <div class="price">₱<?php echo number_format($variant['price'], 2); ?></div>
        </div>
        <?php 
            endfor;
        endforeach; 
        ?>
    </div>

    <script>
        // Generate Code 128 barcodes using JsBarcode
        window.addEventListener('load', function() {
            // Generate barcode for each label
            const barcodeSvgs = document.querySelectorAll('.barcode-svg');
            barcodeSvgs.forEach(function(svg) {
                const barcodeValue = svg.getAttribute('data-barcode');
                try {
                    JsBarcode(svg, barcodeValue, {
                        format: "CODE128",
                        width: 2,
                        height: 45,
                        displayValue: true,
                        fontSize: 11,
                        margin: 0,
                        textMargin: 2,
                        fontOptions: "bold",
                        font: "Arial"
                    });
                } catch (error) {
                    console.error('Error generating barcode:', error);
                    // Fallback: display barcode as text
                    svg.innerHTML = '<text style="font-size: 11px; font-weight: bold;">' + barcodeValue + '</text>';
                }
            });
            
            // Auto-focus print dialog when ready
            setTimeout(function() {
                if (window.location.search.includes('autoprint=1')) {
                    window.print();
                }
            }, 500);
        });

        function updateQuantity() {
            const quantity = document.getElementById('quantityInput').value;
            const url = new URL(window.location);
            url.searchParams.set('quantity_per', quantity);
            window.location = url.toString();
        }
    </script>
</body>
</html>
