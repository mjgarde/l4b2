<?php
/**
 * DJ Cheenee's Fashion Boutique - Print Receipt API
 */

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';

SessionManager::requireAuth();

if (!isset($_GET['id'])) {
    echo "Receipt ID is required";
    exit;
}

$transaction_id = $_GET['id'];
$db = getDbConnection();

try {
    // Get transaction details
    $stmt = $db->prepare("
        SELECT st.*, u.full_name as cashier_name
        FROM sales_transactions st
        JOIN users u ON st.user_id = u.id
        WHERE st.id = :id
    ");
    $stmt->bindParam(':id', $transaction_id);
    $stmt->execute();
    $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$transaction) {
        echo "Transaction not found";
        exit;
    }

    // Get system settings
    $stmt = $db->prepare("SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN ('store_name', 'receipt_footer')");
    $stmt->execute();
    $settings_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $settings = [];
    foreach ($settings_data as $setting) {
        $settings[$setting['setting_key']] = $setting['setting_value'];
    }
    
    $store_name = $settings['store_name'] ?? 'DJ Cheenee\'s Fashion Boutique';
    $receipt_footer = $settings['receipt_footer'] ?? 'Thank you for shopping with us!';

    // Get transaction items
    $stmt = $db->prepare("
        SELECT sti.*, p.name as product_name, pv.size, pv.color, pv.barcode
        FROM sales_transaction_items sti
        JOIN product_variants pv ON sti.product_variant_id = pv.id
        JOIN products p ON pv.product_id = p.id
        WHERE sti.transaction_id = :transaction_id
        ORDER BY sti.id
    ");
    $stmt->bindParam(':transaction_id', $transaction_id);
    $stmt->execute();
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt - <?php echo htmlspecialchars($transaction['transaction_number']); ?></title>
    <style>
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
        }
        
        body {
            font-family: 'Courier New', monospace;
            font-size: 12px;
            margin: 20px;
            background: white;
        }
        
        .receipt {
            max-width: 300px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border: 1px solid #ddd;
        }
        
        .receipt-header {
            text-align: center;
            border-bottom: 2px dashed #333;
            padding-bottom: 15px;
            margin-bottom: 15px;
        }
        
        .store-name {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .receipt-info {
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px dashed #333;
        }
        
        .receipt-info div {
            display: flex;
            justify-content: space-between;
            margin-bottom: 3px;
        }
        
        .items-table {
            width: 100%;
            margin-bottom: 15px;
            border-bottom: 1px dashed #333;
            padding-bottom: 10px;
        }
        
        .item-row {
            display: flex;
            flex-direction: column;
            margin-bottom: 8px;
            padding-bottom: 5px;
            border-bottom: 1px dotted #ccc;
        }
        
        .item-name {
            font-weight: bold;
            margin-bottom: 2px;
        }
        
        .item-details {
            display: flex;
            justify-content: space-between;
            font-size: 10px;
            color: #666;
        }
        
        .item-price {
            display: flex;
            justify-content: space-between;
            margin-top: 2px;
        }
        
        .totals {
            margin-bottom: 15px;
        }
        
        .totals div {
            display: flex;
            justify-content: space-between;
            margin-bottom: 3px;
        }
        
        .total-line {
            border-top: 2px solid #333;
            padding-top: 5px;
            font-weight: bold;
            font-size: 14px;
        }
        
        .receipt-footer {
            text-align: center;
            border-top: 2px dashed #333;
            padding-top: 10px;
            font-size: 10px;
        }
        
        .no-print {
            text-align: center;
            margin: 20px 0;
        }
        
        .no-print button {
            padding: 10px 20px;
            margin: 0 10px;
            border: none;
            background: #6c5ce7;
            color: white;
            cursor: pointer;
            border-radius: 5px;
        }
        
        .no-print button:hover {
            background: #5a4fcf;
        }
    </style>
</head>
<body>
    <div class="no-print">
        <button onclick="window.print()">🖨️ Print Receipt</button>
        <button onclick="window.close()">✕ Close</button>
    </div>

    <div class="receipt">
        <div class="receipt-header">
            <div class="store-name"><?php echo strtoupper(htmlspecialchars($store_name)); ?></div>
            <div>Fashion Boutique</div>
        </div>

        <div class="receipt-info">
            <div>
                <span>Receipt #:</span>
                <span><?php echo htmlspecialchars($transaction['transaction_number']); ?></span>
            </div>
            <div>
                <span>Date:</span>
                <span><?php echo date('M d, Y h:i A', strtotime($transaction['created_at'])); ?></span>
            </div>
            <div>
                <span>Cashier:</span>
                <span><?php echo htmlspecialchars($transaction['cashier_name']); ?></span>
            </div>
            <?php if ($transaction['customer_name']): ?>
            <div>
                <span>Customer:</span>
                <span><?php echo htmlspecialchars($transaction['customer_name']); ?></span>
            </div>
            <?php endif; ?>
        </div>

        <div class="items-table">
            <?php foreach ($items as $item): ?>
            <div class="item-row">
                <div class="item-name"><?php echo htmlspecialchars($item['product_name']); ?></div>
                <div class="item-details">
                    <span>
                        <?php if ($item['size']): ?>Size: <?php echo htmlspecialchars($item['size']); ?><?php endif; ?>
                        <?php if ($item['color']): ?> | Color: <?php echo htmlspecialchars($item['color']); ?><?php endif; ?>
                    </span>
                    <span>Barcode: <?php echo htmlspecialchars($item['barcode']); ?></span>
                </div>
                <div class="item-price">
                    <span><?php echo $item['quantity']; ?> x ₱<?php echo number_format($item['unit_price'], 2); ?></span>
                    <span>₱<?php echo number_format($item['total_price'], 2); ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="totals">
            <?php if ($transaction['discount_amount'] > 0): ?>
            <div>
                <span>Discount:</span>
                <span>-₱<?php echo number_format($transaction['discount_amount'], 2); ?></span>
            </div>
            <?php endif; ?>
            <div class="total-line">
                <span>TOTAL:</span>
                <span>₱<?php echo number_format($transaction['total_amount'], 2); ?></span>
            </div>
            <div style="margin-top: 10px;">
                <span>Payment:</span>
                <span><?php echo strtoupper($transaction['payment_method']); ?></span>
            </div>
            <?php if (isset($transaction['amount_received']) && $transaction['amount_received']): ?>
            <div>
                <span>Amount Received:</span>
                <span>₱<?php echo number_format($transaction['amount_received'], 2); ?></span>
            </div>
            <?php if (isset($transaction['change_amount']) && $transaction['change_amount']): ?>
            <div>
                <span>Change:</span>
                <span>₱<?php echo number_format($transaction['change_amount'], 2); ?></span>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="receipt-footer">
            <?php echo htmlspecialchars($receipt_footer); ?>
            <br><br>
            <small>This serves as your official receipt</small>
        </div>
    </div>

    <script>
        // Auto-print when opened in new window
        if (window.location.search.includes('auto_print=1')) {
            window.onload = function() {
                setTimeout(() => {
                    window.print();
                }, 500);
            };
        }
    </script>
</body>
</html>
