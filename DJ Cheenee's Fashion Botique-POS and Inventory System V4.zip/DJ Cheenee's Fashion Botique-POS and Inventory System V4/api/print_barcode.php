<?php
/**
 * DJ Cheenee's Fashion Boutique - Barcode Printing API
 * Generates printable barcode labels for product variants
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';

SessionManager::requireAuth();

header('Content-Type: text/html; charset=UTF-8');

if (!isset($_GET['variant_id']) && !isset($_GET['barcode'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Variant ID or barcode is required']);
    exit;
}

try {
    $db = getDbConnection();
    
    if (isset($_GET['variant_id'])) {
        // Get product variant by ID
        $query = "SELECT p.name as product_name, pv.barcode, pv.size, pv.color, pv.price, b.name as brand_name
                  FROM product_variants pv
                  JOIN products p ON pv.product_id = p.id
                  LEFT JOIN brands b ON p.brand_id = b.id
                  WHERE pv.id = :variant_id AND pv.is_active = 1";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':variant_id', $_GET['variant_id']);
    } else {
        // Get product variant by barcode
        $query = "SELECT p.name as product_name, pv.barcode, pv.size, pv.color, pv.price, b.name as brand_name
                  FROM product_variants pv
                  JOIN products p ON pv.product_id = p.id
                  LEFT JOIN brands b ON p.brand_id = b.id
                  WHERE pv.barcode = :barcode AND pv.is_active = 1";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':barcode', $_GET['barcode']);
    }
    
    $stmt->execute();
    $variant = $stmt->fetch();
    
    if (!$variant) {
        http_response_code(404);
        echo json_encode(['error' => 'Product variant not found']);
        exit;
    }
    
    // Get store name from system settings
    $store_query = "SELECT setting_value FROM system_settings WHERE setting_key = 'store_name'";
    $store_stmt = $db->prepare($store_query);
    $store_stmt->execute();
    $store_name = $store_stmt->fetchColumn() ?: "DJ Cheenee's Fashion Boutique";
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    exit;
}

// No longer using custom pattern - will use JsBarcode library for proper Code 128 encoding

// Get quantity to print
$quantity = isset($_GET['quantity']) ? max(1, min(50, intval($_GET['quantity']))) : 1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barcode Label - <?php echo htmlspecialchars($variant['barcode']); ?></title>
    <!-- JsBarcode Library for proper Code 128 encoding -->
    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
    <style>
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
            .page-break { page-break-after: always; }
            
            /* Force backgrounds and colors to print */
            * {
                -webkit-print-color-adjust: exact !important;
                color-adjust: exact !important;
                print-color-adjust: exact !important;
            }
            
            .bar.black { 
                background: #000000 !important; 
                background-color: #000000 !important;
                border: 1px solid #000000 !important;
            }
        }
        
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #f5f5f5;
        }
        
        .barcode-label {
            width: 4in;
            height: 2in;
            border: 2px solid #000;
            margin: 10px;
            padding: 8px;
            background: white;
            display: inline-block;
            text-align: center;
            box-sizing: border-box;
        }
        
        .store-name {
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 4px;
            text-transform: uppercase;
        }
        
        .product-name {
            font-size: 11px;
            margin-bottom: 4px;
            font-weight: bold;
            line-height: 1.2;
            height: 26px;
            overflow: hidden;
        }
        
        .variant-info {
            font-size: 9px;
            margin-bottom: 6px;
            color: #666;
        }
        
        .barcode {
            margin: 6px 0;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .barcode svg {
            max-width: 100%;
            height: 45px;
        }
        
        .price {
            font-size: 14px;
            font-weight: bold;
            margin-top: 4px;
        }
        
        .controls {
            margin-bottom: 20px;
            padding: 15px;
            background: white;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .btn {
            padding: 8px 16px;
            margin: 5px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        
        .btn-primary {
            background: #007bff;
            color: white;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn:hover {
            opacity: 0.8;
        }
        
        input[type="number"] {
            width: 60px;
            padding: 4px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="no-print controls">
        <h3>Barcode Label Preview</h3>
        <div>
            <label>Quantity: </label>
            <input type="number" id="quantityInput" value="<?php echo $quantity; ?>" min="1" max="50">
            <button class="btn btn-secondary" onclick="updateQuantity()">Update</button>
            <button class="btn btn-primary" onclick="window.print()">
                <i class="fas fa-print"></i> Print Labels
            </button>
            <button class="btn btn-secondary" onclick="window.close()">Close</button>
        </div>
    </div>

    <div class="labels-container">
        <?php 
        for ($i = 0; $i < $quantity; $i++): 
            if ($i > 0 && $i % 4 == 0) echo '<div class="page-break"></div>';
        ?>
        <div class="barcode-label">
            <div class="store-name"><?php echo htmlspecialchars($store_name); ?></div>
            
            <div class="product-name">
                <?php echo htmlspecialchars($variant['product_name']); ?>
                <?php if ($variant['brand_name']): ?>
                    <br><small><?php echo htmlspecialchars($variant['brand_name']); ?></small>
                <?php endif; ?>
            </div>
            
            <div class="variant-info">
                <?php if ($variant['size']): ?>
                    Size: <?php echo htmlspecialchars($variant['size']); ?> | 
                <?php endif; ?>
                <?php if ($variant['color']): ?>
                    Color: <?php echo htmlspecialchars($variant['color']); ?>
                <?php endif; ?>
            </div>
            
            <div class="barcode">
                <svg class="barcode-svg-<?php echo $i; ?>"></svg>
            </div>
            
            <div class="price">₱<?php echo number_format($variant['price'], 2); ?></div>
        </div>
        <?php endfor; ?>
    </div>

    <script>
        // Generate Code 128 barcodes using JsBarcode
        window.addEventListener('load', function() {
            const barcodeValue = '<?php echo addslashes($variant['barcode']); ?>';
            const quantity = <?php echo $quantity; ?>;
            
            // Generate barcode for each label
            for (let i = 0; i < quantity; i++) {
                try {
                    JsBarcode('.barcode-svg-' + i, barcodeValue, {
                        format: "CODE128",
                        width: 2,
                        height: 45,
                        displayValue: true,
                        fontSize: 11,
                        margin: 0,
                        textMargin: 2,
                        fontOptions: "bold",
                        font: "Arial"
                    });
                } catch (error) {
                    console.error('Error generating barcode:', error);
                    // Fallback: display barcode as text
                    document.querySelector('.barcode-svg-' + i).innerHTML = 
                        '<text style="font-size: 11px; font-weight: bold;">' + barcodeValue + '</text>';
                }
            }
            
            // Auto-focus print dialog when ready
            setTimeout(function() {
                if (window.location.search.includes('autoprint=1')) {
                    window.print();
                }
            }, 500);
        });

        function updateQuantity() {
            const quantity = document.getElementById('quantityInput').value;
            const url = new URL(window.location);
            url.searchParams.set('quantity', quantity);
            window.location = url.toString();
        }
    </script>
</body>
</html>
