<?php
/**
 * Test API endpoint to debug product details issues
 */

// Start output buffering and error handling
ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Set content type first
header('Content-Type: application/json');

try {
    // Include dependencies
    require_once __DIR__ . '/../config/database.php';
    require_once __DIR__ . '/../config/session.php';
    
    // Clear any unwanted output
    ob_clean();
    
    // Check if user is logged in
    if (!SessionManager::isLoggedIn()) {
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit;
    }
    
    if (!isset($_GET['id']) || empty($_GET['id'])) {
        echo json_encode(['success' => false, 'message' => 'Product ID is required']);
        exit;
    }
    
    $product_id = $_GET['id'];
    $db = getDbConnection();
    
    // Check database connection
    if (!$db) {
        echo json_encode([
            'success' => false,
            'message' => 'Database connection failed'
        ]);
        exit;
    }
    
    // Simple query to test
    $query = "SELECT p.*, c.name as category_name, b.name as brand_name
              FROM products p 
              LEFT JOIN categories c ON p.category_id = c.id
              LEFT JOIN brands b ON p.brand_id = b.id
              WHERE p.id = :product_id AND p.is_active = 1";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
    $stmt->execute();
    
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($product) {
        // Get variant data separately
        $variant_query = "SELECT COUNT(*) as variant_count, 
                                 COALESCE(SUM(stock_quantity), 0) as total_stock,
                                 MIN(price) as min_price,
                                 MAX(price) as max_price
                          FROM product_variants 
                          WHERE product_id = :product_id AND is_active = 1";
        
        $variant_stmt = $db->prepare($variant_query);
        $variant_stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
        $variant_stmt->execute();
        
        $variant_data = $variant_stmt->fetch(PDO::FETCH_ASSOC);
        
        // Merge the data
        $product = array_merge($product, $variant_data);
        
        echo json_encode([
            'success' => true,
            'product' => $product
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Product not found'
        ]);
    }
    
} catch (Exception $e) {
    // Clear output buffer
    ob_clean();
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage(),
        'debug_info' => [
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ]
    ]);
}
?>
