<?php
/**
 * API endpoint to get product details
 */

// Suppress any HTML output errors
ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';

// Clear any output that might have been generated
ob_clean();

// Check if user is logged in
if (!SessionManager::isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => 'Product ID is required']);
    exit;
}

$product_id = $_GET['id'];
$db = getDbConnection();

// Check if database connection is successful
if (!$db) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed'
    ]);
    exit;
}

try {
    // Get product details with category and brand names (simplified query)
    $query = "SELECT p.*, c.name as category_name, b.name as brand_name
              FROM products p 
              LEFT JOIN categories c ON p.category_id = c.id
              LEFT JOIN brands b ON p.brand_id = b.id
              WHERE p.id = :product_id AND p.is_active = 1";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
    $stmt->execute();
    
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($product) {
        // Get variant data separately to avoid GROUP BY issues
        $variant_query = "SELECT COUNT(*) as variant_count, 
                                 COALESCE(SUM(stock_quantity), 0) as total_stock,
                                 MIN(price) as min_price,
                                 MAX(price) as max_price
                          FROM product_variants 
                          WHERE product_id = :product_id AND is_active = 1";
        
        $variant_stmt = $db->prepare($variant_query);
        $variant_stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
        $variant_stmt->execute();
        
        $variant_data = $variant_stmt->fetch(PDO::FETCH_ASSOC);
        
        // Merge the data
        $product = array_merge($product, $variant_data);
    }
    
    if ($product) {
        echo json_encode([
            'success' => true,
            'product' => $product
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Product not found'
        ]);
    }
} catch (Exception $e) {
    // Clear any output buffer
    ob_clean();
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage(),
        'error_details' => [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ]
    ]);
}
?>
